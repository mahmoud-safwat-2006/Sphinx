import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'package:sphinx/core/constants/app_colors.dart';
import 'package:sphinx/core/components/screen_header.dart';
import 'package:sphinx/core/utils/responsive_helper.dart';
import 'package:sphinx/l10n/app_localizations.dart';
import '../cubit/branch_cubit.dart';
import '../../data/models/branch_model.dart';
import '../widgets/branch_details_panel.dart';

class BranchesManagementScreen extends StatefulWidget {
  const BranchesManagementScreen({super.key});

  @override
  State<BranchesManagementScreen> createState() =>
      _BranchesManagementScreenState();
}

class _BranchesManagementScreenState extends State<BranchesManagementScreen> {
  @override
  void initState() {
    super.initState();
    context.read<BranchCubit>().loadBranches();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final isArabic = l10n.localeName == 'ar';

    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.symmetric(
                  horizontal: ResponsiveHelper.isMobile(context) ? 16 : 32,
                  vertical: 8),
              child: Row(
                children: [
                  Expanded(
                    child: ScreenHeader(
                      title: isArabic ? 'إدارة الفروع' : 'Branches',
                      icon: LucideIcons.building2,
                      subtitle:
                          isArabic ? 'إضافة وتعديل الفروع' : 'Manage branches',
                    ),
                  ),
                  ElevatedButton.icon(
                    onPressed: () => _showAddBranchDialog(context),
                    icon: const Icon(LucideIcons.plus, size: 18),
                    label: Text(isArabic ? 'إضافة فرع' : 'Add Branch'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primaryColor,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: BlocBuilder<BranchCubit, BranchState>(
                builder: (context, state) {
                  if (state.isLoading) {
                    return const Center(
                      child: CircularProgressIndicator(
                          color: AppColors.primaryColor),
                    );
                  }

                  if (state.branches.isEmpty) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(LucideIcons.building2,
                              size: 48,
                              color: AppColors.mutedColor.withOpacity(0.4)),
                          const SizedBox(height: 12),
                          Text(
                            isArabic ? 'لا يوجد فروع' : 'No branches found',
                            style: TextStyle(
                                color: AppColors.mutedColor, fontSize: 14),
                          ),
                        ],
                      ),
                    );
                  }

                  return ListView.builder(
                    padding: EdgeInsets.symmetric(
                        horizontal:
                            ResponsiveHelper.isMobile(context) ? 16 : 32,
                        vertical: 8),
                    itemCount: state.branches.length + 1,
                    itemBuilder: (context, index) {
                      if (index == 0) {
                        return _buildAllBranchesCard(context, isArabic);
                      }
                      final branch = state.branches[index - 1];
                      return _buildBranchCard(context, branch, isArabic);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBranchCard(BuildContext context, Branch branch, bool isArabic) {
    final selectedId = context.read<BranchCubit>().state.selectedBranchId;
    final isSelected = selectedId == branch.id;

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isSelected ? AppColors.primaryColor : AppColors.borderColor,
          width: isSelected ? 2 : 1,
        ),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => _showStatistics(context, branch: branch),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: isSelected
                      ? AppColors.primaryColor.withOpacity(0.2)
                      : AppColors.primaryColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  branch.isMainBranch ? LucideIcons.star : LucideIcons.store,
                  color: AppColors.primaryColor,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            branch.name,
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        if (branch.isMainBranch) ...[
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: AppColors.accentGold.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              isArabic ? 'رئيسي' : 'Main',
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                color: AppColors.accentGold,
                              ),
                            ),
                          ),
                        ],
                        if (isSelected) ...[
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: AppColors.primaryColor.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              isArabic ? 'محدد' : 'Selected',
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                color: AppColors.primaryColor,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      [
                        if (branch.address.isNotEmpty) branch.address,
                        if (branch.phone.isNotEmpty) branch.phone,
                      ].join(' • '),
                      style: TextStyle(
                        fontSize: 12,
                        color: AppColors.mutedColor,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              Icon(LucideIcons.chevronRight,
                  size: 16, color: AppColors.mutedColor),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAllBranchesCard(BuildContext context, bool isArabic) {
    final l10n = AppLocalizations.of(context);
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppColors.primaryColor.withOpacity(.12),
            AppColors.secondaryColor.withOpacity(.06),
          ],
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.primaryColor.withOpacity(.3)),
      ),
      child: ListTile(
        minTileHeight: 72,
        onTap: () => _showStatistics(context),
        leading: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Icon(
            LucideIcons.warehouse,
            color: AppColors.primaryColor,
          ),
        ),
        title: Text(
          l10n.allBranches,
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
        subtitle: Text(
          l10n.allBranchesReadOnly,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        trailing: Icon(
          isArabic ? LucideIcons.chevronLeft : LucideIcons.chevronRight,
          color: AppColors.primaryColor,
        ),
      ),
    );
  }

  Future<void> _showStatistics(
    BuildContext context, {
    Branch? branch,
  }) async {
    final aggregate = branch == null;
    if (ResponsiveHelper.isMobileOrTablet(context)) {
      await showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        useSafeArea: true,
        backgroundColor: Colors.transparent,
        builder: (sheetContext) => FractionallySizedBox(
          heightFactor: .9,
          child: ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
            child: BranchDetailsPanel(
              branch: branch,
              aggregate: aggregate,
              onClose: () => Navigator.pop(sheetContext),
            ),
          ),
        ),
      );
      return;
    }

    await showGeneralDialog<void>(
      context: context,
      barrierDismissible: true,
      barrierLabel: MaterialLocalizations.of(context).modalBarrierDismissLabel,
      barrierColor: Colors.black38,
      transitionDuration: const Duration(milliseconds: 220),
      pageBuilder: (dialogContext, _, __) => Align(
        alignment: AlignmentDirectional.centerEnd,
        child: ConstrainedBox(
          constraints: const BoxConstraints(minWidth: 460, maxWidth: 560),
          child: BranchDetailsPanel(
            branch: branch,
            aggregate: aggregate,
            onClose: () => Navigator.pop(dialogContext),
          ),
        ),
      ),
      transitionBuilder: (context, animation, _, child) => SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(.12, 0),
          end: Offset.zero,
        ).animate(
          CurvedAnimation(parent: animation, curve: Curves.easeOutCubic),
        ),
        child: FadeTransition(opacity: animation, child: child),
      ),
    );
  }

  // Kept temporarily for compatibility while branch edit/deactivate actions
  // move into the new responsive statistics panel.
  // ignore: unused_element
  void _showBranchDetails(BuildContext context, Branch branch, bool isArabic) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => DraggableScrollableSheet(
        initialChildSize: 0.5,
        minChildSize: 0.3,
        maxChildSize: 0.8,
        expand: false,
        builder: (ctx, scrollController) => SingleChildScrollView(
          controller: scrollController,
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppColors.borderColor,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Icon(
                    branch.isMainBranch ? LucideIcons.star : LucideIcons.store,
                    color: AppColors.primaryColor,
                    size: 24,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      branch.name,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              _buildDetailRow(
                isArabic ? 'العنوان' : 'Address',
                branch.address.isNotEmpty ? branch.address : '-',
                LucideIcons.mapPin,
                isArabic,
              ),
              _buildDetailRow(
                isArabic ? 'الهاتف' : 'Phone',
                branch.phone.isNotEmpty ? branch.phone : '-',
                LucideIcons.phone,
                isArabic,
              ),
              _buildDetailRow(
                isArabic ? 'النوع' : 'Type',
                branch.isMainBranch
                    ? (isArabic ? 'رئيسي' : 'Main')
                    : (isArabic ? 'فرعي' : 'Branch'),
                LucideIcons.building2,
                isArabic,
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () {
                        Navigator.pop(ctx);
                        _showEditBranchDialog(context, branch, isArabic);
                      },
                      icon: const Icon(LucideIcons.pencil, size: 16),
                      label: Text(isArabic ? 'تعديل' : 'Edit'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: AppColors.primaryColor,
                        side: const BorderSide(color: AppColors.primaryColor),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                  ),
                  if (!branch.isMainBranch) ...[
                    const SizedBox(width: 12),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {
                          Navigator.pop(ctx);
                          _confirmDeactivate(context, branch, isArabic);
                        },
                        icon: const Icon(LucideIcons.trash2, size: 16),
                        label: Text(isArabic ? 'تعطيل' : 'Deactivate'),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: AppColors.errorColor,
                          side: const BorderSide(color: AppColors.errorColor),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(
      String label, String value, IconData icon, bool isArabic) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Icon(icon, size: 16, color: AppColors.mutedColor),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 11,
                    color: AppColors.mutedColor,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showEditBranchDialog(
      BuildContext context, Branch branch, bool isArabic) {
    final nameController = TextEditingController(text: branch.name);
    final addressController = TextEditingController(text: branch.address);
    final phoneController = TextEditingController(text: branch.phone);

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(isArabic ? 'تعديل الفرع' : 'Edit Branch'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              decoration: InputDecoration(
                labelText: isArabic ? 'اسم الفرع' : 'Branch Name',
                border: const OutlineInputBorder(),
              ),
              autofocus: true,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: addressController,
              decoration: InputDecoration(
                labelText: isArabic ? 'العنوان' : 'Address',
                border: const OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: phoneController,
              decoration: InputDecoration(
                labelText: isArabic ? 'الهاتف' : 'Phone',
                border: const OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(isArabic ? 'إلغاء' : 'Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (nameController.text.trim().isEmpty) return;
              final branchCubit = context.read<BranchCubit>();
              final success = await branchCubit.updateBranch(
                branchId: branch.id,
                name: nameController.text.trim(),
                address: addressController.text.trim(),
                phone: phoneController.text.trim(),
              );
              if (ctx.mounted) Navigator.pop(ctx);
              if (success && context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(isArabic
                        ? 'تم تحديث الفرع بنجاح'
                        : 'Branch updated successfully'),
                    backgroundColor: Colors.green,
                  ),
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primaryColor,
              foregroundColor: Colors.white,
            ),
            child: Text(isArabic ? 'حفظ' : 'Save'),
          ),
        ],
      ),
    );
  }

  void _showAddBranchDialog(BuildContext context) {
    final nameController = TextEditingController();
    final addressController = TextEditingController();
    final phoneController = TextEditingController();
    final isArabic = AppLocalizations.of(context).localeName == 'ar';

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(isArabic ? 'إضافة فرع جديد' : 'Add New Branch'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              decoration: InputDecoration(
                labelText: isArabic ? 'اسم الفرع' : 'Branch Name',
                border: const OutlineInputBorder(),
              ),
              autofocus: true,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: addressController,
              decoration: InputDecoration(
                labelText: isArabic ? 'العنوان' : 'Address',
                border: const OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: phoneController,
              decoration: InputDecoration(
                labelText: isArabic ? 'الهاتف' : 'Phone',
                border: const OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(isArabic ? 'إلغاء' : 'Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (nameController.text.trim().isEmpty) return;
              final branchCubit = context.read<BranchCubit>();
              final id = await branchCubit.createBranch(
                name: nameController.text.trim(),
                address: addressController.text.trim(),
                phone: phoneController.text.trim(),
              );
              if (ctx.mounted) Navigator.pop(ctx);
              if (id != null && context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(isArabic
                        ? 'تم إنشاء الفرع بنجاح'
                        : 'Branch created successfully'),
                    backgroundColor: Colors.green,
                  ),
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primaryColor,
              foregroundColor: Colors.white,
            ),
            child: Text(isArabic ? 'إنشاء' : 'Create'),
          ),
        ],
      ),
    );
  }

  void _confirmDeactivate(BuildContext context, Branch branch, bool isArabic) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(isArabic ? 'تعطيل الفرع' : 'Deactivate Branch'),
        content: Text(
          isArabic
              ? 'هل أنت متأكد من تعطيل "${branch.name}"؟'
              : 'Are you sure you want to deactivate "${branch.name}"?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(isArabic ? 'إلغاء' : 'Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              final branchCubit = context.read<BranchCubit>();
              await branchCubit.deactivateBranch(branch.id);
              if (ctx.mounted) Navigator.pop(ctx);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.errorColor,
              foregroundColor: Colors.white,
            ),
            child: Text(isArabic ? 'تعطيل' : 'Deactivate'),
          ),
        ],
      ),
    );
  }
}
