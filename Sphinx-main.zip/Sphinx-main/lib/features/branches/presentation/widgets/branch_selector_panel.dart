import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../l10n/app_localizations.dart';
import '../../data/models/branch_model.dart';
import '../cubit/branch_cubit.dart';

class BranchSelectorPanel extends StatefulWidget {
  const BranchSelectorPanel({
    super.key,
    required this.onClose,
    this.showHandle = false,
  });

  final VoidCallback onClose;
  final bool showHandle;

  @override
  State<BranchSelectorPanel> createState() => _BranchSelectorPanelState();
}

class _BranchSelectorPanelState extends State<BranchSelectorPanel> {
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return Material(
      color: Colors.white,
      child: SafeArea(
        child: BlocBuilder<BranchCubit, BranchState>(
          builder: (context, state) {
            final branches = _filteredBranches(state.branches);
            return Column(
              children: [
                if (widget.showHandle) ...[
                  const SizedBox(height: 10),
                  Container(
                    width: 44,
                    height: 5,
                    decoration: BoxDecoration(
                      color: AppColors.borderColor,
                      borderRadius: BorderRadius.circular(3),
                    ),
                  ),
                ],
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 16, 12, 12),
                  child: Row(
                    children: [
                      Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                          color: AppColors.primaryColor.withOpacity(.09),
                          borderRadius: BorderRadius.circular(13),
                        ),
                        child: const Icon(
                          LucideIcons.building2,
                          color: AppColors.primaryColor,
                          size: 21,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              l10n.selectBranch,
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w800,
                                color: AppColors.textPrimary,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              state.isAllBranches
                                  ? l10n.allBranchesReadOnly
                                  : l10n.currentBranch,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 11,
                                color: AppColors.mutedColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        tooltip: MaterialLocalizations.of(context)
                            .closeButtonTooltip,
                        onPressed: widget.onClose,
                        icon: const Icon(LucideIcons.x, size: 20),
                      ),
                    ],
                  ),
                ),
                if (state.branches.length > 8)
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
                    child: TextField(
                      onChanged: (value) =>
                          setState(() => _query = value.trim().toLowerCase()),
                      decoration: InputDecoration(
                        hintText: l10n.searchBranches,
                        prefixIcon: const Icon(LucideIcons.search, size: 18),
                        isDense: true,
                        filled: true,
                        fillColor: AppColors.backgroundColor,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide:
                              const BorderSide(color: AppColors.borderColor),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide:
                              const BorderSide(color: AppColors.borderColor),
                        ),
                      ),
                    ),
                  ),
                const Divider(height: 1, color: AppColors.borderColor),
                Expanded(
                  child: state.isLoading && state.branches.isEmpty
                      ? const Center(child: CircularProgressIndicator())
                      : ListView(
                          padding: const EdgeInsets.all(16),
                          children: [
                            _ScopeTile(
                              icon: LucideIcons.warehouse,
                              title: l10n.allBranches,
                              subtitle: l10n.allBranchesReadOnly,
                              selected: state.isAllBranches,
                              onTap: () async {
                                await context.read<BranchCubit>().selectAll();
                                widget.onClose();
                              },
                            ),
                            const SizedBox(height: 8),
                            if (branches.isEmpty)
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 48),
                                child: Column(
                                  children: [
                                    Icon(
                                      LucideIcons.building2,
                                      size: 42,
                                      color:
                                          AppColors.mutedColor.withOpacity(.35),
                                    ),
                                    const SizedBox(height: 12),
                                    Text(
                                      l10n.noBranchesFound,
                                      style: const TextStyle(
                                        color: AppColors.mutedColor,
                                      ),
                                    ),
                                  ],
                                ),
                              )
                            else
                              ...branches.map(
                                (branch) => Padding(
                                  padding: const EdgeInsets.only(bottom: 8),
                                  child: _ScopeTile(
                                    icon: branch.isMainBranch
                                        ? LucideIcons.star
                                        : LucideIcons.store,
                                    title: branch.name,
                                    subtitle: branch.isMainBranch
                                        ? l10n.mainBranch
                                        : branch.address,
                                    selected:
                                        state.selectedBranchId == branch.id,
                                    onTap: () async {
                                      await context
                                          .read<BranchCubit>()
                                          .selectBranch(branch.id);
                                      widget.onClose();
                                    },
                                  ),
                                ),
                              ),
                          ],
                        ),
                ),
                if (state.error != null)
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    color: AppColors.errorColor.withOpacity(.08),
                    child: Text(
                      state.error == 'branchUnavailable'
                          ? l10n.branchUnavailable
                          : state.error!,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: AppColors.errorColor,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }

  List<Branch> _filteredBranches(List<Branch> branches) {
    if (_query.isEmpty) return branches;
    return branches
        .where(
          (branch) =>
              branch.name.toLowerCase().contains(_query) ||
              branch.address.toLowerCase().contains(_query) ||
              branch.phone.toLowerCase().contains(_query),
        )
        .toList();
  }
}

class _ScopeTile extends StatelessWidget {
  const _ScopeTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.selected,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      selected: selected,
      button: true,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          constraints: const BoxConstraints(minHeight: 64),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: selected
                ? AppColors.primaryColor.withOpacity(.07)
                : Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: selected ? AppColors.primaryColor : AppColors.borderColor,
              width: selected ? 1.5 : 1,
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: AppColors.primaryColor.withOpacity(.09),
                  borderRadius: BorderRadius.circular(11),
                ),
                child: Icon(icon, size: 19, color: AppColors.primaryColor),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight:
                            selected ? FontWeight.w800 : FontWeight.w600,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    if (subtitle.isNotEmpty) ...[
                      const SizedBox(height: 2),
                      Text(
                        subtitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 11,
                          color: AppColors.mutedColor,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(width: 8),
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 160),
                child: selected
                    ? const Icon(
                        LucideIcons.circleCheck,
                        key: ValueKey('selected'),
                        color: AppColors.primaryColor,
                        size: 21,
                      )
                    : const Icon(
                        LucideIcons.chevronRight,
                        key: ValueKey('unselected'),
                        color: AppColors.mutedColor,
                        size: 18,
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
