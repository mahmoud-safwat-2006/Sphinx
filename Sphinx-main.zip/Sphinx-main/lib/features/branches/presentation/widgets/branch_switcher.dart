import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'package:sphinx/core/constants/app_colors.dart';
import 'package:sphinx/core/utils/responsive_helper.dart';
import 'package:sphinx/l10n/app_localizations.dart';
import '../cubit/branch_cubit.dart';
import 'branch_selector_panel.dart';

/// Branch switcher dropdown for the app header.
/// Only visible to primary admins.
class BranchSwitcher extends StatelessWidget {
  const BranchSwitcher({super.key});

  static Future<void> showSelector(BuildContext context) async {
    final branchCubit = context.read<BranchCubit>();
    if (ResponsiveHelper.isMobileOrTablet(context)) {
      await showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        useSafeArea: true,
        backgroundColor: Colors.transparent,
        builder: (sheetContext) => BlocProvider.value(
          value: branchCubit,
          child: FractionallySizedBox(
            heightFactor: .78,
            child: ClipRRect(
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(24)),
              child: BranchSelectorPanel(
                showHandle: true,
                onClose: () => Navigator.pop(sheetContext),
              ),
            ),
          ),
        ),
      );
      return;
    }

    await showGeneralDialog<void>(
      context: context,
      barrierDismissible: true,
      barrierLabel: MaterialLocalizations.of(context).modalBarrierDismissLabel,
      barrierColor: Colors.black38,
      transitionDuration: const Duration(milliseconds: 220),
      pageBuilder: (dialogContext, _, __) => BlocProvider.value(
        value: branchCubit,
        child: Align(
          alignment: AlignmentDirectional.centerEnd,
          child: ConstrainedBox(
            constraints: const BoxConstraints(minWidth: 360, maxWidth: 420),
            child: BranchSelectorPanel(
              onClose: () => Navigator.pop(dialogContext),
            ),
          ),
        ),
      ),
      transitionBuilder: (context, animation, _, child) {
        final curved =
            CurvedAnimation(parent: animation, curve: Curves.easeOutCubic);
        return FadeTransition(
          opacity: curved,
          child: SlideTransition(
            position: Tween<Offset>(
              begin: const Offset(.12, 0),
              end: Offset.zero,
            ).animate(curved),
            child: child,
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return BlocBuilder<BranchCubit, BranchState>(
      builder: (context, state) {
        final branchCubit = context.read<BranchCubit>();
        if (!branchCubit.isPrimaryAdmin) return const SizedBox.shrink();

        final selectedIndex = state.branches
            .indexWhere((branch) => branch.id == state.selectedBranchId);
        final selected =
            selectedIndex == -1 ? null : state.branches[selectedIndex];
        final label = state.isAllBranches
            ? l10n.allBranches
            : selected?.name ?? l10n.selectBranch;
        final compact = ResponsiveHelper.isMobileOrTablet(context);

        return Tooltip(
          message: l10n.selectBranch,
          child: InkWell(
            onTap: () => showSelector(context),
            borderRadius: BorderRadius.circular(12),
            child: Container(
              height: 38,
              constraints: BoxConstraints(maxWidth: compact ? 132 : 220),
              margin: const EdgeInsets.symmetric(horizontal: 4),
              padding: const EdgeInsets.symmetric(horizontal: 10),
              decoration: BoxDecoration(
                color: compact ? Colors.white.withOpacity(.12) : Colors.white,
                borderRadius: BorderRadius.circular(12),
                border:
                    compact ? null : Border.all(color: AppColors.borderColor),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    state.isAllBranches
                        ? LucideIcons.warehouse
                        : LucideIcons.store,
                    size: 16,
                    color: compact ? Colors.white : AppColors.primaryColor,
                  ),
                  const SizedBox(width: 7),
                  Flexible(
                    child: Text(
                      label,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: compact ? 11 : 13,
                        fontWeight: FontWeight.w700,
                        color: compact ? Colors.white : AppColors.textPrimary,
                      ),
                    ),
                  ),
                  const SizedBox(width: 5),
                  Icon(
                    LucideIcons.chevronDown,
                    size: 14,
                    color: compact ? Colors.white70 : AppColors.mutedColor,
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
