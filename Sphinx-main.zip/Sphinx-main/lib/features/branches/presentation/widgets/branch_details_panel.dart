import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/di/dependency_injection.dart';
import '../../../../l10n/app_localizations.dart';
import '../../data/models/branch_model.dart';
import '../../data/models/branch_statistics.dart';
import '../../data/repositories/branch_repository.dart';

class BranchDetailsPanel extends StatefulWidget {
  const BranchDetailsPanel({
    super.key,
    required this.branch,
    required this.aggregate,
    required this.onClose,
  });

  final Branch? branch;
  final bool aggregate;
  final VoidCallback onClose;

  @override
  State<BranchDetailsPanel> createState() => _BranchDetailsPanelState();
}

class _BranchDetailsPanelState extends State<BranchDetailsPanel> {
  final _repository = getIt<BranchRepository>();
  int _days = 30;
  late Future<BranchStatistics> _statistics;
  late Future<List<BranchActivityItem>> _activity;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  void _reload() {
    final end = DateTime.now();
    final start = _days == 1
        ? DateTime(end.year, end.month, end.day)
        : end.subtract(Duration(days: _days));
    _statistics = _repository.getStatistics(
      branchId: widget.aggregate ? null : widget.branch!.id,
      start: start,
      end: end.add(const Duration(milliseconds: 1)),
    );
    _activity = _repository.getRecentActivity(
      branchId: widget.aggregate ? null : widget.branch!.id,
    );
  }

  void _selectDays(int value) {
    if (_days == value) return;
    setState(() {
      _days = value;
      _reload();
    });
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final title =
        widget.aggregate ? l10n.allBranches : widget.branch?.name ?? '';
    return Material(
      color: AppColors.backgroundColor,
      child: SafeArea(
        child: Column(
          children: [
            Container(
              color: Colors.white,
              padding: const EdgeInsets.fromLTRB(20, 14, 12, 14),
              child: Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: AppColors.primaryColor.withOpacity(.1),
                      borderRadius: BorderRadius.circular(13),
                    ),
                    child: Icon(
                      widget.aggregate
                          ? LucideIcons.warehouse
                          : widget.branch!.isMainBranch
                              ? LucideIcons.star
                              : LucideIcons.store,
                      color: AppColors.primaryColor,
                      size: 21,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 19,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        Text(
                          widget.aggregate
                              ? l10n.allBranchesReadOnly
                              : l10n.branchOverview,
                          style: const TextStyle(
                            fontSize: 11,
                            color: AppColors.mutedColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: widget.onClose,
                    icon: const Icon(LucideIcons.x),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(18),
                children: [
                  if (!widget.aggregate && widget.branch != null)
                    _BranchIdentity(branch: widget.branch!),
                  if (!widget.aggregate && widget.branch != null)
                    const SizedBox(height: 14),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      _RangeChip(
                        label: l10n.today,
                        selected: _days == 1,
                        onTap: () => _selectDays(1),
                      ),
                      _RangeChip(
                        label: l10n.last7Days,
                        selected: _days == 7,
                        onTap: () => _selectDays(7),
                      ),
                      _RangeChip(
                        label: l10n.last30Days,
                        selected: _days == 30,
                        onTap: () => _selectDays(30),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  FutureBuilder<BranchStatistics>(
                    future: _statistics,
                    builder: (context, snapshot) {
                      if (snapshot.connectionState != ConnectionState.done) {
                        return const SizedBox(
                          height: 260,
                          child: Center(child: CircularProgressIndicator()),
                        );
                      }
                      if (snapshot.hasError) {
                        return _ErrorCard(
                          message: snapshot.error.toString(),
                          onRetry: () => setState(_reload),
                        );
                      }
                      return _StatisticsGrid(statistics: snapshot.data!);
                    },
                  ),
                  const SizedBox(height: 18),
                  Text(
                    l10n.recentActivity,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 10),
                  FutureBuilder<List<BranchActivityItem>>(
                    future: _activity,
                    builder: (context, snapshot) {
                      if (snapshot.connectionState != ConnectionState.done) {
                        return const SizedBox(
                          height: 130,
                          child: Center(child: CircularProgressIndicator()),
                        );
                      }
                      if (snapshot.hasError) {
                        return _ErrorCard(
                          message: snapshot.error.toString(),
                          onRetry: () => setState(_reload),
                        );
                      }
                      final items = snapshot.data ?? const [];
                      if (items.isEmpty) {
                        return Container(
                          padding: const EdgeInsets.all(28),
                          alignment: Alignment.center,
                          decoration: _cardDecoration(),
                          child: const Icon(
                            LucideIcons.inbox,
                            color: AppColors.mutedColor,
                            size: 32,
                          ),
                        );
                      }
                      return Container(
                        decoration: _cardDecoration(),
                        child: Column(
                          children: [
                            for (var i = 0; i < items.length; i++) ...[
                              _ActivityTile(
                                item: items[i],
                                showBranch: widget.aggregate,
                              ),
                              if (i != items.length - 1)
                                const Divider(
                                  height: 1,
                                  indent: 58,
                                  color: AppColors.borderColor,
                                ),
                            ],
                          ],
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BranchIdentity extends StatelessWidget {
  const _BranchIdentity({required this.branch});

  final Branch branch;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: _cardDecoration(),
      child: Row(
        children: [
          const Icon(LucideIcons.mapPin,
              size: 18, color: AppColors.primaryColor),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              branch.address.isEmpty ? '-' : branch.address,
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
          ),
          const SizedBox(width: 10),
          const Icon(LucideIcons.phone, size: 16, color: AppColors.mutedColor),
          const SizedBox(width: 6),
          Text(
            branch.phone.isEmpty ? '-' : branch.phone,
            style: const TextStyle(color: AppColors.mutedColor),
          ),
        ],
      ),
    );
  }
}

class _StatisticsGrid extends StatelessWidget {
  const _StatisticsGrid({required this.statistics});

  final BranchStatistics statistics;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final metrics = [
      (
        l10n.netSales,
        statistics.netSales,
        LucideIcons.badgeDollarSign,
        AppColors.successColor,
        true
      ),
      (
        l10n.grossSales,
        statistics.grossSales,
        LucideIcons.trendingUp,
        AppColors.primaryColor,
        true
      ),
      (
        l10n.refunds,
        statistics.refunds,
        LucideIcons.rotateCcw,
        AppColors.errorColor,
        true
      ),
      (
        l10n.expensesLabel,
        statistics.expenses,
        LucideIcons.walletCards,
        AppColors.warningColor,
        true
      ),
      (
        l10n.estimatedProfit,
        statistics.estimatedProfit,
        LucideIcons.chartNoAxesCombined,
        AppColors.secondaryColor,
        true
      ),
      (
        l10n.transactions,
        statistics.transactionCount.toDouble(),
        LucideIcons.receiptText,
        AppColors.primaryColor,
        false
      ),
      (
        l10n.activeUsers,
        statistics.activeUserCount.toDouble(),
        LucideIcons.users,
        const Color(0xFF8B5CF6),
        false
      ),
      (
        l10n.openShifts,
        statistics.openShiftCount.toDouble(),
        LucideIcons.clock3,
        AppColors.accentGold,
        false
      ),
      (
        l10n.stockValue,
        statistics.stockRetailValue,
        LucideIcons.packageCheck,
        AppColors.successColor,
        true
      ),
      (
        l10n.stockHealth,
        (statistics.lowStockCount + statistics.outOfStockCount).toDouble(),
        LucideIcons.triangleAlert,
        AppColors.errorColor,
        false
      ),
    ];
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth >= 480
            ? (constraints.maxWidth - 12) / 2
            : constraints.maxWidth;
        return Wrap(
          spacing: 12,
          runSpacing: 12,
          children: [
            for (final metric in metrics)
              SizedBox(
                width: width,
                child: _MetricCard(
                  label: metric.$1,
                  value: metric.$5
                      ? metric.$2.toStringAsFixed(2)
                      : metric.$2.toInt().toString(),
                  icon: metric.$3,
                  color: metric.$4,
                ),
              ),
          ],
        );
      },
    );
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
  });

  final String label;
  final String value;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: _cardDecoration(),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: color.withOpacity(.1),
              borderRadius: BorderRadius.circular(11),
            ),
            child: Icon(icon, color: color, size: 19),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 11,
                    color: AppColors.mutedColor,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ActivityTile extends StatelessWidget {
  const _ActivityTile({required this.item, required this.showBranch});

  final BranchActivityItem item;
  final bool showBranch;

  String _buildTitle(AppLocalizations l10n) {
    return switch (item.type) {
      BranchActivityType.sale => l10n.activitySale,
      BranchActivityType.refund => l10n.activityRefund,
      BranchActivityType.expense => item.title.isEmpty ? l10n.expensesLabel : item.title,
      BranchActivityType.shift => item.isOpen == true
          ? l10n.activityShiftOpen(item.sessionNumber ?? 0)
          : l10n.activityShiftClosed(item.sessionNumber ?? 0),
    };
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final (icon, color) = switch (item.type) {
      BranchActivityType.sale => (LucideIcons.receipt, AppColors.successColor),
      BranchActivityType.refund => (
          LucideIcons.rotateCcw,
          AppColors.errorColor
        ),
      BranchActivityType.expense => (
          LucideIcons.walletCards,
          AppColors.warningColor
        ),
      BranchActivityType.shift => (LucideIcons.clock3, AppColors.primaryColor),
    };
    return ListTile(
      leading: CircleAvatar(
        backgroundColor: color.withOpacity(.1),
        child: Icon(icon, color: color, size: 18),
      ),
      title: Text(
        _buildTitle(l10n),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(fontWeight: FontWeight.w700),
      ),
      subtitle: Text(
        [
          if (showBranch && item.branchName.isNotEmpty) item.branchName,
          if (item.actor?.isNotEmpty == true) item.actor!,
          DateFormat('dd/MM/yyyy HH:mm').format(item.createdAt.toLocal()),
        ].join(' · '),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      trailing: item.amount == null
          ? null
          : Text(
              item.amount!.toStringAsFixed(2),
              style: TextStyle(fontWeight: FontWeight.w800, color: color),
            ),
    );
  }
}

class _RangeChip extends StatelessWidget {
  const _RangeChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return ChoiceChip(
      label: Text(label),
      selected: selected,
      onSelected: (_) => onTap(),
      selectedColor: AppColors.primaryColor.withOpacity(.12),
      side: BorderSide(
        color: selected ? AppColors.primaryColor : AppColors.borderColor,
      ),
      labelStyle: TextStyle(
        color: selected ? AppColors.primaryColor : AppColors.textPrimary,
        fontWeight: FontWeight.w700,
      ),
    );
  }
}

class _ErrorCard extends StatelessWidget {
  const _ErrorCard({required this.message, required this.onRetry});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: _cardDecoration(),
      child: Row(
        children: [
          const Icon(LucideIcons.circleAlert, color: AppColors.errorColor),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              message,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          IconButton(
            onPressed: onRetry,
            icon: const Icon(LucideIcons.refreshCw),
          ),
        ],
      ),
    );
  }
}

BoxDecoration _cardDecoration() => BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(15),
      border: Border.all(color: AppColors.borderColor),
    );
