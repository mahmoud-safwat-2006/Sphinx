import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../../../core/state/state_synchronizer.dart';
import '../../data/models/branch_model.dart';
import '../../domain/branch_scope.dart';

class BranchState {
  final List<Branch> branches;
  final BranchScope scope;
  final int selectionRevision;
  final bool isLoading;
  final String? error;

  const BranchState({
    this.branches = const [],
    this.scope = const BranchScope.uninitialized(),
    this.selectionRevision = 0,
    this.isLoading = false,
    this.error,
  });

  BranchState copyWith({
    List<Branch>? branches,
    BranchScope? scope,
    int? selectionRevision,
    bool? isLoading,
    String? error,
    bool clearError = false,
  }) {
    return BranchState(
      branches: branches ?? this.branches,
      scope: scope ?? this.scope,
      selectionRevision: selectionRevision ?? this.selectionRevision,
      isLoading: isLoading ?? this.isLoading,
      error: clearError ? null : (error ?? this.error),
    );
  }

  String? get selectedBranchId => scope.branchId;
  bool get isAllBranches => scope.isAll;
}

class BranchCubit extends Cubit<BranchState> {
  BranchCubit() : super(const BranchState());

  /// The branch_id of the currently logged-in user.
  /// null means the user is a primary admin with full visibility.
  String? _userBranchId;

  /// The user's is_primary_admin flag.
  bool _isPrimaryAdmin = false;

  /// Initialize from the current user's profile data.
  void init({required String? userBranchId, required bool isPrimaryAdmin}) {
    _userBranchId = userBranchId;
    _isPrimaryAdmin = isPrimaryAdmin;

    final BranchScope nextScope;
    String? configurationError;
    if (!_isPrimaryAdmin && _userBranchId != null) {
      nextScope = BranchScope.branch(_userBranchId!);
    } else if (_isPrimaryAdmin) {
      nextScope = const BranchScope.all();
    } else {
      nextScope = const BranchScope.uninitialized();
      configurationError = 'branchRequired';
    }

    _emitScope(nextScope, error: configurationError);
  }

  /// The effective branch ID to use for all DB queries.
  /// Returns null for primary admins viewing "all branches".
  /// Returns the user's branch_id for regular users.
  /// Returns selectedBranchId if a primary admin has picked a specific branch.
  String? get effectiveBranchId {
    if (!_isPrimaryAdmin) return _userBranchId;
    return state.scope.branchId;
  }

  bool get isPrimaryAdmin => _isPrimaryAdmin;
  bool get canWriteBranchData => state.scope.canWriteBranchData;

  /// Load branches from the database.
  Future<void> loadBranches() async {
    emit(state.copyWith(isLoading: true, clearError: true));
    try {
      dynamic query = Supabase.instance.client
          .from('branches')
          .select()
          .eq('is_active', true);
      if (!_isPrimaryAdmin && _userBranchId != null) {
        query = query.eq('id', _userBranchId!);
      }
      final response =
          await query.order('is_main_branch', ascending: false).order('name');

      final branches = (response as List)
          .map((row) => Branch.fromMap(row as Map<String, dynamic>))
          .toList();

      emit(state.copyWith(branches: branches, isLoading: false));
    } catch (e) {
      emit(state.copyWith(isLoading: false, error: e.toString()));
    }
  }

  Future<void> selectBranch(String branchId) async {
    if (!_isPrimaryAdmin) return;
    final exists = state.branches
        .any((branch) => branch.id == branchId && branch.isActive);
    if (!exists) {
      emit(state.copyWith(error: 'branchUnavailable'));
      return;
    }
    _emitScope(BranchScope.branch(branchId));
  }

  Future<void> selectAll() async {
    if (!_isPrimaryAdmin) return;
    _emitScope(const BranchScope.all());
  }

  void _emitScope(BranchScope scope, {String? error}) {
    if (state.scope == scope && error == null) return;
    final revision = state.scope == scope
        ? state.selectionRevision
        : state.selectionRevision + 1;
    emit(state.copyWith(
      scope: scope,
      selectionRevision: revision,
      error: error,
      clearError: error == null,
    ));
    if (state.scope == scope && error == null) {
      StateSynchronizer.notify(DataChangeEvent(
        entityType: 'branch_scope',
        operation: 'select',
        id: scope.branchId,
        metadata: {
          'mode': scope.mode.name,
          'revision': revision,
        },
      ));
    }
  }

  /// Create a new branch. Calls the create_branch_with_stock RPC.
  Future<String?> createBranch({
    required String name,
    String address = '',
    String phone = '',
  }) async {
    try {
      final result = await Supabase.instance.client
          .rpc('create_branch_with_stock', params: {
        'name_input': name,
        'address_input': address,
        'phone_input': phone,
      });

      final branchId = result as String;
      await loadBranches();
      return branchId;
    } catch (e) {
      emit(state.copyWith(error: e.toString()));
      return null;
    }
  }

  /// Deactivate a branch (soft delete).
  Future<bool> deactivateBranch(String branchId) async {
    try {
      await Supabase.instance.client
          .from('branches')
          .update({'is_active': false}).eq('id', branchId);

      if (state.selectedBranchId == branchId) {
        _emitScope(const BranchScope.all());
      }

      await loadBranches();
      return true;
    } catch (e) {
      emit(state.copyWith(error: e.toString()));
      return false;
    }
  }

  /// Update branch details (name, address, phone).
  Future<bool> updateBranch({
    required String branchId,
    required String name,
    String? address,
    String? phone,
  }) async {
    try {
      final values = <String, dynamic>{
        'name': name,
        if (address != null) 'address': address,
        if (phone != null) 'phone': phone,
      };
      await Supabase.instance.client
          .from('branches')
          .update(values)
          .eq('id', branchId);
      await loadBranches();
      return true;
    } catch (e) {
      emit(state.copyWith(error: e.toString()));
      return false;
    }
  }
}
