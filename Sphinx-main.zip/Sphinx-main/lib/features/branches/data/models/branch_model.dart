class Branch {
  final String id;
  final String name;
  final String address;
  final String phone;
  final bool isMainBranch;
  final bool isActive;

  const Branch({
    required this.id,
    required this.name,
    this.address = '',
    this.phone = '',
    this.isMainBranch = false,
    this.isActive = true,
  });

  factory Branch.fromMap(Map<String, dynamic> map) {
    return Branch(
      id: map['id'] as String,
      name: map['name'] as String? ?? '',
      address: map['address'] as String? ?? '',
      phone: map['phone'] as String? ?? '',
      isMainBranch: map['is_main_branch'] as bool? ?? false,
      isActive: map['is_active'] as bool? ?? true,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'address': address,
      'phone': phone,
      'is_main_branch': isMainBranch,
      'is_active': isActive,
    };
  }

  Branch copyWith({
    String? id,
    String? name,
    String? address,
    String? phone,
    bool? isMainBranch,
    bool? isActive,
  }) {
    return Branch(
      id: id ?? this.id,
      name: name ?? this.name,
      address: address ?? this.address,
      phone: phone ?? this.phone,
      isMainBranch: isMainBranch ?? this.isMainBranch,
      isActive: isActive ?? this.isActive,
    );
  }
}
