class BranchStatistics {
  const BranchStatistics({
    required this.grossSales,
    required this.refunds,
    required this.netSales,
    required this.expenses,
    required this.estimatedProfit,
    required this.transactionCount,
    required this.activeUserCount,
    required this.openShiftCount,
    required this.completedShiftCount,
    required this.productCount,
    required this.lowStockCount,
    required this.outOfStockCount,
    required this.stockRetailValue,
    required this.stockCostValue,
    required this.start,
    required this.end,
  });

  final double grossSales;
  final double refunds;
  final double netSales;
  final double expenses;
  final double estimatedProfit;
  final int transactionCount;
  final int activeUserCount;
  final int openShiftCount;
  final int completedShiftCount;
  final int productCount;
  final int lowStockCount;
  final int outOfStockCount;
  final double stockRetailValue;
  final double stockCostValue;
  final DateTime start;
  final DateTime end;
}

enum BranchActivityType { sale, refund, expense, shift }

class BranchActivityItem {
  const BranchActivityItem({
    required this.id,
    required this.type,
    required this.title,
    required this.branchName,
    required this.createdAt,
    this.amount,
    this.actor,
    this.sessionNumber,
    this.isOpen,
  });

  final String id;
  final BranchActivityType type;
  final String title;
  final String branchName;
  final DateTime createdAt;
  final double? amount;
  final String? actor;
  final int? sessionNumber;
  final bool? isOpen;
}
