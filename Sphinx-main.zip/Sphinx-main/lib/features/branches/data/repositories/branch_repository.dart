import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/branch_statistics.dart';

class BranchRepository {
  BranchRepository({SupabaseClient? client})
      : _client = client ?? Supabase.instance.client;

  final SupabaseClient _client;

  Future<BranchStatistics> getStatistics({
    String? branchId,
    required DateTime start,
    required DateTime end,
  }) async {
    try {
      final response = await _client.rpc(
        'get_branch_statistics',
        params: {
          'branch_id_input': branchId,
          'start_input': start.toUtc().toIso8601String(),
          'end_input': end.toUtc().toIso8601String(),
        },
      );
      final row = Map<String, dynamic>.from(response as Map);
      return BranchStatistics(
        grossSales: (row['gross_sales'] as num?)?.toDouble() ?? 0,
        refunds: (row['refunds'] as num?)?.toDouble() ?? 0,
        netSales: (row['net_sales'] as num?)?.toDouble() ?? 0,
        expenses: (row['expenses'] as num?)?.toDouble() ?? 0,
        estimatedProfit: (row['estimated_profit'] as num?)?.toDouble() ?? 0,
        transactionCount: (row['transaction_count'] as num?)?.toInt() ?? 0,
        activeUserCount: (row['active_user_count'] as num?)?.toInt() ?? 0,
        openShiftCount: (row['open_shift_count'] as num?)?.toInt() ?? 0,
        completedShiftCount:
            (row['completed_shift_count'] as num?)?.toInt() ?? 0,
        productCount: (row['product_count'] as num?)?.toInt() ?? 0,
        lowStockCount: (row['low_stock_count'] as num?)?.toInt() ?? 0,
        outOfStockCount: (row['out_of_stock_count'] as num?)?.toInt() ?? 0,
        stockRetailValue: (row['stock_retail_value'] as num?)?.toDouble() ?? 0,
        stockCostValue: (row['stock_cost_value'] as num?)?.toDouble() ?? 0,
        start: start,
        end: end,
      );
    } on PostgrestException catch (error) {
      if (error.code != 'PGRST202' && error.code != '42883') rethrow;
      return _getStatisticsFromTables(
        branchId: branchId,
        start: start,
        end: end,
      );
    }
  }

  Future<BranchStatistics> _getStatisticsFromTables({
    String? branchId,
    required DateTime start,
    required DateTime end,
  }) async {
    final responses = await Future.wait<dynamic>([
      _scoped(
        _client
            .from('sales')
            .select('total, invoice_type_index')
            .gte('created_at', start.toUtc().toIso8601String())
            .lt('created_at', end.toUtc().toIso8601String()),
        branchId,
      ),
      _scoped(
        _client
            .from('expenses')
            .select('amount')
            .gte('created_at', start.toUtc().toIso8601String())
            .lt('created_at', end.toUtc().toIso8601String()),
        branchId,
      ),
      _scoped(_client.from('shifts').select('is_open'), branchId),
      _scoped(
        _client.from('users').select('id').eq('is_active', true),
        branchId,
      ),
      _scoped(
        _client.from('branch_stock').select(
              'quantity, min_quantity, products(price, wholesale_price)',
            ),
        branchId,
      ),
    ]);

    final sales = (responses[0] as List).cast<Map<String, dynamic>>();
    final expensesRows = (responses[1] as List).cast<Map<String, dynamic>>();
    final shifts = (responses[2] as List).cast<Map<String, dynamic>>();
    final users = responses[3] as List;
    final stock = (responses[4] as List).cast<Map<String, dynamic>>();

    var grossSales = 0.0;
    var refunds = 0.0;
    for (final row in sales) {
      final amount = (row['total'] as num?)?.toDouble() ?? 0;
      if ((row['invoice_type_index'] as int? ?? 0) == 1) {
        refunds += amount.abs();
      } else {
        grossSales += amount;
      }
    }

    final expenses = expensesRows.fold<double>(
      0,
      (sum, row) => sum + ((row['amount'] as num?)?.toDouble() ?? 0),
    );

    var productCount = 0;
    var lowStockCount = 0;
    var outOfStockCount = 0;
    var stockRetailValue = 0.0;
    var stockCostValue = 0.0;
    for (final row in stock) {
      final quantity = (row['quantity'] as num?)?.toDouble() ?? 0;
      final minimum = (row['min_quantity'] as num?)?.toDouble() ?? 0;
      final product = row['products'] as Map<String, dynamic>?;
      final price = (product?['price'] as num?)?.toDouble() ?? 0;
      final cost = (product?['wholesale_price'] as num?)?.toDouble() ?? 0;
      productCount++;
      if (quantity <= 0) {
        outOfStockCount++;
      } else if (quantity <= minimum) {
        lowStockCount++;
      }
      stockRetailValue += quantity * price;
      stockCostValue += quantity * cost;
    }

    final netSales = grossSales - refunds;
    return BranchStatistics(
      grossSales: grossSales,
      refunds: refunds,
      netSales: netSales,
      expenses: expenses,
      estimatedProfit: netSales - expenses,
      transactionCount: sales.length,
      activeUserCount: users.length,
      openShiftCount: shifts.where((row) => row['is_open'] == true).length,
      completedShiftCount: shifts.where((row) => row['is_open'] != true).length,
      productCount: productCount,
      lowStockCount: lowStockCount,
      outOfStockCount: outOfStockCount,
      stockRetailValue: stockRetailValue,
      stockCostValue: stockCostValue,
      start: start,
      end: end,
    );
  }

  Future<List<BranchActivityItem>> getRecentActivity({
    String? branchId,
    int limit = 20,
  }) async {
    final safeLimit = limit.clamp(1, 100);
    final responses = await Future.wait<dynamic>([
      _scoped(
        _client.from('sales').select(
              'id, total, invoice_type_index, cashier_name, created_at, branches(name)',
            ),
        branchId,
      ).order('created_at', ascending: false).limit(safeLimit),
      _scoped(
        _client
            .from('expenses')
            .select('id, title, amount, created_at, branches(name)'),
        branchId,
      ).order('created_at', ascending: false).limit(safeLimit),
      _scoped(
        _client.from('shifts').select(
              'id, session_number, is_open, created_at, branches(name)',
            ),
        branchId,
      ).order('created_at', ascending: false).limit(safeLimit),
    ]);

    final activity = <BranchActivityItem>[
      for (final row in (responses[0] as List).cast<Map<String, dynamic>>())
        BranchActivityItem(
          id: row['id'] as String,
          type: (row['invoice_type_index'] as int? ?? 0) == 1
              ? BranchActivityType.refund
              : BranchActivityType.sale,
          title: '',
          branchName: _branchName(row),
          createdAt: DateTime.parse(row['created_at'] as String),
          amount: (row['total'] as num?)?.toDouble(),
          actor: row['cashier_name'] as String?,
        ),
      for (final row in (responses[1] as List).cast<Map<String, dynamic>>())
        BranchActivityItem(
          id: row['id'] as String,
          type: BranchActivityType.expense,
          title: row['title'] as String? ?? '',
          branchName: _branchName(row),
          createdAt: DateTime.parse(row['created_at'] as String),
          amount: (row['amount'] as num?)?.toDouble(),
        ),
      for (final row in (responses[2] as List).cast<Map<String, dynamic>>())
        BranchActivityItem(
          id: row['id'] as String,
          type: BranchActivityType.shift,
          title: '',
          branchName: _branchName(row),
          createdAt: DateTime.parse(row['created_at'] as String),
          sessionNumber: row['session_number'] as int?,
          isOpen: row['is_open'] as bool?,
        ),
    ]..sort((a, b) => b.createdAt.compareTo(a.createdAt));

    return activity.take(safeLimit).toList(growable: false);
  }

  dynamic _scoped(dynamic query, String? branchId) =>
      branchId == null ? query : query.eq('branch_id', branchId);

  String _branchName(Map<String, dynamic> row) {
    final branch = row['branches'] as Map<String, dynamic>?;
    return branch?['name'] as String? ?? '';
  }
}
