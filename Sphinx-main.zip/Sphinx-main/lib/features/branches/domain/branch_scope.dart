enum BranchScopeMode { uninitialized, all, branch }

class BranchScope {
  const BranchScope._(this.mode, this.branchId);

  const BranchScope.uninitialized()
      : this._(BranchScopeMode.uninitialized, null);

  const BranchScope.all() : this._(BranchScopeMode.all, null);

  const BranchScope.branch(String id) : this._(BranchScopeMode.branch, id);

  final BranchScopeMode mode;
  final String? branchId;

  bool get isInitialized => mode != BranchScopeMode.uninitialized;
  bool get isAll => mode == BranchScopeMode.all;
  bool get isSingleBranch => mode == BranchScopeMode.branch;
  bool get canWriteBranchData => isSingleBranch;

  @override
  bool operator ==(Object other) =>
      other is BranchScope && other.mode == mode && other.branchId == branchId;

  @override
  int get hashCode => Object.hash(mode, branchId);
}
