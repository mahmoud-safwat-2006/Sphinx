import 'dart:math';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../core/constants/app_colors.dart';
import '../auth/presentation/login_screen.dart';
import '../setup/presentation/setup_wizard_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late final AnimationController _mainController;
  late final AnimationController _glowController;
  late final AnimationController _ringController;

  late final Animation<double> _fadeAnimation;
  late final Animation<double> _scaleAnimation;
  late final Animation<double> _logoScaleAnimation;
  late final Animation<double> _progressFadeAnimation;
  late final Animation<double> _textFadeAnimation;
  late final Animation<double> _glowAnimation;
  late final Animation<double> _ringAnimation;
  late final Animation<double> _ringRotation;

  @override
  void initState() {
    super.initState();

    // Main entrance animation
    _mainController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    );

    // Glow pulse (loops)
    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    );

    // Ring expand animation
    _ringController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    );

    // Logo: scale from 0.5 → 1.0 with bounce
    _logoScaleAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(
        parent: _mainController,
        curve: const Interval(0.0, 0.5, curve: Curves.elasticOut),
      ),
    );

    // Overall fade in
    _fadeAnimation = CurvedAnimation(
      parent: _mainController,
      curve: const Interval(0.0, 0.4, curve: Curves.easeOut),
    );

    // Subtle breathing scale
    _scaleAnimation = Tween<double>(begin: 0.95, end: 1.0).animate(
      CurvedAnimation(
        parent: _mainController,
        curve: const Interval(0.3, 0.8, curve: Curves.easeOut),
      ),
    );

    // Text fade in (after logo)
    _textFadeAnimation = CurvedAnimation(
      parent: _mainController,
      curve: const Interval(0.35, 0.65, curve: Curves.easeOut),
    );

    // Progress indicator fade
    _progressFadeAnimation = CurvedAnimation(
      parent: _mainController,
      curve: const Interval(0.6, 0.9, curve: Curves.easeIn),
    );

    // Glow pulse
    _glowAnimation = Tween<double>(begin: 0.3, end: 0.8).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );

    // Ring expand
    _ringAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _ringController,
        curve: const Interval(0.2, 0.8, curve: Curves.easeOutCubic),
      ),
    );

    // Ring rotation
    _ringRotation = Tween<double>(begin: 0.0, end: 2 * pi).animate(
      CurvedAnimation(parent: _ringController, curve: Curves.linear),
    );

    // Start animations
    _mainController.forward();
    _glowController.repeat(reverse: true);
    _ringController.forward();

    // Navigate after delay
    Future.delayed(const Duration(milliseconds: 4800), () async {
      if (!mounted) return;

      bool needsSetup = true;
      try {
        final profiles =
            await Supabase.instance.client.from('users').select('id').limit(1);
        needsSetup = profiles.isEmpty;
      } catch (_) {
        needsSetup = true;
      }

      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        PageRouteBuilder(
          pageBuilder: (context, animation, secondaryAnimation) =>
              needsSetup ? const SetupWizardScreen() : const LoginScreen(),
          transitionsBuilder: (context, animation, secondaryAnimation, child) {
            return FadeTransition(opacity: animation, child: child);
          },
          transitionDuration: const Duration(milliseconds: 500),
        ),
      );
    });
  }

  @override
  void dispose() {
    _mainController.dispose();
    _glowController.dispose();
    _ringController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isArabic = Localizations.localeOf(context).languageCode == 'ar';
    final logoSize = MediaQuery.of(context).size.width * 0.22;
    final clampedLogo = logoSize.clamp(80.0, 160.0);

    return Scaffold(
      backgroundColor: AppColors.primaryColor,
      body: Center(
        child: AnimatedBuilder(
          animation: _mainController,
          builder: (context, child) {
            return Opacity(
              opacity: _fadeAnimation.value,
              child: Transform.scale(
                scale: _scaleAnimation.value,
                child: child,
              ),
            );
          },
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Logo with glow + ring
              _buildLogoContainer(clampedLogo),
              const SizedBox(height: 24),
              // Brand name
              _buildBrandText(isArabic),
              const SizedBox(height: 64),
              // Loading indicator
              FadeTransition(
                opacity: _progressFadeAnimation,
                child: SizedBox(
                  width: 28,
                  height: 28,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation<Color>(
                      Colors.white.withOpacity(0.5),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLogoContainer(double size) {
    return AnimatedBuilder(
      animation:
          Listenable.merge([_mainController, _glowController, _ringController]),
      builder: (context, child) {
        final glowOpacity = _glowAnimation.value;
        final logoScale = _logoScaleAnimation.value;
        final ringProgress = _ringAnimation.value;

        return Transform.scale(
          scale: logoScale,
          child: SizedBox(
            width: size + 40,
            height: size + 40,
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Outer glow
                Container(
                  width: size + 32,
                  height: size + 32,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: AppColors.accentColor
                            .withOpacity(glowOpacity * 0.4),
                        blurRadius: 40,
                        spreadRadius: 8,
                      ),
                      BoxShadow(
                        color: AppColors.accentColor
                            .withOpacity(glowOpacity * 0.2),
                        blurRadius: 80,
                        spreadRadius: 16,
                      ),
                    ],
                  ),
                ),

                // Animated ring
                if (ringProgress > 0)
                  Transform.rotate(
                    angle: _ringRotation.value,
                    child: SizedBox(
                      width: size + 24,
                      height: size + 24,
                      child: CustomPaint(
                        painter: _ArcPainter(
                          progress: ringProgress,
                          color: AppColors.accentColor,
                        ),
                      ),
                    ),
                  ),

                // White circle background
                Container(
                  width: size + 12,
                  height: size + 12,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.15),
                        blurRadius: 20,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                ),

                // Blue accent ring
                Container(
                  width: size + 4,
                  height: size + 4,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: AppColors.accentColor.withOpacity(0.3),
                      width: 2,
                    ),
                  ),
                ),

                // Logo image (clipped circle)
                CircleAvatar(
                  radius: size / 2,
                  backgroundImage: AssetImage(
                    'assets/images/logo.png',
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildBrandText(bool isArabic) {
    return FadeTransition(
      opacity: _textFadeAnimation,
      child: Column(
        children: [
          Text(
            'Sphinx',
            style: TextStyle(
              fontSize: 36,
              fontWeight: FontWeight.w900,
              color: Colors.white,
              letterSpacing: 2,
              height: 1.1,
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            decoration: BoxDecoration(
              color: AppColors.accentColor.withOpacity(0.25),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: AppColors.accentColor.withOpacity(0.4),
                width: 1,
              ),
            ),
            child: Text(
              isArabic ? 'نظام نقاط البيع للمحلات' : 'POS System for Shops',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: Colors.white.withOpacity(0.9),
                letterSpacing: isArabic ? 0 : 1,
              ),
            ),
          ),
          const SizedBox(height: 10),
          Text(
            isArabic ? 'بيع · شراء · إدارة' : 'Sell · Buy · Manage',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w400,
              color: Colors.white.withOpacity(0.45),
              letterSpacing: isArabic ? 0 : 2,
            ),
          ),
        ],
      ),
    );
  }
}

/// Custom painter for the animated arc ring around the logo
class _ArcPainter extends CustomPainter {
  final double progress;
  final Color color;

  _ArcPainter({required this.progress, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 2.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final center = Offset(size.width / 2, size.height / 2);
    final radius = (size.width / 2) - 4;
    final rect = Rect.fromCircle(center: center, radius: radius);

    // Draw two arcs for a spinning effect
    final startAngle1 = 0.0;
    final sweepAngle1 = pi * progress;

    canvas.drawArc(rect, startAngle1, sweepAngle1, false, paint);

    if (progress > 0.5) {
      final startAngle2 = pi;
      final sweepAngle2 = pi * (progress - 0.5);
      canvas.drawArc(rect, startAngle2, sweepAngle2, false, paint);
    }
  }

  @override
  bool shouldRepaint(_ArcPainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.color != color;
}
