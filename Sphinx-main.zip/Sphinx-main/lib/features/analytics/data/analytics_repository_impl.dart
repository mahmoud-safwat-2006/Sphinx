// lib/features/analytics/data/analytics_repository_impl.dart

import 'package:sphinx/core/data/services/supabase_service.dart';
import 'package:dartz/dartz.dart';
import 'package:sphinx/core/di/dependency_injection.dart';
import '../../../core/error/failure.dart';
import '../../branches/presentation/cubit/branch_cubit.dart';
import '../../pos/domain/pos_repository.dart';
import '../domain/analytics_repository.dart';
import 'models/analytics_summary_model.dart';
import '../../shifts/data/models/daily_report_model.dart';
import '../../shifts/data/models/product_performance_model.dart';
import 'package:sphinx/features/pos/data/models/sale_model.dart';

import '../../shifts/data/repositories/shift_repository_impl.dart';

class AnalyticsRepositoryImpl implements AnalyticsRepository {
  final SupabaseService _supabaseService;

  AnalyticsRepositoryImpl({SupabaseService? supabaseService})
      : _supabaseService = supabaseService ?? SupabaseService();

  String? get _branchId => getIt<BranchCubit>().effectiveBranchId;
  String _databaseTimestamp(DateTime value) => value.toUtc().toIso8601String();

  Future<List<Map<String, dynamic>>> _rpc(String query,
      [Map<String, dynamic>? params]) async {
    final result =
        await _supabaseService.client.rpc(query, params: params ?? {});
    if (result is List) {
      return result.cast<Map<String, dynamic>>();
    }
    return [];
  }

  @override
  Future<Either<Failure, Map<int, double>>> getHourlySales(
      DateTime start, DateTime end) async {
    try {
      final rows = await _rpc('get_hourly_sales', {
        'start_date': _databaseTimestamp(start),
        'end_date': _databaseTimestamp(end),
      });

      final Map<int, double> result = {};
      for (var row in rows) {
        result[row['hour'] as int] =
            (row['revenue'] as num?)?.toDouble() ?? 0.0;
      }
      return Right(result);
    } catch (e) {
      try {
        var salesQuery = _supabaseService
            .from('sales')
            .select('created_at, total')
            .eq('invoice_type_index', 0)
            .gte('created_at', _databaseTimestamp(start))
            .lte('created_at', _databaseTimestamp(end));
        if (_branchId != null) {
          salesQuery = salesQuery.eq('branch_id', _branchId!);
        }
        final response = await salesQuery;

        final Map<int, double> result = {};
        for (var row in (response as List)) {
          final dt = DateTime.parse(row['created_at'] as String);
          final hour = dt.hour;
          result[hour] = (result[hour] ?? 0) + (row['total'] as num).toDouble();
        }
        return Right(result);
      } catch (e2) {
        return Left(CacheFailure("Failed to fetch hourly sales"));
      }
    }
  }

  @override
  Future<Either<Failure, Map<String, double>>> getSalesByCategory(
      DateTime start, DateTime end) async {
    try {
      var salesQuery = _supabaseService
          .from('sales')
          .select('id')
          .eq('invoice_type_index', 0)
          .gte('created_at', _databaseTimestamp(start))
          .lte('created_at', _databaseTimestamp(end));
      if (_branchId != null) {
        salesQuery = salesQuery.eq('branch_id', _branchId!);
      }
      final salesResponse = await salesQuery;

      final saleIds =
          (salesResponse as List).map((r) => r['id'] as String).toList();
      if (saleIds.isEmpty) return Right({});

      final itemsResponse = await _supabaseService
          .from('sale_items')
          .select('product_id, price, quantity')
          .inFilter('sale_id', saleIds);

      final Map<String, double> result = {};
      for (var item in (itemsResponse as List)) {
        final productId = item['product_id'] as String;
        final revenue = (item['price'] as num).toDouble() *
            (item['quantity'] as num).toDouble();

        final prodResponse = await _supabaseService
            .from('products')
            .select('category')
            .eq('barcode', productId)
            .maybeSingle();

        final cat = prodResponse?['category'] as String? ?? 'General';
        result[cat] = (result[cat] ?? 0) + revenue;
      }

      final sorted = result.entries.toList()
        ..sort((a, b) => b.value.compareTo(a.value));
      return Right(Map.fromEntries(sorted.take(10)));
    } catch (e) {
      return Right({});
    }
  }

  @override
  Future<Either<Failure, Map<String, double>>> getDailyTimeSeries(
      DateTime start, DateTime end) async {
    try {
      var salesQuery = _supabaseService
          .from('sales')
          .select('created_at, total')
          .eq('invoice_type_index', 0)
          .gte('created_at', _databaseTimestamp(start))
          .lte('created_at', _databaseTimestamp(end));
      if (_branchId != null) {
        salesQuery = salesQuery.eq('branch_id', _branchId!);
      }
      final response = await salesQuery;

      final Map<String, double> result = {};
      for (var row in (response as List)) {
        final dt = DateTime.parse(row['created_at'] as String);
        final day =
            '${dt.year}-${dt.month.toString().padLeft(2, '0')}-${dt.day.toString().padLeft(2, '0')}';
        result[day] = (result[day] ?? 0) + (row['total'] as num).toDouble();
      }
      return Right(result);
    } catch (e) {
      return Left(CacheFailure("Failed to fetch daily time series"));
    }
  }

  @override
  Future<Either<Failure, List<DailyReport>>> getReportsInRange(
      DateTime start, DateTime end) async {
    try {
      final sessionRepo = getIt<SessionRepositoryImpl>();
      final sessions = await sessionRepo.getSessionsInRange(start, end);

      final List<DailyReport> reports = [];
      for (var session in sessions) {
        if (session.dailyReportId != null) {
          final report = await sessionRepo.generateDailyReport(session.id);
          if (report != null) {
            reports.add(report);
          }
        }
      }
      return Right(reports);
    } catch (e) {
      return Left(CacheFailure('Failed to fetch reports: ${e.toString()}'));
    }
  }

  @override
  Future<Either<Failure, AnalyticsSummaryModel>> getSummary(
      DateTime start, DateTime end) async {
    try {
      final startIso = _databaseTimestamp(start);
      final endIso = _databaseTimestamp(end);

      var salesQuery = _supabaseService
          .from('sales')
          .select('total, invoice_type_index')
          .gte('created_at', startIso)
          .lte('created_at', endIso);
      if (_branchId != null) {
        salesQuery = salesQuery.eq('branch_id', _branchId!);
      }
      final salesResponse = await salesQuery;

      int totalSalesCount = 0;
      double totalRevenue = 0;
      double totalRefunds = 0;
      for (var row in (salesResponse as List)) {
        final isRefund = (row['invoice_type_index'] as int?) == 1;
        final total = (row['total'] as num).toDouble();
        if (isRefund) {
          totalRefunds += total;
        } else {
          totalSalesCount++;
          totalRevenue += total;
        }
      }

      final netRevenue = totalRevenue - totalRefunds;

      var itemsQuery = _supabaseService
          .from('sale_items')
          .select(
              'quantity, wholesale_price, sales!inner(invoice_type_index, created_at)')
          .gte('sales.created_at', startIso)
          .lte('sales.created_at', endIso);
      if (_branchId != null) {
        itemsQuery = itemsQuery.eq('sales.branch_id', _branchId!);
      }
      final itemsResponse = await itemsQuery;

      double totalCostSold = 0;
      double totalCostRefunded = 0;
      for (var item in (itemsResponse as List)) {
        final cost = (item['quantity'] as num).toDouble() *
            (item['wholesale_price'] as num).toDouble();
        final sale = item['sales'] as Map<String, dynamic>?;
        if ((sale?['invoice_type_index'] as int?) == 1) {
          totalCostRefunded += cost;
        } else {
          totalCostSold += cost;
        }
      }

      final netCost = totalCostSold - totalCostRefunded;

      var expensesQuery = _supabaseService
          .from('expenses')
          .select('amount')
          .gte('created_at', startIso)
          .lte('created_at', endIso);
      if (_branchId != null) {
        expensesQuery = expensesQuery.eq('branch_id', _branchId!);
      }
      final expensesResponse = await expensesQuery;

      double totalExpenses = 0;
      for (var row in (expensesResponse as List)) {
        totalExpenses += (row['amount'] as num).toDouble();
      }

      final netProfit = netRevenue - netCost - totalExpenses;
      final profitMargin =
          netRevenue > 0 ? (netProfit / netRevenue) * 100 : 0.0;

      return Right(AnalyticsSummaryModel(
        startDate: start,
        endDate: end,
        totalRevenue: netRevenue,
        totalCost: netCost,
        totalProfit: netProfit,
        profitMargin: profitMargin,
        totalSales: totalSalesCount,
        grossRevenue: totalRevenue,
        refundedAmount: totalRefunds,
        totalExpenses: totalExpenses,
      ));
    } catch (e) {
      return Left(
          CacheFailure("Error loading sessions summary: ${e.toString()}"));
    }
  }

  @override
  Future<Either<Failure, List<ProductPerformanceModel>>> getTopProducts(
      int limit, DateTime start, DateTime end) async {
    try {
      var salesQuery = _supabaseService
          .from('sales')
          .select('id, invoice_type_index')
          .gte('created_at', _databaseTimestamp(start))
          .lte('created_at', _databaseTimestamp(end));
      if (_branchId != null) {
        salesQuery = salesQuery.eq('branch_id', _branchId!);
      }
      final salesResponse = await salesQuery;

      final saleIds =
          (salesResponse as List).map((r) => r['id'] as String).toList();
      if (saleIds.isEmpty) return Right([]);

      final refundSaleIds = (salesResponse as List)
          .where((r) => (r['invoice_type_index'] as int?) == 1)
          .map((r) => r['id'] as String)
          .toSet();

      final itemsResponse = await _supabaseService
          .from('sale_items')
          .select('product_id, name, quantity, price, wholesale_price, sale_id')
          .inFilter('sale_id', saleIds);

      final Map<String, ProductPerformanceModel> stats = {};
      for (var item in (itemsResponse as List)) {
        final productId = item['product_id'] as String;
        final isRefund = refundSaleIds.contains(item['sale_id'] as String);
        final sign = isRefund ? -1.0 : 1.0;
        final revenue = (item['price'] as num).toDouble() *
            (item['quantity'] as num).toDouble() *
            sign;
        final cost = (item['wholesale_price'] as num).toDouble() *
            (item['quantity'] as num).toDouble() *
            sign;
        final qty = (item['quantity'] as num).toDouble() * sign;

        if (stats.containsKey(productId)) {
          final existing = stats[productId]!;
          stats[productId] = existing.copyWith(
            quantitySold: existing.quantitySold + qty,
            revenue: existing.revenue + revenue,
            cost: existing.cost + cost,
          );
        } else {
          stats[productId] = ProductPerformanceModel(
            productId: productId,
            productName: item['name'] as String,
            quantitySold: qty,
            revenue: revenue,
            cost: cost,
            profit: 0,
            profitMargin: 0,
          );
        }
      }

      final toplist = stats.values.map((p) {
        final profit = p.revenue - p.cost;
        final margin = p.revenue > 0 ? (profit / p.revenue) * 100 : 0.0;
        return p.copyWith(profit: profit, profitMargin: margin);
      }).toList()
        ..sort((a, b) => b.revenue.compareTo(a.revenue));

      return Right(toplist.take(limit).toList());
    } catch (e) {
      return Left(CacheFailure("Error loading products: ${e.toString()}"));
    }
  }

  @override
  Future<Either<Failure, DailyReport>> getDailyReport(DateTime date) async {
    try {
      final start = DateTime(date.year, date.month, date.day, 0, 0, 0);
      final end = DateTime(date.year, date.month, date.day, 23, 59, 59);

      var salesQuery = _supabaseService
          .from('sales')
          .select('id')
          .gte('created_at', _databaseTimestamp(start))
          .lte('created_at', _databaseTimestamp(end));
      if (_branchId != null) {
        salesQuery = salesQuery.eq('branch_id', _branchId!);
      }
      final salesResponse = await salesQuery;

      if ((salesResponse as List).isEmpty) {
        return Left(CacheFailure("No data found for this day."));
      }

      final summary = await getSummary(start, end);
      return summary.fold(
        (f) => Left(f),
        (analyticsModel) async {
          final topProducts = await getTopProducts(50, start, end);
          return Right(DailyReport(
            id: "DATE_${date.millisecondsSinceEpoch}",
            sessionId: "DATE_AGGREGATE",
            date: date,
            totalSales: analyticsModel.totalRevenue +
                (analyticsModel.totalCost - analyticsModel.totalProfit),
            totalRefunds: 0,
            netRevenue: analyticsModel.totalRevenue,
            totalTransactions: analyticsModel.totalSales,
            closedByUserName: "System",
            topProducts: topProducts.getOrElse(() => []),
            refundedProducts: [],
            transactions: [],
          ));
        },
      );
    } catch (e) {
      return Left(CacheFailure("Error fetching daily report: ${e.toString()}"));
    }
  }

  @override
  Future<Either<Failure, DailyReport?>> getReportForSession(
      String sessionId) async {
    try {
      final salesRepo = getIt<PosRepository>();
      final branchId = getIt<BranchCubit>().effectiveBranchId;
      var query =
          _supabaseService.from('sales').select('id').eq('session_id', sessionId);
      if (branchId != null) {
        query = query.eq('branch_id', branchId);
      }
      final salesIdsResponse = await query;

      if ((salesIdsResponse as List).isEmpty) {
        return Right(DailyReport(
          id: 'EMPTY_$sessionId',
          sessionId: sessionId,
          date: DateTime.now(),
          totalSales: 0,
          totalRefunds: 0,
          netRevenue: 0,
          totalTransactions: 0,
          closedByUserName: 'System',
          topProducts: [],
          transactions: [],
          refundedProducts: [],
        ));
      }

      final ids = salesIdsResponse.map((r) => r['id'] as String).toList();
      final salesResult = await salesRepo.getSalesByIds(ids);

      return salesResult.fold(
        (f) => Left(f),
        (sales) => Right(_generateReportFromSales(sales, DateTime.now())),
      );
    } catch (e) {
      return Left(
          CacheFailure("Failed to fetch session report: ${e.toString()}"));
    }
  }

  DailyReport _generateReportFromSales(List<Sale> sales, DateTime date) {
    double totalSales = 0.0;
    double totalRefunds = 0.0;
    final Map<String, ProductPerformanceModel> productStats = {};
    final Map<String, ProductPerformanceModel> refundStats = {};

    for (final sale in sales) {
      final isRefund = sale.isRefund;
      final sign = isRefund ? -1.0 : 1.0;

      if (isRefund) {
        totalRefunds += sale.total.abs();
      } else {
        totalSales += sale.total;
      }

      for (final item in sale.saleItems) {
        final revenue = (item.price * item.quantity) * sign;
        final cost = (item.wholesalePrice * item.quantity) * sign;
        final qty = item.quantity * (isRefund ? -1 : 1);

        if (productStats.containsKey(item.productId)) {
          final existing = productStats[item.productId]!;
          productStats[item.productId] = existing.copyWith(
            quantitySold: existing.quantitySold + qty,
            revenue: existing.revenue + revenue,
            cost: existing.cost + cost,
          );
        } else {
          productStats[item.productId] = ProductPerformanceModel(
            productId: item.productId,
            productName: item.name,
            quantitySold: qty,
            revenue: revenue,
            cost: cost,
            profit: 0,
            profitMargin: 0,
          );
        }

        if (isRefund) {
          if (refundStats.containsKey(item.productId)) {
            final existing = refundStats[item.productId]!;
            refundStats[item.productId] = existing.copyWith(
              quantitySold: existing.quantitySold + item.quantity,
              revenue: existing.revenue + item.total,
            );
          } else {
            refundStats[item.productId] = ProductPerformanceModel(
              productId: item.productId,
              productName: item.name,
              quantitySold: item.quantity,
              revenue: item.total,
              cost: 0,
              profit: 0,
              profitMargin: 0,
            );
          }
        }
      }
    }

    final topProducts = productStats.values.map((p) {
      final profit = p.revenue - p.cost;
      final margin = p.revenue > 0 ? (profit / p.revenue) * 100 : 0.0;
      return p.copyWith(profit: profit, profitMargin: margin);
    }).toList()
      ..sort((a, b) => b.revenue.compareTo(a.revenue));

    return DailyReport(
      id: "SESSION_REP",
      sessionId: "SESSION",
      date: date,
      totalSales: totalSales,
      totalRefunds: totalRefunds,
      netRevenue: totalSales - totalRefunds,
      totalTransactions: sales.length,
      closedByUserName: "System",
      topProducts: topProducts,
      refundedProducts: refundStats.values.toList(),
      transactions: sales,
    );
  }

  @override
  Future<Either<Failure, Map<String, double>>> getDailySales(
      DateTime start, DateTime end) async {
    final result = await getSummary(start, end);
    return result.fold(
      (f) => Left(f),
      (summary) => Right({
        'Total sales': summary.totalRevenue,
        'Total cost': summary.totalCost,
        'Net profit': summary.totalProfit,
      }),
    );
  }

  @override
  Future<void> deleteReport(String reportId) async {
    print('Delete report called for ID: $reportId (no-op)');
  }

  @override
  Future<Either<Failure, Map<int, double>>> getHourlySalesForSession(
      String sessionId) async {
    try {
      final branchId = getIt<BranchCubit>().effectiveBranchId;
      var query = _supabaseService
          .from('sales')
          .select('created_at, total')
          .eq('invoice_type_index', 0)
          .eq('shift_id', sessionId);
      if (branchId != null) {
        query = query.eq('branch_id', branchId);
      }
      final response = await query;

      final Map<int, double> result = {};
      for (var row in (response as List)) {
        final dt = DateTime.parse(row['created_at'] as String);
        result[dt.hour] =
            (result[dt.hour] ?? 0) + (row['total'] as num).toDouble();
      }
      return Right(result);
    } catch (e) {
      return Left(CacheFailure(
          "Failed to fetch hourly sales for session: ${e.toString()}"));
    }
  }

  @override
  Future<Either<Failure, Map<String, double>>> getCategorySalesForSession(
      String sessionId) async {
    try {
      final branchId = getIt<BranchCubit>().effectiveBranchId;
      var salesQuery = _supabaseService
          .from('sales')
          .select('id')
          .eq('invoice_type_index', 0)
          .eq('shift_id', sessionId);
      if (branchId != null) {
        salesQuery = salesQuery.eq('branch_id', branchId);
      }
      final salesResponse = await salesQuery;

      final saleIds =
          (salesResponse as List).map((r) => r['id'] as String).toList();
      if (saleIds.isEmpty) return Right({});

      final itemsResponse = await _supabaseService
          .from('sale_items')
          .select('product_id, price, quantity')
          .inFilter('sale_id', saleIds);

      final Map<String, double> result = {};
      for (var item in (itemsResponse as List)) {
        final prodResponse = await _supabaseService
            .from('products')
            .select('category')
            .eq('barcode', item['product_id'])
            .maybeSingle();
        final cat = prodResponse?['category'] as String? ?? 'General';
        final revenue = (item['price'] as num).toDouble() *
            (item['quantity'] as num).toDouble();
        result[cat] = (result[cat] ?? 0) + revenue;
      }

      final sorted = result.entries.toList()
        ..sort((a, b) => b.value.compareTo(a.value));
      return Right(Map.fromEntries(sorted.take(10)));
    } catch (e) {
      return Right({});
    }
  }

  @override
  Future<Either<Failure, List<ProductPerformanceModel>>>
      getTopProductsForSession(String sessionId, int limit) async {
    try {
      final branchId = getIt<BranchCubit>().effectiveBranchId;
      var salesQuery = _supabaseService
          .from('sales')
          .select('id, invoice_type_index')
          .eq('shift_id', sessionId);
      if (branchId != null) {
        salesQuery = salesQuery.eq('branch_id', branchId);
      }
      final salesResponse = await salesQuery;

      final saleIds =
          (salesResponse as List).map((r) => r['id'] as String).toList();
      final refundSaleIds = (salesResponse as List)
          .where((r) => (r['invoice_type_index'] as int?) == 1)
          .map((r) => r['id'] as String)
          .toSet();

      if (saleIds.isEmpty) return Right([]);

      final itemsResponse = await _supabaseService
          .from('sale_items')
          .select('product_id, name, quantity, price, wholesale_price, sale_id')
          .inFilter('sale_id', saleIds);

      final Map<String, ProductPerformanceModel> stats = {};
      for (var item in (itemsResponse as List)) {
        final productId = item['product_id'] as String;
        final isRefund = refundSaleIds.contains(item['sale_id'] as String);
        final sign = isRefund ? -1.0 : 1.0;
        final revenue = (item['price'] as num).toDouble() *
            (item['quantity'] as num).toDouble() *
            sign;
        final cost = (item['wholesale_price'] as num).toDouble() *
            (item['quantity'] as num).toDouble() *
            sign;

        if (stats.containsKey(productId)) {
          final existing = stats[productId]!;
          stats[productId] = existing.copyWith(
            quantitySold: existing.quantitySold +
                ((item['quantity'] as num).toDouble() * (isRefund ? -1 : 1)),
            revenue: existing.revenue + revenue,
            cost: existing.cost + cost,
          );
        } else {
          stats[productId] = ProductPerformanceModel(
            productId: productId,
            productName: item['name'] as String,
            quantitySold:
                (item['quantity'] as num).toDouble() * (isRefund ? -1 : 1),
            revenue: revenue,
            cost: cost,
            profit: 0,
            profitMargin: 0,
          );
        }
      }

      final toplist = stats.values.map((p) {
        final profit = p.revenue - p.cost;
        final margin = p.revenue > 0 ? (profit / p.revenue) * 100 : 0.0;
        return p.copyWith(profit: profit, profitMargin: margin);
      }).toList()
        ..sort((a, b) => b.revenue.compareTo(a.revenue));

      return Right(toplist.take(limit).toList());
    } catch (e) {
      return Left(
          CacheFailure("Error loading session products: ${e.toString()}"));
    }
  }

  @override
  Future<Either<Failure, Map<String, double>>> getMonthlySales(
      DateTime start, DateTime end) async {
    try {
      var salesQuery = _supabaseService
          .from('sales')
          .select('created_at, total, invoice_type_index')
          .gte('created_at', _databaseTimestamp(start))
          .lte('created_at', _databaseTimestamp(end));
      if (_branchId != null) {
        salesQuery = salesQuery.eq('branch_id', _branchId!);
      }
      final response = await salesQuery;

      final Map<String, double> result = {};
      for (var row in (response as List)) {
        final dt = DateTime.parse(row['created_at'] as String);
        final month = '${dt.year}-${dt.month.toString().padLeft(2, '0')}';
        final isRefund = (row['invoice_type_index'] as int?) == 1;
        final value = (row['total'] as num).toDouble() * (isRefund ? -1 : 1);
        result[month] = (result[month] ?? 0) + value;
      }

      result.removeWhere((_, v) => v <= 0);
      return Right(result);
    } catch (e) {
      return Left(CacheFailure("Failed to fetch monthly sales"));
    }
  }

  @override
  Future<Either<Failure, Map<String, double>>> getYearlySales(
      DateTime start, DateTime end) async {
    try {
      var salesQuery = _supabaseService
          .from('sales')
          .select('created_at, total, invoice_type_index')
          .gte('created_at', _databaseTimestamp(start))
          .lte('created_at', _databaseTimestamp(end));
      if (_branchId != null) {
        salesQuery = salesQuery.eq('branch_id', _branchId!);
      }
      final response = await salesQuery;

      final Map<String, double> result = {};
      for (var row in (response as List)) {
        final dt = DateTime.parse(row['created_at'] as String);
        final year = dt.year.toString();
        final isRefund = (row['invoice_type_index'] as int?) == 1;
        final value = (row['total'] as num).toDouble() * (isRefund ? -1 : 1);
        result[year] = (result[year] ?? 0) + value;
      }
      return Right(result);
    } catch (e) {
      return Left(CacheFailure("Failed to fetch yearly sales"));
    }
  }

  @override
  Future<Either<Failure, List<ProductPerformanceModel>>> getTopProductsForMonth(
      String yearMonth, int limit) async {
    try {
      final parts = yearMonth.split('-');
      final start = DateTime(int.parse(parts[0]), int.parse(parts[1]), 1);
      final end =
          DateTime(int.parse(parts[0]), int.parse(parts[1]) + 1, 0, 23, 59, 59);

      var salesQuery = _supabaseService
          .from('sales')
          .select('id')
          .eq('invoice_type_index', 0)
          .gte('created_at', _databaseTimestamp(start))
          .lte('created_at', _databaseTimestamp(end));
      if (_branchId != null) {
        salesQuery = salesQuery.eq('branch_id', _branchId!);
      }
      final salesResponse = await salesQuery;

      final saleIds =
          (salesResponse as List).map((r) => r['id'] as String).toList();
      if (saleIds.isEmpty) return Right([]);

      final itemsResponse = await _supabaseService
          .from('sale_items')
          .select('product_id, name, quantity, total, wholesale_price')
          .inFilter('sale_id', saleIds);

      final Map<String, ProductPerformanceModel> stats = {};
      for (var item in (itemsResponse as List)) {
        final productId = item['product_id'] as String;
        final revenue = (item['total'] as num).toDouble();
        final cost = (item['wholesale_price'] as num).toDouble() *
            (item['quantity'] as num).toDouble();

        if (stats.containsKey(productId)) {
          final existing = stats[productId]!;
          stats[productId] = existing.copyWith(
            quantitySold:
                existing.quantitySold + (item['quantity'] as num).toDouble(),
            revenue: existing.revenue + revenue,
            cost: existing.cost + cost,
          );
        } else {
          stats[productId] = ProductPerformanceModel(
            productId: productId,
            productName: item['name'] as String,
            quantitySold: (item['quantity'] as num).toDouble(),
            revenue: revenue,
            cost: cost,
            profit: 0,
            profitMargin: 0,
          );
        }
      }

      final products = stats.values.map((p) {
        final profit = p.revenue - p.cost;
        return p.copyWith(
          profit: profit,
          profitMargin: p.revenue > 0 ? (profit / p.revenue) * 100 : 0,
        );
      }).toList()
        ..sort((a, b) => b.revenue.compareTo(a.revenue));

      return Right(products.take(limit).toList());
    } catch (e) {
      return Left(CacheFailure("Failed to fetch monthly products"));
    }
  }
}
