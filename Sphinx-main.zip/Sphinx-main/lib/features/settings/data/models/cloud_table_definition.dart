class CloudTableDefinition {
  const CloudTableDefinition({
    required this.key,
    required this.label,
    required this.group,
    required this.selectColumns,
    required this.primaryField,
    required this.secondaryField,
    required this.sortColumn,
    this.branchFilterPath,
    this.countSelectColumns = 'id',
    this.searchColumns = const [],
  });

  final String key;
  final String label;
  final String group;
  final String selectColumns;
  final String primaryField;
  final String secondaryField;
  final String sortColumn;
  final String? branchFilterPath;
  final String countSelectColumns;
  final List<String> searchColumns;

  bool get isBranchOwned => branchFilterPath != null;
}

const cloudBusinessTables = <CloudTableDefinition>[
  CloudTableDefinition(
    key: 'branches',
    label: 'Branches',
    group: 'Organization',
    selectColumns:
        'id,name,address,phone,is_main_branch,is_active,created_at,updated_at',
    primaryField: 'name',
    secondaryField: 'address',
    sortColumn: 'name',
    searchColumns: ['name', 'address', 'phone'],
  ),
  CloudTableDefinition(
    key: 'users',
    label: 'Users',
    group: 'Organization',
    selectColumns:
        'id,username,display_name,role,is_active,is_primary_admin,branch_id,created_at,branches(name)',
    primaryField: 'display_name',
    secondaryField: 'username',
    sortColumn: 'display_name',
    branchFilterPath: 'branch_id',
    searchColumns: ['username', 'display_name', 'role'],
  ),
  CloudTableDefinition(
    key: 'user_permission_overrides',
    label: 'Permission overrides',
    group: 'Organization',
    selectColumns:
        'id,user_id,permission,allowed,created_at,users!inner(display_name,branch_id)',
    primaryField: 'permission',
    secondaryField: 'user_id',
    sortColumn: 'created_at',
    branchFilterPath: 'users.branch_id',
    countSelectColumns: 'id,users!inner(branch_id)',
    searchColumns: ['permission'],
  ),
  CloudTableDefinition(
    key: 'store_settings',
    label: 'Store settings',
    group: 'Organization',
    selectColumns:
        'id,name,address,phone,email,vat,logo_url,created_at,updated_at',
    primaryField: 'name',
    secondaryField: 'address',
    sortColumn: 'name',
    searchColumns: ['name', 'address', 'phone', 'email'],
  ),
  CloudTableDefinition(
    key: 'products',
    label: 'Products',
    group: 'Catalog',
    selectColumns:
        'id,name,barcode,price,min_price,wholesale_price,category,unit_id,is_active,created_at,updated_at',
    primaryField: 'name',
    secondaryField: 'barcode',
    sortColumn: 'name',
    searchColumns: ['name', 'barcode', 'category'],
  ),
  CloudTableDefinition(
    key: 'categories',
    label: 'Categories',
    group: 'Catalog',
    selectColumns: 'id,name,description,is_active,created_at,updated_at',
    primaryField: 'name',
    secondaryField: 'description',
    sortColumn: 'name',
    searchColumns: ['name', 'description'],
  ),
  CloudTableDefinition(
    key: 'product_units',
    label: 'Product units',
    group: 'Catalog',
    selectColumns: 'id,name,abbreviation,is_default,created_at,updated_at',
    primaryField: 'name',
    secondaryField: 'abbreviation',
    sortColumn: 'name',
    searchColumns: ['name', 'abbreviation'],
  ),
  CloudTableDefinition(
    key: 'branch_stock',
    label: 'Branch stock',
    group: 'Catalog',
    selectColumns:
        'id,branch_id,product_id,quantity,min_quantity,updated_at,branches(name),products(name,barcode)',
    primaryField: 'product_id',
    secondaryField: 'quantity',
    sortColumn: 'updated_at',
    branchFilterPath: 'branch_id',
  ),
  CloudTableDefinition(
    key: 'shifts',
    label: 'Shifts',
    group: 'Operations',
    selectColumns:
        'id,user_id,session_number,open_time,close_time,is_open,opening_cash,closing_cash,cash_sales,cash_refunds,card_sales,card_refunds,cash_expenses,branch_id,branches(name)',
    primaryField: 'session_number',
    secondaryField: 'user_id',
    sortColumn: 'open_time',
    branchFilterPath: 'branch_id',
  ),
  CloudTableDefinition(
    key: 'sales',
    label: 'Sales and refunds',
    group: 'Operations',
    selectColumns:
        'id,total,subtotal,discount_amount,items,cashier_name,session_id,invoice_type_index,payment_method,branch_id,created_at,branches(name)',
    primaryField: 'id',
    secondaryField: 'cashier_name',
    sortColumn: 'created_at',
    branchFilterPath: 'branch_id',
    searchColumns: ['id', 'cashier_name', 'payment_method'],
  ),
  CloudTableDefinition(
    key: 'sale_items',
    label: 'Sale items',
    group: 'Operations',
    selectColumns:
        'id,sale_id,product_id,product_barcode,name,price,quantity,total,item_discount,branch_id,created_at,branches(name)',
    primaryField: 'name',
    secondaryField: 'product_barcode',
    sortColumn: 'created_at',
    branchFilterPath: 'branch_id',
    searchColumns: ['name', 'product_barcode', 'sale_id'],
  ),
  CloudTableDefinition(
    key: 'expenses',
    label: 'Expenses',
    group: 'Operations',
    selectColumns:
        'id,title,amount,category,payment_method,shift_id,branch_id,created_at,branches(name)',
    primaryField: 'title',
    secondaryField: 'category',
    sortColumn: 'created_at',
    branchFilterPath: 'branch_id',
    searchColumns: ['title', 'category', 'payment_method'],
  ),
  CloudTableDefinition(
    key: 'inventory_snapshots',
    label: 'Inventory snapshots',
    group: 'Inventory',
    selectColumns:
        'id,user_id,status,notes,branch_id,created_at,finalized_at,branches(name)',
    primaryField: 'id',
    secondaryField: 'status',
    sortColumn: 'created_at',
    branchFilterPath: 'branch_id',
    searchColumns: ['status'],
  ),
  CloudTableDefinition(
    key: 'inventory_snapshot_items',
    label: 'Inventory snapshot items',
    group: 'Inventory',
    selectColumns:
        'id,snapshot_id,product_id,expected_qty,counted_qty,difference,created_at,inventory_snapshots!inner(branch_id),products(name,barcode)',
    primaryField: 'product_id',
    secondaryField: 'snapshot_id',
    sortColumn: 'created_at',
    branchFilterPath: 'inventory_snapshots.branch_id',
    countSelectColumns: 'id,inventory_snapshots!inner(branch_id)',
  ),
];

class CloudTableSummary {
  const CloudTableSummary({required this.definition, required this.count});

  final CloudTableDefinition definition;
  final int count;
}

class CloudTablePage {
  const CloudTablePage({
    required this.rows,
    required this.total,
    required this.page,
    required this.pageSize,
  });

  final List<Map<String, dynamic>> rows;
  final int total;
  final int page;
  final int pageSize;

  bool get hasNext => (page + 1) * pageSize < total;
}
