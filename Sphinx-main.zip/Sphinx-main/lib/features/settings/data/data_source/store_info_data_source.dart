import 'package:sphinx/core/data/services/supabase_service.dart';
import '../models/store_info_model.dart';

class StoreInfoDataSource {
  final SupabaseService _supabaseService;

  StoreInfoDataSource({SupabaseService? supabaseService})
      : _supabaseService = supabaseService ?? SupabaseService();

  Future<StoreInfo> saveStoreInfo(StoreInfo storeInfo) async {
    try {
      final existing = await _supabaseService
          .from('store_settings')
          .select('id')
          .limit(1)
          .maybeSingle();

      final values = {
        'name': storeInfo.name,
        'address': storeInfo.address,
        'phone': storeInfo.phone,
        'email': storeInfo.email,
        'vat': storeInfo.vat,
        'logo_url': storeInfo.logoPath ?? '',
      };

      Map<String, dynamic>? savedRow;
      if (existing != null) {
        savedRow = await _supabaseService
            .from('store_settings')
            .update(values)
            .eq('id', existing['id'])
            .select()
            .maybeSingle();
      } else {
        values['created_at'] = DateTime.now().toUtc().toIso8601String();
        savedRow = await _supabaseService
            .from('store_settings')
            .insert(values)
            .select()
            .maybeSingle();
      }

      if (savedRow == null) {
        throw StateError('Store settings were not saved');
      }
      return _storeInfoFromRow(savedRow);
    } catch (e) {
      throw Exception('Failed to save store info: $e');
    }
  }

  Future<StoreInfo?> getStoreInfo() async {
    try {
      final results = await _supabaseService
          .from('store_settings')
          .select()
          .limit(1)
          .maybeSingle();

      if (results != null) {
        return _storeInfoFromRow(results);
      }
      return null;
    } catch (e) {
      throw Exception('Failed to get store info: $e');
    }
  }

  Future<void> deleteStoreInfo() async {}

  Future<bool> hasStoreInfo() async {
    final info = await getStoreInfo();
    return info != null;
  }

  StoreInfo getDefaultStoreInfo() {
    return StoreInfo(
      name: 'Sphinx',
      phone: '',
      email: '',
      address: '',
      vat: '',
      logoPath: '',
    );
  }

  StoreInfo _storeInfoFromRow(Map<String, dynamic> row) {
    return StoreInfo(
      name: (row['name'] as String?) ?? 'Sphinx',
      address: (row['address'] as String?) ?? '',
      phone: (row['phone'] as String?) ?? '',
      email: (row['email'] as String?) ?? '',
      vat: (row['vat'] as String?) ?? '',
      logoPath: row['logo_url'] as String?,
    );
  }
}
