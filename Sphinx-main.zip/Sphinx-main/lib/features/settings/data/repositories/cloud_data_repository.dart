import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../branches/domain/branch_scope.dart';
import '../models/cloud_table_definition.dart';

class CloudDataRepository {
  CloudDataRepository({SupabaseClient? client})
      : _client = client ?? Supabase.instance.client;

  final SupabaseClient _client;

  Future<List<CloudTableSummary>> getSummaries(BranchScope scope) async {
    final counts = await Future.wait<int>(
      cloudBusinessTables.map((definition) => _count(definition, scope)),
    );
    return [
      for (var index = 0; index < cloudBusinessTables.length; index++)
        CloudTableSummary(
          definition: cloudBusinessTables[index],
          count: counts[index],
        ),
    ];
  }

  Future<CloudTablePage> getRows({
    required CloudTableDefinition table,
    required BranchScope scope,
    required int page,
    required int pageSize,
    String search = '',
  }) async {
    final safePage = page < 0 ? 0 : page;
    final safeSize = pageSize.clamp(25, 100);
    final start = safePage * safeSize;
    final end = start + safeSize - 1;
    final safeSearch = _safeSearch(search);

    dynamic query = _client.from(table.key).select(table.selectColumns);
    query = _applyScope(query, table, scope);
    if (safeSearch.isNotEmpty && table.searchColumns.isNotEmpty) {
      query = query.or(
        table.searchColumns
            .map((column) => '$column.ilike.%$safeSearch%')
            .join(','),
      );
    }
    query = query.order(table.sortColumn, ascending: false).range(start, end);
    final response = await query.count(CountOption.exact);

    return CloudTablePage(
      rows: (response.data as List).cast<Map<String, dynamic>>(),
      total: response.count,
      page: safePage,
      pageSize: safeSize,
    );
  }

  Future<int> _count(
    CloudTableDefinition table,
    BranchScope scope,
  ) async {
    dynamic query = _client.from(table.key).select(table.countSelectColumns);
    query = _applyScope(query, table, scope);
    final response = await query.count(CountOption.exact);
    return response.count;
  }

  dynamic _applyScope(
    dynamic query,
    CloudTableDefinition table,
    BranchScope scope,
  ) {
    if (!table.isBranchOwned || scope.isAll) return query;
    final branchId = scope.branchId;
    if (branchId == null) return query;
    return query.eq(table.branchFilterPath!, branchId);
  }

  String _safeSearch(String value) => value
      .trim()
      .replaceAll(RegExp(r'[%_,().]'), ' ')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();
}
