import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sphinx/features/auth/presentation/cubit/user_cubit.dart';
import '../../../auth/data/models/user_model.dart';
import '../../data/models/store_info_model.dart';
import '../../domain/repository/settings_repository_int.dart';
import '../../../invoice/domain/invoice_pdf_service.dart';
import 'settings_states.dart';

class SettingsCubit extends Cubit<SettingsStates> {
  SettingsCubit({
    required this.userCubit,
    required this.storeRepository,
  }) : super(SettingsInitial()) {
    loadStoreInfo();
  }

  final UserCubit userCubit;
  final StoreInfoRepositoryInt storeRepository;

  static SettingsCubit get(context) => BlocProvider.of(context);

  StoreInfo? _currentStoreInfo;
  StoreInfo? get currentStoreInfo => _currentStoreInfo;

  Future<void> loadStoreInfo() async {
    emit(SettingsLoading());
    final result = await storeRepository.getStoreInfo();

    result.fold(
      (failure) => emit(StoreInfoUpdateFailure(failure.message)),
      (storeInfo) {
        _currentStoreInfo = storeInfo;
        emit(StoreInfoLoaded(storeInfo));
      },
    );
  }

  Future<void> updateStoreInfo(Map<String, String> newStoreInfoMap) async {
    // Check for no changes
    if (_currentStoreInfo != null) {
      final current = _currentStoreInfo!;
      final noChange = (newStoreInfoMap['name'] ?? '') == current.name &&
          (newStoreInfoMap['address'] ?? '') == current.address &&
          (newStoreInfoMap['phone'] ?? '') == current.phone &&
          (newStoreInfoMap['email'] ?? '') == current.email &&
          (newStoreInfoMap['vat'] ?? '') == current.vat &&
          (newStoreInfoMap['logoPath'] ?? '') == (current.logoPath ?? '');
      if (noChange) {
        emit(StoreInfoNoChange());
        emit(StoreInfoLoaded(_currentStoreInfo!));
        return;
      }
    }

    emit(SettingsLoading());
    final newStoreInfo = StoreInfo.fromMap(newStoreInfoMap);
    final result = await storeRepository.saveStoreInfo(newStoreInfo);

    result.fold(
      (failure) {
        emit(StoreInfoUpdateFailure(failure.message));
        if (_currentStoreInfo != null) {
          emit(StoreInfoLoaded(_currentStoreInfo!));
        }
      },
      (savedStoreInfo) async {
        _currentStoreInfo = savedStoreInfo;
        InvoicePdfService.clearLogoCache();
        emit(StoreInfoUpdateSuccess('storeInfoSaved'));
        emit(StoreInfoLoaded(savedStoreInfo));
      },
    );
  }

  String getCurrentUserName() {
    try {
      return userCubit.currentUser.name;
    } catch (e) {
      return 'unknownUser';
    }
  }

  String getCurrentUserType() {
    try {
      return userCubit.currentUser.userType.name;
    } catch (e) {
      return 'cashier';
    }
  }

  bool isAdmin() {
    try {
      return userCubit.currentUser.userType == UserType.manager ||
          userCubit.currentUser.userType == UserType.admin;
    } catch (e) {
      return false;
    }
  }
}
