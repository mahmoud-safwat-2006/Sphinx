import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/di/dependency_injection.dart';
import '../../../../core/utils/responsive_helper.dart';
import '../../../../l10n/app_localizations.dart';
import '../../../branches/domain/branch_scope.dart';
import '../../../branches/presentation/cubit/branch_cubit.dart';
import '../../../branches/presentation/widgets/branch_switcher.dart';
import '../../data/models/cloud_table_definition.dart';
import '../../data/repositories/cloud_data_repository.dart';
import '../widgets/cloud_table_inspector.dart';

class DataManagementScreen extends StatefulWidget {
  const DataManagementScreen({super.key});

  @override
  State<DataManagementScreen> createState() => _DataManagementScreenState();
}

class _DataManagementScreenState extends State<DataManagementScreen> {
  final _repository = getIt<CloudDataRepository>();
  final _searchController = TextEditingController();
  Timer? _searchTimer;
  late Future<List<CloudTableSummary>> _summaries;
  CloudTableDefinition? _selected;
  CloudTablePage? _page;
  bool _loadingRows = false;
  int _requestVersion = 0;
  int _pageIndex = 0;

  BranchScope get _scope => getIt<BranchCubit>().state.scope;

  @override
  void initState() {
    super.initState();
    _summaries = _repository.getSummaries(_scope);
  }

  @override
  void dispose() {
    _searchTimer?.cancel();
    _searchController.dispose();
    super.dispose();
  }

  void _refreshAll() {
    setState(() {
      _summaries = _repository.getSummaries(_scope);
    });
    if (_selected != null) {
      _loadRows(page: 0);
    }
  }

  Future<void> _selectTable(CloudTableDefinition definition) async {
    _selected = definition;
    _pageIndex = 0;
    _searchController.clear();
    if (ResponsiveHelper.isMobileOrTablet(context)) {
      await _loadRows(page: 0);
      if (!mounted) return;
      await showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        useSafeArea: true,
        backgroundColor: Colors.transparent,
        builder: (sheetContext) => FractionallySizedBox(
          heightFactor: .9,
          child: ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
            child: StatefulBuilder(
              builder: (context, setSheetState) => CloudTableInspector(
                definition: definition,
                page: _page,
                loading: _loadingRows,
                searchController: _searchController,
                onSearchChanged: (value) =>
                    _scheduleSearch(value, () => setSheetState(() {})),
                onPrevious: _pageIndex == 0
                    ? null
                    : () async {
                        await _loadRows(page: _pageIndex - 1);
                        setSheetState(() {});
                      },
                onNext: _page?.hasNext == true
                    ? () async {
                        await _loadRows(page: _pageIndex + 1);
                        setSheetState(() {});
                      }
                    : null,
                onClose: () => Navigator.pop(sheetContext),
              ),
            ),
          ),
        ),
      );
      return;
    }
    await _loadRows(page: 0);
  }

  void _scheduleSearch(String value, [VoidCallback? refreshSurface]) {
    _searchTimer?.cancel();
    _searchTimer = Timer(const Duration(milliseconds: 300), () async {
      await _loadRows(page: 0, search: value);
      refreshSurface?.call();
    });
  }

  Future<void> _loadRows({required int page, String? search}) async {
    final table = _selected;
    if (table == null) return;
    final request = ++_requestVersion;
    if (mounted) setState(() => _loadingRows = true);
    try {
      final result = await _repository.getRows(
        table: table,
        scope: _scope,
        page: page,
        pageSize: 25,
        search: search ?? _searchController.text,
      );
      if (!mounted || request != _requestVersion) return;
      setState(() {
        _page = result;
        _pageIndex = result.page;
        _loadingRows = false;
      });
    } catch (_) {
      if (!mounted || request != _requestVersion) return;
      setState(() {
        _page = const CloudTablePage(
          rows: [],
          total: 0,
          page: 0,
          pageSize: 25,
        );
        _loadingRows = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!kDebugMode) {
      return const SizedBox.shrink();
    }

    final l10n = AppLocalizations.of(context);
    final isArabic = l10n.localeName == 'ar';
    return BlocProvider<BranchCubit>.value(
      value: getIt<BranchCubit>(),
      child: BlocListener<BranchCubit, BranchState>(
        listenWhen: (previous, current) =>
            previous.selectionRevision != current.selectionRevision,
        listener: (_, __) => _refreshAll(),
        child: Directionality(
          textDirection: isArabic ? TextDirection.rtl : TextDirection.ltr,
          child: Scaffold(
            backgroundColor: AppColors.backgroundColor,
            appBar: AppBar(
              backgroundColor: Colors.white,
              surfaceTintColor: Colors.transparent,
              title: Row(
                children: [
                  const Icon(
                    LucideIcons.cloud,
                    color: AppColors.primaryColor,
                  ),
                  const SizedBox(width: 10),
                  Text(
                    isArabic ? 'إدارة البيانات السحابية' : 'Cloud Data',
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                ],
              ),
              actions: [
                const BranchSwitcher(),
                IconButton(
                  onPressed: _refreshAll,
                  icon: const Icon(LucideIcons.refreshCw),
                ),
              ],
            ),
            body: LayoutBuilder(
              builder: (context, constraints) {
                final desktop = constraints.maxWidth >= 1000;
                return Padding(
                  padding: EdgeInsets.all(desktop ? 22 : 14),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Expanded(
                        flex: desktop && _selected != null ? 6 : 1,
                        child: _buildSummary(context),
                      ),
                      if (desktop && _selected != null) ...[
                        const SizedBox(width: 16),
                        Expanded(
                          flex: 5,
                          child: CloudTableInspector(
                            definition: _selected!,
                            page: _page,
                            loading: _loadingRows,
                            searchController: _searchController,
                            onSearchChanged: _scheduleSearch,
                            onPrevious: _pageIndex == 0
                                ? null
                                : () => _loadRows(page: _pageIndex - 1),
                            onNext: _page?.hasNext == true
                                ? () => _loadRows(page: _pageIndex + 1)
                                : null,
                            onClose: () => setState(() {
                              _selected = null;
                              _page = null;
                            }),
                          ),
                        ),
                      ],
                    ],
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSummary(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return ListView(
      children: [
        _ConnectionBanner(scope: _scope),
        const SizedBox(height: 16),
        FutureBuilder<List<CloudTableSummary>>(
          future: _summaries,
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const Padding(
                padding: EdgeInsets.all(60),
                child: Center(child: CircularProgressIndicator()),
              );
            }
            if (snapshot.hasError) {
              return _SummaryError(
                message: snapshot.error.toString(),
                onRetry: _refreshAll,
              );
            }
            final summaries = snapshot.data ?? const [];
            final groups = <String, List<CloudTableSummary>>{};
            for (final summary in summaries) {
              groups
                  .putIfAbsent(summary.definition.group, () => [])
                  .add(summary);
            }
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (final entry in groups.entries) ...[
                  Padding(
                    padding: const EdgeInsets.fromLTRB(4, 12, 4, 8),
                    child: Text(
                      entry.key.toUpperCase(),
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        letterSpacing: .8,
                        color: AppColors.mutedColor,
                      ),
                    ),
                  ),
                  LayoutBuilder(
                    builder: (context, constraints) {
                      final columns = constraints.maxWidth >= 720 ? 3 : 1;
                      final width =
                          (constraints.maxWidth - ((columns - 1) * 10)) /
                              columns;
                      return Wrap(
                        spacing: 10,
                        runSpacing: 10,
                        children: [
                          for (final summary in entry.value)
                            SizedBox(
                              width: width,
                              child: _TableSummaryCard(
                                summary: summary,
                                selected:
                                    _selected?.key == summary.definition.key,
                                scopeLabel: summary.definition.isBranchOwned
                                    ? (_scope.isAll
                                        ? l10n.allBranches
                                        : l10n.currentBranch)
                                    : (l10n.localeName == 'ar'
                                        ? 'مشترك'
                                        : 'Shared'),
                                onTap: () => _selectTable(summary.definition),
                              ),
                            ),
                        ],
                      );
                    },
                  ),
                ],
              ],
            );
          },
        ),
      ],
    );
  }
}

class _ConnectionBanner extends StatelessWidget {
  const _ConnectionBanner({required this.scope});

  final BranchScope scope;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppColors.primaryColor.withOpacity(.1),
            AppColors.secondaryColor.withOpacity(.05),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.primaryColor.withOpacity(.22)),
      ),
      child: Row(
        children: [
          const Icon(
            LucideIcons.cloudCheck,
            color: AppColors.successColor,
            size: 28,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Supabase Cloud Database',
                  style: TextStyle(fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 2),
                Text(
                  scope.isAll ? l10n.allBranchesReadOnly : l10n.currentBranch,
                  style: const TextStyle(
                    fontSize: 11,
                    color: AppColors.mutedColor,
                  ),
                ),
              ],
            ),
          ),
          const Icon(
            LucideIcons.shieldCheck,
            color: AppColors.successColor,
          ),
        ],
      ),
    );
  }
}

class _TableSummaryCard extends StatelessWidget {
  const _TableSummaryCard({
    required this.summary,
    required this.selected,
    required this.scopeLabel,
    required this.onTap,
  });

  final CloudTableSummary summary;
  final bool selected;
  final String scopeLabel;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color:
              selected ? AppColors.primaryColor.withOpacity(.07) : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected ? AppColors.primaryColor : AppColors.borderColor,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(
                  LucideIcons.tableProperties,
                  color: AppColors.primaryColor,
                  size: 18,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    summary.definition.label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  '${summary.count}',
                  style: const TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.w900,
                    color: AppColors.primaryColor,
                  ),
                ),
                const Spacer(),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                  decoration: BoxDecoration(
                    color: AppColors.backgroundColor,
                    borderRadius: BorderRadius.circular(7),
                  ),
                  child: Text(
                    scopeLabel,
                    style: const TextStyle(
                      fontSize: 9,
                      color: AppColors.mutedColor,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _SummaryError extends StatelessWidget {
  const _SummaryError({required this.message, required this.onRetry});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: const Icon(
          LucideIcons.circleAlert,
          color: AppColors.errorColor,
        ),
        title: Text(message, maxLines: 2, overflow: TextOverflow.ellipsis),
        trailing: IconButton(
          onPressed: onRetry,
          icon: const Icon(LucideIcons.refreshCw),
        ),
      ),
    );
  }
}
