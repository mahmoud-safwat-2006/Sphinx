import 'package:sphinx/core/di/dependency_injection.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import '../../../../core/functions/messege.dart';
import '../../../../l10n/app_localizations.dart';
import '../../../auth/presentation/cubit/user_cubit.dart';
import '../../../auth/presentation/cubit/user_states.dart';
import '../../../auth/data/models/user_model.dart';
import '../../../branches/presentation/cubit/branch_cubit.dart';
import '../../data/models/user_row.dart';

import 'desktop_user_table.dart';
import 'add_edit_user_dialog.dart';

import 'package:sphinx/core/localization/translation_helper.dart';
import 'package:sphinx/core/constants/app_colors.dart';
import 'package:sphinx/core/security/role_permissions.dart';

class UsersManagementCard extends StatefulWidget {
  const UsersManagementCard({
    super.key,
    required this.isMobile,
  });

  final bool isMobile;

  @override
  State<UsersManagementCard> createState() => _UsersManagementCardState();
}

class _UsersManagementCardState extends State<UsersManagementCard> {
  bool _isCardView = true;
  String? _selectedBranchId;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final isArabic = l10n.localeName == 'ar';

    return BlocConsumer<UserCubit, UserStates>(
      listener: (context, state) {
        if (state is UserSuccess) {
          MotionSnackBarSuccess(
              context, TranslationHelper.translate(context, state.message));
        } else if (state is UserFailure) {
          MotionSnackBarError(
              context, TranslationHelper.translate(context, state.error));
        }
      },
      builder: (context, state) {
        List<UserRow> userRows = [];
        List<User> usersData = [];

        if (state is UsersLoaded) {
          usersData = state.users as List<User>;
        } else {
          usersData = context.read<UserCubit>().users;
        }

        // Filter by selected branch
        if (_selectedBranchId != null) {
          usersData = usersData
              .where((u) =>
                  u.branchId == _selectedBranchId || u.isPrimaryAdmin)
              .toList();
        }

        userRows = _convertUsersToRows(context, usersData);

        return Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: AppColors.borderColor.withOpacity(0.5),
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.015),
                blurRadius: 6,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Card header
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  color: AppColors.surfaceColor,
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(14),
                    topRight: Radius.circular(14),
                  ),
                  border: Border(
                    bottom: BorderSide(
                      color: AppColors.borderColor.withOpacity(0.4),
                    ),
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(7),
                      decoration: BoxDecoration(
                        color: AppColors.primaryColor.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Icon(
                        LucideIcons.users,
                        size: 16,
                        color: AppColors.primaryColor,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        l10n.usersManagement,
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontWeight: FontWeight.w800,
                          fontSize: 14,
                          color: AppColors.textPrimary,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: 8),
                    // View Mode Toggle Segmented Switch
                    Container(
                      padding: const EdgeInsets.all(2),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF1F5F9),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          _buildToggleButton(
                            icon: Icons.grid_view_rounded,
                            isActive: _isCardView,
                            onTap: () => setState(() => _isCardView = true),
                            tooltip: isArabic ? 'عرض بطاقات' : 'Card View',
                          ),
                          _buildToggleButton(
                            icon: Icons.table_chart_rounded,
                            isActive: !_isCardView,
                            onTap: () => setState(() => _isCardView = false),
                            tooltip: isArabic ? 'عرض جدول' : 'Table View',
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    // Branch filter dropdown
                    _buildBranchFilter(l10n),
                    const SizedBox(width: 8),
                    Material(
                      color: Colors.transparent,
                      child: InkWell(
                        onTap: getIt<UserCubit>()
                                .currentUser
                                .hasPermission(Permission.manageUsers)
                            ? () => _showAddUserDialog(context)
                            : null,
                        borderRadius: BorderRadius.circular(10),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 8,
                          ),
                          decoration: BoxDecoration(
                            color: AppColors.primaryColor,
                            borderRadius: BorderRadius.circular(10),
                            boxShadow: [
                              BoxShadow(
                                color: AppColors.primaryColor.withOpacity(0.2),
                                blurRadius: 6,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(LucideIcons.plus,
                                  size: 14, color: Colors.white),
                              const SizedBox(width: 6),
                              Text(
                                widget.isMobile ? l10n.add : l10n.addUser,
                                style: const TextStyle(
                                  fontFamily: 'Cairo',
                                  fontWeight: FontWeight.w700,
                                  fontSize: 12,
                                  color: Colors.white,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              // Card body
              Padding(
                padding: const EdgeInsets.all(16),
                child: userRows.isEmpty
                    ? Center(
                        child: Padding(
                          padding: const EdgeInsets.all(32.0),
                          child: Column(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(16),
                                decoration: BoxDecoration(
                                  color: AppColors.mutedColor.withOpacity(0.05),
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(
                                  LucideIcons.users,
                                  size: 36,
                                  color: AppColors.mutedColor.withOpacity(0.5),
                                ),
                              ),
                              const SizedBox(height: 12),
                              Text(
                                l10n.noUsers,
                                style: TextStyle(
                                  fontFamily: 'Cairo',
                                  fontSize: 13,
                                  color: AppColors.mutedColor,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      )
                    : _isCardView
                        ? _buildCardGridView(usersData, userRows)
                        : DesktopUserTable(
                            users: userRows,
                            usersData: usersData,
                          ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildBranchFilter(AppLocalizations l10n) {
    final branches = getIt<BranchCubit>().state.branches;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      decoration: BoxDecoration(
        color: AppColors.surfaceColor,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: AppColors.borderColor.withOpacity(0.5),
        ),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: _selectedBranchId,
          isDense: true,
          isExpanded: false,
          hint: Text(
            l10n.filterByBranch,
            style: const TextStyle(fontSize: 11, color: AppColors.mutedColor),
          ),
          items: [
            DropdownMenuItem<String>(
              value: null,
              child: Text(l10n.allBranches,
                  style: const TextStyle(fontSize: 11)),
            ),
            ...branches.map((b) => DropdownMenuItem<String>(
                  value: b.id,
                  child: Text(b.name,
                      style: const TextStyle(fontSize: 11),
                      overflow: TextOverflow.ellipsis),
                )),
          ],
          onChanged: (value) => setState(() => _selectedBranchId = value),
        ),
      ),
    );
  }

  Widget _buildToggleButton({
    required IconData icon,
    required bool isActive,
    required VoidCallback onTap,
    required String tooltip,
  }) {
    return Tooltip(
      message: tooltip,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
          decoration: BoxDecoration(
            color: isActive ? Colors.white : Colors.transparent,
            borderRadius: BorderRadius.circular(6),
            boxShadow: isActive
                ? [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 3,
                      offset: const Offset(0, 1),
                    )
                  ]
                : null,
          ),
          child: Icon(
            icon,
            size: 16,
            color: isActive ? AppColors.primaryColor : AppColors.mutedColor,
          ),
        ),
      ),
    );
  }

  Widget _buildCardGridView(List<User> users, List<UserRow> rows) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final crossAxisCount = constraints.maxWidth > 800
            ? 3
            : (constraints.maxWidth > 500 ? 2 : 1);
        final itemWidth = (constraints.maxWidth - ((crossAxisCount - 1) * 12)) /
            crossAxisCount;

        return Wrap(
          spacing: 12,
          runSpacing: 12,
          children: List.generate(users.length, (index) {
            final user = users[index];
            final row = rows[index];
            return SizedBox(
              width: itemWidth,
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border:
                      Border.all(color: AppColors.borderColor.withOpacity(0.6)),
                  boxShadow: [
                    BoxShadow(
                      color: row.roleColor.withOpacity(0.04),
                      blurRadius: 10,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 42,
                          height: 42,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(
                              colors: [
                                row.roleColor.withOpacity(0.2),
                                row.roleColor.withOpacity(0.08),
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            border: Border.all(
                                color: row.roleColor.withOpacity(0.2)),
                          ),
                          child: Center(
                            child: Text(
                              user.name.characters.first.toUpperCase(),
                              style: TextStyle(
                                color: row.roleColor,
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                user.name,
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                  color: AppColors.textPrimary,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(height: 2),
                              Row(
                                children: [
                                  Icon(LucideIcons.user,
                                      size: 11,
                                      color: AppColors.mutedColor
                                          .withOpacity(0.7)),
                                  const SizedBox(width: 4),
                                  Expanded(
                                    child: Text(
                                      user.username,
                                      style: const TextStyle(
                                        fontSize: 11,
                                        color: AppColors.mutedColor,
                                        fontWeight: FontWeight.w500,
                                      ),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ],
                              ),
                              if (user.phone.isNotEmpty) ...[
                                const SizedBox(height: 2),
                                Row(
                                  children: [
                                    Icon(LucideIcons.phone,
                                        size: 11,
                                        color: AppColors.mutedColor
                                            .withOpacity(0.7)),
                                    const SizedBox(width: 4),
                                    Text(
                                      user.phone,
                                      style: const TextStyle(
                                        fontSize: 11,
                                        color: AppColors.mutedColor,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                              if (row.branchLabel.isNotEmpty) ...[
                                const SizedBox(height: 2),
                                Row(
                                  children: [
                                    Icon(
                                      LucideIcons.building2,
                                      size: 11,
                                      color:
                                          AppColors.mutedColor.withOpacity(0.7),
                                    ),
                                    const SizedBox(width: 4),
                                    Expanded(
                                      child: Text(
                                        row.branchLabel,
                                        style: const TextStyle(
                                          fontSize: 11,
                                          color: AppColors.mutedColor,
                                          fontWeight: FontWeight.w500,
                                        ),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Divider(
                        height: 1,
                        color: AppColors.borderColor.withOpacity(0.4)),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: row.roleTint,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                                color: row.roleColor.withOpacity(0.2)),
                          ),
                          child: Text(
                            row.roleLabel,
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              color: row.roleColor,
                            ),
                          ),
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Material(
                              color: AppColors.primaryColor.withOpacity(0.08),
                              borderRadius: BorderRadius.circular(8),
                              child: InkWell(
                                onTap: _canManageTarget(user)
                                    ? () => _editUser(user)
                                    : null,
                                borderRadius: BorderRadius.circular(8),
                                child: const Padding(
                                  padding: EdgeInsets.all(6),
                                  child: Icon(Icons.edit_outlined,
                                      size: 15, color: AppColors.primaryColor),
                                ),
                              ),
                            ),
                            const SizedBox(width: 6),
                            Material(
                              color: Colors.redAccent.withOpacity(0.08),
                              borderRadius: BorderRadius.circular(8),
                              child: InkWell(
                                onTap: _canManageTarget(user)
                                    ? () => _deleteUser(user)
                                    : null,
                                borderRadius: BorderRadius.circular(8),
                                child: const Padding(
                                  padding: EdgeInsets.all(6),
                                  child: Icon(Icons.delete_outline,
                                      size: 15, color: Colors.redAccent),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          }),
        );
      },
    );
  }

  void _editUser(User user) async {
    await showDialog(
      context: context,
      builder: (_) => AddEditUserDialog(userToEdit: user),
    );
  }

  void _deleteUser(User user) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(AppLocalizations.of(context).deleteBackup),
        content: Text(
            '${AppLocalizations.of(context).deleteBackupMessage} ${user.name}?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(AppLocalizations.of(context).cancelPayment),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () {
              Navigator.pop(ctx);
              context.read<UserCubit>().deleteUser(user.username);
            },
            child: Text(AppLocalizations.of(context).deleteBackup),
          ),
        ],
      ),
    );
  }

  List<UserRow> _convertUsersToRows(BuildContext context, List<User> users) {
    final l10n = AppLocalizations.of(context);
    return users.map((user) {
      final isManager =
          user.userType == UserType.manager || user.userType == UserType.admin;
      return UserRow(
        name: user.name,
        email: user.username,
        roleLabel: isManager ? l10n.roleManager : l10n.roleCashier,
        branchLabel: user.isPrimaryAdmin
            ? l10n.allBranches
            : (user.branchName ?? l10n.branchRequired),
        roleTint: isManager ? const Color(0xFFFEE2E2) : const Color(0xFFE0F2FE),
        roleColor:
            isManager ? const Color(0xFFDC2626) : const Color(0xFF0369A1),
        active: true,
        lastLogin: l10n.today,
      );
    }).toList();
  }

  void _showAddUserDialog(BuildContext context) async {
    await showDialog<User>(
      context: context,
      builder: (dialogContext) => const AddEditUserDialog(),
    );
  }

  bool _canManageTarget(User target) {
    final current = getIt<UserCubit>().currentUser;
    if (!current.hasPermission(Permission.manageUsers) ||
        target.isPrimaryAdmin ||
        current.id == target.id) {
      return false;
    }
    return current.isPrimaryAdmin ||
        (current.branchId != null && current.branchId == target.branchId);
  }
}
