import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart' hide User, Session;
import '../../../../l10n/app_localizations.dart';

class DataProtectionCard extends StatefulWidget {
  final bool isMobile;

  const DataProtectionCard({super.key, required this.isMobile});

  @override
  State<DataProtectionCard> createState() => _DataProtectionCardState();
}

class _DataProtectionCardState extends State<DataProtectionCard> {
  bool _isConnected = false;

  @override
  void initState() {
    super.initState();
    _checkStatus();
  }

  void _checkStatus() {
    try {
      final client = Supabase.instance.client;
      final session = client.auth.currentSession;
      setState(() {
        _isConnected = session != null;
      });
    } catch (e) {
      setState(() {
        _isConnected = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(widget.isMobile ? 16 : 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _isConnected
                        ? Colors.green.shade50
                        : Colors.blue.shade50,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    _isConnected ? Icons.cloud_done : Icons.cloud_off,
                    color: _isConnected ? Colors.green : Colors.blue,
                    size: 24,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        l10n.localeName == 'ar'
                            ? 'حالة السحابة'
                            : 'Cloud Status',
                        style: TextStyle(
                          fontSize: widget.isMobile ? 16 : 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        _isConnected
                            ? (l10n.localeName == 'ar'
                                ? 'متصل - البيانات محفوظة في السحابة'
                                : 'Connected - Data saved to cloud')
                            : (l10n.localeName == 'ar'
                                ? 'غير متصل'
                                : 'Disconnected'),
                        style: TextStyle(
                          fontSize: 14,
                          color: _isConnected ? Colors.green : Colors.orange,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
                if (_isConnected)
                  const Icon(Icons.check_circle, color: Colors.green, size: 32),
              ],
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color:
                    _isConnected ? Colors.green.shade50 : Colors.orange.shade50,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: _isConnected
                      ? Colors.green.shade200
                      : Colors.orange.shade200,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _isConnected
                      ? _buildFeature(
                          l10n.localeName == 'ar'
                              ? 'متزامن مع السحابة'
                              : 'Synced to cloud',
                          Icons.sync)
                      : _buildWarning(l10n.localeName == 'ar'
                          ? 'غير متزامن'
                          : 'Not synced'),
                  _buildFeature(
                      l10n.localeName == 'ar'
                          ? 'متعدد الأجهزة'
                          : 'Multi-device',
                      Icons.devices),
                  _buildFeature(
                      l10n.localeName == 'ar'
                          ? 'نسخ احتياطي تلقائي'
                          : 'Auto backup',
                      Icons.backup),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFeature(String text, IconData icon) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        children: [
          Icon(icon, size: 14, color: Colors.green.shade700),
          const SizedBox(width: 8),
          Text(
            text,
            style: TextStyle(fontSize: 12, color: Colors.green.shade800),
          ),
        ],
      ),
    );
  }

  Widget _buildWarning(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        children: [
          Icon(Icons.close, size: 14, color: Colors.orange.shade700),
          const SizedBox(width: 8),
          Text(
            text,
            style: TextStyle(fontSize: 12, color: Colors.orange.shade800),
          ),
        ],
      ),
    );
  }
}
