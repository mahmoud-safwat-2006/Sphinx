import 'package:sphinx/core/di/dependency_injection.dart';
import 'package:sphinx/core/components/local_image_view.dart';
import 'package:sphinx/features/auth/presentation/cubit/user_cubit.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'dart:typed_data';
import 'package:sphinx/features/auth/data/models/user_model.dart';
import '../../../branches/presentation/cubit/branch_cubit.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/functions/messege.dart';
import '../../../../core/security/role_permissions.dart';
import '../../../../l10n/app_localizations.dart';

class AddEditUserDialog extends StatefulWidget {
  final User? userToEdit;
  final bool profileOnly;

  const AddEditUserDialog({
    super.key,
    this.userToEdit,
    this.profileOnly = false,
  });

  @override
  State<AddEditUserDialog> createState() => _AddEditUserDialogState();
}

class _AddEditUserDialogState extends State<AddEditUserDialog> {
  late final TextEditingController nameCtrl;
  late final TextEditingController phoneCtrl;
  late final TextEditingController usernameCtrl;
  late final TextEditingController passwordCtrl;
  late final TextEditingController pinCtrl;
  late UserType selectedUserType;
  late Map<Permission, bool?> _permissionOverrides;
  String? _selectedImagePath;
  Uint8List? _selectedImageBytes;
  String? _selectedImageExtension;
  bool _isPasswordVisible = false;
  String? _selectedBranchId;

  @override
  void initState() {
    super.initState();
    final user = widget.userToEdit;
    nameCtrl = TextEditingController(text: user?.name ?? '');
    phoneCtrl = TextEditingController(text: user?.phone ?? '');
    usernameCtrl = TextEditingController(text: user?.username ?? '');
    passwordCtrl = TextEditingController();
    selectedUserType = user?.userType ?? UserType.cashier;
    _selectedBranchId =
        user?.branchId ?? getIt<UserCubit>().currentUser.branchId;
    _selectedImagePath = user?.imagePath;
    _permissionOverrides = {
      for (final permission in Permission.values)
        permission: user?.permissionOverrides[permission],
    };

    pinCtrl = TextEditingController();
  }

  @override
  void dispose() {
    nameCtrl.dispose();
    phoneCtrl.dispose();
    usernameCtrl.dispose();
    passwordCtrl.dispose();
    pinCtrl.dispose();
    super.dispose();
  }

  bool _isSubmitting = false;

  Future<void> _pickImage() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['jpg', 'jpeg', 'png', 'webp', 'bmp'],
      withData: true,
    );
    final selected = result?.files.single;
    if (selected != null && mounted) {
      setState(() {
        _selectedImagePath = selected.path ?? selected.name;
        _selectedImageBytes = selected.bytes;
        _selectedImageExtension = selected.extension;
      });
    }
  }

  Future<void> _submit() async {
    final l10n = AppLocalizations.of(context);
    if (_isSubmitting) return;

    if (nameCtrl.text.trim().isEmpty ||
        usernameCtrl.text.trim().isEmpty ||
        (widget.userToEdit == null && passwordCtrl.text.trim().isEmpty)) {
      MotionSnackBarError(context, l10n.fillRequiredFields);
      return;
    }
    final isPrimaryTarget = widget.userToEdit?.isPrimaryAdmin == true;
    if (!isPrimaryTarget && _selectedBranchId == null) {
      MotionSnackBarError(context, l10n.branchRequired);
      return;
    }

    setState(() => _isSubmitting = true);

    try {
      final username = usernameCtrl.text.trim();

      final User user = User(
        id: widget.userToEdit?.id,
        name: nameCtrl.text.trim(),
        phone: phoneCtrl.text.trim(),
        username: username,
        userType: selectedUserType,
        imagePath: _selectedImagePath,
        avatarBytes: _selectedImageBytes,
        avatarExtension: _selectedImageExtension,
        permissionOverrides: {
          for (final entry in _permissionOverrides.entries)
            if (entry.value != null) entry.key: entry.value!,
        },
        isPrimaryAdmin: widget.userToEdit?.isPrimaryAdmin ?? false,
        branchId: isPrimaryTarget ? null : _selectedBranchId,
      );

      if (!mounted) return;
      final bool saved;
      if (widget.userToEdit == null) {
        saved = await getIt<UserCubit>().saveUser(
          user,
          password: passwordCtrl.text.trim(),
        );
      } else {
        saved = await getIt<UserCubit>().updateUser(
          user,
          password: passwordCtrl.text.trim().isEmpty
              ? null
              : passwordCtrl.text.trim(),
        );
      }
      if (!mounted) return;
      if (!saved) {
        setState(() => _isSubmitting = false);
        return;
      }

      // Set PIN if provided
      final pin = pinCtrl.text.trim();
      if (pin.isNotEmpty && pin.length == 6) {
        // Fetch user to get ID for PIN setting
        final result =
            await getIt<UserCubit>().userRepository.getUser(username);
        result.fold(
          (_) {},
          (savedUser) async {
            if (savedUser.id != null) {
              await getIt<UserCubit>().setUserPin(savedUser.id!, pin);
            }
          },
        );
      }

      Navigator.of(context).pop(user);
    } catch (_) {
      if (!mounted) return;
      setState(() => _isSubmitting = false);
      MotionSnackBarError(
        context,
        l10n.localeName == 'ar'
            ? 'تعذر حفظ صورة الملف الشخصي'
            : 'Could not save the profile image',
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Container(
        constraints: const BoxConstraints(maxWidth: 600),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: LinearGradient(
            colors: [Colors.white, AppColors.surfaceColor],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Header
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppColors.primaryColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      widget.userToEdit == null
                          ? Icons.person_add_outlined
                          : Icons.edit_outlined,
                      color: AppColors.primaryColor,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      widget.userToEdit == null
                          ? l10n.addNewUser
                          : l10n.editUser,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
              const SizedBox(height: 24),

              _buildImagePicker(l10n),
              const SizedBox(height: 20),

              // Form
              Flexible(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      _buildTextField(
                          nameCtrl, l10n.nameRequired, Icons.person),
                      const SizedBox(height: 16),
                      _buildTextField(phoneCtrl, l10n.storePhone, Icons.phone,
                          keyboardType: TextInputType.phone),
                      const SizedBox(height: 16),
                      _buildTextField(
                        usernameCtrl,
                        l10n.usernameRequired,
                        Icons.account_circle,
                        readOnly: widget.userToEdit != null,
                      ),
                      const SizedBox(height: 16),
                      _buildPasswordField(l10n),
                      const SizedBox(height: 16),
                      _buildPinField(l10n),
                      if (!widget.profileOnly) ...[
                        const SizedBox(height: 16),
                        _buildBranchSelector(l10n),
                        const SizedBox(height: 16),
                        _buildUserTypeDropdown(l10n),
                        if (getIt<UserCubit>()
                            .currentUser
                            .hasPermission(Permission.assignRoles)) ...[
                          const SizedBox(height: 16),
                          _buildPermissionsEditor(),
                        ],
                      ],
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),

              // Actions
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.of(context).pop(),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Text(l10n.cancel),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _isSubmitting ? null : _submit,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primaryColor,
                        foregroundColor: AppColors.primaryForeground,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: _isSubmitting
                          ? const SizedBox(
                              height: 20,
                              width: 20,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2, color: Colors.white))
                          : Text(
                              widget.userToEdit == null
                                  ? l10n.addUserButton
                                  : l10n.saveChanges,
                            ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPermissionsEditor() {
    final l10n = AppLocalizations.of(context);
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.borderColor),
        borderRadius: BorderRadius.circular(12),
      ),
      child: ExpansionTile(
        leading: const Icon(Icons.admin_panel_settings_outlined),
        title: Text(
          l10n.userPowers,
          style: const TextStyle(fontWeight: FontWeight.w700),
        ),
        subtitle: Text(l10n.userPowersSubtitle),
        children: Permission.values.map((permission) {
          final inherited = RolePermissions.hasPermission(
            selectedUserType,
            permission,
          );
          final override = _permissionOverrides[permission];
          final effective = override ?? inherited;
          final locked = widget.userToEdit?.isPrimaryAdmin == true &&
              (permission == Permission.manageUsers ||
                  permission == Permission.assignRoles);
          return SwitchListTile(
            dense: true,
            value: locked ? true : effective,
            onChanged: locked
                ? null
                : (value) => setState(() {
                      _permissionOverrides[permission] =
                          value == inherited ? null : value;
                    }),
            title: Text(_permissionLabel(permission, l10n)),
            subtitle: Text(locked
                ? l10n.requiredForPrimaryAdmin
                : override == null
                    ? l10n.inheritedFromRole(selectedUserType.name)
                    : effective
                        ? l10n.customAllowed
                        : l10n.customDenied),
            secondary: override == null || locked
                ? null
                : IconButton(
                    tooltip: 'Restore role default',
                    icon: const Icon(Icons.settings_backup_restore),
                    onPressed: () => setState(() {
                      _permissionOverrides[permission] = null;
                    }),
                  ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildBranchSelector(AppLocalizations l10n) {
    final currentUser = getIt<UserCubit>().currentUser;
    final branchState = getIt<BranchCubit>().state;
    final isPrimaryTarget = widget.userToEdit?.isPrimaryAdmin == true;
    if (isPrimaryTarget) return const SizedBox.shrink();

    final canMoveBetweenBranches = currentUser.isPrimaryAdmin;
    final branchIds = branchState.branches.map((branch) => branch.id).toSet();
    final selectedValue =
        branchIds.contains(_selectedBranchId) ? _selectedBranchId : null;

    return DropdownButtonFormField<String>(
      value: selectedValue,
      isExpanded: true,
      items: branchState.branches
          .where((branch) => branch.isActive)
          .map(
            (branch) => DropdownMenuItem<String>(
              value: branch.id,
              child: Text(branch.name),
            ),
          )
          .toList(),
      onChanged: canMoveBetweenBranches
          ? (value) => setState(() => _selectedBranchId = value)
          : null,
      decoration: InputDecoration(
        labelText:
            canMoveBetweenBranches ? l10n.selectBranch : l10n.currentBranch,
        prefixIcon: const Icon(Icons.store_outlined),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }

  String _permissionLabel(Permission permission, AppLocalizations l10n) {
    switch (permission) {
      case Permission.posCheckout:
        return l10n.permPosCheckout;
      case Permission.viewInvoices:
        return l10n.permViewInvoices;
      case Permission.deleteInvoices:
        return l10n.permDeleteInvoices;
      case Permission.manageProducts:
        return l10n.permManageProducts;
      case Permission.viewReports:
        return l10n.permViewReports;
      case Permission.manageUsers:
        return l10n.permManageUsers;
      case Permission.assignRoles:
        return l10n.permAssignRoles;
      case Permission.viewAnalytics:
        return l10n.permViewAnalytics;
      case Permission.storeSettings:
        return l10n.permStoreSettings;
      case Permission.dataManagement:
        return l10n.permDataManagement;
      case Permission.manageUnits:
        return l10n.permManageUnits;
      case Permission.applyDiscounts:
        return l10n.permApplyDiscounts;
      case Permission.processRefunds:
        return l10n.permProcessRefunds;
      case Permission.closeShift:
        return l10n.localeName == 'ar' ? 'إغلاق الوردية' : 'Close shift';
    }
  }

  Widget _buildImagePicker(AppLocalizations l10n) {
    final isArabic = l10n.localeName == 'ar';
    final initial = nameCtrl.text.trim().isNotEmpty
        ? nameCtrl.text.trim().substring(0, 1).toUpperCase()
        : '?';
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.primaryColor.withOpacity(.045),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.borderColor),
      ),
      child: Row(
        children: [
          LocalImageView(
            path: _selectedImagePath,
            bytes: _selectedImageBytes,
            width: 72,
            height: 72,
            borderRadius: 36,
            fallback: Container(
              color: AppColors.primaryColor,
              alignment: Alignment.center,
              child: Text(
                initial,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  isArabic ? 'صورة الملف الشخصي' : 'Profile image',
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 3),
                Text(
                  isArabic
                      ? 'اختيارية ويمكن تغييرها لاحقاً'
                      : 'Optional and changeable later',
                  style: const TextStyle(
                    color: AppColors.mutedColor,
                    fontSize: 11,
                  ),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 6,
                  children: [
                    OutlinedButton.icon(
                      onPressed: _pickImage,
                      icon: const Icon(Icons.photo_camera_outlined, size: 17),
                      label: Text(isArabic ? 'اختيار صورة' : 'Choose image'),
                    ),
                    if (_selectedImagePath != null)
                      TextButton.icon(
                        onPressed: () => setState(() {
                          _selectedImagePath = null;
                          _selectedImageBytes = null;
                          _selectedImageExtension = null;
                        }),
                        icon: const Icon(Icons.delete_outline, size: 17),
                        label: Text(isArabic ? 'إزالة' : 'Remove'),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField(
      TextEditingController controller, String label, IconData icon,
      {TextInputType? keyboardType, bool readOnly = false}) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.borderColor),
        boxShadow: [
          BoxShadow(
            color: AppColors.mutedColor.withOpacity(0.1),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: TextField(
        readOnly: readOnly,
        controller: controller,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon, color: AppColors.primaryColor),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 16,
          ),
        ),
      ),
    );
  }

  Widget _buildPasswordField(AppLocalizations l10n) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.borderColor),
        boxShadow: [
          BoxShadow(
            color: AppColors.mutedColor.withOpacity(0.1),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: TextField(
        controller: passwordCtrl,
        obscureText: !_isPasswordVisible,
        decoration: InputDecoration(
          labelText: l10n.passwordRequired,
          prefixIcon: Icon(Icons.lock, color: AppColors.primaryColor),
          suffixIcon: IconButton(
            icon: Icon(
              _isPasswordVisible ? Icons.visibility_off : Icons.visibility,
              color: AppColors.mutedColor,
            ),
            onPressed: () {
              setState(() {
                _isPasswordVisible = !_isPasswordVisible;
              });
            },
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 16,
          ),
        ),
      ),
    );
  }

  Widget _buildPinField(AppLocalizations l10n) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.borderColor),
        boxShadow: [
          BoxShadow(
            color: AppColors.mutedColor.withOpacity(0.1),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: TextField(
        controller: pinCtrl,
        keyboardType: TextInputType.number,
        maxLength: 6,
        obscureText: true,
        decoration: InputDecoration(
          counterText: '',
          labelText: l10n.pinCode,
          prefixIcon: Icon(Icons.pin, color: AppColors.primaryColor),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 16,
          ),
        ),
      ),
    );
  }

  Widget _buildUserTypeDropdown(AppLocalizations l10n) {
    final canAssignRoles =
        getIt<UserCubit>().currentUser.hasPermission(Permission.assignRoles);
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.borderColor),
        boxShadow: [
          BoxShadow(
            color: AppColors.mutedColor.withOpacity(0.1),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: DropdownButtonFormField<UserType>(
        value: selectedUserType,
        items: UserType.values.map((type) {
          final isArabic = l10n.localeName == 'ar';
          String roleText = '';
          switch (type) {
            case UserType.admin:
              roleText = isArabic ? 'مدير النظام (Admin)' : 'Admin';
              break;
            case UserType.manager:
              roleText = isArabic ? 'مدير (Manager)' : 'Manager';
              break;
            case UserType.accountant:
              roleText = isArabic ? 'محاسب (Accountant)' : 'Accountant';
              break;
            case UserType.cashier:
              roleText = isArabic ? 'كاشير (Cashier)' : 'Cashier';
              break;
            case UserType.employee:
              roleText = isArabic ? 'موظف (Employee)' : 'Employee';
              break;
          }
          return DropdownMenuItem(
            value: type,
            child: Text(roleText),
          );
        }).toList(),
        onChanged: widget.userToEdit?.isPrimaryAdmin == true || !canAssignRoles
            ? null
            : (v) => setState(
                  () => selectedUserType = v ?? UserType.cashier,
                ),
        decoration: InputDecoration(
          border: InputBorder.none,
          labelText: l10n.userType,
          prefixIcon:
              Icon(Icons.admin_panel_settings, color: AppColors.primaryColor),
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 16,
          ),
        ),
      ),
    );
  }
}
