import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/data/services/supabase_service.dart';
import '../../../auth/data/models/user_model.dart';
import '../../../branches/presentation/cubit/branch_cubit.dart';
import '../../../../core/di/dependency_injection.dart';

class UserShiftsDialog extends StatefulWidget {
  final User user;

  const UserShiftsDialog({super.key, required this.user});

  @override
  State<UserShiftsDialog> createState() => _UserShiftsDialogState();
}

class _UserShiftsDialogState extends State<UserShiftsDialog> {
  bool _isLoading = true;
  List<Map<String, dynamic>> _shifts = [];
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadShifts();
  }

  Future<void> _loadShifts() async {
    try {
      setState(() {
        _isLoading = true;
        _error = null;
      });

      // Query shifts for this user's profile ID
      // If the user does not have an ID (legacy or missing), fallback to matching username via join
      dynamic response;
      final branchId = getIt<BranchCubit>().effectiveBranchId;
      if (widget.user.id != null) {
        var query = SupabaseService().from('shifts')
            .select()
            .eq('user_id', widget.user.id!);
        if (branchId != null) query = query.eq('branch_id', branchId);
        response = await query.order('open_time', ascending: false);
      } else {
        // Fallback: look up by username join
        var query = SupabaseService().from('shifts')
            .select('*, users!inner(username)')
            .eq('users.username', widget.user.username);
        if (branchId != null) query = query.eq('branch_id', branchId);
        response = await query.order('open_time', ascending: false);
      }

      setState(() {
        _shifts = List<Map<String, dynamic>>.from(response);
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isArabic = Localizations.localeOf(context).languageCode == 'ar';
    final title = isArabic 
        ? 'سجل ورديات ${widget.user.name}' 
        : '${widget.user.name}\'s Shift History';
        
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Container(
        constraints: const BoxConstraints(maxWidth: 800, maxHeight: 600),
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.teal.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(
                    LucideIcons.history,
                    color: Colors.teal,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Cairo',
                    ),
                  ),
                ),
                IconButton(
                  onPressed: () => Navigator.of(context).pop(),
                  icon: const Icon(Icons.close),
                ),
              ],
            ),
            const SizedBox(height: 24),

            // Content
            Expanded(
              child: _buildContent(isArabic),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContent(bool isArabic) {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(color: Colors.teal),
      );
    }

    if (_error != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline, size: 48, color: AppColors.errorColor),
            const SizedBox(height: 16),
            Text(
              isArabic ? 'حدث خطأ أثناء تحميل البيانات' : 'Error loading shift history',
              style: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              _error!,
              style: const TextStyle(color: Colors.grey, fontSize: 12),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _loadShifts,
              style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
              child: Text(isArabic ? 'إعادة المحاولة' : 'Retry'),
            )
          ],
        ),
      );
    }

    if (_shifts.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(LucideIcons.calendar, size: 64, color: Colors.grey.shade300),
            const SizedBox(height: 16),
            Text(
              isArabic ? 'لا توجد ورديات مسجلة لهذا المستخدم' : 'No shift records found for this user',
              style: const TextStyle(
                fontFamily: 'Cairo',
                color: Colors.grey,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      );
    }

    return SingleChildScrollView(
      scrollDirection: Axis.vertical,
      child: Theme(
        data: Theme.of(context).copyWith(
          dividerColor: AppColors.borderColor.withOpacity(0.5),
        ),
        child: DataTable(
          columnSpacing: 16,
          headingRowColor: WidgetStateProperty.all(Colors.teal.withOpacity(0.05)),
          columns: [
            DataColumn(
              label: Text(
                isArabic ? 'التاريخ' : 'Date',
                style: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold),
              ),
            ),
            DataColumn(
              label: Text(
                isArabic ? 'وقت البدء' : 'Open Time',
                style: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold),
              ),
            ),
            DataColumn(
              label: Text(
                isArabic ? 'وقت الانتهاء' : 'Close Time',
                style: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold),
              ),
            ),
            DataColumn(
              label: Text(
                isArabic ? 'الدرج (البدء)' : 'Open Cash',
                style: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold),
              ),
            ),
            DataColumn(
              label: Text(
                isArabic ? 'الدرج (الإغلاق)' : 'Close Cash',
                style: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold),
              ),
            ),
            DataColumn(
              label: Text(
                isArabic ? 'الحالة' : 'Status',
                style: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold),
              ),
            ),
          ],
          rows: _shifts.map((shift) {
            final openTime = DateTime.parse(shift['open_time'] as String);
            final closeTimeStr = shift['close_time'] as String?;
            final closeTime = closeTimeStr != null ? DateTime.parse(closeTimeStr) : null;
            final isOpen = shift['is_open'] as bool? ?? false;
            
            final df = DateFormat('yyyy-MM-dd');
            final tf = DateFormat('hh:mm a');

            return DataRow(
              cells: [
                DataCell(Text(df.format(openTime))),
                DataCell(Text(tf.format(openTime))),
                DataCell(Text(closeTime != null ? tf.format(closeTime) : '—')),
                DataCell(Text('${(shift['opening_cash'] as num?)?.toStringAsFixed(2) ?? '0.00'} EGP')),
                DataCell(Text(isOpen ? '—' : '${(shift['closing_cash'] as num?)?.toStringAsFixed(2) ?? '0.00'} EGP')),
                DataCell(
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: isOpen 
                          ? Colors.green.withOpacity(0.1) 
                          : Colors.grey.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      isOpen 
                          ? (isArabic ? 'نشط' : 'Active') 
                          : (isArabic ? 'مغلق' : 'Closed'),
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        fontSize: 11,
                        color: isOpen ? Colors.green : Colors.grey,
                      ),
                    ),
                  ),
                ),
              ],
            );
          }).toList(),
        ),
      ),
    );
  }
}
