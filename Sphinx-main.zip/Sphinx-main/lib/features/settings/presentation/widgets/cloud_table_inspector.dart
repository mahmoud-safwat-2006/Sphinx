import 'package:flutter/material.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

import '../../../../core/constants/app_colors.dart';
import '../../data/models/cloud_table_definition.dart';

class CloudTableInspector extends StatelessWidget {
  const CloudTableInspector({
    super.key,
    required this.definition,
    required this.page,
    required this.loading,
    required this.searchController,
    required this.onSearchChanged,
    required this.onPrevious,
    required this.onNext,
    required this.onClose,
  });

  final CloudTableDefinition definition;
  final CloudTablePage? page;
  final bool loading;
  final TextEditingController searchController;
  final ValueChanged<String> onSearchChanged;
  final VoidCallback? onPrevious;
  final VoidCallback? onNext;
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    final rows = page?.rows ?? const <Map<String, dynamic>>[];
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.borderColor),
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 8, 10),
            child: Row(
              children: [
                const Icon(
                  LucideIcons.tableProperties,
                  color: AppColors.primaryColor,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    definition.label,
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                IconButton(
                  onPressed: onClose,
                  icon: const Icon(LucideIcons.x),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
            child: TextField(
              controller: searchController,
              onChanged: onSearchChanged,
              decoration: InputDecoration(
                hintText: 'Search ${definition.label.toLowerCase()}',
                prefixIcon: const Icon(LucideIcons.search, size: 18),
                isDense: true,
                filled: true,
                fillColor: AppColors.backgroundColor,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: AppColors.borderColor),
                ),
              ),
            ),
          ),
          const Divider(height: 1),
          Expanded(
            child: loading
                ? const Center(child: CircularProgressIndicator())
                : rows.isEmpty
                    ? const Center(
                        child: Icon(
                          LucideIcons.inbox,
                          size: 42,
                          color: AppColors.mutedColor,
                        ),
                      )
                    : ListView.separated(
                        padding: const EdgeInsets.all(12),
                        itemCount: rows.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 8),
                        itemBuilder: (context, index) => _CloudRowCard(
                          definition: definition,
                          row: rows[index],
                          index: index,
                        ),
                      ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: const BoxDecoration(
              border: Border(top: BorderSide(color: AppColors.borderColor)),
            ),
            child: Row(
              children: [
                Text(
                  page == null
                      ? '0 rows'
                      : '${page!.total} rows · Page ${page!.page + 1}',
                  style: const TextStyle(
                    fontSize: 12,
                    color: AppColors.mutedColor,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const Spacer(),
                IconButton(
                  tooltip: 'Previous page',
                  onPressed: onPrevious,
                  icon: const Icon(LucideIcons.chevronLeft),
                ),
                IconButton(
                  tooltip: 'Next page',
                  onPressed: onNext,
                  icon: const Icon(LucideIcons.chevronRight),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _CloudRowCard extends StatelessWidget {
  const _CloudRowCard({
    required this.definition,
    required this.row,
    required this.index,
  });

  final CloudTableDefinition definition;
  final Map<String, dynamic> row;
  final int index;

  @override
  Widget build(BuildContext context) {
    final primary = _display(row[definition.primaryField]);
    final secondary = _display(row[definition.secondaryField]);
    final branch = row['branches'] as Map<String, dynamic>?;
    return ExpansionTile(
      tilePadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
      childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
      collapsedShape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: const BorderSide(color: AppColors.borderColor),
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: const BorderSide(color: AppColors.primaryColor),
      ),
      leading: CircleAvatar(
        backgroundColor: AppColors.primaryColor.withOpacity(.1),
        child: Text(
          '${index + 1}',
          style: const TextStyle(
            color: AppColors.primaryColor,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
      title: Text(
        primary,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(fontWeight: FontWeight.w700),
      ),
      subtitle: Text(
        [
          if (secondary.isNotEmpty && secondary != primary) secondary,
          if (branch?['name'] != null) branch!['name'].toString(),
        ].join(' · '),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      children: [
        for (final entry in row.entries)
          if (!_isSensitive(entry.key))
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: 150,
                    child: Text(
                      entry.key,
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: AppColors.primaryColor,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Text(
                      _display(entry.value),
                      style: const TextStyle(fontSize: 11),
                    ),
                  ),
                ],
              ),
            ),
      ],
    );
  }

  String _display(dynamic value) {
    if (value == null) return '';
    if (value is Map) {
      return value.values.map(_display).where((v) => v.isNotEmpty).join(' · ');
    }
    return value.toString();
  }

  bool _isSensitive(String key) {
    final normalized = key.toLowerCase();
    return normalized.contains('password') ||
        normalized.contains('token') ||
        normalized.contains('secret') ||
        normalized == 'pin_hash';
  }
}
