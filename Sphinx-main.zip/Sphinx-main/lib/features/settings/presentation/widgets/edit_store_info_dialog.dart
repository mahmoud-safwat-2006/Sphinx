import 'package:flutter/material.dart';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:sphinx/core/data/services/supabase_service.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../../../core/components/app_logo.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/functions/messege.dart';

import '../../../../l10n/app_localizations.dart';

class EditStoreInfoDialog extends StatefulWidget {
  final Map<String, String> storeInfo;

  const EditStoreInfoDialog({
    super.key,
    required this.storeInfo,
  });

  @override
  State<EditStoreInfoDialog> createState() => _EditStoreInfoDialogState();
}

class _EditStoreInfoDialogState extends State<EditStoreInfoDialog> {
  late final TextEditingController nameCtrl;
  late final TextEditingController phoneCtrl;
  late final TextEditingController emailCtrl;
  late final TextEditingController vatCtrl;
  late final TextEditingController addressCtrl;
  String? logoPath;
  Uint8List? _logoBytes;
  String _logoExtension = 'png';
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final rawName = widget.storeInfo['name'] ?? '';
    nameCtrl = TextEditingController(
         text: (rawName == 'Sphinx' || rawName.isEmpty) ? '' : rawName);
    phoneCtrl = TextEditingController(text: widget.storeInfo['phone'] ?? '');
    emailCtrl = TextEditingController(text: widget.storeInfo['email'] ?? '');
    vatCtrl = TextEditingController(text: widget.storeInfo['vat'] ?? '');
    addressCtrl =
        TextEditingController(text: widget.storeInfo['address'] ?? '');
    logoPath = widget.storeInfo['logoPath'];
  }

  @override
  void dispose() {
    nameCtrl.dispose();
    phoneCtrl.dispose();
    emailCtrl.dispose();
    vatCtrl.dispose();
    addressCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final l10n = AppLocalizations.of(context);
    if (_saving) return;
    setState(() => _saving = true);
    try {
      if (_logoBytes != null) {
        final storage = SupabaseService().client.storage.from('assets');
        final objectPath = 'store_logos/logo.$_logoExtension';
        await storage.uploadBinary(
          objectPath,
          _logoBytes!,
          fileOptions: const FileOptions(upsert: true),
        );
        logoPath = storage.getPublicUrl(objectPath);
      }
      // If cleared, the UI falls back to the localized application name.
      final nameToSave = nameCtrl.text.trim();

      final Map<String, String> updatedInfo = {
        'name': nameToSave,
        'phone': phoneCtrl.text.trim(),
        'email': emailCtrl.text.trim(),
        'vat': vatCtrl.text.trim(),
        'address': addressCtrl.text.trim(),
        'logoPath': logoPath ?? '',
      };

      if (mounted) Navigator.of(context).pop(updatedInfo);
    } catch (_) {
      if (mounted) {
        setState(() => _saving = false);
        MotionSnackBarError(context, l10n.error);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Container(
        constraints: const BoxConstraints(maxWidth: 600),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: LinearGradient(
            colors: [Colors.white, AppColors.surfaceColor],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Header
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppColors.primaryColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      Icons.store_outlined,
                      color: AppColors.primaryColor,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      l10n.editStoreInfo,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              // Form
              Flexible(
                child: SingleChildScrollView(
                  child: LayoutBuilder(
                    builder: (context, constraints) {
                      final isWide = constraints.maxWidth > 500;
                      return Column(
                        children: [
                          Center(
                            child: Stack(
                              alignment: Alignment.bottomRight,
                              children: [
                                Container(
                                  width: 100,
                                  height: 100,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                        color: AppColors.borderColor),
                                  ),
                                  child: ClipOval(
                                    child:
                                        _logoBytes != null
                                            ? Image.memory(_logoBytes!, fit: BoxFit.cover)
                                            : logoPath != null && logoPath!.isNotEmpty
                                            ? Image.network(logoPath!,
                                                fit: BoxFit.cover,
                                                errorBuilder: (_, __, ___) => const AppLogo(
                                                  width: 100,
                                                  height: 100,
                                                  fit: BoxFit.cover,
                                                ))
                                            : const AppLogo(
                                                width: 100,
                                                height: 100,
                                                fit: BoxFit.cover),
                                  ),
                                ),
                                GestureDetector(
                                  onTap: _pickImage,
                                  child: Container(
                                    padding: const EdgeInsets.all(6),
                                    decoration: BoxDecoration(
                                      color: AppColors.primaryColor,
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                          color: Colors.white, width: 2),
                                    ),
                                    child: const Icon(Icons.camera_alt,
                                        size: 16, color: Colors.white),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 24),
                          if (isWide) ...[
                            _buildTwoColumnRow([
                              _buildTextField(
                                nameCtrl,
                                l10n.storeNameRequired,
                                Icons.store,
                                null,
                                l10n.appName,
                              ),
                              _buildTextField(
                                phoneCtrl,
                                l10n.storePhone,
                                Icons.phone,
                                TextInputType.phone,
                              ),
                            ]),
                            const SizedBox(height: 16),
                            _buildTwoColumnRow([
                              _buildTextField(
                                emailCtrl,
                                l10n.storeEmail,
                                Icons.email,
                                TextInputType.emailAddress,
                              ),
                              _buildTextField(
                                vatCtrl,
                                l10n.storeVat,
                                Icons.receipt_long,
                              ),
                            ]),
                            const SizedBox(height: 16),
                            _buildTextField(
                              addressCtrl,
                              l10n.storeAddress,
                              Icons.location_on,
                            ),
                          ] else ...[
                            _buildTextField(
                              nameCtrl,
                              l10n.storeNameRequired,
                              Icons.store,
                              null,
                              l10n.appName,
                            ),
                            const SizedBox(height: 16),
                            _buildTextField(
                              phoneCtrl,
                              l10n.storePhone,
                              Icons.phone,
                              TextInputType.phone,
                            ),
                            const SizedBox(height: 16),
                            _buildTextField(
                              emailCtrl,
                              l10n.storeEmail,
                              Icons.email,
                              TextInputType.emailAddress,
                            ),
                            const SizedBox(height: 16),
                            _buildTextField(
                              vatCtrl,
                              l10n.storeVat,
                              Icons.receipt_long,
                            ),
                            const SizedBox(height: 16),
                            _buildTextField(
                              addressCtrl,
                              l10n.storeAddress,
                              Icons.location_on,
                            ),
                          ],
                        ],
                      );
                    },
                  ),
                ),
              ),
              const SizedBox(height: 24),
              // Actions
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.of(context).pop(),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Text(l10n.cancel),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _submit,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primaryColor,
                        foregroundColor: AppColors.primaryForeground,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Text(l10n.saveChanges),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTwoColumnRow(List<Widget> children) {
    return Row(
      children: [
        Expanded(child: children[0]),
        const SizedBox(width: 16),
        Expanded(child: children[1]),
      ],
    );
  }

  Widget _buildTextField(
    TextEditingController controller,
    String label,
    IconData icon, [
    TextInputType? keyboardType,
    String? hintText,
  ]) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.borderColor),
        boxShadow: [
          BoxShadow(
            color: AppColors.mutedColor.withOpacity(0.1),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: TextField(
        controller: controller,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          labelText: label,
          hintText: hintText,
          prefixIcon: Icon(icon, color: AppColors.primaryColor),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 16,
          ),
        ),
      ),
    );
  }

  Future<void> _pickImage() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.image,
        withData: true,
      );

      if (result != null && result.files.single.bytes != null) {
        setState(() {
          _logoBytes = result.files.single.bytes;
          _logoExtension = result.files.single.extension ?? 'png';
        });
      }
    } catch (e) {
      if (mounted) {
        MotionSnackBarError(context, AppLocalizations.of(context).error);
      }
    }
  }
}
