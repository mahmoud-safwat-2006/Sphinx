// ignore_for_file: use_build_context_synchronously

import 'package:sphinx/core/constants/app_colors.dart';
import 'package:sphinx/core/functions/messege.dart';
import 'package:sphinx/l10n/app_localizations.dart';
import 'package:sphinx/features/auth/presentation/login_screen.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SetupWizardScreen extends StatefulWidget {
  const SetupWizardScreen({super.key});

  @override
  State<SetupWizardScreen> createState() => _SetupWizardScreenState();
}

class _SetupWizardScreenState extends State<SetupWizardScreen> {
  int _currentStep = 0;
  bool _isLoading = false;
  bool _isCheckingProfiles = true;

  // Store info
  final _storeNameController = TextEditingController();
  final _storeAddressController = TextEditingController();
  final _storePhoneController = TextEditingController();

  // Admin account
  final _adminNameController = TextEditingController();
  final _adminEmailController = TextEditingController();
  final _adminPasswordController = TextEditingController();
  final _adminPinController = TextEditingController();
  bool _isPasswordVisible = false;

  // Store logo
  Uint8List? _logoBytes;
  String? _logoExtension;

  // Branch info
  final _branchNameController = TextEditingController();
  final _branchAddressController = TextEditingController();
  final _branchPhoneController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _checkExistingProfiles();
  }

  @override
  void dispose() {
    _storeNameController.dispose();
    _storeAddressController.dispose();
    _storePhoneController.dispose();
    _adminNameController.dispose();
    _adminEmailController.dispose();
    _adminPasswordController.dispose();
    _adminPinController.dispose();
    _branchNameController.dispose();
    _branchAddressController.dispose();
    _branchPhoneController.dispose();
    super.dispose();
  }

  Future<void> _checkExistingProfiles() async {
    try {
      final profiles =
          await Supabase.instance.client.from('users').select('id').limit(1);
      if (profiles.isNotEmpty && mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const LoginScreen()),
        );
        return;
      }
    } catch (e) {
      debugPrint('[Setup] Profile check failed: $e');
    }
    if (mounted) setState(() => _isCheckingProfiles = false);
  }

  String _t(BuildContext context, String ar, String en) {
    final l10n = AppLocalizations.of(context);
    return l10n.localeName == 'ar' ? ar : en;
  }

  void _nextStep() {
    if (_currentStep == 0 && !_validateStoreInfo()) return;
    if (_currentStep == 1 && !_validateAdminInfo()) return;
    if (_currentStep == 2 && !_validateBranchInfo()) return;

    if (_currentStep < 2) {
      setState(() => _currentStep++);
    } else {
      _submitSetup();
    }
  }

  void _prevStep() {
    if (_currentStep > 0) {
      setState(() => _currentStep--);
    }
  }

  bool _validateStoreInfo() {
    if (_storeNameController.text.trim().isEmpty) {
      MotionSnackBarError(
        context,
        _t(context, 'يرجى إدخال اسم المتجر', 'Please enter store name'),
      );
      return false;
    }
    if (_storeAddressController.text.trim().isEmpty) {
      MotionSnackBarError(
        context,
        _t(context, 'يرجى إدخال عنوان المتجر', 'Please enter store address'),
      );
      return false;
    }
    if (_storePhoneController.text.trim().isEmpty) {
      MotionSnackBarError(
        context,
        _t(context, 'يرجى إدخال رقم الهاتف', 'Please enter phone number'),
      );
      return false;
    }
    return true;
  }

  bool _validateAdminInfo() {
    if (_adminNameController.text.trim().isEmpty) {
      MotionSnackBarError(
        context,
        _t(context, 'يرجى إدخال اسم المدير', 'Please enter admin name'),
      );
      return false;
    }
    if (_adminEmailController.text.trim().isEmpty) {
      MotionSnackBarError(
        context,
        _t(context, 'يرجى إدخال البريد الإلكتروني',
            'Please enter email address'),
      );
      return false;
    }
    if (_adminPasswordController.text.trim().length < 6) {
      MotionSnackBarError(
        context,
        _t(context, 'كلمة المرور يجب أن تكون 6 أحرف على الأقل',
            'Password must be at least 6 characters'),
      );
      return false;
    }
    if (_adminPinController.text.trim().length != 6) {
      MotionSnackBarError(
        context,
        _t(context, 'يرجى إدخال رمز PIN مكون من 6 أرقام',
            'Please enter a 6-digit PIN'),
      );
      return false;
    }
    return true;
  }

  bool _validateBranchInfo() {
    if (_branchNameController.text.trim().isEmpty) {
      MotionSnackBarError(
        context,
        _t(context, 'يرجى إدخال اسم الفرع', 'Please enter branch name'),
      );
      return false;
    }
    return true;
  }

  Future<void> _submitSetup() async {
    setState(() => _isLoading = true);

    try {
      final email = _adminEmailController.text.trim();
      final password = _adminPasswordController.text.trim();
      final client = Supabase.instance.client;

      // 1. Create Supabase Auth user (or find existing)
      User? authUser;
      try {
        final authResponse = await client.auth.signUp(
          email: email,
          password: password,
          data: {
            'display_name': _adminNameController.text.trim(),
          },
        );
        authUser = authResponse.user;
      } catch (signUpError) {
        if (signUpError.toString().contains('already registered')) {
          try {
            await client.auth.signInWithPassword(
              email: email,
              password: password,
            );
            authUser = client.auth.currentUser;
          } catch (_) {}
        }
      }

      if (authUser == null) {
        if (mounted) {
          MotionSnackBarError(
            context,
            _t(context, 'فشل إنشاء الحساب', 'Failed to create account'),
          );
        }
        return;
      }

      // 2. Create the primary admin profile FIRST (needed for branches RLS)
      await client.from('users').upsert({
        'id': authUser.id,
        'username': email.split('@').first,
        'display_name': _adminNameController.text.trim(),
        'phone': '',
        'role': 'admin',
        'is_primary_admin': true,
        'is_active': true,
        'branch_id': null, // primary admin sees all branches
      }, onConflict: 'id');

      // 3. Set the PIN
      final pin = _adminPinController.text.trim();
      if (pin.isNotEmpty) {
        await client.rpc('set_user_pin', params: {
          'target_user_id': authUser.id,
          'pin_code': pin,
        });
      }

      // 4. Upload logo if provided (skip silently if storage bucket is missing)
      String? logoUrl;
      if (_logoBytes != null && _logoExtension != null) {
        try {
          final ext = _logoExtension!;
          final path = 'store_logos/logo.$ext';
          await client.storage.from('assets').uploadBinary(
                path,
                _logoBytes!,
                fileOptions: FileOptions(
                  contentType: 'image/$ext',
                  upsert: true,
                ),
              );
          logoUrl = client.storage.from('assets').getPublicUrl(path);
        } catch (e) {
          debugPrint('[Setup] Logo upload failed (bucket may not exist): $e');
        }
      }

      // 5. Ensure the main branch exists (seeded by migration, but handle race)
      final existingBranch = await client
          .from('branches')
          .select('id')
          .eq('is_main_branch', true)
          .maybeSingle();
      if (existingBranch == null) {
        await client
            .from('branches')
            .insert({'name': 'الفرع الرئيسي', 'is_main_branch': true});
      }

      // 6. Create the user's first branch (if name provided)
      final branchName = _branchNameController.text.trim();
      if (branchName.isNotEmpty) {
        final branchData = <String, dynamic>{
          'name': branchName,
          'is_main_branch': false,
        };
        if (_branchAddressController.text.trim().isNotEmpty) {
          branchData['address'] = _branchAddressController.text.trim();
        }
        if (_branchPhoneController.text.trim().isNotEmpty) {
          branchData['phone'] = _branchPhoneController.text.trim();
        }
        await client.from('branches').insert(branchData);
      }

      // 7. Update store settings
      final storeUpdate = <String, dynamic>{
        'name': _storeNameController.text.trim(),
        'address': _storeAddressController.text.trim(),
        'phone': _storePhoneController.text.trim(),
      };
      if (logoUrl != null) {
        storeUpdate['logo_url'] = logoUrl;
      }
      // Delete existing and insert fresh
      await client.from('store_settings').delete().neq('id', '');
      await client.from('store_settings').insert(storeUpdate);

      if (mounted) {
        MotionSnackBarSuccess(
          context,
          _t(context, 'تم إعداد النظام بنجاح',
              'System setup completed successfully'),
        );
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const LoginScreen()),
        );
      }
    } on AuthException catch (e) {
      if (mounted) {
        MotionSnackBarError(context, e.message);
      }
    } catch (e) {
      if (mounted) {
        MotionSnackBarError(
          context,
          _t(context, 'حدث خطأ غير متوقع: $e',
              'An unexpected error occurred: $e'),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isCheckingProfiles) {
      return const Scaffold(
        backgroundColor: AppColors.backgroundColor,
        body: Center(
          child: CircularProgressIndicator(color: AppColors.accentColor),
        ),
      );
    }

    final screenWidth = MediaQuery.of(context).size.width;
    final isDesktop = screenWidth >= 900;

    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      body: Center(
        child: isDesktop ? _buildDesktopLayout() : _buildMobileLayout(),
      ),
    );
  }

  Widget _buildDesktopLayout() {
    return Container(
      constraints: BoxConstraints(
        maxWidth: 900,
        maxHeight: MediaQuery.of(context).size.height > 750
            ? 720
            : MediaQuery.of(context).size.height,
      ),
      decoration: BoxDecoration(
        color: AppColors.surfaceColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.borderColor, width: 1),
        boxShadow: [
          BoxShadow(
            color: AppColors.primaryColor.withOpacity(0.08),
            blurRadius: 40,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Expanded(
              flex: 55,
              child: Container(
                color: AppColors.surfaceColor,
                padding: const EdgeInsets.all(40),
                child: SingleChildScrollView(
                  child: _buildFormContent(),
                ),
              ),
            ),
            Expanded(
              flex: 45,
              child: _buildBrandingPanel(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMobileLayout() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 450),
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.surfaceColor,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: AppColors.borderColor, width: 1),
            boxShadow: [
              BoxShadow(
                color: AppColors.primaryColor.withOpacity(0.06),
                blurRadius: 24,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
          child: SingleChildScrollView(child: _buildFormContent()),
        ),
      ),
    );
  }

  Widget _buildBrandingPanel() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [
            AppColors.primaryColor,
            AppColors.sidebarColor,
          ],
          stops: [0.0, 1.0],
        ),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 48),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.accentColor, width: 2),
            ),
            padding: const EdgeInsets.all(12),
            child: Icon(
              LucideIcons.rocket,
              color: AppColors.accentColor,
              size: 32,
            ),
          ),
          const Spacer(),
          Text(
            _t(context, 'إعداد النظام', 'System Setup'),
            style: const TextStyle(
              color: Colors.white,
              fontSize: 28,
              fontWeight: FontWeight.w900,
              height: 1.2,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            _t(
              context,
              'قم بإعداد متجرك وإنشاء حساب المدير الأول للبدء في استخدام النظام',
              'Set up your store and create your first admin account to get started',
            ),
            style: TextStyle(
              color: Colors.white.withOpacity(0.85),
              fontSize: 14,
              height: 1.6,
            ),
          ),
          const Spacer(flex: 2),
          _buildFeatureItem(
            icon: LucideIcons.store,
            title: _t(context, 'إعداد المتجر', 'Store Information'),
          ),
          const SizedBox(height: 8),
          _buildFeatureItem(
            icon: LucideIcons.shieldCheck,
            title: _t(context, 'حساب المدير', 'Admin Account'),
          ),
          const SizedBox(height: 8),
          _buildFeatureItem(
            icon: LucideIcons.building,
            title: _t(context, 'الفرع الأول', 'First Branch'),
          ),
          const SizedBox(height: 8),
          _buildFeatureItem(
            icon: LucideIcons.rocket,
            title: _t(context, 'جاهز للبدء', 'Ready to Go'),
          ),
          const Spacer(flex: 2),
        ],
      ),
    );
  }

  Widget _buildFeatureItem({required IconData icon, required String title}) {
    return Row(
      children: [
        Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            color: AppColors.accentColor.withOpacity(0.15),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(
            icon,
            color: AppColors.accentColor,
            size: 18,
          ),
        ),
        const SizedBox(width: 8),
        Text(
          title,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  Widget _buildFormContent() {
    final l10n = AppLocalizations.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          _t(context, 'إعداد النظام', 'System Setup'),
          style: const TextStyle(
            fontSize: 26,
            fontWeight: FontWeight.bold,
            color: AppColors.textPrimary,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          _t(context, 'خطوة ${_currentStep + 1} من 3',
              'Step ${_currentStep + 1} of 3'),
          style: const TextStyle(
            fontSize: 14,
            color: AppColors.mutedColor,
          ),
        ),
        const SizedBox(height: 8),

        // Step indicator
        _buildStepIndicator(),
        const SizedBox(height: 28),

        // Step content
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 300),
          child: _currentStep == 0
              ? _buildStoreInfoStep(key: const ValueKey(0))
              : _currentStep == 1
                  ? _buildAdminAccountStep(key: const ValueKey(1))
                  : _buildBranchStep(key: const ValueKey(2)),
        ),
        const SizedBox(height: 28),

        // Navigation buttons
        Row(
          children: [
            if (_currentStep > 0)
              Expanded(
                child: SizedBox(
                  height: 52,
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.textSecondary,
                      side: const BorderSide(color: AppColors.borderColor),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    onPressed: _isLoading ? null : _prevStep,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(LucideIcons.arrowLeft, size: 18),
                        const SizedBox(width: 6),
                        Text(
                          l10n.localeName == 'ar' ? 'السابق' : 'Back',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            if (_currentStep > 0) const SizedBox(width: 12),
            Expanded(
              flex: _currentStep == 0 ? 1 : 1,
              child: SizedBox(
                height: 52,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryColor,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onPressed: _isLoading ? null : _nextStep,
                  child: _isLoading
                      ? const SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(
                            strokeWidth: 2.5,
                            valueColor:
                                AlwaysStoppedAnimation<Color>(Colors.white),
                          ),
                        )
                      : Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              _currentStep == 2
                                  ? _t(context, 'إنهاء الإعداد',
                                      'Complete Setup')
                                  : _t(context, 'التالي', 'Next'),
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Icon(
                              _currentStep == 2
                                  ? LucideIcons.check
                                  : LucideIcons.arrowRight,
                              size: 20,
                            ),
                          ],
                        ),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 24),
      ],
    );
  }

  Widget _buildStepIndicator() {
    return Row(
      children: [
        _buildStepCircle(0, _t(context, 'المتجر', 'Store')),
        Expanded(
          child: Container(
            height: 3,
            margin: const EdgeInsets.symmetric(horizontal: 8),
            decoration: BoxDecoration(
              color: _currentStep >= 1
                  ? AppColors.accentColor
                  : AppColors.borderColor,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
        ),
        _buildStepCircle(1, _t(context, 'المدير', 'Admin')),
        Expanded(
          child: Container(
            height: 3,
            margin: const EdgeInsets.symmetric(horizontal: 8),
            decoration: BoxDecoration(
              color: _currentStep >= 2
                  ? AppColors.accentColor
                  : AppColors.borderColor,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
        ),
        _buildStepCircle(2, _t(context, 'الفرع', 'Branch')),
      ],
    );
  }

  Widget _buildStepCircle(int step, String label) {
    final isActive = _currentStep >= step;
    final isCurrent = _currentStep == step;

    return Column(
      children: [
        Container(
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            color: isActive ? AppColors.accentColor : Colors.transparent,
            shape: BoxShape.circle,
            border: Border.all(
              color: isActive ? AppColors.accentColor : AppColors.borderColor,
              width: 2,
            ),
          ),
          child: Center(
            child: isActive
                ? const Icon(LucideIcons.check, color: Colors.white, size: 16)
                : Text(
                    '${step + 1}',
                    style: TextStyle(
                      color: isCurrent
                          ? AppColors.accentColor
                          : AppColors.mutedColor,
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
          ),
        ),
        const SizedBox(height: 6),
        Text(
          label,
          style: TextStyle(
            fontSize: 11,
            fontWeight: isActive ? FontWeight.bold : FontWeight.w500,
            color: isActive ? AppColors.textPrimary : AppColors.mutedColor,
          ),
        ),
      ],
    );
  }

  Widget _buildStoreInfoStep({Key? key}) {
    return Column(
      key: key,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppColors.accentColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(LucideIcons.store,
                  color: AppColors.accentColor, size: 22),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _t(context, 'معلومات المتجر', 'Store Information'),
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  Text(
                    _t(context, 'أدخل تفاصيل متجرك',
                        'Enter your store details'),
                    style: const TextStyle(
                        fontSize: 13, color: AppColors.mutedColor),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 24),
        _buildLabel(_t(context, 'اسم المتجر', 'Store Name')),
        const SizedBox(height: 8),
        _buildTextField(
          controller: _storeNameController,
          icon: LucideIcons.store,
          hint: _t(context, 'مثال: متجر سفينكس', 'e.g., Sphinx Store'),
          textInputAction: TextInputAction.next,
        ),
        const SizedBox(height: 16),
        _buildLabel(
            _t(context, 'شعار المتجر (اختياري)', 'Store Logo (optional)')),
        const SizedBox(height: 8),
        _buildLogoPicker(),
        const SizedBox(height: 16),
        _buildLabel(_t(context, 'العنوان', 'Address')),
        const SizedBox(height: 8),
        _buildTextField(
          controller: _storeAddressController,
          icon: LucideIcons.mapPin,
          hint: _t(context, 'المدينة، المنطقة', 'City, District'),
          textInputAction: TextInputAction.next,
        ),
        const SizedBox(height: 16),
        _buildLabel(_t(context, 'رقم الهاتف', 'Phone Number')),
        const SizedBox(height: 8),
        _buildTextField(
          controller: _storePhoneController,
          icon: LucideIcons.phone,
          hint: _t(context, '+966 5XX XXX XXXX', '+966 5XX XXX XXXX'),
          keyboardType: TextInputType.phone,
          textInputAction: TextInputAction.done,
        ),
      ],
    );
  }

  Widget _buildAdminAccountStep({Key? key}) {
    return Column(
      key: key,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppColors.accentColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(LucideIcons.shieldCheck,
                  color: AppColors.accentColor, size: 22),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _t(context, 'حساب المدير', 'Admin Account'),
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  Text(
                    _t(context, 'إنشاء حساب المدير الأول',
                        'Create the first admin account'),
                    style: const TextStyle(
                        fontSize: 13, color: AppColors.mutedColor),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 24),
        _buildLabel(_t(context, 'الاسم الكامل', 'Full Name')),
        const SizedBox(height: 8),
        _buildTextField(
          controller: _adminNameController,
          icon: LucideIcons.user,
          hint: _t(context, 'اسم المدير', 'Admin name'),
          textInputAction: TextInputAction.next,
        ),
        const SizedBox(height: 16),
        _buildLabel(_t(context, 'البريد الإلكتروني', 'Email Address')),
        const SizedBox(height: 8),
        _buildTextField(
          controller: _adminEmailController,
          icon: LucideIcons.mail,
          hint: 'admin@sphinxpos.com',
          keyboardType: TextInputType.emailAddress,
          textInputAction: TextInputAction.next,
        ),
        const SizedBox(height: 16),
        _buildLabel(_t(context, 'كلمة المرور', 'Password')),
        const SizedBox(height: 8),
        TextFormField(
          controller: _adminPasswordController,
          obscureText: !_isPasswordVisible,
          textDirection: TextDirection.ltr,
          style: const TextStyle(fontSize: 15),
          cursorColor: AppColors.accentColor,
          decoration: InputDecoration(
            hintText: '••••••••',
            hintStyle: TextStyle(
                color: AppColors.mutedColor.withOpacity(0.4), fontSize: 14),
            prefixIcon: const Icon(LucideIcons.lock,
                color: AppColors.mutedColor, size: 20),
            suffixIcon: IconButton(
              icon: Icon(
                _isPasswordVisible ? LucideIcons.eye : LucideIcons.eyeOff,
                color: AppColors.mutedColor,
                size: 20,
              ),
              onPressed: () {
                setState(() {
                  _isPasswordVisible = !_isPasswordVisible;
                });
              },
            ),
            filled: true,
            fillColor: Colors.grey.shade50,
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide:
                  const BorderSide(color: AppColors.borderColor, width: 1.5),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide:
                  const BorderSide(color: AppColors.borderColor, width: 1.5),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide:
                  const BorderSide(color: AppColors.accentColor, width: 2),
            ),
          ),
          textInputAction: TextInputAction.next,
        ),
        const SizedBox(height: 16),
        _buildLabel(_t(context, 'رمز PIN (6 أرقام)', 'PIN Code (6 digits)')),
        const SizedBox(height: 8),
        TextFormField(
          controller: _adminPinController,
          obscureText: true,
          keyboardType: TextInputType.number,
          maxLength: 6,
          textDirection: TextDirection.ltr,
          style: const TextStyle(
            fontSize: 22,
            letterSpacing: 12,
            fontWeight: FontWeight.bold,
          ),
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          cursorColor: AppColors.accentColor,
          decoration: InputDecoration(
            hintText: '• • • • • •',
            hintStyle: TextStyle(
                color: AppColors.mutedColor.withOpacity(0.4),
                fontSize: 20,
                letterSpacing: 8),
            prefixIcon: const Icon(LucideIcons.hash,
                color: AppColors.mutedColor, size: 20),
            filled: true,
            fillColor: Colors.grey.shade50,
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            counterText: '',
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide:
                  const BorderSide(color: AppColors.borderColor, width: 1.5),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide:
                  const BorderSide(color: AppColors.borderColor, width: 1.5),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide:
                  const BorderSide(color: AppColors.accentColor, width: 2),
            ),
          ),
          textInputAction: TextInputAction.done,
        ),
      ],
    );
  }

  Widget _buildBranchStep({Key? key}) {
    return Column(
      key: key,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppColors.accentColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(LucideIcons.building,
                  color: AppColors.accentColor, size: 22),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _t(context, 'الفرع الأول', 'First Branch'),
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  Text(
                    _t(context, 'إنشاء الفرع الرئيسي للمتجر',
                        'Create the main branch for your store'),
                    style: const TextStyle(
                        fontSize: 13, color: AppColors.mutedColor),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 24),
        _buildLabel(_t(context, 'اسم الفرع', 'Branch Name')),
        const SizedBox(height: 8),
        _buildTextField(
          controller: _branchNameController,
          icon: LucideIcons.building,
          hint: _t(context, 'مثال: الفرع الرئيسي', 'e.g., Main Branch'),
          textInputAction: TextInputAction.next,
        ),
        const SizedBox(height: 16),
        _buildLabel(_t(context, 'العنوان (اختياري)', 'Address (optional)')),
        const SizedBox(height: 8),
        _buildTextField(
          controller: _branchAddressController,
          icon: LucideIcons.mapPin,
          hint: _t(context, 'المدينة، المنطقة', 'City, District'),
          textInputAction: TextInputAction.next,
        ),
        const SizedBox(height: 16),
        _buildLabel(_t(context, 'رقم الهاتف (اختياري)', 'Phone (optional)')),
        const SizedBox(height: 8),
        _buildTextField(
          controller: _branchPhoneController,
          icon: LucideIcons.phone,
          hint: _t(context, '+966 5XX XXX XXXX', '+966 5XX XXX XXXX'),
          keyboardType: TextInputType.phone,
          textInputAction: TextInputAction.done,
        ),
      ],
    );
  }

  Widget _buildLabel(String text) {
    return Text(
      text,
      style: const TextStyle(
        fontSize: 13,
        fontWeight: FontWeight.bold,
        color: AppColors.textSecondary,
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required IconData icon,
    required String hint,
    TextInputType? keyboardType,
    TextInputAction? textInputAction,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      textDirection: TextDirection.ltr,
      style: const TextStyle(fontSize: 15),
      cursorColor: AppColors.accentColor,
      textInputAction: textInputAction,
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(
            color: AppColors.mutedColor.withOpacity(0.4), fontSize: 14),
        prefixIcon: Icon(icon, color: AppColors.mutedColor, size: 20),
        filled: true,
        fillColor: Colors.grey.shade50,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide:
              const BorderSide(color: AppColors.borderColor, width: 1.5),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide:
              const BorderSide(color: AppColors.borderColor, width: 1.5),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.accentColor, width: 2),
        ),
      ),
    );
  }

  Widget _buildLogoPicker() {
    return GestureDetector(
      onTap: _pickLogo,
      child: Container(
        height: 100,
        width: double.infinity,
        decoration: BoxDecoration(
          color: Colors.grey.shade50,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: _logoBytes != null
                ? AppColors.accentColor
                : AppColors.borderColor,
            width: _logoBytes != null ? 2 : 1.5,
          ),
        ),
        child: _logoBytes != null
            ? Stack(
                alignment: Alignment.center,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.memory(
                      _logoBytes!,
                      fit: BoxFit.contain,
                      width: 80,
                      height: 80,
                    ),
                  ),
                  Positioned(
                    top: 4,
                    right: 4,
                    child: GestureDetector(
                      onTap: () => setState(() {
                        _logoBytes = null;
                        _logoExtension = null;
                      }),
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: Colors.red,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          LucideIcons.x,
                          color: Colors.white,
                          size: 14,
                        ),
                      ),
                    ),
                  ),
                ],
              )
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    LucideIcons.image,
                    color: AppColors.mutedColor.withOpacity(0.5),
                    size: 32,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _t(context, 'اضغط لاختيار شعار', 'Tap to choose logo'),
                    style: TextStyle(
                      color: AppColors.mutedColor.withOpacity(0.6),
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  Future<void> _pickLogo() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.image,
      withData: true,
    );
    if (result != null && result.files.first.bytes != null) {
      setState(() {
        _logoBytes = result.files.first.bytes;
        _logoExtension = result.files.first.name.split('.').last;
      });
    }
  }
}
