class Expense {
  final String id;
  final String title;
  final double amount;
  final String category;
  final String? notes;
  final DateTime date;
  final String paymentMethod;
  final String? shiftId;

  const Expense({
    required this.id,
    required this.title,
    required this.amount,
    required this.category,
    required this.date,
    this.notes,
    this.paymentMethod = 'cash',
    this.shiftId,
  });

  factory Expense.fromMap(Map<String, dynamic> map) => Expense(
        id: map['id'] as String,
        title: map['title'] as String,
        amount: (map['amount'] as num).toDouble(),
        category: map['category'] as String? ?? 'General',
        notes: map['notes'] as String?,
        date: DateTime.parse(map['created_at'] as String),
        paymentMethod: map['payment_method'] as String? ?? 'cash',
        shiftId: map['shift_id'] as String?,
      );

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'amount': amount,
        'category': category,
        'notes': notes,
        'created_at': date.toUtc().toIso8601String(),
        'payment_method': paymentMethod,
      };
}
