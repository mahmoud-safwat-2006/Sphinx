import 'package:sphinx/core/data/services/supabase_service.dart';
import 'package:sphinx/core/di/dependency_injection.dart';
import 'package:sphinx/core/state/state_synchronizer.dart';
import 'package:sphinx/features/branches/presentation/cubit/branch_cubit.dart';
import 'package:sphinx/features/shifts/presentation/cubit/shift_cubit.dart';
import 'expense_model.dart';

class ExpenseRepository {
  final SupabaseService _supabaseService;

  ExpenseRepository({SupabaseService? supabaseService})
      : _supabaseService = supabaseService ?? SupabaseService();

  Future<List<Expense>> getExpenses({DateTime? start, DateTime? end}) async {
    var query = _supabaseService.from('expenses').select();

    if (start != null) {
      query = query.gte('created_at', start.toUtc().toIso8601String());
    }
    if (end != null) {
      query = query.lte('created_at', end.toUtc().toIso8601String());
    }

    // Filter by branch if one is selected
    final branchId = getIt<BranchCubit>().effectiveBranchId;
    if (branchId != null) {
      query = query.eq('branch_id', branchId);
    }

    final rows = await query.order('created_at', ascending: false) as List;
    return rows
        .map((r) => Expense.fromMap(Map<String, dynamic>.from(r)))
        .toList();
  }

  Future<double> total(DateTime start, DateTime end) async {
    var query = _supabaseService
        .from('expenses')
        .select('amount')
        .gte('created_at', start.toUtc().toIso8601String())
        .lte('created_at', end.toUtc().toIso8601String());

    // Filter by branch if one is selected
    final branchId = getIt<BranchCubit>().effectiveBranchId;
    if (branchId != null) {
      query = query.eq('branch_id', branchId);
    }

    final rows = await query as List;

    double total = 0;
    for (var row in rows) {
      total += (row['amount'] as num?)?.toDouble() ?? 0;
    }
    return total;
  }

  Future<void> add(Expense expense) async {
    final input = expense.toMap()..remove('id');
    final branchId = getIt<BranchCubit>().effectiveBranchId;
    if (branchId == null) throw StateError('branchRequired');
    input['branch_id'] = branchId;
    input['shift_id'] = getIt<ShiftCubit>().state.activeShift?.id;
    await _supabaseService.client.rpc(
      'record_expense',
      params: {'expense_input': input},
    );
    StateSynchronizer.notify(DataChangeEvent(
      entityType: 'expense',
      operation: 'create',
      metadata: {'branch_id': branchId},
    ));
  }

  Future<void> delete(String id) async {
    final branchId = getIt<BranchCubit>().effectiveBranchId;
    if (branchId == null) throw StateError('branchRequired');
    await _supabaseService
        .from('expenses')
        .delete()
        .eq('id', id)
        .eq('branch_id', branchId);
    StateSynchronizer.notify(DataChangeEvent(
      entityType: 'expense',
      operation: 'delete',
      id: id,
      metadata: {'branch_id': branchId},
    ));
  }
}
