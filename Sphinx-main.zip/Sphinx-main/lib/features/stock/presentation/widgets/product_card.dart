// ignore_for_file: deprecated_member_use

import 'package:sphinx/core/di/dependency_injection.dart';
import 'package:sphinx/core/functions/messege.dart';
import 'package:sphinx/core/utils/responsive_helper.dart';
import 'package:sphinx/features/auth/data/models/user_model.dart';
import 'package:sphinx/features/auth/presentation/cubit/user_cubit.dart';
import 'package:flutter/material.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'package:sphinx/core/constants/app_colors.dart';
import 'package:sphinx/l10n/app_localizations.dart';
import '../../../../core/components/local_image_view.dart';
import '../../../products/data/models/product_model.dart';
import 'priorty_chip.dart';
import 'status_chip.dart';

class ProductCard extends StatefulWidget {
  final Product product;
  final VoidCallback onRestock;

  const ProductCard({
    super.key,
    required this.product,
    required this.onRestock,
  });

  @override
  State<ProductCard> createState() => _ProductCardState();
}

class _ProductCardState extends State<ProductCard> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    final isMobile = ResponsiveHelper.isMobile(context);
    if (isMobile) return _buildMobileCard();
    return _buildDesktopCard();
  }

  Widget _buildMobileCard() {
    final l10n = AppLocalizations.of(context);
    final product = widget.product;
    final isOut = product.quantity == 0;
    final isLow =
        product.quantity > 0 && product.quantity < product.minQuantity;
    final userType = getIt<UserCubit>().currentUser.userType;
    final canRestock =
        userType == UserType.manager || userType == UserType.admin;

    final statusColor =
        isOut || isLow ? AppColors.errorColor : AppColors.successColor;

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      decoration: BoxDecoration(
        color: (isOut)
            ? AppColors.errorColor.withOpacity(0.02)
            : (isLow)
                ? AppColors.warningColor.withOpacity(0.02)
                : Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: (isOut)
              ? AppColors.errorColor.withOpacity(0.24)
              : (isLow)
                  ? AppColors.warningColor.withOpacity(0.24)
                  : AppColors.borderColor.withOpacity(0.6),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.01),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: IntrinsicHeight(
          child: Row(
            children: [
              Container(
                width: 4,
                decoration: BoxDecoration(
                  color: statusColor,
                  borderRadius: const BorderRadius.only(
                    topRight: Radius.circular(14),
                    bottomRight: Radius.circular(14),
                  ),
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          LocalImageView(
                            path: product.imagePath,
                            width: 40,
                            height: 40,
                            borderRadius: 10,
                            fallback: Container(
                              color: statusColor.withOpacity(.08),
                              alignment: Alignment.center,
                              child: Icon(LucideIcons.package,
                                  size: 18, color: statusColor),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  product.name,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontFamily: 'Cairo',
                                    fontWeight: FontWeight.w800,
                                    fontSize: 13,
                                    color: AppColors.textPrimary,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  product.barcode,
                                  style: const TextStyle(
                                    fontFamily: 'Cairo',
                                    fontSize: 10,
                                    color: AppColors.mutedColor,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          PriorityChip(priority: product.priority),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          _buildInfoChip(
                            icon: LucideIcons.banknote,
                            label: l10n.sellingPrice,
                            value:
                                "${product.price.toStringAsFixed(2)} ${l10n.currencyEg}",
                            valueColor: AppColors.secondaryColor,
                          ),
                          const SizedBox(width: 8),
                          _buildInfoChip(
                            icon: LucideIcons.package,
                            label: l10n.remaining,
                            value: l10n.unitCount(product.quantity),
                            valueColor: statusColor,
                          ),
                          const Spacer(),
                          StatusChip(isOut: isOut, isLow: isLow),
                        ],
                      ),
                      const SizedBox(height: 10),
                      SizedBox(
                        width: double.infinity,
                        child: Material(
                          color: Colors.transparent,
                          child: InkWell(
                            onTap: canRestock ? widget.onRestock : disableMesg,
                            borderRadius: BorderRadius.circular(10),
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 9),
                              decoration: BoxDecoration(
                                color: AppColors.successColor.withOpacity(0.08),
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                  color:
                                      AppColors.successColor.withOpacity(0.24),
                                ),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(LucideIcons.refreshCw,
                                      size: 13, color: AppColors.successColor),
                                  const SizedBox(width: 6),
                                  Text(
                                    l10n.restock,
                                    style: const TextStyle(
                                      fontFamily: 'Cairo',
                                      fontSize: 11.5,
                                      fontWeight: FontWeight.bold,
                                      color: AppColors.successColor,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoChip({
    required IconData icon,
    required String label,
    required String value,
    required Color valueColor,
  }) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon,
                  size: 11, color: AppColors.mutedColor.withOpacity(0.8)),
              const SizedBox(width: 3),
              Flexible(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 10,
                    color: AppColors.mutedColor,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 2),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.w800,
              fontSize: 11.5,
              color: valueColor,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDesktopCard() {
    final l10n = AppLocalizations.of(context);
    final product = widget.product;
    final isOut = product.quantity == 0;
    final isLow =
        product.quantity > 0 && product.quantity < product.minQuantity;
    final userType = getIt<UserCubit>().currentUser.userType;
    final canRestock =
        userType == UserType.manager || userType == UserType.admin;

    final statusColor =
        isOut || isLow ? AppColors.errorColor : AppColors.successColor;

    final cardBgColor = (isOut)
        ? AppColors.errorColor.withOpacity(0.02)
        : (isLow)
            ? AppColors.warningColor.withOpacity(0.02)
            : Colors.white;

    final cardBorderColor = _isHovered
        ? statusColor.withOpacity(0.5)
        : (isOut)
            ? AppColors.errorColor.withOpacity(0.24)
            : (isLow)
                ? AppColors.warningColor.withOpacity(0.24)
                : AppColors.borderColor.withOpacity(0.6);

    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.symmetric(vertical: 4),
        decoration: BoxDecoration(
          color: cardBgColor,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: cardBorderColor,
            width: _isHovered ? 1.5 : 1,
          ),
          boxShadow: [
            BoxShadow(
              color: _isHovered
                  ? statusColor.withOpacity(0.06)
                  : Colors.black.withOpacity(0.01),
              blurRadius: _isHovered ? 12 : 4,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: IntrinsicHeight(
            child: Row(
              children: [
                Container(
                  width: 4,
                  decoration: BoxDecoration(
                    color: statusColor,
                    borderRadius: const BorderRadius.only(
                      topRight: Radius.circular(14),
                      bottomRight: Radius.circular(14),
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 14),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        LocalImageView(
                          path: product.imagePath,
                          width: 48,
                          height: 48,
                          borderRadius: 11,
                          fallback: Container(
                            color: statusColor.withOpacity(.08),
                            alignment: Alignment.center,
                            child: Icon(LucideIcons.package,
                                size: 21, color: statusColor),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          flex: 4,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Row(
                                children: [
                                  Flexible(
                                    child: Text(
                                      product.name,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        fontFamily: 'Cairo',
                                        fontWeight: FontWeight.w800,
                                        fontSize: 13.5,
                                        color: AppColors.textPrimary,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  PriorityChip(priority: product.priority),
                                ],
                              ),
                              const SizedBox(height: 5),
                              Row(
                                children: [
                                  Icon(LucideIcons.barcode,
                                      size: 12,
                                      color: AppColors.mutedColor
                                          .withOpacity(0.8)),
                                  const SizedBox(width: 6),
                                  Text(
                                    product.barcode,
                                    style: const TextStyle(
                                      fontFamily: 'Cairo',
                                      fontSize: 11,
                                      color: AppColors.mutedColor,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          flex: 2,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Row(
                                children: [
                                  Icon(LucideIcons.banknote,
                                      size: 12,
                                      color: AppColors.mutedColor
                                          .withOpacity(0.8)),
                                  const SizedBox(width: 4),
                                  Flexible(
                                    child: Text(
                                      l10n.sellingPrice,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        fontFamily: 'Cairo',
                                        fontSize: 11,
                                        color: AppColors.mutedColor,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 3),
                              Text(
                                "${product.price.toStringAsFixed(2)} ${l10n.currencyEg}",
                                style: const TextStyle(
                                  fontFamily: 'Cairo',
                                  fontWeight: FontWeight.w800,
                                  fontSize: 13,
                                  color: AppColors.secondaryColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Expanded(
                          flex: 2,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Row(
                                children: [
                                  Icon(LucideIcons.package,
                                      size: 12,
                                      color: AppColors.mutedColor
                                          .withOpacity(0.8)),
                                  const SizedBox(width: 4),
                                  Flexible(
                                    child: Text(
                                      l10n.remaining,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        fontFamily: 'Cairo',
                                        fontSize: 11,
                                        color: AppColors.mutedColor,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 3),
                              Row(
                                children: [
                                  Flexible(
                                    child: Text(
                                      l10n.unitCount(product.quantity),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        fontFamily: 'Cairo',
                                        fontWeight: FontWeight.w800,
                                        fontSize: 13,
                                        color: statusColor,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  StatusChip(isOut: isOut, isLow: isLow),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 12),
                        SizedBox(
                          width: 130,
                          child: Material(
                            color: Colors.transparent,
                            child: InkWell(
                              onTap:
                                  canRestock ? widget.onRestock : disableMesg,
                              borderRadius: BorderRadius.circular(10),
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 150),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 12, vertical: 10),
                                decoration: BoxDecoration(
                                  color: _isHovered
                                      ? AppColors.successColor
                                      : AppColors.successColor
                                          .withOpacity(0.08),
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                    color: AppColors.successColor
                                        .withOpacity(0.24),
                                  ),
                                  boxShadow: _isHovered
                                      ? [
                                          BoxShadow(
                                            color: AppColors.successColor
                                                .withOpacity(0.12),
                                            blurRadius: 6,
                                            offset: const Offset(0, 2),
                                          )
                                        ]
                                      : null,
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      LucideIcons.refreshCw,
                                      size: 13,
                                      color: _isHovered
                                          ? Colors.white
                                          : AppColors.successColor,
                                    ),
                                    const SizedBox(width: 6),
                                    FittedBox(
                                      fit: BoxFit.scaleDown,
                                      child: Text(
                                        l10n.restock,
                                        style: TextStyle(
                                          fontFamily: 'Cairo',
                                          fontSize: 11.5,
                                          fontWeight: FontWeight.bold,
                                          color: _isHovered
                                              ? Colors.white
                                              : AppColors.successColor,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void disableMesg() {
    final l10n = AppLocalizations.of(context);
    MotionSnackBarWarning(context, l10n.errAccessDenied);
  }
}
