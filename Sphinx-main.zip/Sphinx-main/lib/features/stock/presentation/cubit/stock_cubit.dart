import 'dart:async';
import 'package:sphinx/features/products/data/models/product_model.dart';
import 'package:sphinx/features/products/domain/product_repository_int.dart';
import 'package:sphinx/features/stock/presentation/cubit/stock_states.dart'
    show StockErrorState, StockLoadingState, StockStates, StockSucssesState;
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../../../core/di/dependency_injection.dart';
import '../../../../core/state/state_synchronizer.dart';
import '../../../branches/presentation/cubit/branch_cubit.dart';

class StockCubit extends Cubit<StockStates> {
  StreamSubscription<DataChangeEvent>? _changeSubscription;

  StockCubit({required this.productRepository}) : super(StockLoadingState()) {
    _changeSubscription = StateSynchronizer.events.listen((event) {
      if (event.entityType == 'sale' ||
          event.entityType == 'product' ||
          event.entityType == 'product_stock') {
        loadData();
      }
    });
  }

  @override
  Future<void> close() {
    _changeSubscription?.cancel();
    return super.close();
  }

  ProductRepositoryInt productRepository;
  List<Product> products = [];

  String filter = 'all';
  int lowStockCount = 0;
  int outOfStockCount = 0;
  int totalCount = 0;
  List<Product> sendData() {
    return products.where((p) => p.quantity <= p.minQuantity).toList();
  }

  void loadData() async {
    final branchId = getIt<BranchCubit>().effectiveBranchId;
    final result = await productRepository.getAllProduct(branchId: branchId);
    result.fold((error) => emit(StockErrorState(error.message)), (data) {
      products = data;
      _calculateCounts();
      filterProducts();
    });
  }

  void _calculateCounts() {
    outOfStockCount = products.where((p) => p.quantity == 0).length;
    lowStockCount = products
        .where((p) => p.quantity > 0 && p.quantity <= p.minQuantity)
        .length;
    totalCount = lowStockCount + outOfStockCount;
  }

  Future<void> restockProduct(Product product, double quantity) async {
    final branchId = getIt<BranchCubit>().effectiveBranchId;
    if (branchId == null) return;

    // Optimistic update
    product.quantity += quantity;

    // Recalculate and update UI immediately
    _calculateCounts();
    filterProducts();

    // Persist to DB: update branch_stock
    try {
      await Supabase.instance.client.from('branch_stock').upsert({
        'branch_id': branchId,
        'product_id': product.id,
        'quantity': product.quantity,
        'min_quantity': product.minQuantity,
      }, onConflict: 'branch_id,product_id');
    } catch (e) {
      await Supabase.instance.client
          .from('branch_stock')
          .update({
            'quantity': product.quantity,
            'min_quantity': product.minQuantity,
          })
          .eq('branch_id', branchId)
          .eq('product_id', product.id!);
    }
  }

  void filterProducts() {
    final List<Product> filtered = products.where((p) {
      if (filter == 'all' && totalCount > 0) {
        return (p.quantity <= p.minQuantity);
      }
      if (filter == 'low' && lowStockCount > 0) {
        return (p.quantity > 0 && p.quantity <= p.minQuantity);
      }
      if (filter == 'out' && outOfStockCount > 0) return p.quantity == 0;
      return false;
    }).toList();
    emit(StockSucssesState(products: filtered));
  }
}
