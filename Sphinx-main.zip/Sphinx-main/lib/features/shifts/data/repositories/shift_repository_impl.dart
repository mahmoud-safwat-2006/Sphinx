// ignore_for_file: avoid_print

import 'package:sphinx/core/data/services/supabase_service.dart';
import 'package:sphinx/core/di/dependency_injection.dart';

import 'package:sphinx/features/auth/data/models/user_model.dart';
import 'package:sphinx/features/branches/presentation/cubit/branch_cubit.dart';
import 'package:sphinx/features/pos/data/models/sale_model.dart';
import '../models/daily_report_model.dart';
import '../models/product_performance_model.dart';
import '../models/shift_model.dart';
import '../../domain/shift_repository.dart';

class SessionRepositoryImpl implements ShiftRepository {
  static const _shiftSelect =
      '*, opened_by:users!shifts_user_id_fkey(display_name, username, avatar_url)';
  final SupabaseService _supabaseService;
  SessionRepositoryImpl({SupabaseService? supabaseService})
      : _supabaseService = supabaseService ?? SupabaseService();

  Session? _cachedSession;

  Future<void> loadCurrentSession() async {
    try {
      final scope = getIt<BranchCubit>().state.scope;
      if (!scope.isSingleBranch) {
        _cachedSession = null;
        return;
      }
      final userId = _supabaseService.client.auth.currentUser?.id;
      if (userId == null) {
        _cachedSession = null;
        return;
      }
      var query = _supabaseService
          .from('shifts')
          .select(_shiftSelect)
          .eq('user_id', userId)
          .eq('is_open', true);
      query = query.eq('branch_id', scope.branchId!);
      final results = await query.limit(1);
      if ((results as List).isNotEmpty) {
        _cachedSession = Session.fromMap(results.first);
      } else {
        _cachedSession = null;
      }
    } catch (e) {
      print('Failed to load session: $e');
    }
  }

  Session? getCurrentSession() => _cachedSession;

  @override
  Future<Session?> getActiveShift(String userId) async {
    final scope = getIt<BranchCubit>().state.scope;
    if (!scope.isSingleBranch) {
      _cachedSession = null;
      return null;
    }
    final query = _supabaseService
        .from('shifts')
        .select(_shiftSelect)
        .eq('user_id', userId)
        .eq('is_open', true)
        .eq('branch_id', scope.branchId!);
    final row = await query.maybeSingle();
    _cachedSession =
        row == null ? null : Session.fromMap(Map<String, dynamic>.from(row));
    if (_cachedSession != null) {
      await _hydrateOpenShiftFinancials([_cachedSession!]);
    }
    return _cachedSession;
  }

  @override
  Future<Session> openShift(double openingCash) async {
    final scope = getIt<BranchCubit>().state.scope;
    if (!scope.isSingleBranch) throw StateError('branchRequired');
    final branchId = scope.branchId!;
    final row = await _supabaseService.client.rpc(
      'open_shift',
      params: {
        'opening_cash_input': openingCash,
        'branch_id_input': branchId,
      },
    );
    final id = _extractRpcRow(row)['id'] as String;
    final hydrated = await _supabaseService
        .from('shifts')
        .select(_shiftSelect)
        .eq('id', id)
        .single();
    _cachedSession = Session.fromMap(Map<String, dynamic>.from(hydrated));
    return _cachedSession!;
  }

  @override
  Future<Session> closeShift({
    required String shiftId,
    required double closingCash,
  }) async {
    final row = await _supabaseService.client.rpc(
      'close_shift',
      params: {
        'shift_id_input': shiftId,
        'closing_cash_input': closingCash,
      },
    );
    final closed = Session.fromMap(_extractRpcRow(row));
    if (_cachedSession?.id == shiftId) {
      _cachedSession = null;
    }
    return closed;
  }

  @override
  Future<List<Session>> getShifts({
    String filter = 'all',
    String search = '',
  }) async {
    final open = await getOpenShifts();
    final closed = await getClosedSessions();
    Iterable<Session> result = [...open, ...closed]
      ..sort((a, b) => b.openTime.compareTo(a.openTime));
    if (filter == 'open') {
      result = result.where((shift) => shift.isOpen);
    } else if (filter == 'closed') {
      result = result.where((shift) => !shift.isOpen);
    }
    final normalized = search.trim().toLowerCase();
    if (normalized.isNotEmpty) {
      result = result.where(
        (shift) =>
            shift.openedByName.toLowerCase().contains(normalized) ||
            shift.sessionNumber.toString().contains(normalized),
      );
    }
    return result.toList(growable: false);
  }

  @override
  Stream<String> watchShiftChanges(String userId) {
    return _supabaseService.client
        .from('shifts')
        .stream(primaryKey: ['id'])
        .eq('user_id', userId)
        .map((_) => userId)
        .handleError((_) {});
  }

  Future<Session> openSession(User user, {double startingCash = 0}) async {
    if (_cachedSession != null && _cachedSession!.isOpen) {
      return _cachedSession!;
    }

    await loadCurrentSession();
    if (_cachedSession != null && _cachedSession!.isOpen) {
      return _cachedSession!;
    }

    return openShift(startingCash);
  }

  Future<DailyReport> closeSession(
    User user, {
    required double totalSales,
    required double totalRefunds,
    required double netRevenue,
    required int totalTransactions,
    required List<ProductPerformanceModel> topProducts,
    List<ProductPerformanceModel> refundedProducts = const [],
    List<Sale> transactions = const [],
    double closingCash = 0,
  }) async {
    if (_cachedSession == null) {
      await loadCurrentSession();
    }

    final session = _cachedSession;
    if (session == null) {
      throw Exception("No open session found to close.");
    }

    final now = DateTime.now();
    final reportId = "${session.id}_REPORT";

    final report = DailyReport(
      id: reportId,
      sessionId: session.id,
      date: now,
      totalSales: totalSales,
      totalRefunds: totalRefunds,
      netRevenue: netRevenue,
      totalTransactions: totalTransactions,
      closedByUserName: user.name,
      topProducts: topProducts,
      refundedProducts: refundedProducts,
      transactions: transactions,
    );

    final closed = await closeShift(
      shiftId: session.id,
      closingCash: closingCash,
    );
    session.isOpen = closed.isOpen;
    session.closeTime = closed.closeTime;
    session.closedByUserId = closed.closedByUserId;
    session.dailyReportId = report.id;
    session.closingCash = closed.closingCash;
    session.systemExpectedCash = closed.systemExpectedCash;
    session.cashDifference = closed.cashDifference;
    session.cashSales = closed.cashSales;
    session.cashRefunds = closed.cashRefunds;
    session.cardSales = closed.cardSales;
    session.cardRefunds = closed.cardRefunds;
    session.cashExpenses = closed.cashExpenses;
    return report;
  }

  Future<List<Session>> getClosedSessions() async {
    try {
      var query = _supabaseService
          .from('shifts')
          .select(_shiftSelect)
          .eq('is_open', false);

      final branchId = getIt<BranchCubit>().effectiveBranchId;
      if (branchId != null) {
        query = query.eq('branch_id', branchId);
      }

      final results = await query.order('open_time', ascending: false);

      return (results as List).map((row) => Session.fromMap(row)).toList();
    } catch (e) {
      print('ERROR getting closed sessions: $e');
      return [];
    }
  }

  Future<void> _hydrateOpenShiftFinancials(List<Session> shifts) async {
    if (shifts.isEmpty) return;

    final shiftIds = shifts.map((shift) => shift.id).toList(growable: false);
    final branchId = getIt<BranchCubit>().effectiveBranchId;
    var salesQuery = _supabaseService
        .from('sales')
        .select('session_id, total, payment_method, invoice_type_index')
        .inFilter('session_id', shiftIds);
    if (branchId != null) {
      salesQuery = salesQuery.eq('branch_id', branchId);
    }
    final sales = await salesQuery;
    var expensesQuery = _supabaseService
        .from('expenses')
        .select('shift_id, amount')
        .inFilter('shift_id', shiftIds);
    if (branchId != null) {
      expensesQuery = expensesQuery.eq('branch_id', branchId);
    }
    final expenses = await expensesQuery;
    final byId = {for (final shift in shifts) shift.id: shift};

    for (final shift in shifts) {
      shift.cashSales = 0;
      shift.cashRefunds = 0;
      shift.cardSales = 0;
      shift.cardRefunds = 0;
      shift.cashExpenses = 0;
    }

    for (final row in sales as List) {
      final shift = byId[row['shift_id'] as String?];
      if (shift == null) continue;
      final amount = (row['total'] as num?)?.toDouble() ?? 0;
      final isRefund = (row['invoice_type_index'] as int?) == 1;
      final isCard = row['payment_method'] == 'card';
      if (isCard) {
        if (isRefund) {
          shift.cardRefunds += amount;
        } else {
          shift.cardSales += amount;
        }
      } else if (isRefund) {
        shift.cashRefunds += amount;
      } else {
        shift.cashSales += amount;
      }
    }

    for (final row in expenses as List) {
      final shift = byId[row['shift_id'] as String?];
      if (shift == null) continue;
      shift.cashExpenses += (row['amount'] as num?)?.toDouble() ?? 0;
    }

    for (final shift in shifts) {
      shift.systemExpectedCash = shift.expectedCashPreview;
    }
  }

  Future<List<Session>> getOpenShifts() async {
    try {
      var query = _supabaseService
          .from('shifts')
          .select(_shiftSelect)
          .eq('is_open', true);

      final branchId = getIt<BranchCubit>().effectiveBranchId;
      if (branchId != null) {
        query = query.eq('branch_id', branchId);
      }

      final results = await query.order('open_time', ascending: false);

      final shifts =
          (results as List).map((row) => Session.fromMap(row)).toList();
      await _hydrateOpenShiftFinancials(shifts);
      return shifts;
    } catch (e) {
      print('ERROR getting open shifts: $e');
      return [];
    }
  }

  Future<void> closeAllOpenShifts(User user, {double closingCash = 0}) async {
    final openShifts = await getOpenShifts();
    for (final shift in openShifts) {
      await closeShift(shiftId: shift.id, closingCash: closingCash);
    }
  }

  Map<String, dynamic> _extractRpcRow(dynamic value) {
    if (value is Map<String, dynamic>) return value;
    if (value is Map) return Map<String, dynamic>.from(value);
    if (value is List && value.isNotEmpty) {
      final first = value.first;
      if (first is Map<String, dynamic>) return first;
      if (first is Map) return Map<String, dynamic>.from(first);
    }
    throw StateError('Shift operation returned no row');
  }

  Future<void> deleteSession(Session session) async {
    if (session.isOpen) {
      throw Exception('Cannot delete an open session.');
    }

    await _supabaseService
        .from('sales')
        .update({'session_id': null}).eq('session_id', session.id);

    await _supabaseService.from('shifts').delete().eq('id', session.id);
  }

  Future<int> deleteSessionsInRange(DateTime start, DateTime end) async {
    var query = _supabaseService
        .from('shifts')
        .select('id')
        .eq('is_open', false)
        .gte('close_time', start.toUtc().toIso8601String())
        .lte('close_time', end.toUtc().toIso8601String());

    final branchId = getIt<BranchCubit>().effectiveBranchId;
    if (branchId != null) {
      query = query.eq('branch_id', branchId);
    }

    final results = await query;

    final count = (results as List).length;
    if (count > 0) {
      final ids = results.map((r) => r['id'] as String).toList();

      await _supabaseService
          .from('sales')
          .update({'session_id': null}).inFilter('session_id', ids);

      await _supabaseService.from('shifts').delete().inFilter('id', ids);
    }
    return count;
  }

  Future<List<Session>> getSessionsInRange(DateTime start, DateTime end) async {
    try {
      var query = _supabaseService
          .from('shifts')
          .select(_shiftSelect)
          .eq('is_open', false)
          .gte('close_time', start.toUtc().toIso8601String())
          .lte('close_time', end.toUtc().toIso8601String());

      final branchId = getIt<BranchCubit>().effectiveBranchId;
      if (branchId != null) {
        query = query.eq('branch_id', branchId);
      }

      final results = await query.order('close_time', ascending: false);

      return (results as List).map((row) => Session.fromMap(row)).toList();
    } catch (e) {
      print('Failed to get sessions in range: $e');
      return [];
    }
  }

  Future<int> getSessionsCount() async {
    try {
      var query =
          _supabaseService.from('shifts').select('id').eq('is_open', false);

      final branchId = getIt<BranchCubit>().effectiveBranchId;
      if (branchId != null) {
        query = query.eq('branch_id', branchId);
      }

      final result = await query;
      return (result as List).length;
    } catch (e) {
      print('Failed to get sessions count: $e');
      return 0;
    }
  }

  Future<DailyReport?> generateDailyReport(String sessionId) async {
    try {
      var shiftQuery = _supabaseService
          .from('shifts')
          .select(_shiftSelect)
          .eq('id', sessionId);
      final branchId = getIt<BranchCubit>().effectiveBranchId;
      if (branchId != null) {
        shiftQuery = shiftQuery.eq('branch_id', branchId);
      }
      final sessionRows = await shiftQuery;
      if ((sessionRows as List).isEmpty) return null;
      final session = Session.fromMap(sessionRows.first);

      final saleRows = await _supabaseService
          .from('sales')
          .select()
          .eq('session_id', sessionId);

      double totalSales = 0;
      double totalRefunds = 0;
      int transactionsCount = (saleRows as List).length;

      final saleIds = (saleRows).map((r) => r['id'] as String).toList();
      Map<String, List<SaleItem>> itemsMap = {};

      if (saleIds.isNotEmpty) {
        final allItems = await _supabaseService
            .from('sale_items')
            .select()
            .inFilter('sale_id', saleIds);

        for (var row in (allItems as List)) {
          final sid = row['sale_id'] as String;
          if (!itemsMap.containsKey(sid)) itemsMap[sid] = [];
          itemsMap[sid]!.add(SaleItem(
            productId: row['product_id'] as String,
            productBarcode: row['product_barcode'] as String? ?? '',
            name: row['name'] as String,
            price: (row['price'] as num).toDouble(),
            salePrice: (row['sale_price'] as num?)?.toDouble() ??
                (row['price'] as num).toDouble(),
            itemDiscount: (row['item_discount'] as num?)?.toDouble() ?? 0,
            unitAbbreviation: row['unit_abbreviation'] as String? ?? '',
            quantity: (row['quantity'] as num).toDouble(),
            total: (row['subtotal'] as num).toDouble(),
            wholesalePrice: (row['wholesale_price'] as num?)?.toDouble() ?? 0.0,
            refundedQuantity:
                (row['refunded_quantity'] as num?)?.toDouble() ?? 0,
          ));
        }
      }

      List<Sale> transactions = [];
      List<ProductPerformanceModel> topProducts = [];
      List<ProductPerformanceModel> refundedProducts = [];
      Map<String, ProductPerformanceModel> productStats = {};
      Map<String, ProductPerformanceModel> refundStats = {};

      for (var row in saleRows) {
        final id = row['id'] as String;
        final total = (row['total'] as num).toDouble();
        final isRefund = (row['invoice_type_index'] as int?) == 1;

        if (isRefund) {
          totalRefunds += total;
        } else {
          totalSales += total;
        }

        final items = itemsMap[id] ?? [];

        transactions.add(Sale(
          id: id,
          total: total,
          items: (row['items'] as int? ?? 0),
          date: DateTime.parse(row['created_at'] as String),
          saleItems: items,
          cashierName: row['cashier_name'] as String?,
          cashierUserId: row['cashier_user_id'] as String?,
          subtotal: (row['subtotal'] as num?)?.toDouble() ?? total,
          discountAmount: (row['discount_amount'] as num?)?.toDouble() ?? 0,
          discountType: row['discount_type'] as String? ?? 'none',
          discountValue: (row['discount_value'] as num?)?.toDouble() ?? 0,
          sessionId: sessionId,
          invoiceTypeIndex: isRefund ? 1 : 0,
          refundOriginalInvoiceId: row['original_sale_id'] as String?,
        ));

        for (var item in items) {
          if (isRefund) {
            if (!refundStats.containsKey(item.productId)) {
              refundStats[item.productId] = ProductPerformanceModel(
                productId: item.productId,
                productName: item.name,
                quantitySold: 0,
                revenue: 0,
                cost: 0,
                profit: 0,
                profitMargin: 0,
              );
            }
            var current = refundStats[item.productId]!;
            refundStats[item.productId] = ProductPerformanceModel(
              productId: current.productId,
              productName: current.productName,
              quantitySold: current.quantitySold + item.quantity,
              revenue: current.revenue + item.total,
              cost: 0,
              profit: 0,
              profitMargin: 0,
            );
          } else {
            if (!productStats.containsKey(item.productId)) {
              productStats[item.productId] = ProductPerformanceModel(
                productId: item.productId,
                productName: item.name,
                quantitySold: 0,
                revenue: 0,
                cost: 0,
                profit: 0,
                profitMargin: 0,
              );
            }
            var current = productStats[item.productId]!;
            var revenue = item.total;
            var cost = item.wholesalePrice * item.quantity;
            var profit = revenue - cost;
            var newRev = current.revenue + revenue;
            var newProfit = current.profit + profit;

            productStats[item.productId] = ProductPerformanceModel(
              productId: current.productId,
              productName: current.productName,
              quantitySold: current.quantitySold + item.quantity,
              revenue: newRev,
              cost: current.cost + cost,
              profit: newProfit,
              profitMargin: newRev > 0 ? (newProfit / newRev) * 100 : 0,
            );
          }
        }
      }

      topProducts = productStats.values.toList()
        ..sort((a, b) => b.revenue.compareTo(a.revenue));
      refundedProducts = refundStats.values.toList()
        ..sort((a, b) => b.revenue.compareTo(a.revenue));

      return DailyReport(
        id: '${sessionId}_REPORT',
        sessionId: sessionId,
        date: session.closeTime ?? DateTime.now(),
        totalSales: totalSales,
        totalRefunds: totalRefunds,
        netRevenue: totalSales - totalRefunds,
        totalTransactions: transactionsCount,
        closedByUserName: session.closedByUserId ?? 'System',
        topProducts: topProducts,
        refundedProducts: refundedProducts,
        transactions: transactions,
      );
    } catch (e) {
      print('Failed to generate report: $e');
      return null;
    }
  }
}
