enum SessionStatus { open, closed }

class Session {
  final String id;
  final DateTime openTime;
  DateTime? closeTime;
  SessionStatus status;
  final String openedByUserId;
  final int sessionNumber;
  final String openedByName;
  final String? openedByAvatarUrl;
  String? closedByUserId;
  final List<String> invoiceIds;
  String? dailyReportId;
  double startingCash;
  double closingCash;
  double systemExpectedCash;
  double cashDifference;
  double cashSales;
  double cashRefunds;
  double cardSales;
  double cardRefunds;
  double cashExpenses;

  Session({
    required this.id,
    required this.openTime,
    this.closeTime,
    bool isOpen = true,
    SessionStatus? status,
    required this.openedByUserId,
    this.sessionNumber = 0,
    this.openedByName = 'Unknown user',
    this.openedByAvatarUrl,
    this.closedByUserId,
    List<String>? invoiceIds,
    this.dailyReportId,
    this.startingCash = 0,
    this.closingCash = 0,
    this.systemExpectedCash = 0,
    this.cashDifference = 0,
    this.cashSales = 0,
    this.cashRefunds = 0,
    this.cardSales = 0,
    this.cardRefunds = 0,
    this.cashExpenses = 0,
  })  : status = status ?? (isOpen ? SessionStatus.open : SessionStatus.closed),
        invoiceIds = invoiceIds ?? [];

  /// Backward-compatible getter.
  bool get isOpen => status == SessionStatus.open;

  /// Backward-compatible setter.
  set isOpen(bool value) {
    status = value ? SessionStatus.open : SessionStatus.closed;
  }

  factory Session.fromMap(Map<String, dynamic> row) {
    final opener = row['opened_by'];
    final openerMap = opener is Map ? opener : const {};
    final displayName = (openerMap['display_name'] as String?)?.trim();
    final username = (openerMap['username'] as String?)?.trim();
    return Session(
      id: row['id'] as String,
      openTime: DateTime.parse(row['open_time'] as String).toLocal(),
      openedByUserId: row['user_id'] as String,
      sessionNumber: (row['session_number'] as num?)?.toInt() ?? 0,
      openedByName: displayName?.isNotEmpty == true
          ? displayName!
          : username?.isNotEmpty == true
              ? username!
              : 'Unknown user',
      openedByAvatarUrl: openerMap['avatar_url'] as String?,
      isOpen: row['is_open'] as bool? ?? false,
      closeTime: row['close_time'] != null
          ? DateTime.parse(row['close_time'] as String).toLocal()
          : null,
      closedByUserId: row['closed_by'] as String?,
      startingCash: (row['opening_cash'] as num?)?.toDouble() ??
          (row['starting_cash'] as num?)?.toDouble() ??
          0,
      closingCash: (row['closing_cash'] as num?)?.toDouble() ?? 0,
      systemExpectedCash:
          (row['system_expected_cash'] as num?)?.toDouble() ?? 0,
      cashDifference: (row['cash_difference'] as num?)?.toDouble() ??
          (row['cash_diff'] as num?)?.toDouble() ??
          0,
      cashSales: (row['cash_sales'] as num?)?.toDouble() ?? 0,
      cashRefunds: (row['cash_refunds'] as num?)?.toDouble() ?? 0,
      cardSales: (row['card_sales'] as num?)?.toDouble() ?? 0,
      cardRefunds: (row['card_refunds'] as num?)?.toDouble() ?? 0,
      cashExpenses: (row['cash_expenses'] as num?)?.toDouble() ?? 0,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'openTime': openTime.toIso8601String(),
      'closeTime': closeTime?.toIso8601String(),
      'isOpen': isOpen,
      'status': status.name,
      'openedByUserId': openedByUserId,
      'sessionNumber': sessionNumber,
      'openedByName': openedByName,
      'openedByAvatarUrl': openedByAvatarUrl,
      'closedByUserId': closedByUserId,
      'invoiceIds': invoiceIds,
      'dailyReportId': dailyReportId,
      'startingCash': startingCash,
      'closingCash': closingCash,
      'systemExpectedCash': systemExpectedCash,
      'cashDifference': cashDifference,
      'cashSales': cashSales,
      'cashRefunds': cashRefunds,
      'cardSales': cardSales,
      'cardRefunds': cardRefunds,
      'cashExpenses': cashExpenses,
    };
  }

  String get displayLabel => 'Session #$sessionNumber';

  double get expectedCashPreview =>
      startingCash + cashSales - cashRefunds - cashExpenses;
}
