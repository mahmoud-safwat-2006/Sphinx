import 'dart:async';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart' hide TextDirection;
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'package:sphinx/core/constants/app_colors.dart';
import 'package:sphinx/core/di/dependency_injection.dart';
import 'package:sphinx/core/state/state_synchronizer.dart';
import 'package:sphinx/features/auth/data/models/user_model.dart';
import 'package:sphinx/features/auth/presentation/cubit/user_cubit.dart';
import 'package:sphinx/features/shifts/data/models/shift_model.dart';
import 'package:sphinx/features/shifts/domain/shift_repository.dart';
import 'package:sphinx/features/shifts/presentation/widgets/shift_detail_drawer.dart';
import 'package:sphinx/features/shifts/presentation/widgets/shift_report_sheet.dart';
import 'package:sphinx/l10n/app_localizations.dart';

class ShiftsScreen extends StatefulWidget {
  const ShiftsScreen({super.key});

  @override
  State<ShiftsScreen> createState() => _ShiftsScreenState();
}

class _ShiftsScreenState extends State<ShiftsScreen> {
  List<Session> _sessions = [];
  bool _isLoading = true;
  String _filter = 'all';
  String _search = '';
  final _searchCtrl = TextEditingController();
  StreamSubscription<DataChangeEvent>? _dataChanges;
  DateTime? _selectedDay;

  @override
  void initState() {
    super.initState();
    _loadSessions();
    _dataChanges = StateSynchronizer.events
        .where((event) => const {'sale', 'expense', 'shift', 'branch_scope'}
            .contains(event.entityType))
        .listen((event) => unawaited(
              _loadSessions(showLoading: event.entityType == 'branch_scope'),
            ));
  }

  @override
  void dispose() {
    _dataChanges?.cancel();
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadSessions({bool showLoading = true}) async {
    if (showLoading) setState(() => _isLoading = true);
    try {
      final all = await getIt<ShiftRepository>().getShifts();
      if (mounted) {
        setState(() {
          _sessions = all;
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  List<Session> get _filtered {
    var list = _sessions;
    if (_filter == 'open') list = list.where((s) => s.isOpen).toList();
    if (_filter == 'closed') list = list.where((s) => !s.isOpen).toList();
    if (_selectedDay != null) {
      final day = _selectedDay!;
      final start = DateTime(day.year, day.month, day.day);
      final end = DateTime(day.year, day.month, day.day, 23, 59, 59);
      list = list
          .where((s) => !s.openTime.isBefore(start) && !s.openTime.isAfter(end))
          .toList();
    }
    if (_search.isNotEmpty) {
      final query = _search.trim().toLowerCase();
      list = list
          .where((s) =>
              s.openedByName.toLowerCase().contains(query) ||
              s.sessionNumber.toString().contains(query))
          .toList();
    }
    return list;
  }

  bool get _canViewReport {
    final userType = getIt<UserCubit>().currentUser.userType;
    return userType == UserType.manager || userType == UserType.admin;
  }

  void _showShiftDetail(Session session) {
    final isArabic = AppLocalizations.of(context).localeName == 'ar';
    showGeneralDialog<void>(
      context: context,
      barrierDismissible: true,
      barrierLabel: AppLocalizations.of(context).reconciliationTitle,
      barrierColor: Colors.black38,
      transitionDuration: const Duration(milliseconds: 240),
      pageBuilder: (context, animation, secondaryAnimation) =>
          ShiftDetailDrawer(session: session, onClosed: _loadSessions),
      transitionBuilder: (context, animation, secondaryAnimation, child) {
        return SlideTransition(
          position: Tween<Offset>(
            begin: Offset(isArabic ? -1 : 1, 0),
            end: Offset.zero,
          ).animate(CurvedAnimation(
            parent: animation,
            curve: Curves.easeOutCubic,
          )),
          child: child,
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);

    return Column(
      children: [
        _buildHeader(l10n),
        _buildFilterBar(l10n),
        Expanded(
          child: _isLoading
              ? const Center(child: CircularProgressIndicator())
              : _filtered.isEmpty
                  ? _buildEmpty(l10n)
                  : RefreshIndicator(
                      onRefresh: _loadSessions,
                      child: ListView.builder(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 8),
                        itemCount: _filtered.length,
                        itemBuilder: (ctx, i) => _buildShiftCard(_filtered[i]),
                      ),
                    ),
        ),
      ],
    );
  }

  Widget _buildHeader(AppLocalizations l10n) {
    final openCount = _sessions.where((s) => s.isOpen).length;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(
            bottom: BorderSide(color: AppColors.borderColor.withOpacity(.5))),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: AppColors.primaryColor.withOpacity(.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(LucideIcons.repeat,
                size: 18, color: AppColors.primaryColor),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(l10n.shiftsTitle,
                    style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: AppColors.textPrimary)),
                Text(
                    '${_filtered.length} ${l10n.shiftsTitle} · $openCount ${l10n.shiftOpenStatus}',
                    style: const TextStyle(
                        fontSize: 11, color: AppColors.mutedColor)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _pickDay() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDay ?? DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: AppColors.primaryColor,
              onPrimary: Colors.white,
              onSurface: AppColors.textPrimary,
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null) setState(() => _selectedDay = picked);
  }

  Widget _buildFilterBar(AppLocalizations l10n) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 8),
      color: Colors.white,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SizedBox(
            height: 40,
            child: TextField(
              controller: _searchCtrl,
              onChanged: (value) => setState(() => _search = value),
              style: const TextStyle(fontSize: 12),
              decoration: InputDecoration(
                hintText: l10n.shiftSearchHint,
                prefixIcon: const Icon(LucideIcons.search, size: 16),
                filled: true,
                fillColor: AppColors.surfaceColor,
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 0),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide.none),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              GestureDetector(
                onTap: _pickDay,
                child: Container(
                  constraints: const BoxConstraints(minHeight: 34),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: _selectedDay != null
                        ? AppColors.primaryColor.withOpacity(0.08)
                        : AppColors.surfaceColor,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: _selectedDay != null
                          ? AppColors.primaryColor.withOpacity(0.3)
                          : AppColors.borderColor.withOpacity(0.5),
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(LucideIcons.calendar,
                          size: 13,
                          color: _selectedDay != null
                              ? AppColors.primaryColor
                              : AppColors.mutedColor),
                      const SizedBox(width: 6),
                      Text(
                        _selectedDay != null
                            ? DateFormat('dd/MM/yyyy').format(_selectedDay!)
                            : l10n.selectDate,
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: _selectedDay != null
                              ? AppColors.primaryColor
                              : AppColors.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              if (_selectedDay != null) ...[
                const SizedBox(width: 6),
                GestureDetector(
                  onTap: () => setState(() => _selectedDay = null),
                  child: Container(
                    constraints: const BoxConstraints(minHeight: 34),
                    padding: const EdgeInsets.symmetric(horizontal: 6),
                    decoration: BoxDecoration(
                      color: AppColors.errorColor.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(LucideIcons.x,
                        size: 13, color: AppColors.errorColor),
                  ),
                ),
              ],
              const Spacer(),
              _filterChip(l10n.all, 'all'),
              const SizedBox(width: 4),
              _filterChip(l10n.shiftOpenStatus, 'open'),
              const SizedBox(width: 4),
              _filterChip(l10n.shiftClosedStatus, 'closed'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _filterChip(String label, String value) {
    final isActive = _filter == value;
    return GestureDetector(
      onTap: () => setState(() => _filter = value),
      child: Container(
        constraints: const BoxConstraints(minHeight: 34),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: isActive ? AppColors.primaryColor : AppColors.surfaceColor,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.bold,
            color: isActive ? Colors.white : AppColors.textSecondary,
          ),
        ),
      ),
    );
  }

  Widget _buildEmpty(AppLocalizations l10n) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(LucideIcons.repeat,
              size: 44, color: AppColors.mutedColor.withOpacity(.3)),
          const SizedBox(height: 10),
          Text(l10n.noShiftsYet,
              style:
                  const TextStyle(color: AppColors.mutedColor, fontSize: 13)),
        ],
      ),
    );
  }

  Widget _buildShiftCard(Session session) {
    final l10n = AppLocalizations.of(context);
    final duration =
        (session.closeTime ?? DateTime.now()).difference(session.openTime);
    final expected = session.isOpen
        ? session.expectedCashPreview
        : session.systemExpectedCash;
    final statusColor =
        session.isOpen ? AppColors.successColor : AppColors.mutedColor;
    final initials = session.openedByName.isNotEmpty
        ? session.openedByName.substring(0, 1).toUpperCase()
        : '?';

    return GestureDetector(
      onTap: () => _showShiftDetail(session),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: session.isOpen
                ? AppColors.successColor.withOpacity(.25)
                : AppColors.borderColor.withOpacity(.5),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: (session.isOpen ? AppColors.successColor : Colors.black)
                  .withOpacity(0.04),
              blurRadius: 12,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: IntrinsicHeight(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Left accent strip
              Container(
                width: 4,
                decoration: BoxDecoration(
                  color: statusColor,
                  borderRadius: const BorderRadiusDirectional.only(
                    topStart: Radius.circular(14),
                    bottomStart: Radius.circular(14),
                  ),
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Row 1: Avatar + Name + Status + Chevron
                      Row(
                        children: [
                          // Avatar
                          Container(
                            width: 36,
                            height: 36,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: LinearGradient(
                                colors: [
                                  statusColor.withOpacity(0.2),
                                  statusColor.withOpacity(0.08),
                                ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              border: Border.all(
                                  color: statusColor.withOpacity(0.2)),
                            ),
                            child: Center(
                              child: Text(
                                initials,
                                style: TextStyle(
                                  color: statusColor,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  session.openedByName,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w700,
                                    color: AppColors.textPrimary,
                                  ),
                                ),
                                const SizedBox(height: 1),
                                Text(
                                  '${l10n.shiftLabel} #${session.sessionNumber}',
                                  style: const TextStyle(
                                    fontSize: 10,
                                    color: AppColors.mutedColor,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          // Status badge
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: statusColor.withOpacity(.08),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              session.isOpen
                                  ? l10n.shiftOpenStatus
                                  : l10n.shiftClosedStatus,
                              style: TextStyle(
                                fontSize: 9,
                                fontWeight: FontWeight.w800,
                                color: statusColor,
                              ),
                            ),
                          ),
                          const SizedBox(width: 4),
                          Icon(Icons.chevron_right_rounded,
                              size: 18, color: AppColors.mutedColor),
                        ],
                      ),
                      const SizedBox(height: 10),
                      // Row 2: Date + Duration badges
                      Row(
                        children: [
                          _metaBadge(
                            LucideIcons.calendar,
                            DateFormat('dd/MM').format(session.openTime),
                          ),
                          const SizedBox(width: 6),
                          _metaBadge(
                            LucideIcons.clock,
                            l10n.hoursMinutes(duration.inHours,
                                duration.inMinutes.remainder(60)),
                          ),
                          if (!session.isOpen && session.closeTime != null) ...[
                            const SizedBox(width: 6),
                            _metaBadge(
                              LucideIcons.circleCheck,
                              DateFormat('HH:mm').format(session.closeTime!),
                            ),
                          ],
                        ],
                      ),
                      const SizedBox(height: 10),
                      // Row 3: Financial data chips
                      Row(
                        children: [
                          _financialChip(
                            l10n.openingCashLabel,
                            session.startingCash,
                            AppColors.primaryColor,
                          ),
                          const SizedBox(width: 4),
                          _financialChip(
                            l10n.systemExpectedLabel,
                            expected,
                            AppColors.secondaryColor,
                          ),
                          if (!session.isOpen) ...[
                            const SizedBox(width: 4),
                            _financialChip(
                              l10n.actualCashLabel,
                              session.closingCash,
                              AppColors.textPrimary,
                            ),
                          ],
                        ],
                      ),
                      if (!session.isOpen) ...[
                        const SizedBox(height: 8),
                        // Row 4: Variance + Report button
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            ShiftVarianceBadge(difference: session.cashDifference),
                            if (_canViewReport) ...[
                              const SizedBox(width: 6),
                              _ReportButton(session: session),
                            ],
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _metaBadge(IconData icon, String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
      decoration: BoxDecoration(
        color: AppColors.surfaceColor,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 10, color: AppColors.mutedColor),
          const SizedBox(width: 3),
          Text(
            text,
            style: const TextStyle(
              fontSize: 9,
              color: AppColors.mutedColor,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _financialChip(String label, double amount, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 5),
        decoration: BoxDecoration(
          color: color.withOpacity(.06),
          borderRadius: BorderRadius.circular(6),
        ),
        child: Column(
          children: [
            Text(label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 8,
                  color: color.withOpacity(.7),
                  fontWeight: FontWeight.w600,
                )),
            const SizedBox(height: 1),
            Text(
              amount.toStringAsFixed(2),
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w800,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ReportButton extends StatelessWidget {
  final Session session;
  const _ReportButton({required this.session});

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return GestureDetector(
      onTap: () {
        showModalBottomSheet(
          context: context,
          isScrollControlled: true,
          useSafeArea: true,
          backgroundColor: Colors.transparent,
          builder: (_) => ShiftReportSheet(
            sessionId: session.id,
            reportDate: session.openTime,
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
        decoration: BoxDecoration(
          color: AppColors.primaryColor.withOpacity(0.08),
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: AppColors.primaryColor.withOpacity(0.2)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(LucideIcons.fileText, size: 11, color: AppColors.primaryColor),
            const SizedBox(width: 3),
            Text(
              l10n.shiftReportBtn,
              style: const TextStyle(
                fontSize: 9,
                fontWeight: FontWeight.w700,
                color: AppColors.primaryColor,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
