import 'dart:async';

import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/state/state_synchronizer.dart';
import '../../domain/shift_repository.dart';
import 'shift_state.dart';

class ShiftCubit extends Cubit<ShiftState> {
  ShiftCubit(
    this._repository, {
    required String? Function() currentUserId,
  })  : _currentUserId = currentUserId,
        super(const ShiftInitial());

  final ShiftRepository _repository;
  final String? Function() _currentUserId;

  StreamSubscription<String>? _shiftChangesSubscription;
  String? _subscribedUserId;

  Future<void> load() async {
    final userId = _currentUserId();
    if (userId == null) {
      await _cancelShiftChanges();
      emit(const ShiftClosed());
      return;
    }

    emit(const ShiftLoading());
    try {
      final shift = await _repository.getActiveShift(userId);
      emit(shift == null ? const ShiftClosed() : ShiftActive(shift));
      await _subscribeToShiftChanges(userId);
    } catch (error) {
      emit(ShiftFailure(error.toString(), const ShiftClosed()));
    }
  }

  Future<void> refresh() async {
    final previous = state;
    final userId = _currentUserId();
    if (userId == null) {
      emit(const ShiftClosed());
      return;
    }

    try {
      final shift = await _repository.getActiveShift(userId);
      emit(shift == null ? const ShiftClosed() : ShiftActive(shift));
    } catch (error) {
      emit(ShiftFailure(error.toString(), previous));
    }
  }

  Future<void> open(double openingCash) async {
    final previous = state;
    emit(ShiftOpening(previous));
    try {
      final shift = await _repository.openShift(openingCash);
      emit(ShiftActive(shift));
      StateSynchronizer.notify(DataChangeEvent(
        entityType: 'shift',
        operation: 'open',
        id: shift.id,
        metadata: {'userId': shift.openedByUserId},
      ));
    } catch (error) {
      if (error.toString().contains('SHIFT_ALREADY_OPEN')) {
        await refresh();
        return;
      }
      emit(ShiftFailure(error.toString(), previous));
      rethrow;
    }
  }

  Future<void> closeShift({
    required String shiftId,
    required double closingCash,
  }) async {
    final previous = state;
    final current = previous.activeShift;
    if (current?.id == shiftId) {
      emit(ShiftClosing(current!));
    }

    try {
      final closed = await _repository.closeShift(
        shiftId: shiftId,
        closingCash: closingCash,
      );
      if (current?.id == shiftId) {
        emit(const ShiftClosed());
      } else {
        emit(previous);
      }
      StateSynchronizer.notify(DataChangeEvent(
        entityType: 'shift',
        operation: 'close',
        id: closed.id,
        metadata: {'userId': closed.openedByUserId},
      ));
      StateSynchronizer.notify(DataChangeEvent(
        entityType: 'work_hours',
        operation: 'update',
        metadata: {'shiftId': closed.id},
      ));
    } catch (error) {
      emit(ShiftFailure(error.toString(), previous));
      rethrow;
    }
  }

  Future<void> _subscribeToShiftChanges(String userId) async {
    if (_subscribedUserId == userId && _shiftChangesSubscription != null) {
      return;
    }
    await _cancelShiftChanges();
    _subscribedUserId = userId;
    _shiftChangesSubscription =
        _repository.watchShiftChanges(userId).listen((_) {
      unawaited(refresh());
    });
  }

  Future<void> _cancelShiftChanges() async {
    await _shiftChangesSubscription?.cancel();
    _shiftChangesSubscription = null;
    _subscribedUserId = null;
  }

  @override
  Future<void> close() async {
    await _cancelShiftChanges();
    return super.close();
  }
}
