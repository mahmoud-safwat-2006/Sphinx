import '../../data/models/shift_model.dart';

sealed class ShiftState {
  const ShiftState();

  Session? get activeShift => switch (this) {
        ShiftActive(:final shift) => shift,
        ShiftOpening(:final previous) => previous.activeShift,
        ShiftClosing(:final shift) => shift,
        ShiftFailure(:final previous) => previous.activeShift,
        _ => null,
      };
}

final class ShiftInitial extends ShiftState {
  const ShiftInitial();
}

final class ShiftLoading extends ShiftState {
  const ShiftLoading();
}

final class ShiftClosed extends ShiftState {
  const ShiftClosed();
}

final class ShiftOpening extends ShiftState {
  const ShiftOpening(this.previous);

  final ShiftState previous;
}

final class ShiftActive extends ShiftState {
  const ShiftActive(this.shift);

  final Session shift;
}

final class ShiftClosing extends ShiftState {
  const ShiftClosing(this.shift);

  final Session shift;
}

final class ShiftFailure extends ShiftState {
  const ShiftFailure(this.message, this.previous);

  final String message;
  final ShiftState previous;
}
