import 'package:flutter/material.dart';
import 'package:intl/intl.dart' hide TextDirection;
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'package:printing/printing.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/components/message_overlay.dart';
import '../../../../core/di/dependency_injection.dart';
import '../../../../l10n/app_localizations.dart';
import '../../../analytics/domain/analytics_repository.dart';
import '../../data/models/daily_report_model.dart';
import '../../data/models/product_performance_model.dart';
import '../../domain/daily_report_pdf_service.dart';
import '../screens/daily_report_preview_screen.dart';
import '../screens/daily_report_datasheet_screen.dart';

class ShiftReportSheet extends StatefulWidget {
  final String sessionId;
  final DateTime reportDate;

  const ShiftReportSheet({
    super.key,
    required this.sessionId,
    required this.reportDate,
  });

  @override
  State<ShiftReportSheet> createState() => _ShiftReportSheetState();
}

class _ShiftReportSheetState extends State<ShiftReportSheet> {
  DailyReport? report;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _fetchReport();
  }

  Future<void> _fetchReport() async {
    setState(() => loading = true);
    final repo = getIt<AnalyticsRepository>();
    final result = await repo.getReportForSession(widget.sessionId);
    result.fold((failure) {
      if (mounted) {
        GlobalMessage.showError(
            AppLocalizations.of(context).loadReportError(failure.message));
        setState(() {
          report = null;
          loading = false;
        });
      }
    }, (loadedReport) {
      if (mounted) {
        setState(() {
          report = loadedReport;
          loading = false;
        });
      }
    });
  }

  Future<void> _handlePrint() async {
    if (report == null) return;
    GlobalMessage.showLoading(AppLocalizations.of(context).loadingReport);
    try {
      final pdfBytes = await DailyReportPdfService.generateDailyReportPDF(
          report!,
          locale: Localizations.localeOf(context));
      await Printing.layoutPdf(onLayout: (format) => pdfBytes);
      if (mounted) {
        GlobalMessage.showSuccess(
            AppLocalizations.of(context).printReportSuccess);
      }
    } catch (e) {
      if (mounted) {
        GlobalMessage.showError(
            AppLocalizations.of(context).printReportError(e.toString()));
      }
    }
  }

  Future<void> _handleShare() async {
    if (report == null) return;
    GlobalMessage.showLoading(AppLocalizations.of(context).loadingShare);
    try {
      final bytes = await DailyReportPdfService.generateDailyReportPDF(report!,
          locale: Localizations.localeOf(context));
      await Printing.sharePdf(
        bytes: bytes,
        filename:
            'daily_report_${DateFormat('yyyy-MM-dd').format(widget.reportDate)}.pdf',
      );
      if (mounted) {
        GlobalMessage.showSuccess(
            AppLocalizations.of(context).shareReportSuccess);
      }
    } catch (e) {
      if (mounted) {
        GlobalMessage.showError(
            AppLocalizations.of(context).shareReportError(e.toString()));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final screenWidth = MediaQuery.of(context).size.width;
    final isDesktop = screenWidth > 900;

    return Directionality(
      textDirection:
          l10n.localeName == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Container(
        height: MediaQuery.of(context).size.height * 0.9,
        decoration: const BoxDecoration(
          color: AppColors.backgroundColor,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          children: [
            _buildHandle(),
            _buildHeader(l10n),
            Expanded(
              child: loading
                  ? const Center(
                      child: CircularProgressIndicator(
                          color: AppColors.primaryColor))
                  : report == null
                      ? _buildEmpty(l10n)
                      : _buildContent(l10n, isDesktop),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHandle() {
    return Center(
      child: Container(
        margin: const EdgeInsets.only(top: 12),
        width: 40,
        height: 4,
        decoration: BoxDecoration(
          color: AppColors.borderColor,
          borderRadius: BorderRadius.circular(2),
        ),
      ),
    );
  }

  Widget _buildHeader(AppLocalizations l10n) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(
            bottom:
                BorderSide(color: AppColors.borderColor.withOpacity(0.5))),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppColors.primaryColor.withOpacity(0.08),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(LucideIcons.calendar,
                color: AppColors.primaryColor, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(l10n.dailyReports,
                    style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: AppColors.textPrimary)),
                Text(
                    DateFormat('dd MMMM yyyy', l10n.localeName)
                        .format(widget.reportDate),
                    style: const TextStyle(
                        fontSize: 11, color: AppColors.mutedColor)),
              ],
            ),
          ),
          IconButton(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(LucideIcons.x, size: 20),
            color: AppColors.mutedColor,
          ),
        ],
      ),
    );
  }

  Widget _buildEmpty(AppLocalizations l10n) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: AppColors.primaryColor.withOpacity(0.04),
              shape: BoxShape.circle,
            ),
            child: Icon(LucideIcons.barChart2,
                size: 56, color: AppColors.mutedColor.withOpacity(0.4)),
          ),
          const SizedBox(height: 16),
          Text(l10n.noDataForDate,
              style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textPrimary)),
          const SizedBox(height: 6),
          Text(l10n.ensureValidDate,
              style: const TextStyle(
                  fontSize: 12, color: AppColors.mutedColor)),
        ],
      ),
    );
  }

  Widget _buildContent(AppLocalizations l10n, bool isDesktop) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSummaryCards(l10n, isDesktop),
          const SizedBox(height: 16),
          _buildActionButtons(l10n, isDesktop),
          if (report!.refundedProducts.isNotEmpty) ...[
            const SizedBox(height: 16),
            _buildRefundedProducts(l10n),
          ],
          if (report!.transactions.isNotEmpty) ...[
            const SizedBox(height: 16),
            _buildTransactionsLog(l10n),
          ],
          const SizedBox(height: 16),
          _buildTopProducts(l10n),
        ],
      ),
    );
  }

  Widget _buildSummaryCards(AppLocalizations l10n, bool isDesktop) {
    final salesCard = _summaryCard(
      l10n.todayTotalSales,
      '${report!.totalSales.toStringAsFixed(2)} ${l10n.currencyEg}',
      LucideIcons.banknote,
      AppColors.successColor,
    );
    final profitCard = _summaryCard(
      l10n.dailyNetProfit,
      '${report!.netRevenue.toStringAsFixed(2)} ${l10n.currencyEg}',
      LucideIcons.trendingUp,
      const Color(0xFF059669),
    );
    if (isDesktop) {
      return Row(
        children: [
          Expanded(child: salesCard),
          const SizedBox(width: 12),
          Expanded(child: profitCard),
        ],
      );
    }
    return Column(
      children: [
        salesCard,
        const SizedBox(height: 10),
        profitCard,
      ],
    );
  }

  Widget _summaryCard(
      String title, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.borderColor.withOpacity(0.6)),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.015),
              blurRadius: 8,
              offset: const Offset(0, 2)),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
                color: color.withOpacity(0.08),
                borderRadius: BorderRadius.circular(10)),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        fontSize: 11,
                        color: AppColors.mutedColor,
                        fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text(value,
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: color)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons(AppLocalizations l10n, bool isDesktop) {
    return LayoutBuilder(builder: (context, constraints) {
      final isMobile = constraints.maxWidth < 500;
      if (isMobile) {
        return Column(
          children: [
            _actionButton(
              onPressed: () {
                if (report == null) return;
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => DailyReportPreviewScreen(report: report!),
                  ),
                );
              },
              icon: LucideIcons.eye,
              label: l10n.salesReportPreview,
              color: AppColors.primaryColor,
            ),
            const SizedBox(height: 8),
            _actionButton(
              onPressed: () {
                if (report == null) return;
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) =>
                        DailyReportDatasheetScreen(report: report!),
                  ),
                );
              },
              icon: LucideIcons.table,
              label: l10n.viewDetailedTable,
              color: AppColors.secondaryColor,
            ),
            const SizedBox(height: 8),
            _actionButton(
              onPressed: _handlePrint,
              icon: LucideIcons.printer,
              label: l10n.instantPrintReport,
              color: const Color(0xFF059669),
            ),
            const SizedBox(height: 8),
            _actionButton(
              onPressed: _handleShare,
              icon: LucideIcons.share2,
              label: l10n.sharePdfReport,
              color: AppColors.mutedColor,
              isOutlined: true,
            ),
          ],
        );
      }
      return Column(
        children: [
          Row(
            children: [
              Expanded(
                child: _actionButton(
                  onPressed: () {
                    if (report == null) return;
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) =>
                            DailyReportPreviewScreen(report: report!),
                      ),
                    );
                  },
                  icon: LucideIcons.eye,
                  label: l10n.previewReportTitle,
                  color: AppColors.primaryColor,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _actionButton(
                  onPressed: () {
                    if (report == null) return;
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) =>
                            DailyReportDatasheetScreen(report: report!),
                      ),
                    );
                  },
                  icon: LucideIcons.table,
                  label: l10n.viewTableBtn,
                  color: AppColors.secondaryColor,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _actionButton(
                  onPressed: _handlePrint,
                  icon: LucideIcons.printer,
                  label: l10n.instantPrint,
                  color: const Color(0xFF059669),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: _actionButton(
              onPressed: _handleShare,
              icon: LucideIcons.share2,
              label: l10n.sharePdfReport,
              color: AppColors.textSecondary,
              isOutlined: true,
            ),
          ),
        ],
      );
    });
  }

  Widget _actionButton({
    required VoidCallback onPressed,
    required IconData icon,
    required String label,
    required Color color,
    bool isOutlined = false,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(10),
        child: Container(
          alignment: Alignment.center,
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isOutlined ? Colors.transparent : color,
            border: Border.all(color: color, width: isOutlined ? 1.5 : 1),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 16, color: isOutlined ? color : Colors.white),
              const SizedBox(width: 6),
              Text(
                label,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                  color: isOutlined ? color : Colors.white,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTopProducts(AppLocalizations l10n) {
    if (report!.topProducts.isEmpty) {
      return Center(
          child: Padding(
        padding: const EdgeInsets.all(20),
        child: Text(l10n.noProductsSoldDate,
            style: TextStyle(
                color: AppColors.mutedColor.withOpacity(0.5), fontSize: 13)),
      ));
    }
    return _sectionCard(
      header: Row(
        children: [
          const Icon(LucideIcons.barChart2,
              color: AppColors.primaryColor, size: 18),
          const SizedBox(width: 8),
          Text(
            l10n.dailyProductsPerformance(report!.topProducts.length),
            style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.bold,
                color: AppColors.textPrimary),
          ),
        ],
      ),
      child: ListView.separated(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        padding: const EdgeInsets.all(16),
        itemCount: report!.topProducts.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (ctx, i) =>
            _productTile(report!.topProducts[i], i, l10n),
      ),
    );
  }

  Widget _productTile(ProductPerformanceModel p, int index, AppLocalizations l10n) {
    return Row(
      children: [
        Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            color: AppColors.primaryColor.withOpacity(0.06),
            borderRadius: BorderRadius.circular(8),
          ),
          child: const Icon(LucideIcons.package,
              color: AppColors.primaryColor, size: 16),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(p.productName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      fontSize: 12, fontWeight: FontWeight.bold)),
              Text(l10n.salesUnits(p.quantitySold),
                  style: const TextStyle(
                      fontSize: 10, color: AppColors.mutedColor)),
            ],
          ),
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text('${p.revenue.toStringAsFixed(2)} ${l10n.currencyEg}',
                style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: AppColors.primaryColor)),
            Text('${p.profitMargin.toStringAsFixed(1)}%',
                style: const TextStyle(
                    fontSize: 10, color: AppColors.successColor)),
          ],
        ),
      ],
    );
  }

  Widget _buildRefundedProducts(AppLocalizations l10n) {
    return _sectionCard(
      header: Row(
        children: [
          const Icon(LucideIcons.packageX,
              color: AppColors.errorColor, size: 18),
          const SizedBox(width: 8),
          Text(l10n.returnedProductsDetails,
              style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textPrimary)),
        ],
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.all(16),
        child: DataTable(
          horizontalMargin: 12,
          headingTextStyle: const TextStyle(
              fontWeight: FontWeight.bold,
              color: AppColors.mutedColor,
              fontSize: 11),
          dataTextStyle: const TextStyle(
              color: AppColors.textPrimary,
              fontWeight: FontWeight.w600,
              fontSize: 11),
          columnSpacing: 20,
          columns: [
            DataColumn(label: Text(l10n.productNameColumn)),
            DataColumn(label: Text(l10n.returnedQty), numeric: true),
            DataColumn(label: Text(l10n.returnedValue), numeric: true),
          ],
          rows: report!.refundedProducts.map((p) {
            return DataRow(cells: [
              DataCell(Text(p.productName)),
              DataCell(Text('${p.quantitySold}')),
              DataCell(Text(
                '${p.revenue.toStringAsFixed(2)} ${l10n.currencyEg}',
                style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    color: AppColors.errorColor),
              )),
            ]);
          }).toList(),
        ),
      ),
    );
  }

  Widget _buildTransactionsLog(AppLocalizations l10n) {
    return _sectionCard(
      header: Row(
        children: [
          const Icon(LucideIcons.fileSpreadsheet,
              color: AppColors.primaryColor, size: 18),
          const SizedBox(width: 8),
          Text(l10n.dailyFinancialLog,
              style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textPrimary)),
        ],
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.all(16),
        child: DataTable(
          horizontalMargin: 12,
          headingTextStyle: const TextStyle(
              fontWeight: FontWeight.bold,
              color: AppColors.mutedColor,
              fontSize: 11),
          dataTextStyle: const TextStyle(
              color: AppColors.textPrimary,
              fontWeight: FontWeight.w600,
              fontSize: 11),
          columnSpacing: 18,
          columns: [
            DataColumn(label: Text(l10n.invoiceNumberPdf)),
            DataColumn(label: Text(l10n.operationTime)),
            DataColumn(label: Text(l10n.operationType)),
            DataColumn(
                label: Text(l10n.totalAmountLabel), numeric: true),
          ],
          rows: report!.transactions.map((sale) {
            final isRefund = sale.isRefund;
            return DataRow(cells: [
              DataCell(Text(sale.id.length > 8
                  ? '#${sale.id.substring(0, 8).toUpperCase()}'
                  : '#${sale.id.toUpperCase()}')),
              DataCell(Text(DateFormat('hh:mm a').format(sale.date))),
              DataCell(
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: (isRefund
                            ? AppColors.errorColor
                            : AppColors.successColor)
                        .withOpacity(0.08),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    isRefund ? l10n.refundLabel : l10n.saleProcess,
                    style: TextStyle(
                      fontSize: 10,
                      color: isRefund
                          ? AppColors.errorColor
                          : AppColors.successColor,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              DataCell(Text(
                '${sale.total.toStringAsFixed(2)} ${l10n.currencyEg}',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: isRefund
                      ? AppColors.errorColor
                      : AppColors.textPrimary,
                ),
              )),
            ]);
          }).toList(),
        ),
      ),
    );
  }

  Widget _sectionCard({required Widget header, required Widget child}) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.borderColor.withOpacity(0.6)),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.015),
              blurRadius: 8,
              offset: const Offset(0, 2)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
            child: header,
          ),
          child,
        ],
      ),
    );
  }
}
