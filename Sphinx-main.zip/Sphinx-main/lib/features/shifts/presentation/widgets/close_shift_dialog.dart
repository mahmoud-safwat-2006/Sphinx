import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/utils/responsive_helper.dart';
import '../../../../l10n/app_localizations.dart';
import '../../data/models/shift_model.dart';

class CloseShiftDialog extends StatefulWidget {
  final Session session;
  final double totalSales;
  final double totalRefunds;

  const CloseShiftDialog({
    super.key,
    required this.session,
    required this.totalSales,
    required this.totalRefunds,
  });

  @override
  State<CloseShiftDialog> createState() => _CloseShiftDialogState();
}

class _CloseShiftDialogState extends State<CloseShiftDialog> {
  final _cashController = TextEditingController();
  bool _submitting = false;

  @override
  void initState() {
    super.initState();
    _cashController.text =
        widget.session.expectedCashPreview.toStringAsFixed(2);
  }

  @override
  void dispose() {
    _cashController.dispose();
    super.dispose();
  }

  double get _declaredCash => double.tryParse(_cashController.text.trim()) ?? 0;
  double get _systemExpected => widget.session.expectedCashPreview;
  double get _difference => _declaredCash - _systemExpected;

  void _submit() {
    if (_submitting) return;
    setState(() => _submitting = true);
    Navigator.of(context).pop(_declaredCash);
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final duration = DateTime.now().difference(widget.session.openTime);
    final isBalanced = _difference.abs() < 0.005;
    final isShortage = !isBalanced && _difference < 0;

    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Container(
        constraints: BoxConstraints(
          maxWidth: ResponsiveHelper.dialogMaxWidth(context, desktop: 480),
          maxHeight: MediaQuery.sizeOf(context).height * .9,
        ),
        padding: EdgeInsets.all(ResponsiveHelper.isMobile(context) ? 18 : 28),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.primaryColor.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.lock_outline_rounded,
                  size: 36,
                  color: AppColors.primaryColor,
                ),
              ),
              const SizedBox(height: 16),
              Text(
                l10n.closeShiftAction,
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textPrimary,
                ),
              ),
              const SizedBox(height: 20),

              // Shift summary
              _buildSummaryRow(l10n.shiftOpenDateLabel,
                  widget.session.openTime.toString().substring(0, 16)),
              _buildSummaryRow(
                  l10n.shiftDurationLabel,
                  l10n.hoursMinutes(
                      duration.inHours, duration.inMinutes.remainder(60))),
              _buildSummaryRow(
                  l10n.totalSalesLabel, widget.totalSales.toStringAsFixed(2)),
              _buildSummaryRow(l10n.totalRefundsLabel,
                  widget.totalRefunds.toStringAsFixed(2)),
              _buildSummaryRow(l10n.openingCashLabel,
                  widget.session.startingCash.toStringAsFixed(2)),
              _buildSummaryRow(
                  l10n.systemExpectedLabel, _systemExpected.toStringAsFixed(2)),
              const Divider(height: 24),

              // Cash input
              Text(
                l10n.actualCashLabel,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textSecondary,
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _cashController,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,2}')),
                ],
                textDirection: TextDirection.ltr,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
                decoration: InputDecoration(
                  hintText: '0.00',
                  prefixIcon: const Padding(
                    padding: EdgeInsets.only(left: 16),
                    child: Icon(Icons.attach_money, size: 28),
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: const BorderSide(
                        color: AppColors.borderColor, width: 1.5),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide:
                        BorderSide(color: AppColors.primaryColor, width: 2),
                  ),
                ),
                onSubmitted: (_) => _submit(),
              ),
              const SizedBox(height: 16),

              // Difference indicator
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                decoration: BoxDecoration(
                  color: isShortage
                      ? Colors.red.shade50
                      : isBalanced
                          ? Colors.green.shade50
                          : Colors.blue.shade50,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isShortage
                        ? Colors.red.shade200
                        : isBalanced
                            ? Colors.green.shade200
                            : Colors.blue.shade200,
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      isShortage
                          ? Icons.warning_amber_rounded
                          : isBalanced
                              ? Icons.check_circle_outline
                              : Icons.info_outline,
                      color: isShortage
                          ? Colors.red.shade700
                          : isBalanced
                              ? Colors.green.shade700
                              : Colors.blue.shade700,
                      size: 22,
                    ),
                    const SizedBox(width: 10),
                    Text(
                      isShortage
                          ? '${l10n.shortageStatus}: ${_difference.abs().toStringAsFixed(2)}'
                          : isBalanced
                              ? l10n.balancedStatus
                              : '${l10n.surplusStatus}: ${_difference.toStringAsFixed(2)}',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: isShortage
                            ? Colors.red.shade700
                            : isBalanced
                                ? Colors.green.shade700
                                : Colors.blue.shade700,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // Actions
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.of(context).pop(null),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Text(l10n.cancel),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _submitting ? null : _submit,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primaryColor,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: _submitting
                          ? const SizedBox(
                              height: 20,
                              width: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : Text(
                              l10n.closeShiftAction,
                              style:
                                  const TextStyle(fontWeight: FontWeight.bold),
                            ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSummaryRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label,
              style:
                  const TextStyle(color: AppColors.mutedColor, fontSize: 13)),
          Text(value,
              style:
                  const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
        ],
      ),
    );
  }
}
