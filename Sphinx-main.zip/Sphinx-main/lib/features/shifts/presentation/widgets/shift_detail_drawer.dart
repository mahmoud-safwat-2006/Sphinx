import 'dart:async';

import 'package:sphinx/core/constants/app_colors.dart';
import 'package:sphinx/core/state/state_synchronizer.dart';
import 'package:sphinx/core/di/dependency_injection.dart';
import 'package:sphinx/core/security/role_permissions.dart';
import 'package:sphinx/features/auth/data/models/user_model.dart';
import 'package:sphinx/features/auth/presentation/cubit/user_cubit.dart';
import 'package:sphinx/features/shifts/data/models/shift_model.dart';
import 'package:sphinx/features/shifts/presentation/cubit/shift_cubit.dart';
import 'package:sphinx/features/shifts/domain/shift_repository.dart';
import 'package:sphinx/features/shifts/presentation/widgets/close_shift_dialog.dart';
import 'package:sphinx/l10n/app_localizations.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

enum ShiftVarianceKind { balanced, shortage, surplus }

ShiftVarianceKind shiftVarianceKind(double difference) {
  if (difference.abs() < 0.005) return ShiftVarianceKind.balanced;
  return difference < 0
      ? ShiftVarianceKind.shortage
      : ShiftVarianceKind.surplus;
}

class ShiftDetailDrawer extends StatefulWidget {
  const ShiftDetailDrawer({
    super.key,
    required this.session,
    required this.onClosed,
  });

  final Session session;
  final VoidCallback onClosed;

  @override
  State<ShiftDetailDrawer> createState() => _ShiftDetailDrawerState();
}

class _ShiftDetailDrawerState extends State<ShiftDetailDrawer> {
  late Session session = widget.session;
  StreamSubscription<DataChangeEvent>? _dataChanges;

  bool get _canClose {
    final user = getIt<UserCubit>().currentUser;
    if (!user.hasPermission(Permission.closeShift)) return false;
    return user.isPrimaryAdmin ||
        user.userType == UserType.admin ||
        user.userType == UserType.manager ||
        user.id == session.openedByUserId;
  }

  @override
  void initState() {
    super.initState();
    if (session.isOpen) {
      _dataChanges = StateSynchronizer.events
          .where(
              (event) => const {'sale', 'expense'}.contains(event.entityType))
          .listen((_) => unawaited(_refreshFinancials()));
    }
  }

  Future<void> _refreshFinancials() async {
    final refreshed =
        await getIt<ShiftRepository>().getActiveShift(session.openedByUserId);
    if (!mounted || refreshed?.id != session.id) return;
    setState(() => session = refreshed!);
  }

  @override
  void dispose() {
    _dataChanges?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final screenWidth = MediaQuery.sizeOf(context).width;
    final isPhone = screenWidth < 600;
    final width = isPhone ? screenWidth : 480.0;
    final expected = session.isOpen
        ? session.expectedCashPreview
        : session.systemExpectedCash;
    final netMovement =
        session.cashSales - session.cashRefunds - session.cashExpenses;
    final duration = (session.closeTime ?? DateTime.now()).difference(
      session.openTime,
    );
    final date = DateFormat('dd/MM/yyyy • hh:mm a', l10n.localeName);

    return SafeArea(
      child: Align(
        alignment: AlignmentDirectional.centerEnd,
        child: Material(
          color: Colors.white,
          borderRadius: isPhone
              ? BorderRadius.zero
              : const BorderRadiusDirectional.only(
                  topStart: Radius.circular(24),
                  bottomStart: Radius.circular(24),
                ),
          clipBehavior: Clip.antiAlias,
          child: SizedBox(
            width: width,
            height: double.infinity,
            child: Column(
              children: [
                _Header(
                  session: session,
                  onClose: () => Navigator.pop(context),
                ),
                Expanded(
                  child: ListView(
                    padding: EdgeInsets.fromLTRB(
                      isPhone ? 16 : 24,
                      20,
                      isPhone ? 16 : 24,
                      24,
                    ),
                    children: [
                      _MetaCard(
                        rows: [
                          _MetaData(
                            l10n.shiftUserLabel,
                            session.openedByName,
                            LucideIcons.user,
                          ),
                          _MetaData(
                            l10n.shiftOpenDateLabel,
                            date.format(session.openTime),
                            LucideIcons.calendar,
                          ),
                          if (session.closeTime != null)
                            _MetaData(
                              l10n.shiftCloseDateLabel,
                              date.format(session.closeTime!),
                              LucideIcons.calendarCheck,
                            ),
                          _MetaData(
                            l10n.shiftDurationLabel,
                            l10n.hoursMinutes(
                              duration.inHours,
                              duration.inMinutes.remainder(60),
                            ),
                            LucideIcons.clock,
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      Text(
                        l10n.reconciliationTitle,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 12),
                      _MoneyStep(
                        icon: LucideIcons.banknote,
                        label: l10n.openingCashLabel,
                        amount: session.startingCash,
                        l10n: l10n,
                        color: AppColors.primaryColor,
                      ),
                      _Connector(),
                      _MovementCard(
                        session: session,
                        netMovement: netMovement,
                        l10n: l10n,
                      ),
                      _Connector(),
                      _MoneyStep(
                        icon: LucideIcons.calculator,
                        label: l10n.systemExpectedLabel,
                        amount: expected,
                        l10n: l10n,
                        color: AppColors.secondaryColor,
                        emphasized: true,
                      ),
                      if (!session.isOpen) ...[
                        _Connector(),
                        _MoneyStep(
                          icon: LucideIcons.wallet,
                          label: l10n.actualCashLabel,
                          amount: session.closingCash,
                          l10n: l10n,
                          color: AppColors.textPrimary,
                        ),
                        const SizedBox(height: 16),
                        ShiftVarianceBadge(
                          difference: session.cashDifference,
                        ),
                      ],
                    ],
                  ),
                ),
                if (session.isOpen && _canClose)
                  SafeArea(
                    top: false,
                    child: Padding(
                      padding: EdgeInsets.fromLTRB(
                        isPhone ? 16 : 24,
                        12,
                        isPhone ? 16 : 24,
                        16,
                      ),
                      child: SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: ElevatedButton.icon(
                          onPressed: () => _closeShift(context),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.primaryColor,
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                          ),
                          icon: const Icon(LucideIcons.lock, size: 18),
                          label: Text(
                            l10n.closeShiftAction,
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _closeShift(BuildContext context) async {
    final result = await showDialog<double>(
      context: context,
      barrierDismissible: false,
      builder: (_) => CloseShiftDialog(
        session: session,
        totalSales: session.cashSales + session.cardSales,
        totalRefunds: session.cashRefunds + session.cardRefunds,
      ),
    );
    if (result == null || !context.mounted) return;
    await getIt<ShiftCubit>().closeShift(
      shiftId: session.id,
      closingCash: result,
    );
    widget.onClosed();
    if (context.mounted) Navigator.pop(context);
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.session, required this.onClose});

  final Session session;
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return Column(
      children: [
        Container(
          height: 64,
          padding: const EdgeInsets.symmetric(horizontal: 8),
          color: Colors.white,
          child: Row(
            children: [
              IconButton(
                onPressed: onClose,
                icon: const Icon(LucideIcons.x, size: 24),
                color: AppColors.textPrimary,
              ),
              Expanded(
                child: Text(
                  l10n.reconciliationTitle,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              const SizedBox(width: 48),
            ],
          ),
        ),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 20),
          color: AppColors.sidebarColor,
          child: Column(
            children: [
              Text(
                l10n.shiftLabel,
                style: TextStyle(
                  color: Colors.white.withOpacity(.75),
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                '#${session.sessionNumber}',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 34,
                  letterSpacing: 1,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 14),
              _StatusPill(isOpen: session.isOpen),
            ],
          ),
        ),
      ],
    );
  }
}

class _StatusPill extends StatelessWidget {
  const _StatusPill({required this.isOpen});
  final bool isOpen;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final color = isOpen ? const Color(0xFF4ADE80) : Colors.white70;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
      decoration: BoxDecoration(
        color: color.withOpacity(.12),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(.8)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 9,
            height: 9,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          ),
          const SizedBox(width: 7),
          Text(
            isOpen ? l10n.shiftOpenStatus : l10n.shiftClosedStatus,
            style: TextStyle(
              color: color,
              fontSize: 13,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}

class _MetaData {
  const _MetaData(this.label, this.value, this.icon);
  final String label;
  final String value;
  final IconData icon;
}

class _MetaCard extends StatelessWidget {
  const _MetaCard({required this.rows});
  final List<_MetaData> rows;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surfaceColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.borderColor),
      ),
      child: Column(
        children: rows
            .map(
              (row) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 7),
                child: Row(
                  children: [
                    Icon(row.icon, size: 17, color: AppColors.primaryColor),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        row.label,
                        style: const TextStyle(
                          color: AppColors.mutedColor,
                          fontSize: 12,
                        ),
                      ),
                    ),
                    Flexible(
                      child: Text(
                        row.value,
                        textAlign: TextAlign.end,
                        style: const TextStyle(
                          color: AppColors.textPrimary,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            )
            .toList(),
      ),
    );
  }
}

String _money(AppLocalizations l10n, double amount) =>
    '${NumberFormat('#,##0.00', l10n.localeName).format(amount)} ${l10n.currencyEg}';

class _MoneyStep extends StatelessWidget {
  const _MoneyStep({
    required this.icon,
    required this.label,
    required this.amount,
    required this.l10n,
    required this.color,
    this.emphasized = false,
  });

  final IconData icon;
  final String label;
  final double amount;
  final AppLocalizations l10n;
  final Color color;
  final bool emphasized;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: emphasized ? color.withOpacity(.08) : Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: emphasized ? color.withOpacity(.35) : AppColors.borderColor,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: color.withOpacity(.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              label,
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: AppColors.textSecondary,
              ),
            ),
          ),
          Text(
            _money(l10n, amount),
            style: TextStyle(
              fontSize: emphasized ? 17 : 15,
              fontWeight: FontWeight.w900,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}

class _Connector extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Align(
        alignment: AlignmentDirectional.centerStart,
        child: Container(
          width: 2,
          height: 16,
          margin: const EdgeInsetsDirectional.only(start: 36),
          color: AppColors.borderColor,
        ),
      );
}

class _MovementCard extends StatelessWidget {
  const _MovementCard({
    required this.session,
    required this.netMovement,
    required this.l10n,
  });

  final Session session;
  final double netMovement;
  final AppLocalizations l10n;

  @override
  Widget build(BuildContext context) {
    final rows = <(String, double, Color)>[
      (l10n.cashSalesLabel, session.cashSales, AppColors.successColor),
      (l10n.cashRefundsLabel, -session.cashRefunds, AppColors.errorColor),
      (l10n.cashExpensesLabel, -session.cashExpenses, AppColors.warningColor),
    ];
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.borderColor),
      ),
      child: Column(
        children: [
          ...rows.map(
            (row) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      row.$1,
                      style: const TextStyle(
                        fontSize: 12,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ),
                  Text(
                    '${row.$2 > 0 ? '+' : ''}${_money(l10n, row.$2)}',
                    style: TextStyle(
                      color: row.$3,
                      fontWeight: FontWeight.w800,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const Divider(height: 14),
          Row(
            children: [
              Expanded(
                child: Text(
                  l10n.netCashMovementLabel,
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
              ),
              Text(
                _money(l10n, netMovement),
                style: const TextStyle(
                  fontWeight: FontWeight.w900,
                  color: AppColors.textPrimary,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class ShiftVarianceBadge extends StatelessWidget {
  const ShiftVarianceBadge({super.key, required this.difference});
  final double difference;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final kind = shiftVarianceKind(difference);
    final (label, color, icon) = switch (kind) {
      ShiftVarianceKind.balanced => (
          l10n.balancedStatus,
          AppColors.successColor,
          LucideIcons.circleCheck,
        ),
      ShiftVarianceKind.shortage => (
          l10n.shortageStatus,
          AppColors.errorColor,
          LucideIcons.trendingDown,
        ),
      ShiftVarianceKind.surplus => (
          l10n.surplusStatus,
          AppColors.warningColor,
          LucideIcons.trendingUp,
        ),
    };
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: color.withOpacity(.08),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(width: 12),
          Flexible(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: color,
                    fontWeight: FontWeight.w900,
                    fontSize: 15,
                  ),
                ),
                Text(
                  l10n.cashDifferenceLabel,
                  style: const TextStyle(
                    color: AppColors.mutedColor,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Text(
            '${difference > 0.005 ? '+' : ''}${_money(l10n, difference)}',
            style: TextStyle(
              color: color,
              fontWeight: FontWeight.w800,
              fontSize: 16,
            ),
          ),
        ],
      ),
    );
  }
}
