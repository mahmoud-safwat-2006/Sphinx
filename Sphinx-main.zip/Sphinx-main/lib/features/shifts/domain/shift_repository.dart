import '../data/models/shift_model.dart';

abstract interface class ShiftRepository {
  Future<Session?> getActiveShift(String userId);

  Future<List<Session>> getShifts({
    String filter = 'all',
    String search = '',
  });

  Future<Session> openShift(double openingCash);

  Future<Session> closeShift({
    required String shiftId,
    required double closingCash,
  });

  Stream<String> watchShiftChanges(String userId);
}
