import 'package:flutter/material.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'package:sphinx/core/constants/app_colors.dart';
import '../../../../l10n/app_localizations.dart';

class SummaryRow extends StatelessWidget {
  const SummaryRow({
    super.key,
    required this.total,
    required this.opened,
    required this.urgent,
    required this.unread,
  });

  final int total;
  final int opened;
  final int urgent;
  final int unread;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return LayoutBuilder(
      builder: (context, constraints) {
        final isMobile = constraints.maxWidth < 600;
        final isTablet =
            constraints.maxWidth >= 600 && constraints.maxWidth < 920;

        final children = [
          SummaryCard(
            label: l10n.readNotifications,
            value: opened,
            icon: LucideIcons.eye,
            bg: AppColors.successColor.withOpacity(0.08),
            fg: AppColors.successColor,
            isMobile: isMobile,
          ),
          SummaryCard(
            label: l10n.urgentNotifications,
            value: urgent,
            icon: LucideIcons.alertTriangle,
            bg: AppColors.errorColor.withOpacity(0.08),
            fg: AppColors.errorColor,
            isMobile: isMobile,
          ),
          SummaryCard(
            label: l10n.unreadLabel,
            value: unread,
            icon: LucideIcons.eyeOff,
            bg: AppColors.warningColor.withOpacity(0.08),
            fg: AppColors.warningColor,
            isMobile: isMobile,
          ),
        ];

        if (isMobile) {
          return Column(
            children: [
              for (var i = 0; i < children.length; i++) ...[
                children[i],
                if (i < children.length - 1) const SizedBox(height: 10),
              ],
            ],
          );
        }

        if (isTablet) {
          return Column(
            children: [
              Row(
                children: [
                  Expanded(child: children[0]),
                  const SizedBox(width: 10),
                  Expanded(child: children[1]),
                ],
              ),
              const SizedBox(height: 10),
              children[2],
            ],
          );
        }

        return Row(
          children: [
            Expanded(child: children[0]),
            const SizedBox(width: 12),
            Expanded(child: children[1]),
            const SizedBox(width: 12),
            Expanded(child: children[2]),
          ],
        );
      },
    );
  }
}

class SummaryCard extends StatelessWidget {
  const SummaryCard({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
    required this.bg,
    required this.fg,
    required this.isMobile,
  });

  final String label;
  final int value;
  final IconData icon;
  final Color bg;
  final Color fg;
  final bool isMobile;

  @override
  Widget build(BuildContext context) {
    // Flat white card + colored left accent strip + colored icon chip —
    // matches the notification card language below instead of a full
    // pastel-fill block, so the whole screen reads as one cohesive system.
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: isMobile ? 14 : 18,
        vertical: isMobile ? 14 : 16,
      ),
      decoration: BoxDecoration(
        color: AppColors.surfaceColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.borderColor.withOpacity(0.7)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          // colored left accent strip — carries the semantic color
          Container(
            width: 3,
            height: isMobile ? 32 : 36,
            decoration: BoxDecoration(
              color: fg,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 12),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: fg.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              icon,
              color: fg,
              size: isMobile ? 17 : 19,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                fontFamily: 'Cairo',
                color: AppColors.textSecondary,
                fontWeight: FontWeight.w600,
                fontSize: isMobile ? 12.5 : 13.5,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          const SizedBox(width: 10),
          Text(
            '$value',
            style: TextStyle(
              color: AppColors.textPrimary,
              fontWeight: FontWeight.w800,
              fontFamily: 'Cairo',
              fontSize: isMobile ? 18 : 20,
            ),
          ),
        ],
      ),
    );
  }
}
