import 'package:bloc/bloc.dart';
import 'package:sphinx/core/data/services/supabase_service.dart';
import 'package:sphinx/core/di/dependency_injection.dart';
import 'package:sphinx/features/branches/presentation/cubit/branch_cubit.dart';
import '../../data/models/stock_summary_category_model.dart';
import '../../data/models/product_sales_detail.dart';
import 'stock_summary_state.dart';

class StockSummaryCubit extends Cubit<StockSummaryState> {
  final SupabaseService _supabaseService;

  StockSummaryCubit({SupabaseService? supabaseService})
      : _supabaseService = supabaseService ?? SupabaseService(),
        super(StockSummaryInitial());

  void init() {
    loadData();
  }

  Future<void> loadData() async {
    if (isClosed) return;
    final selectionRevision = getIt<BranchCubit>().state.selectionRevision;
    emit(StockSummaryLoading());
    try {
      final Map<String, String> categoryNamesMap = {};
      try {
        final catRes =
            await _supabaseService.from('categories').select('id, name');
        for (var c in (catRes as List)) {
          final id = c['id'] as String?;
          final name = c['name'] as String?;
          if (id != null && name != null && name.trim().isNotEmpty) {
            final normalizedName = name.trim();
            categoryNamesMap[id] = normalizedName;
            categoryNamesMap[normalizedName] = normalizedName;
          }
        }
      } catch (_) {}

      // Get branch stock — branch-specific or aggregated for All Branches
      final branchId = getIt<BranchCubit>().effectiveBranchId;
      Map<String, Map<String, dynamic>> branchStockMap = {};

      if (branchId != null) {
        final stockResp = await _supabaseService
            .from('branch_stock')
            .select('product_id, quantity')
            .eq('branch_id', branchId);
        for (var row in (stockResp as List)) {
          branchStockMap[row['product_id'] as String] = row;
        }
      } else {
        // All Branches: aggregate all branch_stock rows
        final stockResp = await _supabaseService
            .from('branch_stock')
            .select('product_id, quantity');
        for (var row in (stockResp as List)) {
          final pid = row['product_id'] as String;
          final qty = (row['quantity'] as num?)?.toDouble() ?? 0;
          final existing = branchStockMap[pid]?['quantity'] as num? ?? 0;
          branchStockMap[pid] = {
            'product_id': pid,
            'quantity': existing + qty,
          };
        }
      }

      final stockResponse = await _supabaseService
          .from('products')
          .select(
              'id, category, barcode, quantity, wholesale_price, min_price, price')
          .eq('is_active', true);

      final Map<String, Map<String, dynamic>> stockDataMap = {};
      final Map<String, String> productCategories = {};
      for (var row in (stockResponse as List)) {
        final cat = row['category'] as String? ?? 'General';
        final productId = row['id'] as String;
        productCategories[productId] = cat;
        if (!stockDataMap.containsKey(cat)) {
          stockDataMap[cat] = {
            'category': cat,
            'product_count': 0,
            'total_quantity': 0,
            'wholesale_value': 0.0,
            'min_sell_value': 0.0,
            'default_sell_value': 0.0,
          };
        }
        final data = stockDataMap[cat]!;
        data['product_count'] = (data['product_count'] as int) + 1;
        final stock =
            (branchStockMap[productId]?['quantity'] as num?)?.toDouble() ?? 0;
        data['total_quantity'] = (data['total_quantity'] as num) + stock;
        data['wholesale_value'] = (data['wholesale_value'] as double) +
            stock * (row['wholesale_price'] as num).toDouble();
        data['min_sell_value'] = (data['min_sell_value'] as double) +
            stock * (row['min_price'] as num).toDouble();
        data['default_sell_value'] = (data['default_sell_value'] as double) +
            stock * (row['price'] as num).toDouble();
      }

      var salesQuery = _supabaseService
          .from('sale_items')
          .select(
              'product_id, name, product_barcode, quantity, refunded_quantity, wholesale_price, sales!inner(invoice_type_index, branch_id)')
          .eq('sales.invoice_type_index', 0);

      if (branchId != null) {
        salesQuery = salesQuery.eq('sales.branch_id', branchId);
      }

      final salesResponse = await salesQuery;

      final Map<String, List<ProductSalesDetail>> catDetails = {};
      final Map<String, int> catSoldQty = {};
      final Map<String, double> catSoldValue = {};

      for (var row in (salesResponse as List)) {
        final productId = row['product_id'] as String;
        final soldQty = (row['quantity'] as num).toInt();
        final refundedQty = (row['refunded_quantity'] as num?)?.toInt() ?? 0;
        final wholesaleCost =
            (row['wholesale_price'] as num).toDouble() * soldQty;

        final categoryId = productCategories[productId] ?? 'Deleted';

        catSoldQty[categoryId] =
            (catSoldQty[categoryId] ?? 0) + (soldQty - refundedQty);
        catSoldValue[categoryId] =
            (catSoldValue[categoryId] ?? 0) + wholesaleCost;

        if (!catDetails.containsKey(categoryId)) {
          catDetails[categoryId] = [];
        }
        catDetails[categoryId]!.add(ProductSalesDetail(
          productName: row['name'] as String,
          barcode: row['product_barcode'] as String? ?? productId,
          soldQuantity: soldQty,
          refundedQuantity: refundedQty,
        ));
      }

      final List<StockSummaryCategoryModel> summaryList = [];
      // Only include categories that exist in the categories table
      final validCats = categoryNamesMap.keys.toSet();
      final allCats = {...stockDataMap.keys, ...catDetails.keys}
          .where((cat) => validCats.contains(cat))
          .toList();

      for (var cat in allCats) {
        final stockRow = stockDataMap[cat];
        final currentQty =
            stockRow != null ? (stockRow['total_quantity'] as num).toInt() : 0;
        final currentWholesale =
            stockRow != null ? (stockRow['wholesale_value'] as double) : 0.0;
        final minSell =
            stockRow != null ? (stockRow['min_sell_value'] as double) : 0.0;
        final defaultSell =
            stockRow != null ? (stockRow['default_sell_value'] as double) : 0.0;
        final productCount =
            stockRow != null ? (stockRow['product_count'] as int) : 0;
        final soldVal = catSoldValue[cat] ?? 0.0;

        String categoryDisplayName = cat;
        if (cat == 'Deleted') {
          categoryDisplayName = 'قسم مؤرشف';
        } else if (cat == 'General') {
          categoryDisplayName = 'عام';
        } else if (categoryNamesMap.containsKey(cat)) {
          categoryDisplayName = categoryNamesMap[cat]!;
        } else if (RegExp(r'^[0-9a-fA-F\-]{20,}$').hasMatch(cat)) {
          categoryDisplayName = 'قسم غير مسمى';
        }

        summaryList.add(StockSummaryCategoryModel(
          categoryName: categoryDisplayName,
          productCount: productCount,
          totalQuantity: currentQty,
          totalSoldQuantity: catSoldQty[cat] ?? 0,
          totalHistoricValue: currentWholesale + soldVal,
          totalCurrentWholesaleValue: currentWholesale,
          totalMinSellValue: minSell,
          totalDefaultSellValue: defaultSell,
          isDeletedCategory: cat == 'Deleted',
          productDetails: catDetails[cat] ?? [],
        ));
      }

      double grandHistoric = 0;
      double grandCurrent = 0;
      double grandExpectedProfit = 0;

      for (var s in summaryList) {
        grandHistoric += s.totalHistoricValue;
        grandCurrent += s.totalCurrentWholesaleValue;
        grandExpectedProfit += s.expectedProfit;
      }

      if (!isClosed &&
          selectionRevision == getIt<BranchCubit>().state.selectionRevision) {
        emit(StockSummaryLoaded(
          categories: summaryList,
          totalStoreHistoricValue: grandHistoric,
          totalStoreCurrentValue: grandCurrent,
          totalExpectedProfit: grandExpectedProfit,
        ));
      }
    } catch (e) {
      if (!isClosed) emit(StockSummaryError("Failed to calculate summary: $e"));
    }
  }
}
