import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/components/screen_header.dart';
import '../../../../core/di/dependency_injection.dart';
import '../../../../core/utils/responsive_helper.dart';
import '../../../../l10n/app_localizations.dart';
import '../../../auth/presentation/cubit/user_cubit.dart';
import '../../../branches/presentation/cubit/branch_cubit.dart';

class TakeInventoryScreen extends StatefulWidget {
  const TakeInventoryScreen({super.key});

  @override
  State<TakeInventoryScreen> createState() => _TakeInventoryScreenState();
}

class _TakeInventoryScreenState extends State<TakeInventoryScreen> {
  List<Map<String, dynamic>> _products = [];
  bool _loading = true;
  bool _saving = false;
  String _searchQuery = '';
  final Map<String, TextEditingController> _countControllers = {};
  String? _snapshotId;

  @override
  void initState() {
    super.initState();
    _loadProducts();
  }

  @override
  void dispose() {
    for (final c in _countControllers.values) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _loadProducts() async {
    setState(() => _loading = true);
    try {
      final branchId = getIt<BranchCubit>().effectiveBranchId;

      final response = await Supabase.instance.client
          .from('products')
          .select('id, name, barcode, category')
          .eq('is_active', true)
          .order('name');

      List<Map<String, dynamic>> products =
          (response as List).cast<Map<String, dynamic>>();

      if (branchId != null) {
        // Load stock from branch_stock
        final stockResponse = await Supabase.instance.client
            .from('branch_stock')
            .select('product_id, quantity, min_quantity')
            .eq('branch_id', branchId);

        final stockMap = <String, Map<String, dynamic>>{};
        for (var row in (stockResponse as List)) {
          stockMap[row['product_id'] as String] = row;
        }

        for (var p in products) {
          final stock = stockMap[p['id'] as String];
          p['stock'] =
              stock != null ? (stock['quantity'] as num?)?.toDouble() ?? 0 : 0;
          p['min_stock'] = stock != null
              ? (stock['min_quantity'] as num?)?.toDouble() ?? 0
              : 0;
        }
      } else {
        // Fallback: read from products.stock (stock column already in response)
      }

      setState(() {
        _products = products;
        for (final p in _products) {
          final id = p['id'] as String;
          final systemQty = (p['stock'] as num?)?.toDouble() ?? 0;
          _countControllers[id] = TextEditingController(
            text: systemQty.toStringAsFixed(
                systemQty.truncateToDouble() == systemQty ? 0 : 3),
          );
        }
        _loading = false;
      });
    } catch (e) {
      setState(() => _loading = false);
    }
  }

  List<Map<String, dynamic>> get _filteredProducts {
    if (_searchQuery.isEmpty) return _products;
    final q = _searchQuery.toLowerCase();
    return _products.where((p) {
      final name = (p['name'] as String? ?? '').toLowerCase();
      final barcode = (p['barcode'] as String? ?? '').toLowerCase();
      return name.contains(q) || barcode.contains(q);
    }).toList();
  }

  double _getSystemQty(Map<String, dynamic> product) {
    return (product['stock'] as num?)?.toDouble() ?? 0;
  }

  double _getActualQty(Map<String, dynamic> product) {
    final id = product['id'] as String;
    return double.tryParse(_countControllers[id]?.text ?? '') ?? 0;
  }

  double _getDifference(Map<String, dynamic> product) {
    return _getActualQty(product) - _getSystemQty(product);
  }

  int get _totalDiscrepancies {
    return _products.where((p) {
      final diff = _getDifference(p);
      return diff != 0;
    }).length;
  }

  Future<void> _saveInventory() async {
    if (_saving) return;
    final branchId = getIt<BranchCubit>().effectiveBranchId;
    if (branchId == null) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(AppLocalizations.of(context).branchRequired)),
      );
      return;
    }
    setState(() => _saving = true);

    try {
      final l10n = AppLocalizations.of(context);
      final userId = getIt<UserCubit>().currentUser.id;

      // Create snapshot
      final snapshotResponse = await Supabase.instance.client
          .from('inventory_snapshots')
          .insert({
            'user_id': userId,
            'notes':
                'Inventory count - ${DateTime.now().toString().substring(0, 10)}',
            'status': 'draft',
            'branch_id': branchId,
          })
          .select('id')
          .single();

      final snapshotId = snapshotResponse['id'] as String;

      // Insert items
      final items = _products.map((p) {
        final id = p['id'] as String;
        final systemQty = _getSystemQty(p);
        final actualQty = _getActualQty(p);
        return {
          'snapshot_id': snapshotId,
          'product_id': id,
          'expected_qty': systemQty,
          'counted_qty': actualQty,
          'difference': actualQty - systemQty,
        };
      }).toList();

      await Supabase.instance.client
          .from('inventory_snapshot_items')
          .insert(items);

      // Finalize
      await Supabase.instance.client.rpc('finalize_inventory_snapshot',
          params: {'snapshot_id': snapshotId});

      setState(() => _snapshotId = snapshotId);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(l10n.localeName == 'ar'
                ? 'تم حفظ الجرد بنجاح'
                : 'Inventory saved successfully'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        final l10n = AppLocalizations.of(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(l10n.localeName == 'ar'
                ? 'خطأ في حفظ الجرد: $e'
                : 'Error saving inventory: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final isArabic = l10n.localeName == 'ar';

    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Padding(
              padding: EdgeInsets.symmetric(
                  horizontal: ResponsiveHelper.isMobile(context) ? 16 : 32,
                  vertical: 8),
              child: ScreenHeader(
                title: isArabic ? 'جرد المخزن' : 'Take Inventory',
                icon: LucideIcons.clipboardList,
                subtitle: isArabic
                    ? 'عدّ كميات المخزون الفعلية'
                    : 'Count actual stock quantities',
              ),
            ),

            // Summary bar
            if (!_loading && _products.isNotEmpty)
              Container(
                margin: EdgeInsets.symmetric(
                    horizontal: ResponsiveHelper.isMobile(context) ? 16 : 32),
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppColors.borderColor),
                ),
                child: Row(
                  children: [
                    _buildSummaryChip(
                      '${_products.length}',
                      isArabic ? 'منتج' : 'Products',
                      AppColors.primaryColor,
                    ),
                    const SizedBox(width: 16),
                    _buildSummaryChip(
                      '$_totalDiscrepancies',
                      isArabic ? 'فرق' : 'Discrepancies',
                      _totalDiscrepancies > 0 ? Colors.orange : Colors.green,
                    ),
                    const Spacer(),
                    if (_snapshotId != null)
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.green.shade50,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.check_circle,
                                size: 14, color: Colors.green.shade700),
                            const SizedBox(width: 4),
                            Text(
                              isArabic ? 'تم الحفظ' : 'Saved',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                color: Colors.green.shade700,
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),

            const SizedBox(height: 8),

            // Search
            if (!_loading && _products.isNotEmpty)
              Padding(
                padding: EdgeInsets.symmetric(
                    horizontal: ResponsiveHelper.isMobile(context) ? 16 : 32),
                child: TextField(
                  onChanged: (val) => setState(() => _searchQuery = val),
                  decoration: InputDecoration(
                    hintText: isArabic ? 'بحث...' : 'Search...',
                    prefixIcon: const Icon(LucideIcons.search, size: 18),
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide:
                          const BorderSide(color: AppColors.borderColor),
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 12),
                  ),
                ),
              ),

            const SizedBox(height: 8),

            // Product list
            Expanded(
              child: _loading
                  ? const Center(
                      child: CircularProgressIndicator(
                          color: AppColors.primaryColor))
                  : _products.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(LucideIcons.packageOpen,
                                  size: 48,
                                  color: AppColors.mutedColor.withOpacity(0.4)),
                              const SizedBox(height: 12),
                              Text(
                                isArabic
                                    ? 'لا يوجد منتجات'
                                    : 'No products found',
                                style: TextStyle(
                                    color: AppColors.mutedColor, fontSize: 14),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          padding: EdgeInsets.symmetric(
                              horizontal:
                                  ResponsiveHelper.isMobile(context) ? 16 : 32,
                              vertical: 4),
                          itemCount: _filteredProducts.length,
                          itemBuilder: (ctx, index) =>
                              _buildProductRow(_filteredProducts[index]),
                        ),
            ),

            // Save button
            if (!_loading && _products.isNotEmpty)
              Container(
                padding: EdgeInsets.all(
                    ResponsiveHelper.isMobile(context) ? 16 : 32),
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border(top: BorderSide(color: AppColors.borderColor)),
                ),
                child: SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    onPressed: _saving ? null : _saveInventory,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primaryColor,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: _saving
                        ? const SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(LucideIcons.save, size: 20),
                              const SizedBox(width: 8),
                              Text(
                                isArabic ? 'حفظ الجرد' : 'Save Inventory',
                                style: const TextStyle(
                                    fontSize: 16, fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryChip(String value, String label, Color color) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            value,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
        ),
        const SizedBox(width: 6),
        Text(
          label,
          style: const TextStyle(fontSize: 12, color: AppColors.mutedColor),
        ),
      ],
    );
  }

  Widget _buildProductRow(Map<String, dynamic> product) {
    final id = product['id'] as String;
    final name = product['name'] as String? ?? '';
    final barcode = product['barcode'] as String? ?? '';
    final categoryName =
        (product['categories'] as Map<String, dynamic>?)?['name'] as String? ??
            '';
    final systemQty = _getSystemQty(product);
    _getActualQty(product);
    final diff = _getDifference(product);

    final diffColor = diff > 0
        ? Colors.green
        : diff < 0
            ? Colors.red
            : AppColors.mutedColor;

    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: diff != 0
              ? diffColor.withOpacity(0.3)
              : AppColors.borderColor.withOpacity(0.5),
        ),
      ),
      child: Row(
        children: [
          // Product info
          Expanded(
            flex: 3,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                if (barcode.isNotEmpty || categoryName.isNotEmpty)
                  Text(
                    [barcode, categoryName]
                        .where((e) => e.isNotEmpty)
                        .join(' · '),
                    style: TextStyle(
                      fontSize: 11,
                      color: AppColors.mutedColor.withOpacity(0.7),
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
              ],
            ),
          ),

          // System qty
          SizedBox(
            width: 65,
            child: Column(
              children: [
                Text(
                  systemQty.toStringAsFixed(
                      systemQty.truncateToDouble() == systemQty ? 0 : 2),
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    color: AppColors.textPrimary,
                  ),
                ),
                Text(
                  'System',
                  style: TextStyle(
                      fontSize: 9,
                      color: AppColors.mutedColor.withOpacity(0.6)),
                ),
              ],
            ),
          ),

          const SizedBox(width: 8),

          // Actual qty input
          SizedBox(
            width: 80,
            child: TextField(
              controller: _countControllers[id],
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              inputFormatters: [
                FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,3}')),
              ],
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
              decoration: InputDecoration(
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(color: AppColors.borderColor),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide:
                      BorderSide(color: AppColors.primaryColor, width: 2),
                ),
                isDense: true,
              ),
              onChanged: (_) => setState(() {}),
            ),
          ),

          const SizedBox(width: 8),

          // Difference
          SizedBox(
            width: 55,
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 4),
              decoration: BoxDecoration(
                color: diffColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(
                diff > 0
                    ? '+${diff.toStringAsFixed(diff.truncateToDouble() == diff ? 0 : 2)}'
                    : diff.toStringAsFixed(
                        diff.truncateToDouble() == diff ? 0 : 2),
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                  color: diffColor,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
