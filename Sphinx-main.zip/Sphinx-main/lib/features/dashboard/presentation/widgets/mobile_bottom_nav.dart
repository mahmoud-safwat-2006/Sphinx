import 'package:flutter/material.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../l10n/app_localizations.dart';
import 'side_bar.dart';

/// Premium mobile bottom navigation bar with smooth animations.
///
/// Shows 4 pinned items (dashboard, pos, products, invoices) and a "More"
/// overflow that opens a professional grouped bottom sheet.
class MobileBottomNav extends StatelessWidget {
  final List<SidebarItem> items;
  final int selectedIndex;
  final ValueChanged<int> onTap;

  const MobileBottomNav({
    super.key,
    required this.items,
    required this.selectedIndex,
    required this.onTap,
  });

  static const _mainIds = ['dashboard', 'pos', 'products', 'invoices'];

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final mainItems = <SidebarItem>[];
    final moreItems = <SidebarItem>[];

    for (final item in items) {
      if (_mainIds.contains(item.id)) {
        mainItems.add(item);
      } else {
        moreItems.add(item);
      }
    }

    final selectedId = items[selectedIndex].id;
    final isMoreSelected = !mainItems.any((i) => i.id == selectedId);

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: AppColors.textPrimary.withOpacity(.06),
            blurRadius: 20,
            offset: const Offset(0, -4),
          ),
        ],
        border: const Border(
          top: BorderSide(color: AppColors.borderColor, width: .5),
        ),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(6, 6, 6, 4),
          child: Row(
            children: [
              ...mainItems.map((item) {
                final globalIdx = items.indexWhere((i) => i.id == item.id);
                final isSelected = globalIdx == selectedIndex;
                return Expanded(
                  child: _NavItem(
                    icon: item.icon,
                    label: item.title,
                    isSelected: isSelected,
                    onTap: () => onTap(globalIdx),
                  ),
                );
              }),
              Expanded(
                child: _NavItem(
                  icon: LucideIcons.ellipsis,
                  label: l10n.moreLabel,
                  isSelected: isMoreSelected,
                  onTap: () => _showMoreSheet(context, moreItems),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showMoreSheet(BuildContext context, List<SidebarItem> moreItems) {
    final l10n = AppLocalizations.of(context);
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) => _MoreSheet(
        allItems: items,
        moreItems: moreItems,
        selectedIndex: selectedIndex,
        l10n: l10n,
        onTap: (idx) {
          Navigator.pop(ctx);
          onTap(idx);
        },
      ),
    );
  }
}

// ─────────────────────── Single nav destination ─────────────────────────

class _NavItem extends StatefulWidget {
  final IconData icon;
  final String label;
  final bool isSelected;
  final VoidCallback onTap;

  const _NavItem({
    required this.icon,
    required this.label,
    required this.isSelected,
    required this.onTap,
  });

  @override
  State<_NavItem> createState() => _NavItemState();
}

class _NavItemState extends State<_NavItem>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _scale;
  late final Animation<double> _pillWidth;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 280),
      value: widget.isSelected ? 1 : 0,
    );
    _scale = Tween(begin: 1.0, end: 1.12).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic),
    );
    _pillWidth = Tween(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic),
    );
  }

  @override
  void didUpdateWidget(_NavItem old) {
    super.didUpdateWidget(old);
    if (widget.isSelected != old.isSelected) {
      widget.isSelected ? _ctrl.forward() : _ctrl.reverse();
    }
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final activeColor = AppColors.primaryColor;
    final inactiveColor = AppColors.mutedColor;

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: widget.onTap,
      child: AnimatedBuilder(
        animation: _ctrl,
        builder: (context, _) {
          final color =
              Color.lerp(inactiveColor, activeColor, _ctrl.value)!;
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Pill indicator
              AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                curve: Curves.easeOutCubic,
                width: 32 * _pillWidth.value,
                height: 3,
                decoration: BoxDecoration(
                  color: activeColor,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 6),
              // Icon with scale
              Transform.scale(
                scale: _scale.value,
                child: Icon(widget.icon, size: 22, color: color),
              ),
              const SizedBox(height: 3),
              // Label
              Text(
                widget.label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 10,
                  fontWeight:
                      widget.isSelected ? FontWeight.w800 : FontWeight.w500,
                  color: color,
                  letterSpacing: widget.isSelected ? .3 : 0,
                ),
              ),
              const SizedBox(height: 2),
            ],
          );
        },
      ),
    );
  }
}

// ─────────────────────── "More" bottom sheet ────────────────────────────

/// Section grouping for the More sheet.
const _moreSections = {
  'stock': ['stock_alerts', 'stock_summary'],
  'finance': ['expenses'],
  'management': ['branches', 'reports', 'sessions'],
  'system': ['notifications', 'settings'],
};

class _MoreSheet extends StatelessWidget {
  final List<SidebarItem> allItems;
  final List<SidebarItem> moreItems;
  final int selectedIndex;
  final AppLocalizations l10n;
  final ValueChanged<int> onTap;

  const _MoreSheet({
    required this.allItems,
    required this.moreItems,
    required this.selectedIndex,
    required this.l10n,
    required this.onTap,
  });

  String _sectionTitle(String key) {
    final isArabic = l10n.localeName == 'ar';
    switch (key) {
      case 'stock':
        return isArabic ? 'المخزون' : 'STOCK';
      case 'finance':
        return isArabic ? 'المالية' : 'FINANCE';
      case 'management':
        return isArabic ? 'الإدارة' : 'MANAGEMENT';
      case 'system':
        return isArabic ? 'النظام' : 'SYSTEM';
      default:
        return key.toUpperCase();
    }
  }

  IconData _sectionIcon(String key) {
    switch (key) {
      case 'stock':
        return LucideIcons.warehouse;
      case 'finance':
        return LucideIcons.wallet;
      case 'management':
        return LucideIcons.chartBar;
      case 'system':
        return LucideIcons.settings;
      default:
        return LucideIcons.grid3x3;
    }
  }

  Color _sectionColor(String key) {
    switch (key) {
      case 'stock':
        return AppColors.warningColor;
      case 'finance':
        return AppColors.successColor;
      case 'management':
        return AppColors.primaryColor;
      case 'system':
        return AppColors.mutedColor;
      default:
        return AppColors.primaryColor;
    }
  }

  @override
  Widget build(BuildContext context) {
    // Build sections that have matching items
    final activeSections = <String, List<SidebarItem>>{};

    for (final entry in _moreSections.entries) {
      final sectionItems = <SidebarItem>[];
      for (final id in entry.value) {
        final match = moreItems.where((i) => i.id == id);
        if (match.isNotEmpty) sectionItems.add(match.first);
      }
      if (sectionItems.isNotEmpty) {
        activeSections[entry.key] = sectionItems;
      }
    }

    // Catch any items not in a section
    final grouped = activeSections.values.expand((e) => e).map((e) => e.id).toSet();
    final ungrouped =
        moreItems.where((i) => !grouped.contains(i.id)).toList();

    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(
            maxHeight: MediaQuery.of(context).size.height * 0.6,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 12),
              // Handle bar
              Container(
                width: 44,
                height: 5,
                decoration: BoxDecoration(
                  color: AppColors.borderColor,
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
              const SizedBox(height: 16),
              // Title
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: AppColors.primaryColor.withOpacity(.08),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(LucideIcons.layoutGrid,
                          size: 18, color: AppColors.primaryColor),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      l10n.moreLabel,
                      style: const TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const Spacer(),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        width: 32,
                        height: 32,
                        decoration: BoxDecoration(
                          color: AppColors.surfaceColor,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(LucideIcons.x,
                            size: 16, color: AppColors.mutedColor),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              // Sections
              Flexible(
                child: ListView(
                  shrinkWrap: true,
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                  children: [
                    for (final entry in activeSections.entries) ...[
                      _SectionHeader(
                        title: _sectionTitle(entry.key),
                        icon: _sectionIcon(entry.key),
                        color: _sectionColor(entry.key),
                      ),
                      Container(
                        margin: const EdgeInsets.only(bottom: 14),
                        decoration: BoxDecoration(
                          color: AppColors.surfaceColor,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                              color: AppColors.borderColor.withOpacity(.5)),
                        ),
                        child: Column(
                          children: [
                            for (int i = 0; i < entry.value.length; i++) ...[
                              _MoreTile(
                                item: entry.value[i],
                                isSelected: allItems.indexWhere(
                                        (x) => x.id == entry.value[i].id) ==
                                    selectedIndex,
                                isLast: i == entry.value.length - 1,
                                onTap: () => onTap(allItems.indexWhere(
                                    (x) => x.id == entry.value[i].id)),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ],
                    // Ungrouped items
                    if (ungrouped.isNotEmpty) ...[
                      _SectionHeader(
                        title: l10n.localeName == 'ar' ? 'أخرى' : 'OTHER',
                        icon: LucideIcons.moreHorizontal,
                        color: AppColors.mutedColor,
                      ),
                      Container(
                        margin: const EdgeInsets.only(bottom: 14),
                        decoration: BoxDecoration(
                          color: AppColors.surfaceColor,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                              color: AppColors.borderColor.withOpacity(.5)),
                        ),
                        child: Column(
                          children: [
                            for (int i = 0; i < ungrouped.length; i++)
                              _MoreTile(
                                item: ungrouped[i],
                                isSelected: allItems.indexWhere(
                                        (x) => x.id == ungrouped[i].id) ==
                                    selectedIndex,
                                isLast: i == ungrouped.length - 1,
                                onTap: () => onTap(allItems.indexWhere(
                                    (x) => x.id == ungrouped[i].id)),
                              ),
                          ],
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─────────────────────── Section header ──────────────────────────────────

class _SectionHeader extends StatelessWidget {
  final String title;
  final IconData icon;
  final Color color;
  const _SectionHeader(
      {required this.title, required this.icon, required this.color});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 6, 4, 6),
      child: Row(
        children: [
          Icon(icon, size: 13, color: color),
          const SizedBox(width: 6),
          Text(
            title,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w800,
              color: color,
              letterSpacing: .8,
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────── Single tile in a section ───────────────────────

class _MoreTile extends StatefulWidget {
  final SidebarItem item;
  final bool isSelected;
  final bool isLast;
  final VoidCallback onTap;

  const _MoreTile({
    required this.item,
    required this.isSelected,
    required this.isLast,
    required this.onTap,
  });

  @override
  State<_MoreTile> createState() => _MoreTileState();
}

class _MoreTileState extends State<_MoreTile> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final fg =
        widget.isSelected ? AppColors.primaryColor : AppColors.textPrimary;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        decoration: BoxDecoration(
          color: widget.isSelected
              ? AppColors.primaryColor.withOpacity(.06)
              : _pressed
                  ? AppColors.primaryColor.withOpacity(.03)
                  : Colors.transparent,
          borderRadius: widget.isLast
              ? const BorderRadius.vertical(bottom: Radius.circular(14))
              : null,
        ),
        child: Column(
          children: [
            Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              child: Row(
                children: [
                  // Icon container
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(
                      color: widget.isSelected
                          ? AppColors.primaryColor.withOpacity(.10)
                          : AppColors.backgroundColor,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(widget.item.icon, size: 18, color: fg),
                  ),
                  const SizedBox(width: 12),
                  // Title
                  Expanded(
                    child: Text(
                      widget.item.title,
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: widget.isSelected
                            ? FontWeight.w700
                            : FontWeight.w500,
                        color: fg,
                      ),
                    ),
                  ),
                  // Selected indicator
                  if (widget.isSelected)
                    Container(
                      width: 8,
                      height: 8,
                      decoration: const BoxDecoration(
                        color: AppColors.primaryColor,
                        shape: BoxShape.circle,
                      ),
                    )
                  else
                    Icon(LucideIcons.chevronRight,
                        size: 16, color: AppColors.mutedColor.withOpacity(.5)),
                ],
              ),
            ),
            // Divider (except last)
            if (!widget.isLast)
              Divider(
                height: 1,
                thickness: .5,
                indent: 64,
                color: AppColors.borderColor.withOpacity(.5),
              ),
          ],
        ),
      ),
    );
  }
}
