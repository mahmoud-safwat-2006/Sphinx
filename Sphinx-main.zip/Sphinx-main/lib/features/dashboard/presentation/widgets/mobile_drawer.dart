import 'package:flutter/material.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/components/local_image_view.dart';
import '../../../../core/di/dependency_injection.dart';
import '../../../../core/localization/locale_provider.dart';
import '../../../../core/localization/translation_helper.dart';
import '../../../../l10n/app_localizations.dart';
import '../../../auth/data/models/user_model.dart';
import '../../../auth/presentation/cubit/user_cubit.dart';
import '../../../settings/presentation/widgets/add_edit_user_dialog.dart';
import 'side_bar.dart';

/// Professional mobile drawer with grouped navigation sections,
/// profile header with avatar & edit action.
class MobileDrawer extends StatelessWidget {
  final List<SidebarItem> items;
  final int selectedIndex;
  final ValueChanged<int> onTap;

  const MobileDrawer({
    super.key,
    required this.items,
    required this.selectedIndex,
    required this.onTap,
  });

  static const _sections = {
    'home': ['dashboard'],
    'sales': ['pos', 'invoices'],
    'stock': ['products', 'stock_alerts', 'stock_summary'],
    'system': [
      'branches',
      'expenses',
      'reports',
      'sessions',
      'notifications',
      'settings'
    ],
  };

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final user = getIt<UserCubit>().currentUser;
    final name = TranslationHelper.translateUserName(context, user.name,
        username: user.username);
    final initial = name.isNotEmpty ? name.substring(0, 1).toUpperCase() : '?';
    final isArabic = l10n.localeName == 'ar';
    final roleLabel = _roleLabel(user.userType, isArabic);

    return Drawer(
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.horizontal(right: Radius.circular(20)),
      ),
      child: Column(
        children: [
          // ─── Profile header ─────────────────────────────────
          Container(
            width: double.infinity,
            padding: EdgeInsets.fromLTRB(20, MediaQuery.of(context).padding.top + 12, 20, 16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  AppColors.sidebarColor,
                  AppColors.sidebarColor.withOpacity(.85),
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    // Avatar
                    GestureDetector(
                      onTap: () => _editProfile(context, user),
                      child: Container(
                        width: 52,
                        height: 52,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                              color: Colors.white.withOpacity(.3), width: 2),
                        ),
                        child: ClipOval(
                          child: LocalImageView(
                            path: user.imagePath,
                            width: 48,
                            height: 48,
                            borderRadius: 24,
                            fallback: Container(
                              width: 48,
                              height: 48,
                              color: AppColors.secondaryColor,
                              alignment: Alignment.center,
                              child: Text(
                                initial,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            name,
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w700,
                              fontSize: 16,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            user.username,
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.7),
                              fontSize: 12,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(.15),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              roleLabel,
                              style: TextStyle(
                                color: Colors.white.withOpacity(.85),
                                fontSize: 10,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                // Action buttons row
                Row(
                  children: [
                    // Edit profile
                    Expanded(
                      child: _DrawerActionBtn(
                        icon: LucideIcons.pencil,
                        label: l10n.editProfile,
                        onTap: () => _editProfile(context, user),
                      ),
                    ),
                    const SizedBox(width: 8),
                    // Language toggle
                    Expanded(
                      child: _DrawerActionBtn(
                        icon: Icons.language,
                        label: isArabic ? 'English' : 'العربية',
                        onTap: () => getIt<LocaleProvider>().toggleLocale(),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          // ─── Nav sections ───────────────────────────────────
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 8),
              children: [
                for (final entry in _sections.entries) ...[
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 14, 20, 4),
                    child: Text(
                      _sectionLabel(entry.key, l10n),
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        color: AppColors.mutedColor,
                        letterSpacing: .5,
                      ),
                    ),
                  ),
                  for (final id in entry.value)
                    ...items.where((i) => i.id == id).map((item) {
                      final idx = items.indexOf(item);
                      final isSelected = idx == selectedIndex;
                      return _DrawerNavTile(
                        item: item,
                        isSelected: isSelected,
                        onTap: () => onTap(idx),
                      );
                    }),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _editProfile(BuildContext context, User user) {
    Navigator.pop(context); // close drawer
    showDialog<User>(
      context: context,
      builder: (_) => AddEditUserDialog(
        userToEdit: user,
        profileOnly: true,
      ),
    );
  }

  String _roleLabel(UserType? type, bool isArabic) {
    switch (type) {
      case UserType.manager:
        return isArabic ? 'مدير' : 'Manager';
      case UserType.cashier:
        return isArabic ? 'كاشير' : 'Cashier';
      default:
        return isArabic ? 'مستخدم' : 'User';
    }
  }

  String _sectionLabel(String key, AppLocalizations l10n) {
    switch (key) {
      case 'home':
        return l10n.localeName == 'ar' ? 'الرئيسية' : 'HOME';
      case 'sales':
        return l10n.localeName == 'ar' ? 'المبيعات' : 'SALES';
      case 'stock':
        return l10n.localeName == 'ar' ? 'المخزون' : 'STOCK';
      case 'system':
        return l10n.localeName == 'ar' ? 'النظام' : 'SYSTEM';
      default:
        return key;
    }
  }
}

// ─────────────────────── Drawer action button ───────────────────────────

class _DrawerActionBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _DrawerActionBtn(
      {required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(.12),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 15, color: Colors.white),
            const SizedBox(width: 6),
            Flexible(
              child: Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────── Navigation tile ─────────────────────────────────

class _DrawerNavTile extends StatefulWidget {
  final SidebarItem item;
  final bool isSelected;
  final VoidCallback onTap;
  const _DrawerNavTile(
      {required this.item, required this.isSelected, required this.onTap});

  @override
  State<_DrawerNavTile> createState() => _DrawerNavTileState();
}

class _DrawerNavTileState extends State<_DrawerNavTile> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 1),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: widget.isSelected
              ? AppColors.primaryColor.withOpacity(0.08)
              : _pressed
                  ? AppColors.primaryColor.withOpacity(0.03)
                  : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            // Icon
            AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: widget.isSelected
                    ? AppColors.primaryColor.withOpacity(.10)
                    : AppColors.surfaceColor,
                borderRadius: BorderRadius.circular(9),
              ),
              child: Icon(
                widget.item.icon,
                size: 17,
                color: widget.isSelected
                    ? AppColors.primaryColor
                    : AppColors.textSecondary,
              ),
            ),
            const SizedBox(width: 12),
            // Title
            Expanded(
              child: Text(
                widget.item.title,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight:
                      widget.isSelected ? FontWeight.w700 : FontWeight.w500,
                  color: widget.isSelected
                      ? AppColors.primaryColor
                      : AppColors.textPrimary,
                ),
              ),
            ),
            // Active dot
            if (widget.isSelected)
              Container(
                width: 6,
                height: 6,
                decoration: const BoxDecoration(
                  color: AppColors.primaryColor,
                  shape: BoxShape.circle,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
