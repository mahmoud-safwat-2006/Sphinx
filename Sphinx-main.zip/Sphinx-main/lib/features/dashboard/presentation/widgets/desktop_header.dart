import 'package:flutter/material.dart';

import '../../../../core/constants/app_colors.dart';

/// Desktop header bar with page icon, title, and trailing actions.
class DesktopHeader extends StatelessWidget {
  final String pageTitle;
  final IconData pageIcon;
  final List<Widget> actions;

  const DesktopHeader({
    super.key,
    required this.pageTitle,
    required this.pageIcon,
    required this.actions,
  });

  @override
  Widget build(BuildContext context) => Container(
        height: 80,
        padding: const EdgeInsets.symmetric(horizontal: 26),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Colors.white, AppColors.surfaceColor],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          border:
              const Border(bottom: BorderSide(color: AppColors.borderColor)),
          boxShadow: [
            BoxShadow(
              color: AppColors.textPrimary.withOpacity(.04),
              blurRadius: 14,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: AppColors.secondaryColor.withOpacity(.09),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(pageIcon, size: 19, color: AppColors.secondaryColor),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Text(
              pageTitle,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: AppColors.textPrimary,
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          ...actions,
        ]),
      );
}
