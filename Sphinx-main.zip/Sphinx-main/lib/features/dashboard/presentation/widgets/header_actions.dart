import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/components/local_image_view.dart';
import '../../../../core/di/dependency_injection.dart';
import '../../../../core/localization/locale_provider.dart';
import '../../../../core/localization/translation_helper.dart';
import '../../../../l10n/app_localizations.dart';
import '../../../auth/data/models/user_model.dart';
import '../../../auth/presentation/cubit/user_cubit.dart';
import '../../../auth/presentation/cubit/user_states.dart';
import '../../../branches/presentation/widgets/branch_switcher.dart';
import '../../../notifications/presentation/cubit/notifications_cubit.dart';
import '../../../notifications/presentation/cubit/notifications_states.dart';
import '../../../settings/presentation/widgets/add_edit_user_dialog.dart';
import '../../../shifts/presentation/cubit/shift_cubit.dart';
import '../../../shifts/presentation/cubit/shift_state.dart';

/// Builds the standard header action chips used in both the desktop
/// header and the mobile AppBar.
List<Widget> buildHeaderActions(
  BuildContext context, {
  bool compact = false,
  required VoidCallback onNotificationsTap,
}) {
  return [
    const BranchSwitcher(),
    ShiftStatusChip(compact: compact),
    if (!compact) LanguageToggle(compact: compact),
    _NotificationBell(
      compact: compact,
      onTap: onNotificationsTap,
    ),
    if (!compact)
      BlocBuilder<UserCubit, UserStates>(
        bloc: getIt<UserCubit>(),
        builder: (_, __) => ProfileMenu(
          user: getIt<UserCubit>().currentUser,
          compact: compact,
        ),
      ),
    const SizedBox(width: 8),
  ];
}

// ───────────────────────────── Shift Status ─────────────────────────────

class ShiftStatusChip extends StatelessWidget {
  final bool compact;
  const ShiftStatusChip({super.key, required this.compact});

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return BlocBuilder<ShiftCubit, ShiftState>(
      bloc: getIt<ShiftCubit>(),
      builder: (context, shiftState) {
        final session = shiftState.activeShift;
        final isOpen = session != null;

        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Container(
            padding: EdgeInsets.symmetric(
                horizontal: compact ? 8 : 12, vertical: compact ? 6 : 8),
            decoration: BoxDecoration(
              color: isOpen
                  ? Colors.green.withOpacity(compact ? 0.2 : 0.08)
                  : AppColors.errorColor.withOpacity(compact ? 0.2 : 0.08),
              borderRadius: BorderRadius.circular(13),
              border: Border.all(
                color: isOpen
                    ? Colors.green.withOpacity(0.3)
                    : AppColors.errorColor.withOpacity(0.3),
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: isOpen ? Colors.green : AppColors.errorColor,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  isOpen
                      ? (compact
                          ? '#${session.sessionNumber} · ${l10n.shiftOpen}'
                          : l10n.shiftOpen)
                      : l10n.noShift,
                  style: TextStyle(
                    fontSize: compact ? 10 : 11,
                    fontWeight: FontWeight.bold,
                    color:
                        isOpen ? Colors.green.shade700 : AppColors.errorColor,
                  ),
                ),
                if (session != null && !compact) ...[
                  const SizedBox(width: 4),
                  StreamBuilder<int>(
                    stream: Stream.periodic(
                      const Duration(minutes: 1),
                      (tick) => tick,
                    ),
                    builder: (context, snapshot) {
                      final duration =
                          DateTime.now().difference(session.openTime);
                      return Text(
                        '${duration.inHours}h '
                        '${duration.inMinutes.remainder(60)}m',
                        style: TextStyle(
                          fontSize: 10,
                          color: Colors.green.shade600,
                        ),
                      );
                    },
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}

// ───────────────────────────── Language ──────────────────────────────────

class LanguageToggle extends StatelessWidget {
  final bool compact;
  const LanguageToggle({super.key, required this.compact});

  @override
  Widget build(BuildContext context) {
    final isArabic = AppLocalizations.of(context).localeName == 'ar';
    final foreground = compact ? Colors.white : AppColors.textSecondary;

    return Tooltip(
      message: isArabic ? 'English' : 'العربية',
      child: InkWell(
        onTap: () => getIt<LocaleProvider>().toggleLocale(),
        borderRadius: BorderRadius.circular(20),
        child: Container(
          height: 38,
          margin: const EdgeInsets.symmetric(horizontal: 4),
          padding: EdgeInsets.symmetric(horizontal: compact ? 9 : 12),
          decoration: BoxDecoration(
            color: compact
                ? Colors.white.withOpacity(.12)
                : AppColors.backgroundColor,
            borderRadius: BorderRadius.circular(20),
            border: compact ? null : Border.all(color: AppColors.borderColor),
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.language, size: 18, color: foreground),
            if (!compact) ...[
              const SizedBox(width: 6),
              Text(
                isArabic ? 'EN' : 'ع',
                style: TextStyle(
                    color: foreground,
                    fontSize: 12,
                    fontWeight: FontWeight.w700),
              ),
            ],
          ]),
        ),
      ),
    );
  }
}

// ───────────────────────────── Notification Bell ────────────────────────

class _NotificationBell extends StatelessWidget {
  final bool compact;
  final VoidCallback onTap;
  const _NotificationBell({required this.compact, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<NotificationsCubit, NotificationsStates>(
      builder: (context, state) {
        final total = getIt<NotificationsCubit>().total;
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: compact
                      ? Colors.white.withOpacity(.12)
                      : AppColors.backgroundColor,
                  borderRadius: BorderRadius.circular(13),
                  border: compact
                      ? null
                      : Border.all(color: AppColors.borderColor),
                ),
                child: IconButton(
                  tooltip: AppLocalizations.of(context).notifications,
                  padding: EdgeInsets.zero,
                  iconSize: 19,
                  icon: Icon(
                    LucideIcons.bell,
                    color: compact ? Colors.white : AppColors.textSecondary,
                  ),
                  onPressed: onTap,
                ),
              ),
              if (total > 0)
                Positioned(
                  right: -2,
                  top: -3,
                  child: Container(
                    constraints:
                        const BoxConstraints(minWidth: 16, minHeight: 16),
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    alignment: Alignment.center,
                    decoration: const BoxDecoration(
                        color: AppColors.errorColor, shape: BoxShape.circle),
                    child: Text('$total',
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 9,
                            fontWeight: FontWeight.bold)),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

// ───────────────────────────── Profile Menu ──────────────────────────────

class ProfileMenu extends StatelessWidget {
  final User user;
  final bool compact;
  const ProfileMenu({super.key, required this.user, required this.compact});

  @override
  Widget build(BuildContext context) {
    final name = TranslationHelper.translateUserName(context, user.name,
        username: user.username);
    final initial = name.isNotEmpty ? name.substring(0, 1).toUpperCase() : '?';
    return PopupMenuButton<String>(
      tooltip: name,
      offset: const Offset(0, 48),
      onSelected: (value) {
        if (value == 'edit-profile') {
          showDialog<User>(
            context: context,
            builder: (_) => AddEditUserDialog(
              userToEdit: user,
              profileOnly: true,
            ),
          );
        }
      },
      itemBuilder: (_) => [
        PopupMenuItem<String>(
          enabled: false,
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(name,
                    style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary)),
                Text(user.username,
                    style: const TextStyle(
                        fontSize: 12, color: AppColors.mutedColor)),
              ]),
        ),
        PopupMenuItem<String>(
          value: 'edit-profile',
          child: Row(
            children: [
              const Icon(LucideIcons.pencil,
                  size: 18, color: AppColors.secondaryColor),
              const SizedBox(width: 10),
              Text(
                AppLocalizations.of(context).editProfile,
              ),
            ],
          ),
        ),
      ],
      child: Container(
        padding:
            EdgeInsets.symmetric(horizontal: compact ? 4 : 10, vertical: 6),
        decoration: BoxDecoration(
          color: compact
              ? Colors.white.withOpacity(.12)
              : AppColors.backgroundColor,
          borderRadius: BorderRadius.circular(22),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          LocalImageView(
            path: user.imagePath,
            width: 32,
            height: 32,
            borderRadius: 16,
            fallback: Container(
              color: AppColors.secondaryColor,
              alignment: Alignment.center,
              child: Text(
                initial,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          if (!compact) ...[
            const SizedBox(width: 8),
            ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 130),
                child: Text(name,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textPrimary))),
            const SizedBox(width: 4),
            const Icon(LucideIcons.chevronDown,
                size: 16, color: AppColors.mutedColor),
          ],
        ]),
      ),
    );
  }
}
