import 'package:sphinx/core/constants/app_colors.dart';
import 'package:sphinx/core/di/dependency_injection.dart';
import 'package:sphinx/features/invoice/presentation/cubit/invoice_cubit.dart';
import 'package:sphinx/features/invoice/presentation/cubit/invoice_state.dart';
import 'package:sphinx/features/pos/data/models/sale_model.dart';
import 'package:sphinx/l10n/app_localizations.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

class DashboardSalesCharts extends StatelessWidget {
  const DashboardSalesCharts({super.key});

  Map<String, double> _paymentTotals(List<Sale> sales) {
    final totals = <String, double>{'cash': 0, 'card': 0};
    for (final sale in sales) {
      final key = sale.paymentMethod == 'card' ? 'card' : 'cash';
      totals[key] = totals[key]! + (sale.isRefund ? -sale.total : sale.total);
    }
    return totals;
  }

  List<double> _todayHourlyTotals(List<Sale> sales, DateTime now) {
    final totals = List<double>.filled(24, 0);
    for (final sale in sales) {
      if (sale.date.year == now.year &&
          sale.date.month == now.month &&
          sale.date.day == now.day) {
        totals[sale.date.hour] += sale.isRefund ? -sale.total : sale.total;
      }
    }
    return totals;
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<InvoiceCubit, InvoiceState>(
      bloc: getIt<InvoiceCubit>(),
      builder: (context, state) {
        if (state.loading && state.sales.isEmpty) {
          return _chartCard(
            context: context,
            title: AppLocalizations.of(context).paymentMethodsChartTitle,
            icon: LucideIcons.chartPie,
            child: const SizedBox(
              height: 220,
              child: Center(child: CircularProgressIndicator()),
            ),
          );
        }

        final paymentTotals = _paymentTotals(state.sales);
        final hourlyTotals = _todayHourlyTotals(state.sales, DateTime.now());
        return Column(
          children: [
            _paymentChart(context, paymentTotals),
            const SizedBox(height: 16),
            _hourlyChart(context, hourlyTotals),
          ],
        );
      },
    );
  }

  Widget _paymentChart(
    BuildContext context,
    Map<String, double> totals,
  ) {
    final l10n = AppLocalizations.of(context);
    final cash = totals['cash'] ?? 0;
    final card = totals['card'] ?? 0;
    final cashDisplay = cash.clamp(0, double.infinity).toDouble();
    final cardDisplay = card.clamp(0, double.infinity).toDouble();
    final displayTotal = cashDisplay + cardDisplay;
    final netTotal = cash + card;

    return _chartCard(
      context: context,
      title: l10n.paymentMethodsChartTitle,
      icon: LucideIcons.chartPie,
      child: displayTotal <= 0
          ? _emptyState(context)
          : Column(
              children: [
                SizedBox(
                  height: 180,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      PieChart(
                        PieChartData(
                          centerSpaceRadius: 52,
                          sectionsSpace: 3,
                          startDegreeOffset: -90,
                          sections: [
                            PieChartSectionData(
                              value: cashDisplay,
                              color: AppColors.primaryColor,
                              radius: 28,
                              showTitle: false,
                            ),
                            PieChartSectionData(
                              value: cardDisplay,
                              color: AppColors.accentColor,
                              radius: 28,
                              showTitle: false,
                            ),
                          ],
                        ),
                      ),
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            netTotal.toStringAsFixed(2),
                            style: const TextStyle(
                              color: AppColors.textPrimary,
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          Text(
                            l10n.currencyEg,
                            style: const TextStyle(
                              color: AppColors.mutedColor,
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                _legendRow(
                  label: l10n.cashPayment,
                  value: cash,
                  percentage:
                      displayTotal == 0 ? 0 : cashDisplay / displayTotal,
                  color: AppColors.primaryColor,
                  currency: l10n.currencyEg,
                ),
                const SizedBox(height: 8),
                _legendRow(
                  label: l10n.cardPayment,
                  value: card,
                  percentage:
                      displayTotal == 0 ? 0 : cardDisplay / displayTotal,
                  color: AppColors.accentColor,
                  currency: l10n.currencyEg,
                ),
              ],
            ),
    );
  }

  Widget _hourlyChart(BuildContext context, List<double> totals) {
    final l10n = AppLocalizations.of(context);
    final displayTotals = totals
        .map((value) => value.clamp(0, double.infinity).toDouble())
        .toList();
    final maxValue = displayTotals.fold<double>(
      0,
      (current, value) => value > current ? value : current,
    );

    return _chartCard(
      context: context,
      title: l10n.hourlySalesChartTitle,
      icon: LucideIcons.chartColumn,
      child: maxValue <= 0
          ? _emptyState(context)
          : SizedBox(
              height: 240,
              child: Directionality(
                textDirection: TextDirection.ltr,
                child: BarChart(
                  BarChartData(
                    maxY: maxValue * 1.2,
                    alignment: BarChartAlignment.spaceAround,
                    borderData: FlBorderData(show: false),
                    gridData: FlGridData(
                      show: true,
                      drawVerticalLine: false,
                      getDrawingHorizontalLine: (value) => FlLine(
                        color: AppColors.borderColor.withOpacity(.6),
                        strokeWidth: 1,
                      ),
                    ),
                    titlesData: FlTitlesData(
                      leftTitles: const AxisTitles(
                        sideTitles: SideTitles(showTitles: false),
                      ),
                      rightTitles: const AxisTitles(
                        sideTitles: SideTitles(showTitles: false),
                      ),
                      topTitles: const AxisTitles(
                        sideTitles: SideTitles(showTitles: false),
                      ),
                      bottomTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          reservedSize: 28,
                          interval: 1,
                          getTitlesWidget: (value, meta) {
                            final hour = value.toInt();
                            if (hour < 0 || hour > 23 || hour % 4 != 0) {
                              return const SizedBox.shrink();
                            }
                            return Padding(
                              padding: const EdgeInsets.only(top: 7),
                              child: Text(
                                '${hour.toString().padLeft(2, '0')}:00',
                                style: const TextStyle(
                                  color: AppColors.mutedColor,
                                  fontSize: 9,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                    barTouchData: BarTouchData(
                      touchTooltipData: BarTouchTooltipData(
                        getTooltipColor: (_) => AppColors.secondaryColor,
                        getTooltipItem: (group, groupIndex, rod, rodIndex) {
                          final value = totals[group.x];
                          return BarTooltipItem(
                            '${group.x.toString().padLeft(2, '0')}:00\n'
                            '${value.toStringAsFixed(2)} ${l10n.currencyEg}',
                            const TextStyle(
                              color: Colors.white,
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                            ),
                          );
                        },
                      ),
                    ),
                    barGroups: List.generate(
                      24,
                      (hour) => BarChartGroupData(
                        x: hour,
                        barRods: [
                          BarChartRodData(
                            toY: displayTotals[hour],
                            width: 7,
                            borderRadius: const BorderRadius.vertical(
                              top: Radius.circular(4),
                            ),
                            gradient: const LinearGradient(
                              colors: [
                                AppColors.secondaryColor,
                                AppColors.primaryColor,
                              ],
                              begin: Alignment.bottomCenter,
                              end: Alignment.topCenter,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
    );
  }

  Widget _chartCard({
    required BuildContext context,
    required String title,
    required IconData icon,
    required Widget child,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.surfaceColor,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.borderColor),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.035),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: AppColors.primaryColor.withOpacity(.09),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  icon,
                  size: 19,
                  color: AppColors.primaryColor,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          child,
        ],
      ),
    );
  }

  Widget _emptyState(BuildContext context) => SizedBox(
        height: 180,
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                LucideIcons.chartNoAxesColumn,
                size: 34,
                color: AppColors.mutedColor.withOpacity(.35),
              ),
              const SizedBox(height: 10),
              Text(
                AppLocalizations.of(context).noSalesToday,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: AppColors.mutedColor,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      );

  Widget _legendRow({
    required String label,
    required double value,
    required double percentage,
    required Color color,
    required String currency,
  }) {
    return Row(
      children: [
        Container(
          width: 9,
          height: 9,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            label,
            style: const TextStyle(
              color: AppColors.textSecondary,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        Text(
          '${value.toStringAsFixed(2)} $currency',
          style: const TextStyle(
            color: AppColors.textPrimary,
            fontSize: 11,
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(width: 8),
        Text(
          '${(percentage * 100).toStringAsFixed(0)}%',
          style: TextStyle(
            color: color,
            fontSize: 10,
            fontWeight: FontWeight.w800,
          ),
        ),
      ],
    );
  }
}
