// lib/features/dashboard/presentation/dashboard_screen.dart
import 'package:sphinx/features/notifications/presentation/cubit/notifications_cubit.dart';
import 'package:sphinx/features/notifications/presentation/cubit/notifications_states.dart';
import 'package:sphinx/features/stock/presentation/cubit/stock_cubit.dart';
import 'package:sphinx/l10n/app_localizations.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/components/screen_header.dart';
import '../../../core/di/dependency_injection.dart';
import '../../../core/functions/messege.dart';
import '../../../core/security/permission_guard.dart';
import '../../../core/security/role_permissions.dart';
import '../../../core/utils/responsive_helper.dart';
import '../../auth/presentation/cubit/user_cubit.dart';
import '../../branches/presentation/cubit/branch_cubit.dart';
import '../../invoice/presentation/cubit/invoice_cubit.dart';
import '../../notifications/presentation/notifications_screen.dart';
import '../../products/presentation/cubit/product_cubit.dart';
import '../../products/presentation/products_screen.dart';
import '../../pos/data/repository/pos_repository_impl.dart';

import '../../pos/presentation/pos_screen.dart';
import '../../pos/presentation/cubit/pos_cubit.dart';
import '../../settings/presentation/settings_screen.dart';
import '../../stock/presentation/cubit/stock_states.dart';
import '../../stock/presentation/stock_screen.dart';
import '../../invoice/presentation/invoices_screen.dart';

import '../../shifts/presentation/screens/shifts_screen.dart';
import '../../shifts/presentation/cubit/shift_cubit.dart';
import '../../analytics/presentation/screens/analytics_screen.dart';
import '../../analytics/presentation/cubit/analytics_cubit.dart';

import 'widgets/dashboard_home.dart';
import 'widgets/desktop_header.dart';
import 'widgets/header_actions.dart';
import 'widgets/mobile_bottom_nav.dart';
import 'widgets/mobile_drawer.dart';
import 'widgets/side_bar.dart';
import '../../stock_summary/presentation/screens/stock_summary_screen.dart';
import '../../stock_summary/presentation/cubit/stock_summary_cubit.dart';
import '../../expenses/presentation/expenses_screen.dart';
import '../../branches/presentation/screens/branches_management_screen.dart';

import 'package:lucide_icons_flutter/lucide_icons.dart';
import '../../../core/state/state_synchronizer.dart';
import '../../../core/components/connection_banner.dart';
import '../../../core/data/services/supabase_service.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int selectedIndex = 0;
  bool isSidebarCollapsed = false;

  late final PosRepositoryImpl _salesRepository;

  List<SidebarItem> get sidebarItems => _getSidebarItems(context);

  @override
  void initState() {
    super.initState();
    _salesRepository = getIt<PosRepositoryImpl>();
    getIt<ShiftCubit>().load();
    SupabaseService().startConnectionMonitor();
  }

  @override
  void dispose() {
    SupabaseService().stopConnectionMonitor();
    super.dispose();
  }

  List<SidebarItem> _getSidebarItems(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final curUser = getIt<UserCubit>().currentUser;
    bool can(Permission permission) => curUser.hasPermission(permission);
    return [
      SidebarItem(
        id: 'dashboard',
        icon: LucideIcons.layoutDashboard,
        title: l10n.dashboard,
        screen: DashboardHome(
          onCardTap: (id) => handleCardTap(id),
          isManager: can(Permission.viewReports),
        ),
      ),
      if (can(Permission.posCheckout))
        SidebarItem(
          id: 'pos',
          icon: LucideIcons.shoppingCart,
          title: l10n.posNavigation,
          screen: const PosScreen(),
        ),
      if (can(Permission.viewInvoices))
        SidebarItem(
          id: 'invoices',
          icon: LucideIcons.fileText,
          title: l10n.invoices,
          screen: BlocProvider<InvoiceCubit>(
            create: (_) => InvoiceCubit(_salesRepository),
            child: InvoiceScreen(
                repository: _salesRepository, currentUser: curUser),
          ),
        ),
      if (can(Permission.manageProducts))
        SidebarItem(
          id: 'products',
          icon: LucideIcons.box,
          title: l10n.products,
          screen: const ProductsScreen(),
        ),
      if (can(Permission.manageProducts))
        SidebarItem(
          id: 'stock_alerts',
          icon: LucideIcons.triangleAlert,
          title: l10n.stockAlerts,
          screen: const StockScreen(),
        ),
      if (can(Permission.manageProducts))
        SidebarItem(
          id: 'stock_summary',
          icon: LucideIcons.clipboardList,
          title: l10n.stockSummary,
          screen: BlocProvider(
            create: (_) => getIt<StockSummaryCubit>()..init(),
            child: const StockSummaryScreen(),
          ),
        ),
      if (can(Permission.viewReports))
        SidebarItem(
          id: 'reports',
          icon: LucideIcons.chartPie,
          title: l10n.reports,
          screen: BlocProvider.value(
            value: getIt<AnalyticsCubit>(),
            child: const AnalyticsScreen(),
          ),
        ),
      if (can(Permission.viewReports))
        SidebarItem(
          id: 'sessions',
          icon: LucideIcons.repeat,
          title: l10n.shiftsLabel,
          screen: const ShiftsScreen(),
        ),
      if (can(Permission.viewReports))
        SidebarItem(
          id: 'notifications',
          icon: LucideIcons.bell,
          title: l10n.notifications,
          screen: const NotificationsScreen(),
        ),
      SidebarItem(
        id: 'expenses',
        icon: LucideIcons.walletCards,
        title: l10n.expensesLabel,
        screen: const ExpensesScreen(),
      ),
      if (can(Permission.storeSettings) ||
          can(Permission.manageUsers) ||
          can(Permission.dataManagement))
        SidebarItem(
          id: 'settings',
          icon: LucideIcons.settings,
          title: l10n.settings,
          screen: const SettingsScreen(),
        ),
      if (curUser.isPrimaryAdmin)
        SidebarItem(
          id: 'branches',
          icon: LucideIcons.building2,
          title: l10n.localeName == 'ar' ? 'الفروع' : 'Branches',
          screen: BlocProvider.value(
            value: getIt<BranchCubit>(),
            child: const BranchesManagementScreen(),
          ),
        ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final isMobileOrTablet = ResponsiveHelper.isMobileOrTablet(context);

    return MultiBlocProvider(
      providers: [
        BlocProvider<BranchCubit>.value(
          value: getIt<BranchCubit>(),
        ),
        BlocProvider<StockCubit>.value(
          value: getIt<StockCubit>()..loadData(),
        ),
        BlocProvider<ProductCubit>.value(
          value: getIt<ProductCubit>()..getAllProducts(),
        ),
        BlocProvider<NotificationsCubit>.value(
          value: getIt<NotificationsCubit>()..loadData(),
        ),
      ],
      child: MultiBlocListener(
        listeners: [
          BlocListener<BranchCubit, BranchState>(
            listenWhen: (previous, current) =>
                previous.selectionRevision != current.selectionRevision,
            listener: (context, state) {
              getIt<StockCubit>().loadData();
              getIt<ProductCubit>().getAllProducts();
              getIt<NotificationsCubit>().loadData();
              getIt<ShiftCubit>().load();
              getIt<PosCubit>().reloadForBranchSelection();
              getIt<AnalyticsCubit>().reloadForBranchSelection();
              getIt<InvoiceCubit>().loadSales();
              StateSynchronizer.notify(DataChangeEvent(
                entityType: 'branch_scope',
                operation: 'switch',
              ));
            },
          ),
          BlocListener<NotificationsCubit, NotificationsStates>(
            listener: (context, state) {
              if (state is NotificationsError) {
                MotionSnackBarWarning(context, state.message);
              }
            },
          ),
          BlocListener<StockCubit, StockStates>(
            listener: (context, state) {
              if (state is StockSucssesState) {
                getIt<NotificationsCubit>().loadData();
              }
            },
          ),
        ],
        child: Directionality(
          textDirection:
              l10n.localeName == 'ar' ? TextDirection.rtl : TextDirection.ltr,
          child: Scaffold(
            appBar: isMobileOrTablet
                ? AppBar(
                    backgroundColor: AppColors.sidebarColor,
                    title: Text(sidebarItems[selectedIndex].title),
                    leading: Builder(
                      builder: (ctx) => IconButton(
                        icon: const Icon(Icons.menu, color: Colors.white),
                        onPressed: () => Scaffold.of(ctx).openDrawer(),
                      ),
                    ),
                    actions: buildHeaderActions(
                      context,
                      compact: true,
                      onNotificationsTap: () => _openNotifications(context),
                    ),
                  )
                : null,
            drawer: isMobileOrTablet
                ? MobileDrawer(
                    items: sidebarItems,
                    selectedIndex: selectedIndex,
                    onTap: (index) {
                      Navigator.pop(context);
                      _onSidebarSelected(context, index);
                    },
                  )
                : null,
            body: isMobileOrTablet
                ? ScreenHeaderScope(
                    showInPage: false,
                    child: Column(
                      children: [
                        const ConnectionBanner(),
                        Expanded(child: sidebarItems[selectedIndex].screen),
                      ],
                    ),
                  )
                : Row(
                    children: [
                      CustomSidebar(
                        items: sidebarItems,
                        selectedIndex: selectedIndex,
                        isCollapsed: isSidebarCollapsed,
                        onItemSelected: (index) =>
                            _onSidebarSelected(context, index),
                        onToggleCollapse: () {
                          setState(() {
                            isSidebarCollapsed = !isSidebarCollapsed;
                          });
                        },
                      ),
                      Expanded(
                        child: Container(
                          color: AppColors.backgroundColor,
                          child: Column(
                            children: [
                              const ConnectionBanner(),
                              DesktopHeader(
                                pageTitle: sidebarItems[selectedIndex].title,
                                pageIcon: sidebarItems[selectedIndex].icon,
                                actions: buildHeaderActions(
                                  context,
                                  onNotificationsTap: () =>
                                      _openNotifications(context),
                                ),
                              ),
                              Expanded(
                                child: ScreenHeaderScope(
                                  showInPage: false,
                                  child: sidebarItems[selectedIndex].screen,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
            bottomNavigationBar: isMobileOrTablet
                ? MobileBottomNav(
                    items: sidebarItems,
                    selectedIndex: selectedIndex,
                    onTap: (index) => _onSidebarSelected(context, index),
                  )
                : null,
          ),
        ),
      ),
    );
  }

  void _openNotifications(BuildContext context) {
    final index = sidebarItems.indexWhere((item) => item.id == 'notifications');
    if (index != -1) _onSidebarSelected(context, index);
  }

  void _onSidebarSelected(BuildContext context, int index) {
    final curUser = getIt<UserCubit>().currentUser;
    final item = sidebarItems[index];
    if (item.id == 'reports' || item.id == 'stock_summary') {
      try {
        PermissionGuard.checkReportAccess(curUser);
      } catch (e) {
        MotionSnackBarError(context, AppLocalizations.of(context).errAccessDenied);
        return;
      }
    }

    setState(() {
      selectedIndex = index;
    });

    if (Scaffold.maybeOf(context)?.isDrawerOpen ?? false) {
      Navigator.pop(context);
    }
  }

  /// Handles tap on a card in the dashboard screen.
  void handleCardTap(String id) {
    final index = sidebarItems.indexWhere((item) => item.id == id);
    if (index != -1) {
      _onSidebarSelected(context, index);
    } else {
      MotionSnackBarWarning(
          context, AppLocalizations.of(context).screenUnavailable);
    }
  }
}
