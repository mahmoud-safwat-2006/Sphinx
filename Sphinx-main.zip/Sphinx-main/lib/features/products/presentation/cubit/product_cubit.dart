import 'dart:async';
import 'package:sphinx/core/di/dependency_injection.dart';
import 'package:sphinx/core/error/failure.dart';
import 'package:sphinx/features/products/data/models/product_model.dart';
import 'package:sphinx/features/products/domain/product_repository_int.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../branches/presentation/cubit/branch_cubit.dart';
import '../../../../core/state/state_synchronizer.dart';

import 'product_states.dart';

class ProductCubit extends Cubit<ProductStates> {
  StreamSubscription<DataChangeEvent>? _changeSubscription;

  ProductCubit({required this.productRepositoryInt})
      : super(ProductInitialState()) {
    _changeSubscription = StateSynchronizer.events.listen((event) {
      if (event.entityType == 'sale' ||
          event.entityType == 'product' ||
          event.entityType == 'product_stock') {
        getAllProducts();
      }
    });
  }

  @override
  Future<void> close() {
    _changeSubscription?.cancel();
    return super.close();
  }

  static ProductCubit get(context) => BlocProvider.of(context);
  ProductRepositoryInt productRepositoryInt;
  List<Product> products = [];
  List<Product> get allProducts => products;
  List<String> categories = [];
  String selectedCategory = '*';
  String selectedAvailability = '*';

  String currentSearchQuery = '';

  // Pagination state
  int currentPage = 0;
  bool hasMoreProducts = true;
  bool isLoadingMore = false;
  static const int pageSize = 50;
  int _requestVersion = 0;

  void clearProducts() {
    products = [];
    currentPage = 0;
    hasMoreProducts = true;
    currentSearchQuery = '';
    selectedCategory = '*';
    selectedAvailability = '*';
    emit(ProductLoadedState([]));
  }

  bool get isAllBranches => getIt<BranchCubit>().effectiveBranchId == null;
  String? get _branchId => getIt<BranchCubit>().effectiveBranchId;

  Future<void> getAllProducts() async {
    final requestVersion = ++_requestVersion;
    emit(ProductLoadingState());

    // Reset pagination
    currentPage = 0;
    hasMoreProducts = true;
    isLoadingMore = false;
    products = [];

    // Load first page
    final result = await productRepositoryInt.getProductsPaginated(
      page: currentPage,
      pageSize: pageSize,
      category: selectedCategory,
      availability: selectedAvailability,
      searchQuery: currentSearchQuery,
      branchId: _branchId,
    );

    result.fold(
      (failure) {
        if (requestVersion == _requestVersion) {
          emit(ProductErrorState(failure.message));
        }
      },
      (productsList) {
        if (requestVersion != _requestVersion) return;
        products = List<Product>.from(productsList);
        hasMoreProducts = productsList.length == pageSize;
        emit(ProductLoadedState(List<Product>.unmodifiable(products)));
      },
    );
  }

  void loadMoreProducts() async {
    if (isLoadingMore || !hasMoreProducts) return;

    final requestVersion = _requestVersion;
    final nextPage = currentPage + 1;
    isLoadingMore = true;
    emit(ProductLoadedState(List<Product>.unmodifiable(products)));

    final result = await productRepositoryInt.getProductsPaginated(
      page: nextPage,
      pageSize: pageSize,
      category: selectedCategory,
      availability: selectedAvailability,
      searchQuery: currentSearchQuery,
      branchId: _branchId,
    );

    result.fold(
      (failure) {
        if (requestVersion != _requestVersion) return;
        isLoadingMore = false;
        emit(ProductErrorState(failure.message));
        emit(ProductLoadedState(List<Product>.unmodifiable(products)));
      },
      (productsList) {
        if (requestVersion != _requestVersion) return;
        final existingBarcodes = products.map((p) => p.barcode).toSet();
        products.addAll(
          productsList.where((p) => existingBarcodes.add(p.barcode)),
        );
        currentPage = nextPage;
        hasMoreProducts = productsList.length == pageSize;
        isLoadingMore = false;
        emit(ProductLoadedState(List<Product>.unmodifiable(products)));
      },
    );
  }

  void saveProduct(Product product) async {
    emit(ProductLoadingState());
    final result = await productRepositoryInt.saveProduct(product, branchId: _branchId);
    result.fold(
      (failure) => emit(ProductErrorState(failure.message)),
      (_) async {
        emit(ProductSuccessState("productSavedSuccess"));

        getAllProducts();
      },
    );
  }

  void deleteProduct(String barcode) async {
    emit(ProductLoadingState());
    final result = await productRepositoryInt.deleteProduct(barcode);
    result.fold(
      (failure) => emit(ProductErrorState(failure.message)),
      (_) async {
        emit(ProductSuccessState("msgProductDeleted"));

        getAllProducts();
      },
    );
  }

  void filterByCategory(String category) {
    selectedCategory = category;
    getAllProducts();
  }

  void filterByAvailability(String availability) {
    selectedAvailability = availability;
    getAllProducts();
  }

  void searchProducts(String query) {
    currentSearchQuery = query;
    getAllProducts();
  }

  void getAllCategories() async {
    await Future.delayed(const Duration(milliseconds: 200));
    final result = await productRepositoryInt.getAllCategory();
    result.fold(
      (failure) => emit(CategoryErrorState(failure.message)),
      (categoriesList) {
        categories = categoriesList;
        emit(CategoryLoadedState(categoriesList));
      },
    );
  }

  void saveCategory(String category) async {
    emit(ProductLoadingState());
    final result = await productRepositoryInt.saveCategory(category);
    result.fold(
      (failure) => emit(CategoryErrorState(failure.message)),
      (_) {
        emit(CategorySuccessState("categoryAddedSuccess"));
        getAllCategories();
      },
    );
  }

  void deleteCategory(
      {required String category,
      bool forceDelete = false,
      String? newCategory}) async {
    emit(ProductLoadingState());
    final result = await productRepositoryInt.deleteCategory(
        category: category, forceDelete: forceDelete, newCategory: newCategory);
    result.fold(
      (failure) {
        if (failure is CacheFailure) {
          emit(CategoryErrorDeleteState(failure.message, category));
        } else {
          emit(CategoryErrorState(failure.message));
        }
      },
      (_) {
        emit(CategorySuccessState("categoryDeletedSuccess"));
        getAllCategories();
        getAllProducts();
      },
    );
  }

  Future<bool> checkProductExists(String barcode) async {
    final result = await productRepositoryInt.productExists(barcode);
    return result.fold((l) => false, (exists) => exists);
  }
}
