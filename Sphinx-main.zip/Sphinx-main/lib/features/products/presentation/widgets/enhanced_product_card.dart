import 'package:flutter/material.dart';
import 'package:sphinx/features/products/data/models/product_model.dart';
import 'package:sphinx/core/constants/app_colors.dart';
import 'package:sphinx/core/localization/product_unit_localizer.dart';
import '../../../../core/components/local_image_view.dart';
import '../../../../core/di/dependency_injection.dart';
import '../../../../l10n/app_localizations.dart';
import '../../../auth/data/models/user_model.dart';
import '../../../auth/presentation/cubit/user_cubit.dart';

class EnhancedProductCard extends StatelessWidget {
  final Product product;
  final VoidCallback onDelete;
  final VoidCallback onEdit;
  final Color statusColor;
  final String statusText;

  const EnhancedProductCard({
    super.key,
    required this.product,
    required this.onDelete,
    required this.onEdit,
    required this.statusColor,
    required this.statusText,
  });

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final qty = product.quantity;
    final userType = getIt<UserCubit>().currentUser.userType;
    final isManager =
        userType == UserType.manager || userType == UserType.admin;
    final canEdit = userType != UserType.cashier;

    return LayoutBuilder(
      builder: (context, c) {
        // scale down type/paddings once the card gets narrow (5-6 col grids)
        final w = c.maxWidth;
        final compact = w < 160;
        final nameSize = compact ? 10.0 : 12.5;
        final priceSize = compact ? 11.0 : 13.5;
        final labelSize = compact ? 7.5 : 9.0;
        final pad = compact ? 5.0 : 8.0;
        final qtyLabel = ProductUnitLocalizer.quantity(
          l10n,
          qty,
          product.unitAbbreviation,
        );

        return Container(
          decoration: BoxDecoration(
            color: AppColors.surfaceColor,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: statusColor.withOpacity(0.45),
              width: 1.2,
            ),
            boxShadow: [
              BoxShadow(
                color: statusColor.withOpacity(0.06),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          clipBehavior: Clip.antiAlias,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ── Image + badges (fixed small band, not Expanded) ───
              AspectRatio(
                aspectRatio: 1.4, // short image, more room for text below
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    LocalImageView(
                      path: product.imagePath,
                      width: double.infinity,
                      height: double.infinity,
                      borderRadius: 0,
                      fallback: Container(
                        color: AppColors.primaryColor.withOpacity(.06),
                        alignment: Alignment.center,
                        child: Icon(Icons.inventory_2_outlined,
                            color: AppColors.primaryColor,
                            size: compact ? 18 : 22),
                      ),
                    ),
                    Positioned(
                      top: 4,
                      left: 4,
                      child: _Badge(
                        text: statusText,
                        color: statusColor,
                        fontSize: labelSize,
                      ),
                    ),
                    if (canEdit)
                      Positioned(
                        top: 2,
                        right: 2,
                        child: _CircleAction(
                          icon: Icons.more_vert_rounded,
                          color: AppColors.textPrimary,
                          onEdit: onEdit,
                          onDelete: onDelete,
                          editLabel: l10n.edit,
                          deleteLabel: l10n.delete,
                        ),
                      ),
                    Positioned(
                      bottom: 4,
                      right: 4,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 5, vertical: 1),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.55),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          qtyLabel,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: labelSize,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // ── Details ─────────────────────────────
              Padding(
                padding: EdgeInsets.fromLTRB(pad, 6, pad, pad),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (product.category.isNotEmpty && !compact)
                      Text(
                        product.category.toUpperCase(),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: labelSize,
                          color: AppColors.primaryColor,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.3,
                        ),
                      ),
                    const SizedBox(height: 1),
                    Text(
                      product.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: nameSize,
                        height: 1.15,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      "${product.price.toStringAsFixed(2)} ${l10n.currencyEg}",
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontWeight: FontWeight.w900,
                        fontSize: priceSize,
                        color: AppColors.successColor,
                      ),
                    ),
                    if (isManager && !compact) ...[
                      const SizedBox(height: 2),
                      Text(
                        "${l10n.minPriceColumn}: ${product.minPrice.toStringAsFixed(2)}",
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 9,
                          fontWeight: FontWeight.w700,
                          color: Colors.deepOrange,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _Badge extends StatelessWidget {
  final String text;
  final Color color;
  final double fontSize;
  const _Badge(
      {required this.text, required this.color, required this.fontSize});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        text,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          color: Colors.white,
          fontSize: fontSize,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

/// Single button that opens a small popup menu with Edit/Delete —
/// avoids two floating circles fighting for space in narrow cards.
class _CircleAction extends StatelessWidget {
  final IconData icon;
  final Color color;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final String editLabel;
  final String deleteLabel;

  const _CircleAction({
    required this.icon,
    required this.color,
    required this.onEdit,
    required this.onDelete,
    required this.editLabel,
    required this.deleteLabel,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      shape: const CircleBorder(),
      elevation: 2,
      child: PopupMenuButton<String>(
        padding: EdgeInsets.zero,
        icon: Icon(icon, size: 16, color: color),
        onSelected: (v) => v == 'edit' ? onEdit() : onDelete(),
        itemBuilder: (context) => [
          PopupMenuItem(
            value: 'edit',
            child: Row(
              children: [
                const Icon(Icons.edit_rounded,
                    size: 16, color: AppColors.primaryColor),
                const SizedBox(width: 8),
                Text(editLabel),
              ],
            ),
          ),
          PopupMenuItem(
            value: 'delete',
            child: Row(
              children: [
                const Icon(Icons.delete_rounded,
                    size: 16, color: AppColors.errorColor),
                const SizedBox(width: 8),
                Text(deleteLabel),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
