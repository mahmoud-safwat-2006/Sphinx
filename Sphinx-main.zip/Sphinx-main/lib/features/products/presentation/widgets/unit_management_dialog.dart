import 'package:sphinx/core/constants/app_colors.dart';
import 'package:sphinx/core/di/dependency_injection.dart';
import 'package:sphinx/core/localization/product_unit_localizer.dart';
import 'package:sphinx/core/utils/responsive_helper.dart';
import 'package:sphinx/features/products/data/models/product_unit_model.dart';
import 'package:sphinx/features/products/presentation/cubit/product_cubit.dart';
import 'package:sphinx/l10n/app_localizations.dart';
import 'package:flutter/material.dart';

class UnitManagementDialog extends StatefulWidget {
  const UnitManagementDialog({super.key});

  @override
  State<UnitManagementDialog> createState() => _UnitManagementDialogState();
}

class _UnitManagementDialogState extends State<UnitManagementDialog> {
  List<ProductUnit> _units = const [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    final result =
        await getIt<ProductCubit>().productRepositoryInt.getAllUnits();
    if (!mounted) return;
    result.fold(
      (failure) => setState(() {
        _loading = false;
        _error = failure.message;
      }),
      (units) => setState(() {
        _loading = false;
        _units = units;
      }),
    );
  }

  Future<void> _edit([ProductUnit? unit]) async {
    final l10n = AppLocalizations.of(context);
    final name = TextEditingController(text: unit?.name ?? '');
    final abbreviation = TextEditingController(text: unit?.abbreviation ?? '');
    var isDefault = unit?.isDefault ?? false;

    final result = await showDialog<ProductUnit>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppColors.primaryColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(Icons.straighten_rounded,
                    color: AppColors.primaryColor, size: 20),
              ),
              const SizedBox(width: 10),
              Text(
                unit == null ? l10n.addNewUnit : l10n.editUnit,
                style:
                    const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: name,
                autofocus: true,
                decoration: InputDecoration(
                  labelText: l10n.unitName,
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: abbreviation,
                decoration: InputDecoration(
                  labelText: l10n.unitAbbreviation,
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
              ),
              const SizedBox(height: 8),
              CheckboxListTile(
                contentPadding: EdgeInsets.zero,
                value: isDefault,
                activeColor: AppColors.primaryColor,
                title: Text(
                  l10n.setAsDefault,
                  style: const TextStyle(
                      fontSize: 13, fontWeight: FontWeight.w600),
                ),
                onChanged: (value) =>
                    setDialogState(() => isDefault = value ?? false),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: Text(l10n.cancel),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryColor,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
              ),
              onPressed: () {
                if (name.text.trim().isEmpty ||
                    abbreviation.text.trim().isEmpty) {
                  return;
                }
                Navigator.pop(
                  dialogContext,
                  ProductUnit(
                    id: unit?.id,
                    name: name.text.trim(),
                    abbreviation: abbreviation.text.trim(),
                    isDefault: isDefault,
                  ),
                );
              },
              child: Text(l10n.save),
            ),
          ],
        ),
      ),
    );
    name.dispose();
    abbreviation.dispose();
    if (result == null) return;

    final saved =
        await getIt<ProductCubit>().productRepositoryInt.saveUnit(result);
    if (!mounted) return;
    saved.fold(
      (failure) => ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            failure.message == 'unitAlreadyExists'
                ? l10n.unitAlreadyExists
                : failure.message,
          ),
        ),
      ),
      (_) => _load(),
    );
  }

  Future<void> _delete(ProductUnit unit) async {
    if (unit.id == null || unit.isDefault) return;
    final l10n = AppLocalizations.of(context);

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(l10n.deleteUnitTitle),
        content: Text(l10n.deleteUnitConfirm),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(l10n.cancel),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.redAccent,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(l10n.delete),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    final result =
        await getIt<ProductCubit>().productRepositoryInt.deleteUnit(unit.id!);
    if (!mounted) return;
    result.fold(
      (failure) => ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(failure.message)),
      ),
      (_) => _load(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);

    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxWidth: ResponsiveHelper.dialogMaxWidth(context, desktop: 540),
          maxHeight: MediaQuery.sizeOf(context).height * 0.88,
        ),
        child: Padding(
          padding: EdgeInsets.all(
            ResponsiveHelper.isMobile(context) ? 16 : 24,
          ),
          child: Column(
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: AppColors.primaryColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.straighten_rounded,
                        color: AppColors.primaryColor, size: 22),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          l10n.unitsTitle,
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        Text(
                          l10n.unitsSubtitle,
                          style: const TextStyle(
                              fontSize: 12, color: AppColors.mutedColor),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context, true),
                    icon: const Icon(Icons.close),
                    splashRadius: 20,
                  ),
                ],
              ),
              const SizedBox(height: 16),
              const Divider(height: 1),
              const SizedBox(height: 16),
              Expanded(
                child: _loading
                    ? const Center(
                        child: CircularProgressIndicator(
                          valueColor:
                              AlwaysStoppedAnimation<Color>(AppColors.primaryColor),
                        ),
                      )
                    : _error != null
                        ? Center(child: Text(_error!))
                        : ListView.separated(
                            itemCount: _units.length,
                            separatorBuilder: (_, __) =>
                                const SizedBox(height: 8),
                            itemBuilder: (context, index) {
                              final unit = _units[index];
                              return Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 14, vertical: 10),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(12),
                                  border:
                                      Border.all(color: AppColors.borderColor),
                                ),
                                child: Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 10, vertical: 6),
                                      decoration: BoxDecoration(
                                        color: const Color(0xFFF1F5F9),
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      child: Text(
                                        ProductUnitLocalizer.abbreviation(
                                          l10n,
                                          unit.abbreviation,
                                        ),
                                        style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 13,
                                          color: AppColors.primaryColor,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Row(
                                        children: [
                                          Text(
                                            ProductUnitLocalizer.name(
                                              l10n,
                                              name: unit.name,
                                              abbreviation: unit.abbreviation,
                                            ),
                                            style: const TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.bold,
                                              color: AppColors.textPrimary,
                                            ),
                                          ),
                                          if (unit.isDefault) ...[
                                            const SizedBox(width: 8),
                                            Container(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                      horizontal: 8,
                                                      vertical: 2),
                                              decoration: BoxDecoration(
                                                color: const Color(0xFFDCFCE7),
                                                borderRadius:
                                                    BorderRadius.circular(6),
                                              ),
                                              child: Text(
                                                l10n.defaultTag,
                                                style: const TextStyle(
                                                  fontSize: 10,
                                                  fontWeight: FontWeight.bold,
                                                  color: Color(0xFF15803D),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ],
                                      ),
                                    ),
                                    IconButton(
                                      tooltip: l10n.edit,
                                      onPressed: () => _edit(unit),
                                      icon: const Icon(Icons.edit_outlined,
                                          size: 18, color: AppColors.primaryColor),
                                    ),
                                    IconButton(
                                      tooltip: l10n.delete,
                                      onPressed: unit.isDefault
                                          ? null
                                          : () => _delete(unit),
                                      icon: Icon(
                                        Icons.delete_outline,
                                        size: 18,
                                        color: unit.isDefault
                                            ? Colors.grey
                                            : Colors.redAccent,
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                height: 46,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryColor,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: () => _edit(),
                  icon: const Icon(Icons.add_circle_outline, size: 20),
                  label: Text(
                    l10n.addCustomUnit,
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 14),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
