import 'package:sphinx/core/constants/app_colors.dart';
import 'package:sphinx/core/utils/responsive_helper.dart';
import 'package:sphinx/features/auth/data/models/user_model.dart';
import 'package:sphinx/features/auth/presentation/cubit/user_cubit.dart';
import 'package:sphinx/features/products/presentation/widgets/enhanced_add_edit_Dialog.dart'
    show AddCategories;
import 'package:flutter/material.dart';

import '../../../../core/di/dependency_injection.dart';
import '../../../../l10n/app_localizations.dart';
import '../../data/models/product_model.dart';
import '../cubit/product_cubit.dart';
import 'add_button.dart';
import 'dropdown_filter.dart';

class DesktopLayout extends StatelessWidget {
  const DesktopLayout({
    super.key,
    required this.searchController,
    required this.onSearchChanged,
    required this.categoryFilter,
    required this.categories,
    required this.onCategoryChanged,
    required this.availabilityFilter,
    required this.availabilities,
    required this.onAvailabilityChanged,
    required this.onAddPressed,
    required this.productCount,
    required this.isTableView,
    required this.onViewToggle,
  });

  final TextEditingController searchController;
  final VoidCallback onSearchChanged;
  final String? categoryFilter;
  final List<String> categories;
  final ValueChanged<String> onCategoryChanged;
  final String? availabilityFilter;
  final List<String> availabilities;
  final ValueChanged<String> onAvailabilityChanged;
  final VoidCallback onAddPressed;
  final int productCount;
  final bool isTableView;
  final ValueChanged<bool> onViewToggle;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final isMobile = ResponsiveHelper.isMobileOrTablet(context);

    if (isMobile) {
      return _buildMobile(context, l10n);
    }

    return _buildDesktop(context, l10n);
  }

  Widget _buildMobile(BuildContext context, AppLocalizations l10n) {
    return Column(
      children: [
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.mutedColor.withOpacity(0.4)),
            boxShadow: [
              BoxShadow(
                color: AppColors.mutedColor.withOpacity(0.08),
                blurRadius: 3,
                offset: const Offset(0, 1),
              ),
            ],
          ),
          child: TextField(
            controller: searchController,
            onChanged: (s) {
              getIt<ProductCubit>().searchProducts(s);
            },
            decoration: InputDecoration(
              hintText: l10n.searchProductHint,
              hintStyle: TextStyle(color: AppColors.mutedColor, fontSize: 13),
              prefixIcon: const Icon(Icons.search,
                  color: AppColors.primaryColor, size: 20),
              border: InputBorder.none,
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Icon(Icons.inventory_outlined,
                color: AppColors.primaryColor, size: 14),
            const SizedBox(width: 4),
            Text(
              l10n.products,
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 11,
                  color: AppColors.textPrimary),
            ),
            const SizedBox(width: 4),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
              decoration: BoxDecoration(
                color: AppColors.primaryColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                '$productCount',
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 11,
                    color: AppColors.primaryColor),
              ),
            ),
            const Spacer(),
            if (getIt<UserCubit>().currentUser.userType != UserType.cashier)
              _buildCompactAction(
                  l10n.addCategory, Icons.add, const Color(0xff8b5cf6), () {
                showAddEditDialog(context);
              }),
            if (getIt<UserCubit>().currentUser.userType != UserType.cashier)
              const SizedBox(width: 6),
            if (getIt<UserCubit>().currentUser.userType != UserType.cashier)
              _buildCompactAction(l10n.addProduct, Icons.add,
                  AppColors.primaryColor, onAddPressed),
            const Spacer(),
            GestureDetector(
              onTap: () => _showFilterSheet(context, l10n),
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: AppColors.primaryColor.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.filter_list_rounded,
                        size: 16, color: AppColors.primaryColor),
                  ],
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  void _showFilterSheet(BuildContext context, AppLocalizations l10n) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) {
        return Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 16),
              DropDownFilter(
                label: l10n.filterByCategory,
                value: categoryFilter,
                items: categories,
                onChanged: onCategoryChanged,
                icon: Icons.category_outlined,
                iconRemove: Icons.cancel,
                hint: l10n.selectCategory,
              ),
              const SizedBox(height: 12),
              DropDownFilter(
                label: l10n.filterByAvailability,
                value: availabilityFilter,
                items: availabilities,
                onChanged: onAvailabilityChanged,
                icon: Icons.inventory_outlined,
                hint: l10n.selectAvailability,
              ),
              const SizedBox(height: 16),
            ],
          ),
        );
      },
    );
  }

  Widget _buildCompactAction(
      String label, IconData icon, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(6),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 12, color: color),
            const SizedBox(width: 3),
            Text(
              label,
              style: TextStyle(
                  fontSize: 10, fontWeight: FontWeight.w600, color: color),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDesktop(BuildContext context, AppLocalizations l10n) {
    return Column(
      children: [
        // Search Bar
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.mutedColor.withOpacity(0.4)),
            boxShadow: [
              BoxShadow(
                color: AppColors.mutedColor.withOpacity(0.08),
                blurRadius: 3,
                offset: const Offset(0, 1),
              ),
            ],
          ),
          child: TextField(
            controller: searchController,
            onChanged: (s) {
              getIt<ProductCubit>().searchProducts(s);
            },
            decoration: InputDecoration(
              hintText: l10n.searchProductHint,
              hintStyle: TextStyle(color: AppColors.mutedColor, fontSize: 13),
              prefixIcon: const Icon(
                Icons.search,
                color: AppColors.primaryColor,
                size: 20,
              ),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 14,
                vertical: 10,
              ),
            ),
          ),
        ),
        const SizedBox(height: 8),

        // Filters Row
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            getIt<UserCubit>().currentUser.userType == UserType.cashier
                ? const SizedBox()
                : Expanded(
                    flex: 1,
                    child: AddButton(
                      onAddPressed: () {
                        showAddEditDialog(context);
                      },
                      text: l10n.addNewCategory,
                      color: const Color(0xff8b5cf6),
                    )),
            const SizedBox(width: 10),
            getIt<UserCubit>().currentUser.userType == UserType.cashier
                ? const SizedBox()
                : Expanded(
                    flex: 1,
                    child: AddButton(
                      onAddPressed: onAddPressed,
                      text: l10n.addNewProduct,
                      color: AppColors.primaryColor,
                    )),
            const SizedBox(width: 10),
            Expanded(
              flex: 2,
              child: DropDownFilter(
                label: l10n.filterByAvailability,
                value: availabilityFilter,
                items: availabilities,
                onChanged: onAvailabilityChanged,
                icon: Icons.inventory_outlined,
                hint: l10n.selectAvailability,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              flex: 2,
              child: DropDownFilter(
                label: l10n.filterByCategory,
                value: categoryFilter,
                items: categories,
                onChanged: onCategoryChanged,
                icon: Icons.category_outlined,
                iconRemove: Icons.cancel,
                hint: l10n.selectCategory,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),

        // Info & View Toggle Row
        Row(
          children: [
            // Product Count
            Row(
              children: [
                Icon(
                  Icons.inventory_outlined,
                  color: AppColors.primaryColor,
                  size: 16,
                ),
                const SizedBox(width: 6),
                Text(
                  l10n.products,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(width: 6),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: AppColors.primaryColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    '$productCount',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                      color: AppColors.primaryColor,
                    ),
                  ),
                ),
              ],
            ),
            const Spacer(),
            // View Toggle
            Container(
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppColors.borderColor),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: const Icon(Icons.grid_view, size: 16),
                    color: !isTableView ? AppColors.primaryColor : Colors.grey,
                    onPressed: () => onViewToggle(false),
                    tooltip: l10n.viewGrid,
                    constraints:
                        const BoxConstraints(minWidth: 28, minHeight: 28),
                    padding: const EdgeInsets.all(4),
                  ),
                  Container(width: 1, height: 14, color: Colors.grey.shade300),
                  IconButton(
                    icon: const Icon(Icons.table_chart_outlined, size: 16),
                    color: isTableView ? AppColors.primaryColor : Colors.grey,
                    onPressed: () => onViewToggle(true),
                    tooltip: l10n.viewTable,
                    constraints:
                        const BoxConstraints(minWidth: 28, minHeight: 28),
                    padding: const EdgeInsets.all(4),
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }
}

Future<void> showAddEditDialog(context, [Product? product]) async {
  await showDialog(context: context, builder: (_) => AddCategories());
}
