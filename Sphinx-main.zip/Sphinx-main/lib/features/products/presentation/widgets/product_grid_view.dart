import 'package:flutter/material.dart';
import 'package:sphinx/features/products/data/models/product_model.dart';
import '../../../../core/components/empty_state.dart';
import '../../../../l10n/app_localizations.dart';
import 'enhanced_product_card.dart';

class ProductsGridView extends StatelessWidget {
  final List<Product> products;
  final void Function(Product) onDelete;
  final void Function(Product) onEdit;
  final Color Function(double, double) statusColorFn;
  final String Function(double, double) statusTextFn;

  final ScrollController? scrollController;
  final bool isLoadingMore;
  final String? emptyTitle;
  final String? emptyMessage;

  const ProductsGridView({
    super.key,
    required this.products,
    required this.onDelete,
    required this.onEdit,
    required this.statusColorFn,
    required this.statusTextFn,
    this.scrollController,
    this.isLoadingMore = false,
    this.emptyTitle,
    this.emptyMessage,
  });

  // Target card width instead of fixed breakpoints — scales to any
  // container width, e.g. ~10 columns at 1500px, ~2 at 400px (mobile).
  static const double _targetCardWidth = 130.0;
  static const int _minColumns = 2;
  static const int _maxColumns = 10;

  int _crossAxisCount(double width) {
    final count = (width / _targetCardWidth).floor();
    return count.clamp(_minColumns, _maxColumns);
  }

  double _aspectRatio(double width) {
    // small compact card (short image band + tight text) — keep it short.
    return 0.78;
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    if (products.isEmpty) {
      return EmptyState(
        variant: EmptyStateVariant.products,
        title: emptyTitle ?? l10n.noProducts,
        message: emptyMessage ?? l10n.addProductsHint,
        icon: Icons.search,
      );
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        final crossAxisCount = _crossAxisCount(width);
        final isMobile = width < 420;

        return GridView.builder(
          controller: scrollController,
          padding: EdgeInsets.symmetric(
            horizontal: isMobile ? 8 : 12,
            vertical: 12,
          ),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: crossAxisCount,
            childAspectRatio: _aspectRatio(width),
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
          ),
          itemCount: products.length + (isLoadingMore ? 1 : 0),
          itemBuilder: (context, index) {
            if (index == products.length) {
              return const Center(child: CircularProgressIndicator());
            }
            final product = products[index];
            final qty = product.quantity;
            final min = product.minQuantity;
            return EnhancedProductCard(
              product: product,
              onDelete: () => onDelete(product),
              onEdit: () => onEdit(product),
              statusColor: statusColorFn(qty, min),
              statusText: statusTextFn(qty, min),
            );
          },
        );
      },
    );
  }
}
