class ProductUnit {
  const ProductUnit({
    this.id,
    required this.name,
    required this.abbreviation,
    this.isDefault = false,
  });

  final String? id;
  final String name;
  final String abbreviation;
  final bool isDefault;

  factory ProductUnit.fromMap(Map<String, dynamic> map) {
    return ProductUnit(
      id: map['id'] as String?,
      name: map['name'] as String? ?? '',
      abbreviation: map['abbreviation'] as String? ?? '',
      isDefault: map['is_default'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toMap() => {
        'name': name.trim(),
        'abbreviation': abbreviation.trim(),
        'is_default': isDefault,
      };

  ProductUnit copyWith({
    String? id,
    String? name,
    String? abbreviation,
    bool? isDefault,
  }) {
    return ProductUnit(
      id: id ?? this.id,
      name: name ?? this.name,
      abbreviation: abbreviation ?? this.abbreviation,
      isDefault: isDefault ?? this.isDefault,
    );
  }
}
