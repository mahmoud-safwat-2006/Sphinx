
import 'dart:typed_data';

class Product {
  final String? id;
  final String name;
  final String barcode;
  double price;
  double minPrice;
  double wholesalePrice;
  double quantity;
  final double minQuantity;
  final String category;
  final String? imagePath;
  final Uint8List? imageBytes;
  final String? imageExtension;
  final String? unitId;
  final String? unitAbbreviation;

  Product({
    this.id,
    required this.name,
    required this.barcode,
    required this.price,
    required this.minPrice,
    required this.wholesalePrice,
    required this.quantity,
    required this.minQuantity,
    required this.category,
    this.imagePath,
    this.imageBytes,
    this.imageExtension,
    this.unitId,
    this.unitAbbreviation,
  });

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'id': id,
      'barcode': barcode,
      'price': price,
      'minPrice': minPrice,
      'wholesalePrice': wholesalePrice,
      'quantity': quantity,
      'minQuantity': minQuantity,
      'category': category,
      'imagePath': imagePath,
      'unitId': unitId,
      'unitAbbreviation': unitAbbreviation,
    };
  }

  String get status {
    if (quantity == 0) return 'outOfStock';
    if (quantity < minQuantity) return 'lowStock';
    return 'available';
  }

  String get priority {
    if (quantity == 0) return 'veryHigh';
    final diff = minQuantity - quantity;
    if (diff >= 3) return 'high';
    if (diff > 0) return 'medium';
    return 'low';
  }

  String get displayQuantity {
    if (unitAbbreviation != null && unitAbbreviation!.isNotEmpty) {
      return '${_formatQuantity(quantity)} $unitAbbreviation';
    }
    return _formatQuantity(quantity);
  }

  Product copyWith({
    String? id,
    String? name,
    String? barcode,
    double? price,
    double? minPrice,
    double? wholesalePrice,
    double? quantity,
    double? minQuantity,
    String? category,
    String? imagePath,
    Uint8List? imageBytes,
    String? imageExtension,
    String? unitId,
    String? unitAbbreviation,
  }) {
    return Product(
      id: id ?? this.id,
      name: name ?? this.name,
      barcode: barcode ?? this.barcode,
      price: price ?? this.price,
      minPrice: minPrice ?? this.minPrice,
      wholesalePrice: wholesalePrice ?? this.wholesalePrice,
      quantity: quantity ?? this.quantity,
      minQuantity: minQuantity ?? this.minQuantity,
      category: category ?? this.category,
      imagePath: imagePath ?? this.imagePath,
      imageBytes: imageBytes ?? this.imageBytes,
      imageExtension: imageExtension ?? this.imageExtension,
      unitId: unitId ?? this.unitId,
      unitAbbreviation: unitAbbreviation ?? this.unitAbbreviation,
    );
  }

  static String _formatQuantity(double value) {
    return value == value.truncateToDouble()
        ? value.toStringAsFixed(0)
        : value.toStringAsFixed(3).replaceFirst(RegExp(r'0+$'), '');
  }
}
