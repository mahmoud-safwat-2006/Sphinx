// ignore_for_file: avoid_print

import 'package:sphinx/core/data/services/supabase_service.dart';
import 'package:sphinx/core/data/services/file_bytes_loader.dart';
import 'package:sphinx/core/error/failure.dart';
import 'package:sphinx/core/error/error_handler.dart';
import 'package:sphinx/core/state/state_synchronizer.dart';
import 'package:sphinx/features/products/data/models/product_model.dart';
import 'package:sphinx/features/products/data/models/product_unit_model.dart';
import 'package:sphinx/features/products/domain/product_repository_int.dart';
import 'package:either_dart/either.dart';
import 'package:supabase_flutter/supabase_flutter.dart'
    show FileOptions, PostgrestException;

class ProductRepositoryImp extends ProductRepositoryInt {
  final SupabaseService _supabaseService;

  ProductRepositoryImp({SupabaseService? supabaseService})
      : _supabaseService = supabaseService ?? SupabaseService();

  static const _productSelect =
      '*, product_units(abbreviation)';

  Product _mapProduct(Map<String, dynamic> map, {double? branchQty, double? branchMinQty}) {
    final unit = map['product_units'] as Map<String, dynamic>?;
    return Product(
      id: map['id'] as String?,
      name: map['name'] as String? ?? '',
      barcode: map['barcode'] as String? ?? '',
      price: (map['price'] as num?)?.toDouble() ?? 0,
      minPrice: (map['min_price'] as num?)?.toDouble() ?? 0,
      wholesalePrice: (map['wholesale_price'] as num?)?.toDouble() ?? 0,
      quantity: branchQty ?? (map['quantity'] as num?)?.toDouble() ?? 0,
      minQuantity: branchMinQty ?? (map['min_quantity'] as num?)?.toDouble() ?? 0,
      category: map['category'] as String? ?? 'General',
      imagePath: map['image_url'] as String?,
      unitId: map['unit_id'] as String?,
      unitAbbreviation: unit?['abbreviation'] as String?,
    );
  }

  Future<String?> _storeProductImage(Product product) async {
    final selectedImage = product.imagePath;
    if (selectedImage == null || selectedImage.isEmpty) return null;
    if (selectedImage.startsWith('http://') ||
        selectedImage.startsWith('https://')) {
      return selectedImage;
    }

    final bytes = product.imageBytes ?? await loadFileBytes(selectedImage);
    final pathParts = selectedImage.split('.');
    final inferredExtension = pathParts.length > 1 ? pathParts.last : 'png';
    final extension =
        (product.imageExtension ?? inferredExtension).toLowerCase();
    final storagePath =
        'products/${product.barcode}_${DateTime.now().millisecondsSinceEpoch}.$extension';
    await _supabaseService.client.storage.from('product-images').uploadBinary(
          storagePath,
          bytes,
          fileOptions: const FileOptions(upsert: true),
        );
    return _supabaseService.client.storage
        .from('product-images')
        .getPublicUrl(storagePath);
  }

  @override
  Future<Either<Failure, void>> deleteProduct(String barcode) async {
    return ErrorHandler.executeWithErrorHandlingEitherDart(
      operation: () async {
        await _supabaseService
            .from('products')
            .update({'is_active': false}).eq('barcode', barcode);

        StateSynchronizer.notify(DataChangeEvent(
          entityType: 'product',
          operation: 'delete',
          id: barcode,
        ));

        return const Right(null);
      },
      operationName: 'deleteProduct',
      userFriendlyMessage: 'Failed to delete product',
      source: 'ProductRepository',
    );
  }

  @override
  Future<Either<Failure, List<Product>>> getAllProduct({String? branchId}) async {
    try {
      final response = await _supabaseService
          .from('products')
          .select(_productSelect)
          .eq('is_active', true);

      List<Product> products;
      if (branchId != null) {
        // Fetch branch_stock for this branch
        final stockResponse = await _supabaseService
            .from('branch_stock')
            .select('product_id, quantity, min_quantity')
            .eq('branch_id', branchId);

        final stockMap = <String, Map<String, dynamic>>{};
        for (var row in (stockResponse as List)) {
          stockMap[row['product_id'] as String] = row;
        }

        products = (response as List).map((row) {
          final m = row as Map<String, dynamic>;
          final productId = m['id'] as String;
          final stock = stockMap[productId];
          return _mapProduct(m,
              branchQty: stock != null ? (stock['quantity'] as num?)?.toDouble() : 0,
              branchMinQty: stock != null ? (stock['min_quantity'] as num?)?.toDouble() : 0);
        }).toList();
      } else {
        // All Branches: aggregate branch_stock quantities
        final allStock = await _supabaseService
            .from('branch_stock')
            .select('product_id, quantity, min_quantity');
        final aggMap = <String, double>{};
        final minMap = <String, double>{};
        for (var row in (allStock as List)) {
          final pid = row['product_id'] as String;
          final qty = (row['quantity'] as num?)?.toDouble() ?? 0;
          final minQty = (row['min_quantity'] as num?)?.toDouble() ?? 0;
          aggMap[pid] = (aggMap[pid] ?? 0) + qty;
          minMap[pid] = (minMap[pid] ?? 0) + minQty;
        }
        products = (response as List).map((row) {
          final m = row as Map<String, dynamic>;
          final pid = m['id'] as String;
          return _mapProduct(m,
              branchQty: aggMap[pid],
              branchMinQty: minMap[pid]);
        }).toList();
      }

      return Right(products);
    } on Exception catch (e) {
      return Left(CacheFailure("Error fetching products: ${e.toString()}"));
    }
  }

  @override
  Future<Either<Failure, List<Product>>> getProductsPaginated({
    required int page,
    required int pageSize,
    String? category,
    String? availability,
    String? searchQuery,
    String? branchId,
  }) async {
    try {
      final offset = page * pageSize;

      var query = _supabaseService
          .from('products')
          .select(_productSelect)
          .eq('is_active', true);

      if (category != null && category != '*') {
        query = query.eq('category', category);
      }

      if (searchQuery != null && searchQuery.isNotEmpty) {
        query =
            query.or('name.ilike.%$searchQuery%,barcode.ilike.%$searchQuery%');
      }

      final response = await query.order('name');
      var rows = (response as List).cast<Map<String, dynamic>>();

      // Overlay branch stock
      List<Product> products;
      if (branchId != null) {
        final stockResponse = await _supabaseService
            .from('branch_stock')
            .select('product_id, quantity, min_quantity')
            .eq('branch_id', branchId);
        final stockMap = <String, Map<String, dynamic>>{};
        for (var row in (stockResponse as List)) {
          stockMap[row['product_id'] as String] = row;
        }
        products = rows.map((m) {
          final pid = m['id'] as String;
          final stock = stockMap[pid];
          return _mapProduct(m,
              branchQty: stock != null ? (stock['quantity'] as num?)?.toDouble() : 0,
              branchMinQty: stock != null ? (stock['min_quantity'] as num?)?.toDouble() : 0);
        }).toList();
      } else {
        // All Branches: aggregate branch_stock quantities
        final allStock = await _supabaseService
            .from('branch_stock')
            .select('product_id, quantity, min_quantity');
        final aggMap = <String, double>{};
        final minMap = <String, double>{};
        for (var row in (allStock as List)) {
          final pid = row['product_id'] as String;
          final qty = (row['quantity'] as num?)?.toDouble() ?? 0;
          final minQty = (row['min_quantity'] as num?)?.toDouble() ?? 0;
          aggMap[pid] = (aggMap[pid] ?? 0) + qty;
          minMap[pid] = (minMap[pid] ?? 0) + minQty;
        }
        products = rows.map((m) {
          final pid = m['id'] as String;
          return _mapProduct(m,
              branchQty: aggMap[pid],
              branchMinQty: minMap[pid]);
        }).toList();
      }

      // Filter by availability
      if (availability != null && availability != '*') {
        if (availability == 'outOfStock') {
          products = products.where((p) => p.quantity == 0).toList();
        } else if (availability == 'lowStock') {
          products = products
              .where((p) => p.quantity > 0 && p.quantity <= p.minQuantity)
              .toList();
        } else if (availability == 'available') {
          products = products.where((p) => p.quantity > 0).toList();
        }
      }

      products = products.skip(offset).take(pageSize).toList();
      return Right(products);
    } on Exception catch (e) {
      return Left(
          CacheFailure("Error fetching products page: ${e.toString()}"));
    }
  }

  @override
  Future<Either<Failure, void>> saveProduct(Product product, {String? branchId}) async {
    return ErrorHandler.executeWithErrorHandlingEitherDart(
      operation: () async {
        final imageUrl = await _storeProductImage(product);
        final existing = await _supabaseService
            .from('products')
            .select('barcode')
            .eq('barcode', product.barcode)
            .maybeSingle();

        final catalogValues = <String, dynamic>{
          'barcode': product.barcode,
          'name': product.name,
          'price': product.price,
          'min_price': product.minPrice,
          'wholesale_price': product.wholesalePrice,
          'category': product.category,
          'image_url': imageUrl,
          'unit_id': product.unitId,
          'is_active': true,
          'updated_at': DateTime.now().toUtc().toIso8601String(),
        };

        String productId;
        if (existing != null) {
          await _supabaseService
              .from('products')
              .update(catalogValues)
              .eq('barcode', product.barcode);
          final row = await _supabaseService
              .from('products')
              .select('id')
              .eq('barcode', product.barcode)
              .single();
          productId = row['id'] as String;
        } else {
          catalogValues['created_at'] = DateTime.now().toUtc().toIso8601String();
          final inserted = await _supabaseService
              .from('products')
              .insert(catalogValues)
              .select('id')
              .single();
          productId = inserted['id'] as String;
        }

        // Write stock to branch_stock if branchId provided
        if (branchId != null) {
          await _supabaseService.from('branch_stock').upsert({
            'branch_id': branchId,
            'product_id': productId,
            'quantity': product.quantity.toDouble(),
            'min_quantity': product.minQuantity.toDouble(),
          }, onConflict: 'branch_id,product_id');
        }

        StateSynchronizer.notify(DataChangeEvent(
          entityType: 'product',
          operation: existing != null ? 'update' : 'create',
          id: product.barcode,
        ));

        return const Right(null);
      },
      operationName: 'saveProduct',
      userFriendlyMessage: 'Failed to save product',
      source: 'ProductRepository',
    );
  }

  @override
  Future<Either<Failure, void>> deleteCategory({
    required String category,
    bool forceDelete = false,
    String? newCategory,
  }) async {
    try {
      if (category == newCategory) {
        return Left(
            NetworkFailure("Cannot move products to the same category."));
      }

      final productsResult = await getAllProduct();
      return productsResult.fold(
        (failure) => Left(NetworkFailure("Error fetching products")),
        (productsList) async {
          final filteredProducts = productsList
              .where((product) => product.category == category)
              .toList();

          if (forceDelete) {
            for (var product in filteredProducts) {
              await deleteProduct(product.barcode);
            }
            await _supabaseService
                .from('categories')
                .delete()
                .eq('name', category);
            return const Right(null);
          } else {
            if (filteredProducts.isNotEmpty) {
              if (newCategory == null || newCategory.isEmpty) {
                return Left(CacheFailure(
                    "Cannot delete category because it contains products. Please choose a new category to move products to or use force delete."));
              }
              for (var product in filteredProducts) {
                var updatedProduct = Product(
                  barcode: product.barcode,
                  name: product.name,
                  price: product.price,
                  category: newCategory,
                  quantity: product.quantity,
                  minPrice: product.minPrice,
                  minQuantity: product.minQuantity,
                  wholesalePrice: product.wholesalePrice,
                  imagePath: product.imagePath,
                  unitId: product.unitId,
                  unitAbbreviation: product.unitAbbreviation,
                );
                await saveProduct(updatedProduct);
              }
            }
          }
          await _supabaseService
              .from('categories')
              .delete()
              .eq('name', category);
          return const Right(null);
        },
      );
    } on Exception {
      return Left(NetworkFailure("Error deleting category"));
    }
  }

  @override
  Future<Either<Failure, List<String>>> getAllCategory() async {
    try {
      final response = await _supabaseService
          .from('categories')
          .select('name')
          .order('name');

      final categories =
          (response as List).map((m) => m['name'] as String).toList();

      return Right(categories);
    } on Exception catch (e) {
      return Left(CacheFailure("Error fetching categories: ${e.toString()}"));
    }
  }

  @override
  Future<Either<Failure, void>> saveCategory(String category) async {
    return ErrorHandler.executeWithErrorHandlingEitherDart(
      operation: () async {
        await _supabaseService.from('categories').upsert(
          {'name': category.trim()},
          onConflict: 'name',
        );

        StateSynchronizer.notify(DataChangeEvent(
          entityType: 'category',
          operation: 'create',
          id: category,
        ));

        return const Right(null);
      },
      operationName: 'saveCategory',
      userFriendlyMessage: 'Failed to save category',
      source: 'ProductRepository',
    );
  }

  @override
  Future<Either<Failure, bool>> productExists(String barcode) async {
    try {
      final result = await _supabaseService
          .from('products')
          .select('barcode')
          .eq('barcode', barcode)
          .maybeSingle();
      return Right(result != null);
    } catch (e) {
      return Left(
          CacheFailure("Error checking product existence: ${e.toString()}"));
    }
  }

  @override
  Future<Either<Failure, List<ProductUnit>>> getAllUnits() async {
    try {
      final response = await _supabaseService
          .from('product_units')
          .select()
          .order('is_default', ascending: false)
          .order('name');
      return Right((response as List)
          .map((row) => ProductUnit.fromMap(row as Map<String, dynamic>))
          .toList());
    } on Exception catch (error) {
      return Left(CacheFailure('Failed to fetch product units: $error'));
    }
  }

  @override
  Future<Either<Failure, ProductUnit>> saveUnit(ProductUnit unit) async {
    try {
      if (unit.name.trim().isEmpty || unit.abbreviation.trim().isEmpty) {
        return Left(CacheFailure('Unit name and abbreviation are required'));
      }
      if (unit.isDefault) {
        await _supabaseService
            .from('product_units')
            .update({'is_default': false}).neq('is_default', false);
      }
      final payload = unit.toMap();
      final Map<String, dynamic> row;
      if (unit.id == null) {
        row = await _supabaseService
            .from('product_units')
            .insert(payload)
            .select()
            .single();
      } else {
        row = await _supabaseService
            .from('product_units')
            .update(payload)
            .eq('id', unit.id!)
            .select()
            .single();
      }
      return Right(ProductUnit.fromMap(row));
    } on PostgrestException catch (error) {
      if (error.code == '23505') {
        return Left(CacheFailure('unitAlreadyExists'));
      }
      return Left(CacheFailure('Failed to save product unit: $error'));
    } on Exception catch (error) {
      return Left(CacheFailure('Failed to save product unit: $error'));
    }
  }

  @override
  Future<Either<Failure, void>> deleteUnit(String id) async {
    try {
      final inUse = await _supabaseService
          .from('products')
          .select('id')
          .eq('unit_id', id)
          .limit(1);
      if ((inUse as List).isNotEmpty) {
        return Left(CacheFailure('Cannot delete a unit used by products'));
      }
      await _supabaseService.from('product_units').delete().eq('id', id);
      return const Right(null);
    } on Exception catch (error) {
      return Left(CacheFailure('Failed to delete product unit: $error'));
    }
  }
}
