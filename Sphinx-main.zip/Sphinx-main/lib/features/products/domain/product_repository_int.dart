import 'package:sphinx/features/products/data/models/product_model.dart';
import 'package:sphinx/features/products/data/models/product_unit_model.dart';
import 'package:either_dart/either.dart';

import '../../../core/error/failure.dart';

abstract class ProductRepositoryInt {
  Future<Either<Failure, List<Product>>> getAllProduct({String? branchId});
  Future<Either<Failure, List<Product>>> getProductsPaginated({
    required int page,
    required int pageSize,
    String? category,
    String? availability,
    String? searchQuery,
    String? branchId,
  });
  Future<Either<Failure, void>> saveProduct(Product product, {String? branchId});
  Future<Either<Failure, void>> deleteProduct(String barcode);
  Future<Either<Failure, List<String>>> getAllCategory();
  Future<Either<Failure, void>> saveCategory(String category);
  Future<Either<Failure, void>> deleteCategory(
      {required String category,
      bool forceDelete = false,
      String? newCategory});
  Future<Either<Failure, bool>> productExists(String barcode);
  Future<Either<Failure, List<ProductUnit>>> getAllUnits();
  Future<Either<Failure, ProductUnit>> saveUnit(ProductUnit unit);
  Future<Either<Failure, void>> deleteUnit(String id);
}
