import 'package:either_dart/either.dart';

import '../../../../core/error/failure.dart';
import '../../data/models/user_model.dart';

abstract class UserRepositoryInt {
  Future<Either<Failure, User>> getUser(String username);
  Future<Either<Failure, User>> getUserById(String userId);
  Future<Either<Failure, List<User>>> getAllUsers();
  Future<Either<Failure, void>> saveUser(
    User user, {
    required String password,
  });
  Future<Either<Failure, void>> updateUser(
    User user, {
    String? password,
  });
  Future<Either<Failure, void>> deleteUser(String username);
  Future<Either<Failure, void>> setUserPin(String userId, String pin);
}
