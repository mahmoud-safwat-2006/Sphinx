import 'package:flutter/material.dart';
import 'package:sphinx/core/components/local_image_view.dart';
import '../../../../core/constants/app_colors.dart';
import '../../data/models/quick_login_user.dart';
import 'package:sphinx/l10n/app_localizations.dart';

class QuickLoginUsers extends StatelessWidget {
  final List<QuickLoginUser> users;
  final ValueChanged<String> onSelected;

  const QuickLoginUsers({
    super.key,
    required this.users,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    if (users.isEmpty) return const SizedBox.shrink();
    final l10n = AppLocalizations.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: AppColors.accentColor.withOpacity(0.12),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(
                Icons.people_outline_rounded,
                size: 16,
                color: AppColors.accentColor,
              ),
            ),
            const SizedBox(width: 8),
            Text(
              l10n.quickLoginHeader,
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.bold,
                color: AppColors.textPrimary,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 74,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: users.length,
            separatorBuilder: (_, __) => const SizedBox(width: 6),
            itemBuilder: (context, index) {
              final user = users[index];
              return _QuickUserCardItem(
                user: user,
                onTap: () => onSelected(user.username),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _QuickUserCardItem extends StatefulWidget {
  final QuickLoginUser user;
  final VoidCallback onTap;

  const _QuickUserCardItem({
    required this.user,
    required this.onTap,
  });

  @override
  State<_QuickUserCardItem> createState() => _QuickUserCardItemState();
}

class _QuickUserCardItemState extends State<_QuickUserCardItem> {
  bool _isHovered = false;

  Color _getRoleColor(String role) {
    final r = role.toLowerCase();
    if (r.contains('admin')) {
      return AppColors.accentColor; // Samsung Blue
    } else if (r.contains('manager')) {
      return AppColors.primaryColor; // Black
    } else if (r.contains('cashier')) {
      return AppColors.successColor; // Green
    } else {
      return AppColors.mutedColor; // Grey
    }
  }

  String _formatRole(String role, AppLocalizations l10n) {
    final r = role.trim().toLowerCase();
    switch (r) {
      case 'admin':
        return l10n.roleAdmin;
      case 'manager':
        return l10n.roleManager;
      case 'cashier':
        return l10n.roleCashier;
      case 'accountant':
        return l10n.roleAccountant;
      case 'employee':
        return l10n.roleEmployee;
      default:
        return r.isEmpty
            ? l10n.roleEmployee
            : role[0].toUpperCase() + role.substring(1);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final roleColor = _getRoleColor(widget.user.role);
    final displayName = widget.user.displayName.isNotEmpty
        ? widget.user.displayName
        : widget.user.username;

    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          curve: Curves.easeOutCubic,
          width: 96,
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
          decoration: BoxDecoration(
            color: _isHovered ? roleColor.withOpacity(0.06) : Colors.white,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: _isHovered
                  ? roleColor
                  : AppColors.borderColor.withOpacity(0.8),
              width: _isHovered ? 1.2 : 1.0,
            ),
            boxShadow: [
              BoxShadow(
                color: _isHovered
                    ? roleColor.withOpacity(0.1)
                    : Colors.black.withOpacity(0.015),
                blurRadius: _isHovered ? 6 : 3,
                offset: Offset(0, _isHovered ? 2 : 1),
              ),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: roleColor.withOpacity(0.3),
                    width: 1.0,
                  ),
                ),
                child: LocalImageView(
                  path: widget.user.avatarUrl,
                  width: 22,
                  height: 22,
                  borderRadius: 11,
                  fallback: ColoredBox(
                    color: roleColor.withOpacity(0.12),
                    child: Center(
                      child: Text(
                        displayName.isEmpty
                            ? '?'
                            : displayName.characters.first.toUpperCase(),
                        style: TextStyle(
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                          color: roleColor,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 2),
              SizedBox(
                width: double.infinity,
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    displayName,
                    style: const TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      color: AppColors.textPrimary,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 1.5),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 4, vertical: 1.0),
                decoration: BoxDecoration(
                  color: roleColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(3),
                ),
                child: Text(
                  _formatRole(widget.user.role, l10n),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 8,
                    fontWeight: FontWeight.w700,
                    color: roleColor,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
