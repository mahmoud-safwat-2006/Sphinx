import 'package:flutter/material.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'package:sphinx/core/constants/app_colors.dart';

class LoginPinInput extends StatelessWidget {
  final TextEditingController controller;
  final VoidCallback onSubmit;

  const LoginPinInput({
    super.key,
    required this.controller,
    required this.onSubmit,
  });

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildPinBoxes(),
          const SizedBox(height: 16),
          _buildNumberKeypad(),
        ],
      ),
    );
  }

  Widget _buildPinBoxes() {
    return ValueListenableBuilder<TextEditingValue>(
      valueListenable: controller,
      builder: (context, value, _) {
        final pin = value.text;
        return Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(6, (index) {
            final isFilled = index < pin.length;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 46,
              height: 54,
              margin: const EdgeInsets.symmetric(horizontal: 4),
              decoration: BoxDecoration(
                color: isFilled ? AppColors.primaryColor : AppColors.inputFill,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color:
                      isFilled ? AppColors.primaryColor : AppColors.borderColor,
                  width: 2,
                ),
              ),
              child: Center(
                child: isFilled
                    ? const Icon(Icons.circle, size: 14, color: Colors.white)
                    : null,
              ),
            );
          }),
        );
      },
    );
  }

  Widget _buildNumberKeypad() {
    return Column(
      children: [
        _buildKeypadRow(['1', '2', '3']),
        const SizedBox(height: 8),
        _buildKeypadRow(['4', '5', '6']),
        const SizedBox(height: 8),
        _buildKeypadRow(['7', '8', '9']),
        const SizedBox(height: 8),
        _buildKeypadRow(['del', '0', 'ok']),
      ],
    );
  }

  Widget _buildKeypadRow(List<String> keys) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: keys.map((key) {
        final isDel = key == 'del';
        final isOk = key == 'ok';
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: SizedBox(
            width: 68,
            height: 54,
            child: Material(
              color: isDel
                  ? AppColors.errorColor.withOpacity(0.08)
                  : isOk
                      ? AppColors.successColor
                      : AppColors.surfaceColor,
              borderRadius: BorderRadius.circular(12),
              child: InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: () {
                  if (isDel) {
                    if (controller.text.isNotEmpty) {
                      controller.text = controller.text
                          .substring(0, controller.text.length - 1);
                    }
                  } else if (isOk) {
                    onSubmit();
                  } else {
                    if (controller.text.length < 6) {
                      controller.text += key;
                    }
                  }
                },
                child: Center(
                  child: isDel
                      ? const Icon(LucideIcons.delete,
                          size: 20, color: AppColors.errorColor)
                      : isOk
                          ? const Icon(LucideIcons.check,
                              size: 22, color: Colors.white)
                          : Text(
                              key,
                              style: const TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w700,
                                color: AppColors.textPrimary,
                              ),
                            ),
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}
