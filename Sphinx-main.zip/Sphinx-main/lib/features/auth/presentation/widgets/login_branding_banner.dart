import 'package:flutter/material.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'package:sphinx/core/constants/app_colors.dart';
import 'package:sphinx/core/components/app_logo.dart';
import 'package:sphinx/core/di/dependency_injection.dart';
import 'package:sphinx/features/settings/presentation/cubit/settings_cubit.dart';
import 'package:sphinx/l10n/app_localizations.dart';

class LoginBrandingBanner extends StatelessWidget {
  const LoginBrandingBanner({super.key});

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final configuredStoreName = getIt<SettingsCubit>().currentStoreInfo?.name;
    final isDefaultBrand = configuredStoreName == null ||
        configuredStoreName.isEmpty ||
        configuredStoreName == 'Sphinx' ||
        configuredStoreName == 'Sphinx Store';
    final storeName =
        isDefaultBrand ? 'Sphinx' : configuredStoreName;

    return Container(
      decoration: const BoxDecoration(color: AppColors.primaryColor),
      padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 48),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _buildLogo(),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      storeName,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.3,
                      ),
                    ),
                    Text(
                      l10n.systemSubtitle,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.6),
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const Spacer(flex: 3),
          Text(
            'Sphinx',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 34,
              fontWeight: FontWeight.w900,
              height: 1.2,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            l10n.systemDescription,
            style: TextStyle(
              color: Colors.white.withOpacity(0.7),
              fontSize: 14,
              height: 1.6,
            ),
          ),
          const Spacer(flex: 2),
          _buildFeatureItem(
              icon: LucideIcons.cloud, title: l10n.cloudSyncFeature),
          const SizedBox(height: 16),
          _buildFeatureItem(
              icon: LucideIcons.barcode, title: l10n.barcodeFeature),
          const SizedBox(height: 16),
          _buildFeatureItem(
              icon: LucideIcons.trendingUp, title: l10n.reportsFeature),
          const Spacer(flex: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '${l10n.version} 2.2',
                style: TextStyle(
                    color: Colors.white.withOpacity(0.4), fontSize: 12),
              ),
              Text(
                '© 2026 $storeName. ${l10n.copyright}',
                style: TextStyle(
                    color: Colors.white.withOpacity(0.4), fontSize: 12),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildLogo() {
    double size = 96.0;
    double glowOpacity = 0.3;
    return AnimatedContainer(
      width: size + 16,
      height: size + 16,
      duration: const Duration(seconds: 2),
      curve: Curves.easeInOut,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: AppColors.accentColor.withOpacity(glowOpacity * 0.4),
            blurRadius: 40,
            spreadRadius: 10,
          ),
          BoxShadow(
            color: AppColors.accentColor.withOpacity(glowOpacity * 0.2),
            blurRadius: 80,
            spreadRadius: 20,
          ),
        ],
      ),
      child: CircleAvatar(
        radius: 48,
        backgroundColor: Colors.white,
        child: ClipOval(
          child: AppLogo(width: 100, height: 100, fit: BoxFit.cover),
        ),
      ),
    );
  }

  Widget _buildFeatureItem({required IconData icon, required String title}) {
    return Row(
      children: [
        Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.1),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: AppColors.accentColor, size: 18),
        ),
        const SizedBox(width: 14),
        Text(
          title,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}
