// ignore_for_file: use_build_context_synchronously, deprecated_member_use

import 'package:sphinx/core/constants/app_colors.dart';
import 'package:sphinx/core/components/app_logo.dart';
import 'package:sphinx/core/di/dependency_injection.dart';
import 'package:sphinx/core/functions/messege.dart';
import 'package:sphinx/core/localization/translation_helper.dart';
import 'package:sphinx/features/auth/data/models/quick_login_user.dart';
import 'package:sphinx/features/auth/presentation/widgets/login_branding_banner.dart';
import 'package:sphinx/features/auth/presentation/widgets/login_mode_toggle.dart';
import 'package:sphinx/features/auth/presentation/widgets/login_pin_input.dart';
import 'package:sphinx/features/auth/presentation/widgets/quick_login_users.dart';
import 'package:sphinx/l10n/app_localizations.dart';
import 'package:sphinx/core/localization/locale_provider.dart';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'package:supabase_flutter/supabase_flutter.dart' hide User;

import '../../../core/shifts/shift_manager.dart';
import '../../dashboard/presentation/dashboard_screen.dart';
import 'cubit/user_cubit.dart';
import 'cubit/user_states.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool _isPasswordVisible = false;
  bool _usePin = false;
  final _passwordController = TextEditingController();
  final _passwordFocusNode = FocusNode();
  final _emailController = TextEditingController();
  final _pinController = TextEditingController();
  final _pinFocusNode = FocusNode();
  late Future<List<QuickLoginUser>> _quickLoginUsers;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    _passwordFocusNode.dispose();
    _pinController.dispose();
    _pinFocusNode.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _quickLoginUsers = _loadQuickLoginUsers();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      await getIt<SessionManager>().loadSession();
      if (mounted) setState(() {});
    });
  }

  void _onLoginPressed() {
    final email = _emailController.text.trim();
    final l10n = AppLocalizations.of(context);

    if (_usePin) {
      final pin = _pinController.text.trim();
      if (pin.isEmpty || pin.length != 6) {
        MotionSnackBarError(context, l10n.pinRequired);
        return;
      }
      getIt<UserCubit>().loginWithPin(pin);
    } else {
      final password = _passwordController.text.trim();
      if (email.isEmpty) {
        MotionSnackBarError(context, l10n.enterEmail);
        return;
      }
      if (password.isEmpty) {
        MotionSnackBarError(context, l10n.enterPassword);
        return;
      }
      getIt<UserCubit>().login(email, password);
    }
  }

  Future<List<QuickLoginUser>> _loadQuickLoginUsers() async {
    List<QuickLoginUser> users = [];
    try {
      final rows = await Supabase.instance.client
          .from('users')
          .select('id, username, display_name, role, avatar_url')
          .eq('is_active', true)
          .limit(20);
      users = (rows as List).map((row) {
        final m = row as Map<String, dynamic>;
        return QuickLoginUser(
          displayName:
              m['display_name'] as String? ?? m['username'] as String? ?? '',
          username: m['username'] as String? ?? '',
          role: m['role'] as String? ?? 'employee',
          avatarUrl: m['avatar_url'] as String?,
        );
      }).toList();
    } catch (tableError) {
      try {
        final rows =
            await Supabase.instance.client.rpc('list_quick_login_users');
        users = (rows as List)
            .whereType<Map<String, dynamic>>()
            .map(QuickLoginUser.fromMap)
            .toList();
      } catch (rpcError) {
        debugPrint('[Quick Login] Quick login users query failed: $rpcError');
      }
    }
    return users;
  }

  void _selectQuickLogin(String username) {
    _emailController.text = username;
    _emailController.selection = TextSelection.collapsed(
      offset: _emailController.text.length,
    );
    if (_usePin) {
      _pinFocusNode.requestFocus();
    } else {
      _passwordFocusNode.requestFocus();
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isDesktop = screenWidth >= 900;

    return BlocProvider<UserCubit>.value(
      value: getIt<UserCubit>(),
      child: BlocListener<UserCubit, UserStates>(
        listener: (context, state) {
          if (state is UserFailure) {
            MotionSnackBarError(
                context, TranslationHelper.translate(context, state.error));
          } else if (state is LoginSuccess) {
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => const DashboardScreen(),
                ));
          } else if (state is UserSuccess) {
            MotionSnackBarSuccess(
                context, TranslationHelper.translate(context, state.message));
            if (state.message == "dayClosedSuccessReport") {
              Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const DashboardScreen(),
                  ));
            } else {
              MotionSnackBarInfo(
                  context, TranslationHelper.translate(context, state.message));
            }
          }
        },
        child: Scaffold(
          backgroundColor: AppColors.backgroundColor,
          body: Center(
            child: isDesktop
                ? _buildDesktopLayout(context)
                : SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(vertical: 24),
                    child: _buildMobileLayout(context),
                  ),
          ),
        ),
      ),
    );
  }

  // ─── Layouts ───────────────────────────────────────────────

  Widget _buildDesktopLayout(BuildContext context) {
    return Container(
      constraints: BoxConstraints(
        maxWidth: 1050,
        maxHeight: MediaQuery.of(context).size.height > 750
            ? 680
            : MediaQuery.of(context).size.height - 48,
      ),
      decoration: BoxDecoration(
        color: AppColors.surfaceColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.borderColor, width: 1),
        boxShadow: [
          BoxShadow(
            color: AppColors.primaryColor.withOpacity(0.08),
            blurRadius: 40,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Expanded(
              flex: 55,
              child: Container(
                color: AppColors.surfaceColor,
                padding: const EdgeInsets.all(40),
                child: SingleChildScrollView(
                  child: _buildLoginForm(context),
                ),
              ),
            ),
            const Expanded(
              flex: 45,
              child: LoginBrandingBanner(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMobileLayout(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 450),
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.surfaceColor,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: AppColors.borderColor, width: 1),
            boxShadow: [
              BoxShadow(
                color: AppColors.primaryColor.withOpacity(0.06),
                blurRadius: 24,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 28),
          child: SingleChildScrollView(child: _buildLoginForm(context)),
        ),
      ),
    );
  }

  // ─── Form ──────────────────────────────────────────────────

  Widget _buildLoginForm(BuildContext context) {
    final l10n = AppLocalizations.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        // Logo (mobile only — desktop shows it in the banner)
        if (MediaQuery.of(context).size.width < 900) ...[
          Center(child: _buildLogo()),
          const SizedBox(height: 20),
        ],

        // Language toggle
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox.shrink(),
            TextButton.icon(
              icon: const Icon(Icons.language,
                  size: 18, color: AppColors.accentColor),
              label: Text(
                l10n.localeName == 'ar'
                    ? l10n.switchToEnglish
                    : l10n.switchToArabic,
                style: const TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.w700,
                  color: AppColors.accentColor,
                  fontSize: 13,
                ),
              ),
              onPressed: () => getIt<LocaleProvider>().toggleLocale(),
            ),
          ],
        ),

        // Welcome text
        Text(
          l10n.loginWelcome,
          style: const TextStyle(
            fontSize: 26,
            fontWeight: FontWeight.w800,
            color: AppColors.textPrimary,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          l10n.loginSubtitle,
          style: const TextStyle(fontSize: 14, color: AppColors.mutedColor),
        ),
        const SizedBox(height: 24),

        // Mode toggle
        LoginModeToggle(
          usePin: _usePin,
          onToggle: (v) => setState(() => _usePin = v),
        ),
        const SizedBox(height: 24),

        // Session warning
        _buildSessionWarning(l10n),

        // Email + Password fields
        if (!_usePin) ...[
          _buildEmailField(l10n),
          const SizedBox(height: 20),
          _buildPasswordField(l10n),
        ],

        // PIN input
        if (_usePin) ...[
          const SizedBox(height: 4),
          Text(
            l10n.pinCode,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: AppColors.textSecondary,
            ),
          ),
          const SizedBox(height: 10),
          LoginPinInput(
            controller: _pinController,
            onSubmit: _onLoginPressed,
          ),
        ],

        const SizedBox(height: 24),

        // Login button
        if (!_usePin) _buildLoginButton(l10n),
        const SizedBox(height: 24),

        // Quick login
        if (!_usePin) _buildQuickLoginUsers(),
      ],
    );
  }

  // ─── Form Elements ─────────────────────────────────────────

  Widget _buildSessionWarning(AppLocalizations l10n) {
    return Builder(
      builder: (context) {
        final session = getIt<SessionManager>().currentSession;
        if (session != null && session.isOpen) {
          return Container(
            margin: const EdgeInsets.only(bottom: 20),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: AppColors.accentColor.withOpacity(0.06),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.accentColor.withOpacity(0.2)),
            ),
            child: Row(
              children: [
                Icon(LucideIcons.info, color: AppColors.accentColor, size: 20),
                const SizedBox(width: 10),
                Flexible(
                  child: Text(
                    l10n.sessionOpenWarning,
                    style: const TextStyle(
                      color: AppColors.accentColor,
                      fontWeight: FontWeight.w600,
                      fontSize: 13,
                    ),
                  ),
                ),
              ],
            ),
          );
        }
        return const SizedBox.shrink();
      },
    );
  }

  Widget _buildEmailField(AppLocalizations l10n) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          l10n.localeName == 'ar' ? 'البريد الإلكتروني' : 'Email address',
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w700,
            color: AppColors.textSecondary,
          ),
        ),
        const SizedBox(height: 10),
        TextFormField(
          controller: _emailController,
          keyboardType: TextInputType.emailAddress,
          textDirection: TextDirection.ltr,
          style: const TextStyle(fontSize: 15),
          cursorColor: AppColors.primaryColor,
          decoration: InputDecoration(
            hintText: 'admin@sphinxpos.com',
            hintStyle: TextStyle(
                color: AppColors.mutedColor.withOpacity(0.5), fontSize: 14),
            prefixIcon: const Icon(LucideIcons.mail,
                color: AppColors.mutedColor, size: 20),
          ),
        ),
      ],
    );
  }

  Widget _buildPasswordField(AppLocalizations l10n) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          l10n.password,
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w700,
            color: AppColors.textSecondary,
          ),
        ),
        const SizedBox(height: 10),
        TextFormField(
          controller: _passwordController,
          focusNode: _passwordFocusNode,
          obscureText: !_isPasswordVisible,
          textDirection: TextDirection.ltr,
          style: const TextStyle(fontSize: 15),
          cursorColor: AppColors.primaryColor,
          decoration: InputDecoration(
            hintText: l10n.passwordHint,
            hintStyle: TextStyle(
                color: AppColors.mutedColor.withOpacity(0.5), fontSize: 14),
            prefixIcon: const Icon(LucideIcons.lock,
                color: AppColors.mutedColor, size: 20),
            suffixIcon: IconButton(
              icon: Icon(
                _isPasswordVisible ? LucideIcons.eye : LucideIcons.eyeOff,
                color: AppColors.mutedColor,
                size: 20,
              ),
              onPressed: () =>
                  setState(() => _isPasswordVisible = !_isPasswordVisible),
            ),
          ),
          onFieldSubmitted: (_) => _onLoginPressed(),
        ),
      ],
    );
  }

  Widget _buildLoginButton(AppLocalizations l10n) {
    return BlocBuilder<UserCubit, UserStates>(
      builder: (context, state) {
        final isLoading = state is UserLoading;
        return SizedBox(
          width: double.infinity,
          height: 54,
          child: ElevatedButton(
            onPressed: isLoading ? null : _onLoginPressed,
            child: isLoading
                ? const SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                    ),
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(LucideIcons.logIn, size: 20),
                      const SizedBox(width: 8),
                      Text(
                        l10n.loginButton,
                        style: const TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w700),
                      ),
                    ],
                  ),
          ),
        );
      },
    );
  }

  Widget _buildLogo() {
    return Container(
      width: 104,
      height: 104,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: AppColors.accentColor.withOpacity(0.12),
            blurRadius: 36,
            spreadRadius: 12,
          ),
          BoxShadow(
            color: AppColors.accentColor.withOpacity(0.06),
            blurRadius: 70,
            spreadRadius: 18,
          ),
        ],
      ),
      child: CircleAvatar(
        radius: 54,
        backgroundColor: Colors.white,
        child: ClipOval(
          child: AppLogo(width: 88, height: 88, fit: BoxFit.cover),
        ),
      ),
    );
  }

  Widget _buildQuickLoginUsers() {
    return FutureBuilder<List<QuickLoginUser>>(
      future: _quickLoginUsers,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Padding(
            padding: EdgeInsets.only(bottom: 16),
            child: LinearProgressIndicator(minHeight: 2),
          );
        }
        if (snapshot.hasError) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: TextButton.icon(
              onPressed: () => setState(() {
                _quickLoginUsers = _loadQuickLoginUsers();
              }),
              icon: const Icon(Icons.refresh),
              label: Text(AppLocalizations.of(context).retryQuickLogin),
            ),
          );
        }
        final users = snapshot.data ?? const [];
        if (users.isEmpty) return const SizedBox.shrink();
        return QuickLoginUsers(
          users: users,
          onSelected: _selectQuickLogin,
        );
      },
    );
  }
}
