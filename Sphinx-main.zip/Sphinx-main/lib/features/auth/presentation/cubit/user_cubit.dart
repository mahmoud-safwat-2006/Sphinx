import 'package:sphinx/features/auth/data/models/user_model.dart';
import 'package:sphinx/features/auth/domain/repository/user_repository_int.dart';
import 'package:sphinx/features/auth/presentation/cubit/user_states.dart';
import 'package:sphinx/features/shifts/data/repositories/shift_repository_impl.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/di/dependency_injection.dart';
import '../../../branches/presentation/cubit/branch_cubit.dart';
import '../../../pos/data/repository/pos_repository_impl.dart';

import '../../../../core/shifts/shift_manager.dart';

import 'package:supabase_flutter/supabase_flutter.dart' hide User, Session;
import '../../../shifts/data/models/product_performance_model.dart';
import '../../../shifts/data/models/shift_model.dart';

class UserCubit extends Cubit<UserStates> {
  UserCubit({
    required this.userRepository,
    required this.sessionRepository,
  }) : super(UserInitial());

  final UserRepositoryInt userRepository;
  final SessionRepositoryImpl sessionRepository;

  static UserCubit get(context) => BlocProvider.of(context);
  late User currentUser;
  bool _isPasswordVisible = false;

  bool get isPasswordVisible => _isPasswordVisible;

  List<User> _users = [];
  List<User> get users =>
      _users; // Access cached users even if state is not Loaded

  Future<void> getAllUsers() async {
    emit(UserLoading());
    final result = await userRepository.getAllUsers();
    result.fold(
      (failure) => emit(UserFailure(failure.message)),
      (usersList) async {
        // Sort: Admins first, then Managers
        usersList.sort((a, b) {
          if (a.userType == UserType.admin && b.userType != UserType.admin)
            return -1;
          if (a.userType != UserType.admin && b.userType == UserType.admin)
            return 1;
          if (a.userType == UserType.manager && b.userType != UserType.manager)
            return -1;
          if (a.userType != UserType.manager && b.userType == UserType.manager)
            return 1;
          return 0;
        });
        _users = usersList;
        emit(UsersLoaded(usersList));
      },
    );
  }

  void deleteUser(String username) async {
    emit(UserLoading());
    final result = await userRepository.deleteUser(username);
    result.fold(
      (failure) => emit(UserFailure(failure.message)),
      (_) async {
        emit(UserSuccess("msgUserDeleted"));

        getAllUsers();
      },
    );
  }

  Future<bool> saveUser(User user, {required String password}) async {
    emit(UserLoading());
    final result = await userRepository.saveUser(user, password: password);
    return result.fold(
      (failure) {
        emit(UserFailure(failure.message));
        return false;
      },
      (_) {
        emit(UserSuccess("msgUserCreated"));
        getAllUsers();
        return true;
      },
    );
  }

  Future<bool> updateUser(User user, {String? password}) async {
    emit(UserLoading());
    final result = await userRepository.updateUser(user, password: password);
    return result.fold(
      (failure) {
        emit(UserFailure(failure.message));
        return false;
      },
      (_) {
        if (currentUser.username == user.username) {
          currentUser = user;
        }
        emit(UserSuccess("msgUserUpdated"));
        getAllUsers();
        return true;
      },
    );
  }

  void getUser(String username) async {
    emit(UserLoading());
    final result = await userRepository.getUser(username);
    result.fold(
      (failure) => emit(UserFailure(failure.message)),
      (user) =>
          emit(UserSuccess("User fetched successfully: ${user.username}")),
    );
  }

  Future<void> login(String username, String password) async {
    emit(UserLoading());
    final trimmedUsername = username.trim();
    final trimmedPassword = password.trim();

    try {
      final client = Supabase.instance.client;
      final email = trimmedUsername.contains('@')
          ? trimmedUsername.toLowerCase()
          : '${trimmedUsername.toLowerCase()}@sphinxpos.com';

      final authResponse = await client.auth.signInWithPassword(
        email: email,
        password: trimmedPassword,
      );

      final authUser = authResponse.user;
      if (authUser == null) {
        emit(UserFailure("wrongPassword"));
        return;
      }

      final result = await userRepository.getUserById(authUser.id);
      await result.fold(
        (failure) async => emit(UserFailure(failure.message)),
        (user) => _completeLogin(user),
      );
    } on AuthException {
      emit(UserFailure("wrongPassword"));
    } catch (_) {
      emit(UserFailure("wrongPassword"));
    }
  }

  Future<void> _completeLogin(User user) async {
    currentUser = user;

    // Initialize BranchCubit with the user's branch info
    final branchCubit = getIt<BranchCubit>();
    branchCubit.init(
      userBranchId: user.branchId,
      isPrimaryAdmin: user.isPrimaryAdmin,
    );
    await branchCubit.loadBranches();

    try {
      final sessionManager = getIt<SessionManager>();
      await sessionManager.loadSession();
      final bool hadOpenSession = sessionManager.currentSession?.isOpen == true;

      emit(LoginSuccess(
        hadOpenSession ? "loginExistingSession" : "loginNewSession",
        isExistingSession: hadOpenSession,
      ));
    } catch (e) {
      emit(UserFailure("failedOpenDay:$e"));
    }
  }

  void loginWithPin(String pin) async {
    emit(UserLoading());
    final trimmedPin = pin.trim();

    try {
      final result =
          await Supabase.instance.client.rpc('verify_user_pin_only', params: {
        'pin_code': trimmedPin,
      });

      if (result != null && result is List && result.isNotEmpty) {
        final row = result.first;
        final verified = row['verified'] as bool? ?? false;
        if (verified) {
          final userId = row['user_id'] as String?;
          if (userId != null) {
            final userResult = await userRepository.getUserById(userId);
            userResult.fold(
              (failure) => emit(UserFailure(failure.message)),
              (user) async => _completeLogin(user),
            );
            return;
          }
        }
      }
      emit(UserFailure("wrongPin"));
    } catch (e) {
      print("   ❌ PIN Login error: $e");
      emit(UserFailure("wrongPin"));
    }
  }

  Future<bool> setUserPin(String userId, String pin) async {
    try {
      final result = await userRepository.setUserPin(userId, pin);
      return result.isRight;
    } catch (e) {
      return false;
    }
  }

  Future<void> requestPasswordReset(String identifier) async {
    emit(UserLoading());
    final trimmedIdentifier = identifier.trim().toLowerCase();
    final email = trimmedIdentifier.contains('@')
        ? trimmedIdentifier
        : '$trimmedIdentifier@sphinxpos.com';

    try {
      await Supabase.instance.client.auth.resetPasswordForEmail(email);
      emit(UserSuccess('passwordResetSent'));
    } on AuthException catch (error) {
      emit(UserFailure('passwordResetFailed:${error.message}'));
    } catch (error) {
      emit(UserFailure('passwordResetFailed:$error'));
    }
  }

  Future<void> closeSession() async {
    emit(CloseSessionLoading());
    try {
      final sessionManager = getIt<SessionManager>();
      print('DEBUG_SESSION: UserCubit.closeSession called');
      print(
          'DEBUG_SESSION: Manager.currentSession: ${sessionManager.currentSession?.id}');
      print(
          'DEBUG_SESSION: Repo.getCurrentSession: ${sessionRepository.getCurrentSession()?.id}');

      final session =
          sessionManager.currentSession; // Get pure object from manager/repo

      if (session == null || !session.isOpen) {
        print(
            'DEBUG_SESSION: No open session found in manager. Attempting loadSession...');
        // Try forcing a load just in case (e.g. if started sealed)
        await sessionManager.loadSession();
        if (sessionManager.currentSession == null) {
          print(
              'DEBUG_SESSION: Still no session after load. Emitting failure.');
          emit(UserFailure("noOpenSession"));
          return;
        }
      }

      final currentSessionToClose = sessionManager.currentSession!;

      // if (currentSessionToClose.id == null) {
      //     emit(UserFailure("خطأ في معرف اليوم"));
      //     return;
      // }

      // Robust Session Capture: Time-Based + ID-Based
      // We explicitly scan recent sales to ensure nothing is missed
      final salesRepo = getIt<PosRepositoryImpl>();
      final legacyResult = await salesRepo.getRecentSales(limit: 200000);
      final allRecent = legacyResult.getOrElse(() => []);

      final sales = allRecent.where((s) {
        // 1. Explicit Session Match
        if (s.sessionId == currentSessionToClose.id) return true;

        // 2. Time Window Match (Fallback for orphans or missing IDs)
        // "From Start to End" as requested by user
        if (s.date.isAfter(currentSessionToClose.openTime) &&
            s.date.isBefore(DateTime.now())) {
          // If manual linking failed, time is the source of truth
          return true;
        }
        return false;
      }).toList();

      // Ensure all found sales are linked to this session in DB
      // This fixes "No Data" bug for orphans found by time-window
      if (sales.isNotEmpty) {
        await salesRepo.linkSalesToSession(
            sales.map((e) => e.id).toList(), currentSessionToClose.id);
      }

      double totalSales = 0.0;
      double totalRefunds = 0.0;
      final Map<String, ProductPerformanceModel> productStats = {};
      final Map<String, ProductPerformanceModel> refundStats = {};

      for (final sale in sales) {
        final isRefund = sale.isRefund;
        final sign = isRefund ? -1.0 : 1.0;

        if (isRefund) {
          totalRefunds += sale.total.abs();
        } else {
          totalSales += sale.total;
        }

        for (final item in sale.saleItems) {
          final revenue = (item.price * item.quantity) * sign;
          final cost = (item.wholesalePrice * item.quantity) * sign;

          // Main Stats (Net)
          if (productStats.containsKey(item.productId)) {
            final existing = productStats[item.productId]!;
            productStats[item.productId] = ProductPerformanceModel(
              productId: existing.productId,
              productName: existing.productName,
              quantitySold:
                  existing.quantitySold + (item.quantity * (isRefund ? -1 : 1)),
              revenue: existing.revenue + revenue,
              cost: existing.cost + cost,
              profit: 0,
              profitMargin: 0,
            );
          } else {
            productStats[item.productId] = ProductPerformanceModel(
              productId: item.productId,
              productName: item.name,
              quantitySold: item.quantity * (isRefund ? -1 : 1),
              revenue: revenue,
              cost: cost,
              profit: 0,
              profitMargin: 0,
            );
          }

          // Refund Specific Stats
          if (isRefund) {
            if (refundStats.containsKey(item.productId)) {
              final existing = refundStats[item.productId]!;
              refundStats[item.productId] = existing.copyWith(
                quantitySold: existing.quantitySold + item.quantity,
                revenue: existing.revenue + item.total, // Refund amount
              );
            } else {
              refundStats[item.productId] = ProductPerformanceModel(
                productId: item.productId,
                productName: item.name,
                quantitySold: item.quantity,
                revenue: item.total, // Refunded Amount
                cost: item.wholesalePrice *
                    item.quantity, // Cost not usually subtracted on refund list view
                profit: 0,
                profitMargin: 0,
              );
            }
          }
        }
      }

      final List<ProductPerformanceModel> topProducts =
          productStats.values.map((p) {
        final profit = p.revenue - p.cost;
        final margin = p.revenue > 0 ? (profit / p.revenue) * 100 : 0.0;
        return p.copyWith(profit: profit, profitMargin: margin);
      }).toList()
            ..sort((a, b) => b.revenue.compareTo(a.revenue));

      final List<ProductPerformanceModel> refundedProducts =
          refundStats.values.toList();

      final netRevenue = totalSales - totalRefunds;

      // Close session via SessionManager
      final report = await sessionManager.closeCurrentSession(
        currentUser,
        totalSales: totalSales,
        totalRefunds: totalRefunds,
        netRevenue: netRevenue,
        totalTransactions: sales.length,
        topProducts: topProducts,
        refundedProducts: refundedProducts,
        transactions: sales,
      );

      // Create closed session for navigation
      final closedSession = Session(
        id: currentSessionToClose.id,
        openTime: currentSessionToClose.openTime,
        closeTime: report.date,
        isOpen: false,
        openedByUserId: currentSessionToClose.openedByUserId,
        closedByUserId: currentUser.id,
        invoiceIds: currentSessionToClose.invoiceIds,
        dailyReportId: report.id,
      );

      emit(UserSuccessWithReport(
          "dayClosedSuccessReport", report, closedSession));
    } catch (e) {
      emit(UserFailure("failedCloseDay:$e"));
    }
  }

  void togglePasswordVisibility() {
    _isPasswordVisible = !_isPasswordVisible;
    emit(PasswordVisibilityChanged(_isPasswordVisible));
  }

  void logout() async {
    currentUser =
        User(name: '', phone: '', username: '', userType: UserType.cashier);
    try {
      await Supabase.instance.client.auth.signOut();
    } catch (_) {}
    emit(UserInitial());
  }
}
