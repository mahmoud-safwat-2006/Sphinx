import 'dart:typed_data';
import '../../../../core/security/role_permissions.dart';

/// Expanded user types for cloud-based system
enum UserType { admin, manager, accountant, cashier, employee }

class User {
  final String? id; // UUID from Supabase auth
  String username;
  String name;
  String phone;
  String? email;
  UserType userType;
  String? imagePath; // avatar_url from Supabase
  Uint8List? avatarBytes;
  String? avatarExtension;
  final Map<Permission, bool> permissionOverrides;
  final bool isPrimaryAdmin;
  final bool hasPin;
  final String?
      branchId; // nullable: NULL only for primary admins (sees all branches)
  final String? branchName;

  User({
    this.id,
    required this.username,
    required this.name,
    this.phone = '',
    this.email,
    required this.userType,
    this.imagePath,
    this.avatarBytes,
    this.avatarExtension,
    this.permissionOverrides = const {},
    this.isPrimaryAdmin = false,
    this.hasPin = false,
    this.branchId,
    this.branchName,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'username': username,
      'name': name,
      'phone': phone,
      'email': email,
      'userType': userType.index,
      'imagePath': imagePath,
      'permissionOverrides': {
        for (final entry in permissionOverrides.entries)
          entry.key.name: entry.value,
      },
      'isPrimaryAdmin': isPrimaryAdmin,
      'hasPin': hasPin,
      'branchId': branchId,
      'branchName': branchName,
    };
  }

  /// Create a User from a Supabase `users` row
  factory User.fromSupabase(Map<String, dynamic> map, {String? email}) {
    return User(
      id: map['id'] as String?,
      username: map['username'] as String? ?? '',
      name: map['display_name'] as String? ?? '',
      phone: map['phone'] as String? ?? '',
      email: email,
      userType: _roleToUserType(map['role'] as String? ?? 'cashier'),
      imagePath: map['avatar_url'] as String?,
      permissionOverrides: _parsePermissionOverrides(
        map['user_permission_overrides'],
      ),
      isPrimaryAdmin: map['is_primary_admin'] as bool? ?? false,
      hasPin: (map['pin_hash'] as String?)?.isNotEmpty == true,
      branchId: map['branch_id'] as String?,
      branchName:
          (map['branches'] as Map<String, dynamic>?)?['name'] as String?,
    );
  }

  static Map<Permission, bool> _parsePermissionOverrides(dynamic value) {
    if (value is! List) return const {};
    final result = <Permission, bool>{};
    for (final row in value.whereType<Map>()) {
      final name = row['permission'] as String?;
      final allowed = row['allowed'] as bool?;
      if (name == null || allowed == null) continue;
      for (final permission in Permission.values) {
        if (permission.name == name) result[permission] = allowed;
      }
    }
    return result;
  }

  bool hasPermission(Permission permission) {
    if (isPrimaryAdmin &&
        (permission == Permission.manageUsers ||
            permission == Permission.assignRoles)) {
      return true;
    }
    return permissionOverrides[permission] ??
        RolePermissions.hasPermission(userType, permission);
  }

  User copyWith({
    String? id,
    String? username,
    String? name,
    String? phone,
    String? email,
    UserType? userType,
    String? imagePath,
    Uint8List? avatarBytes,
    String? avatarExtension,
    Map<Permission, bool>? permissionOverrides,
    bool? isPrimaryAdmin,
    bool? hasPin,
    String? branchId,
    String? branchName,
  }) =>
      User(
        id: id ?? this.id,
        username: username ?? this.username,
        name: name ?? this.name,
        phone: phone ?? this.phone,
        email: email ?? this.email,
        userType: userType ?? this.userType,
        imagePath: imagePath ?? this.imagePath,
        avatarBytes: avatarBytes ?? this.avatarBytes,
        avatarExtension: avatarExtension ?? this.avatarExtension,
        permissionOverrides:
            permissionOverrides ?? Map.of(this.permissionOverrides),
        isPrimaryAdmin: isPrimaryAdmin ?? this.isPrimaryAdmin,
        hasPin: hasPin ?? this.hasPin,
        branchId: branchId ?? this.branchId,
        branchName: branchName ?? this.branchName,
      );

  static UserType _roleToUserType(String role) {
    switch (role) {
      case 'admin':
        return UserType.admin;
      case 'manager':
        return UserType.manager;
      case 'accountant':
        return UserType.accountant;
      case 'employee':
        return UserType.employee;
      case 'cashier':
      default:
        return UserType.cashier;
    }
  }

  static String userTypeToRole(UserType type) {
    switch (type) {
      case UserType.admin:
        return 'admin';
      case UserType.manager:
        return 'manager';
      case UserType.accountant:
        return 'accountant';
      case UserType.employee:
        return 'employee';
      case UserType.cashier:
        return 'cashier';
    }
  }

  /// Whether this user has manager-level access or higher
  bool get isManagerOrAbove =>
      userType == UserType.admin || userType == UserType.manager;

  /// Whether this user can access POS checkout
  bool get canCheckout =>
      userType == UserType.admin ||
      userType == UserType.manager ||
      userType == UserType.cashier;
}
