class QuickLoginUser {
  final String displayName;
  final String username;
  final String role;
  final String? avatarUrl;

  const QuickLoginUser({
    required this.displayName,
    required this.username,
    required this.role,
    this.avatarUrl,
  });

  factory QuickLoginUser.fromMap(Map<String, dynamic> map) => QuickLoginUser(
        displayName: map['display_name'] as String? ?? '',
        username: map['username'] as String? ?? '',
        role: map['role'] as String? ?? 'employee',
        avatarUrl: map['avatar_url'] as String?,
      );
}
