import 'package:sphinx/core/data/services/file_bytes_loader.dart';
import 'package:sphinx/core/data/services/supabase_service.dart';
import 'package:sphinx/core/error/failure.dart';
import 'package:sphinx/core/error/error_handler.dart';
import 'package:sphinx/features/auth/data/models/user_model.dart';

import 'package:sphinx/features/auth/domain/repository/user_repository_int.dart';
import 'package:either_dart/either.dart';
import 'package:supabase_flutter/supabase_flutter.dart' hide User;

class UserRepositoryImp extends UserRepositoryInt {
  final SupabaseService _supabaseService;

  UserRepositoryImp({SupabaseService? supabaseService})
      : _supabaseService = supabaseService ?? SupabaseService();

  String _emailOf(String username) {
    if (username.contains('@')) return username;
    return '${username.toLowerCase().trim()}@sphinxpos.com';
  }

  @override
  Future<Either<Failure, void>> deleteUser(String username) async {
    try {
      print('👤 === DELETING USER (Supabase): $username ===');
      await _supabaseService.client.rpc('soft_delete_user', params: {
        'target_username': username,
      });
      return const Right(null);
    } on Exception catch (e) {
      return Left(ServerFailure("Failed to delete user: ${e.toString()}"));
    }
  }

  @override
  Future<Either<Failure, List<User>>> getAllUsers() async {
    try {
      print('👥 === LOADING USERS (Supabase) ===');

      var query = _supabaseService
          .from('users')
          .select('*, branches(name)')
          .eq('is_active', true);

      final response = await _supabaseService.withSessionRecovery(
        () => query,
      );

      Map<String, List<Map<String, dynamic>>> overridesMap = {};
      try {
        final overridesResponse = await _supabaseService
            .from('user_permission_overrides')
            .select('user_id, permission, allowed');
        for (final row in (overridesResponse as List)) {
          final uid = row['user_id'] as String?;
          if (uid == null) continue;
          overridesMap.putIfAbsent(uid, () => []).add(row);
        }
      } catch (e) {
        print('  ⚠️ Could not fetch permission overrides: $e');
      }

      final users = (response as List).map((m) {
        final userId = m['id'] as String?;
        final overrides = overridesMap[userId] ?? [];
        return User.fromSupabase(
            {...m, 'user_permission_overrides': overrides});
      }).toList();
      print('  👤 Users found: ${users.length}');
      return Right(users);
    } on Exception catch (e) {
      print('  ❌ Failed to load users: $e');
      return Left(ServerFailure("Failed to fetch users: ${e.toString()}"));
    }
  }

  @override
  Future<Either<Failure, User>> getUser(String username) async {
    try {
      print('👤 === GETTING USER: $username (Supabase) ===');

      final response = await _supabaseService
          .from('users')
          .select('*, branches(name)')
          .eq('username', username)
          .eq('is_active', true)
          .maybeSingle();

      if (response != null) {
        final userId = response['id'] as String?;
        List<Map<String, dynamic>> overrides = [];
        if (userId != null) {
          try {
            final overridesResponse = await _supabaseService
                .from('user_permission_overrides')
                .select('permission, allowed')
                .eq('user_id', userId);
            overrides =
                (overridesResponse as List).cast<Map<String, dynamic>>();
          } catch (e) {
            print('  ⚠️ Could not fetch permission overrides: $e');
          }
        }
        final user = User.fromSupabase(
            {...response, 'user_permission_overrides': overrides});
        print('  ✅ User found: ${user.name}');
        return Right(user);
      } else {
        print('  ❌ User not found');
        return Left(ServerFailure("User not found"));
      }
    } on Exception catch (e) {
      print('  ❌ Failed to get user: $e');
      return Left(ServerFailure("Failed to fetch user: ${e.toString()}"));
    }
  }

  @override
  Future<Either<Failure, User>> getUserById(String userId) async {
    try {
      final response = await _supabaseService
          .from('users')
          .select('*, branches(name)')
          .eq('id', userId)
          .eq('is_active', true)
          .maybeSingle();

      if (response == null) {
        return Left(ServerFailure('User profile not found'));
      }

      List<Map<String, dynamic>> overrides = [];
      try {
        final overridesResponse = await _supabaseService
            .from('user_permission_overrides')
            .select('permission, allowed')
            .eq('user_id', userId);
        overrides = (overridesResponse as List).cast<Map<String, dynamic>>();
      } catch (e) {
        print('  ⚠️ Could not fetch permission overrides: $e');
      }

      return Right(User.fromSupabase(
        {...response, 'user_permission_overrides': overrides},
        email: _supabaseService.client.auth.currentUser?.email,
      ));
    } on Exception catch (error) {
      return Left(ServerFailure('Failed to fetch user: $error'));
    }
  }

  @override
  Future<Either<Failure, void>> saveUser(
    User user, {
    required String password,
  }) async {
    return ErrorHandler.executeWithErrorHandlingEitherDart(
      operation: () async {
        print('👤 === SAVING USER (Supabase) ===');
        print('  📝 Name: ${user.name}');
        print('  👤 Username: ${user.username}');

        var avatarUrl = user.imagePath;
        if (user.avatarBytes != null ||
            (avatarUrl != null &&
                avatarUrl.isNotEmpty &&
                !avatarUrl.startsWith('http'))) {
          try {
            // Upload to Supabase Storage avatars bucket
            final bytes = user.avatarBytes ?? await loadFileBytes(avatarUrl!);
            final fileExt = user.avatarExtension ?? avatarUrl!.split('.').last;
            final fileName =
                '${user.username}_${DateTime.now().millisecondsSinceEpoch}.$fileExt';
            final storagePath = 'avatars/$fileName';

            await _supabaseService.client.storage.from('avatars').uploadBinary(
                storagePath, bytes,
                fileOptions: const FileOptions(upsert: true));

            avatarUrl = _supabaseService.client.storage
                .from('avatars')
                .getPublicUrl(storagePath);
            print('  Uploaded avatar: $avatarUrl');
          } catch (e) {
            print('  Failed to upload avatar to Supabase: $e');
          }
        }

        final existingProfile = await _supabaseService
            .from('users')
            .select()
            .eq('username', user.username)
            .maybeSingle();

        if (existingProfile != null) {
          // Update existing user
          final userId = existingProfile['id'] as String;
          await _supabaseService.client.rpc('admin_update_user', params: {
            'user_id_input': userId,
            'password_input': password.isNotEmpty ? password : null,
            'display_name_input': user.name,
            'phone_input': user.phone,
            'role_input': User.userTypeToRole(user.userType),
            'is_active_input': true,
            'branch_id_input': user.branchId,
          });

          if (avatarUrl != null) {
            await _supabaseService.client.rpc('set_user_avatar', params: {
              'target_user_id': userId,
              'avatar_url_input': avatarUrl,
            });
          }
          await _savePermissionOverrides(userId, user);
        } else {
          // Create new user using the RPC function
          final email = _emailOf(user.username);
          final newUserId =
              await _supabaseService.client.rpc('admin_create_user', params: {
            'email_input': email,
            'password_input': password,
            'username_input': user.username,
            'display_name_input': user.name,
            'phone_input': user.phone,
            'role_input': User.userTypeToRole(user.userType),
            'branch_id_input': user.branchId,
          });

          if (avatarUrl != null) {
            await _supabaseService.client.rpc('set_user_avatar', params: {
              'target_user_id': newUserId,
              'avatar_url_input': avatarUrl,
            });
          }
          await _savePermissionOverrides(newUserId as String, user);
        }

        print('  ✅ User saved successfully in Supabase\n');
        return const Right(null);
      },
      operationName: 'saveUser',
      userFriendlyMessage: 'Failed to save user',
      source: 'UserRepository',
    );
  }

  Future<void> _savePermissionOverrides(String userId, User user) async {
    try {
      await _supabaseService.client.rpc(
        'set_user_permission_overrides',
        params: {
          'target_user_id': userId,
          'overrides': {
            for (final entry in user.permissionOverrides.entries)
              entry.key.name: entry.value,
          },
        },
      );
    } catch (e) {
      // If RPC is missing on database, silently catch to allow user creation
      print('⚠️ set_user_permission_overrides RPC skipped/failed: $e');
    }
  }

  @override
  Future<Either<Failure, void>> updateUser(
    User user, {
    String? password,
  }) async {
    return saveUser(user, password: password ?? '');
  }

  @override
  Future<Either<Failure, void>> setUserPin(String userId, String pin) async {
    try {
      await _supabaseService.client.rpc('set_user_pin', params: {
        'target_user_id': userId,
        'pin_code': pin,
      });
      return const Right(null);
    } on Exception catch (e) {
      return Left(ServerFailure("Failed to set PIN: ${e.toString()}"));
    }
  }
}
