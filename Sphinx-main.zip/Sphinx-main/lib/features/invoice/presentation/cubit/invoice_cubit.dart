import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:uuid/uuid.dart';
import 'package:sphinx/core/di/dependency_injection.dart';
import 'package:sphinx/features/auth/presentation/cubit/user_cubit.dart';
import 'package:sphinx/features/shifts/presentation/cubit/shift_cubit.dart';
import 'package:sphinx/core/state/state_synchronizer.dart';

import '../../../pos/data/models/sale_model.dart';
import '../../../pos/domain/pos_repository.dart';
import '../widgets/partial_refund_dialog.dart';
import 'invoice_state.dart';

class InvoiceCubit extends Cubit<InvoiceState> {
  final PosRepository repository;

  StreamSubscription<DataChangeEvent>? _changeSubscription;

  InvoiceCubit(this.repository) : super(InvoiceState.initial()) {
    _changeSubscription = StateSynchronizer.events.listen((event) {
      if (event.entityType == 'sale' || event.entityType == 'branch_scope') {
        loadSales();
      }
    });
  }

  @override
  Future<void> close() {
    _changeSubscription?.cancel();
    return super.close();
  }

  // Load initial and filtered sales
  Future<void> loadSales() async {
    await _load(
      query: state.searchQuery,
      start: state.startDate,
      end: state.endDate,
      filterType: state.filterType,
    );
  }

  // Set search query and reload
  Future<void> setSearchQuery(String query) async {
    await _load(
      query: query,
      start: state.startDate,
      end: state.endDate,
      filterType: state.filterType,
    );
  }

  // Set date range and reload
  Future<void> setDate(DateTime? start, DateTime? end) async {
    await _load(
      query: state.searchQuery,
      start: start,
      end: end,
      filterType: state.filterType,
    );
  }

  // Set filter type and reload
  Future<void> setFilterType(InvoiceFilterType type) async {
    await _load(
      query: state.searchQuery,
      start: state.startDate,
      end: state.endDate,
      filterType: type,
    );
  }

  Future<void> _load({
    required String query,
    required DateTime? start,
    required DateTime? end,
    required InvoiceFilterType filterType,
  }) async {
    final currentSales = state.sales;
    emit(InvoiceState.loadingState(
      query,
      start,
      end,
      filterType,
      currentSales: currentSales,
    ));
    final result = await repository.getRecentSales(
      limit: 10000,
      startDate: start,
      endDate: end == null
          ? null
          : DateTime(end.year, end.month, end.day, 23, 59, 59, 999),
    );
    result.fold(
      (failure) {
        if (isClosed) return;
        emit(InvoiceState.error(
          failure.message,
          query,
          start,
          end,
          filterType,
          currentSales: currentSales,
        ));
      },
      (sales) {
        if (isClosed) return;
        emit(InvoiceState.loaded(
          _filterSales(sales, query, start, end, filterType),
          query,
          start,
          end,
          filterType,
        ));
      },
    );
  }

  List<Sale> _filterSales(List<Sale> sales, String searchQuery,
      DateTime? startDate, DateTime? endDate, InvoiceFilterType filterType) {
    var filtered = sales;

    // Filter by Type
    if (filterType == InvoiceFilterType.sales) {
      filtered = filtered.where((s) => !s.isRefund).toList();
    } else if (filterType == InvoiceFilterType.refunded) {
      filtered = filtered.where((s) => s.isRefund).toList();
    }

    if (startDate != null || endDate != null) {
      filtered = filtered.where((sale) {
        if (startDate != null && sale.date.isBefore(startDate)) return false;
        if (endDate != null) {
          final endOfDay =
              DateTime(endDate.year, endDate.month, endDate.day, 23, 59, 59);
          if (sale.date.isAfter(endOfDay)) return false;
        }
        return true;
      }).toList();
    }
    if (searchQuery.isNotEmpty) {
      filtered = filtered.where((sale) {
        if (sale.id.contains(searchQuery)) return true;
        return sale.saleItems.any((item) =>
            item.productId.contains(searchQuery) ||
            item.name.toLowerCase().contains(searchQuery.toLowerCase()));
      }).toList();
    }
    return filtered;
  }

  // Delete a single sale
  Future<void> deleteSale(String saleId) async {
    await repository.deleteSale(saleId);

    loadSales();
  }

  // Create Partial Refund (Item-based refund)
  Future<Sale?> createPartialRefund({
    required Sale originalSale,
    required List<RefundItem> itemsToRefund,
  }) async {
    if (itemsToRefund.isEmpty) return null;

    final session = getIt<ShiftCubit>().state.activeShift;

    // 2. Calculate total and create refund sale items
    double refundTotal = 0;
    final totalItems = itemsToRefund.length;

    final refundSaleItems = itemsToRefund.map((item) {
      refundTotal += item.total;
      return SaleItem(
        productId: item.productId,
        productBarcode: item.productBarcode,
        name: item.productName,
        price: item.unitPrice,
        salePrice: item.unitPrice,
        quantity: item.quantity,
        total: item.total,
        wholesalePrice: item.wholesalePrice,
      );
    }).toList();

    // 3. Create Refund Invoice
    final refundSale = Sale(
      id: const Uuid().v4(),
      total: refundTotal,
      items: totalItems,
      date: DateTime.now(),
      saleItems: refundSaleItems,
      cashierName: getIt<UserCubit>().currentUser.name,
      cashierUsername: getIt<UserCubit>().currentUser.username,
      cashierUserId: getIt<UserCubit>().currentUser.id,
      sessionId: session?.id,
      invoiceTypeIndex: 1, // REFUND
      refundOriginalInvoiceId: originalSale.id,
      paymentMethod: originalSale.paymentMethod,
      notes: itemsToRefund.first.reason,
    );

    final saved = await repository.saveSale(refundSale);
    if (saved.isLeft()) return null;

    loadSales();
    return refundSale;
  }

  // Bulk delete (date range or query)
  Future<void> deleteInvoices(
      DateTime? start, DateTime? end, String searchQuery) async {
    if (start != null && end != null) {
      await repository.deleteSalesInRange(start, end);
    } else {
      await repository.deleteSalesByQuery(searchQuery);
    }

    loadSales();
  }

  // Reset all filters
  Future<void> resetFilters() async {
    const query = '';
    const InvoiceFilterType type = InvoiceFilterType.all;
    DateTime? start;
    DateTime? end;

    await _load(
      query: query,
      start: start,
      end: end,
      filterType: type,
    );
  }
}
