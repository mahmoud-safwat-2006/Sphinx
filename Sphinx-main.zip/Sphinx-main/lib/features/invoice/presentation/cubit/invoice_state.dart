import '../../../pos/data/models/sale_model.dart';

enum InvoiceFilterType { all, sales, refunded }

class InvoiceState {
  final List<Sale> sales;
  final bool loading;
  final String? errorMessage;
  final String searchQuery;
  final DateTime? startDate;
  final DateTime? endDate;
  final InvoiceFilterType filterType;

  InvoiceState({
    required this.sales,
    required this.loading,
    this.errorMessage,
    required this.searchQuery,
    required this.startDate,
    required this.endDate,
    required this.filterType,
  });

  // Factory constructors for basic state creation
  static InvoiceState initial() => InvoiceState(
        sales: [],
        loading: false,
        errorMessage: null,
        searchQuery: '',
        startDate: null,
        endDate: null,
        filterType: InvoiceFilterType.all,
      );

  static InvoiceState loadingState(String query, DateTime? start, DateTime? end,
          InvoiceFilterType filterType,
          {List<Sale>? currentSales}) =>
      InvoiceState(
        sales: currentSales ?? [],
        loading: true,
        errorMessage: null,
        searchQuery: query,
        startDate: start,
        endDate: end,
        filterType: filterType,
      );

  static InvoiceState loaded(List<Sale> sales, String query, DateTime? start,
          DateTime? end, InvoiceFilterType filterType) =>
      InvoiceState(
        sales: sales,
        loading: false,
        errorMessage: null,
        searchQuery: query,
        startDate: start,
        endDate: end,
        filterType: filterType,
      );

  static InvoiceState error(String message, String query, DateTime? start,
          DateTime? end, InvoiceFilterType filterType,
          {List<Sale>? currentSales}) =>
      InvoiceState(
        sales: currentSales ?? [],
        loading: false,
        errorMessage: message,
        searchQuery: query,
        startDate: start,
        endDate: end,
        filterType: filterType,
      );
}
