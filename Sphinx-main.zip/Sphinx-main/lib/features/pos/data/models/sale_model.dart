// sale_model.dart

class Sale {
  final String id;
  final double total;
  final double subtotal;
  final double discountAmount;
  final String discountType;
  final double discountValue;
  final int items;
  final DateTime date;
  final List<SaleItem> saleItems;
  final String? cashierName;
  final String? cashierUsername;
  final String? cashierUserId;
  final String? sessionId;
  final int invoiceTypeIndex;
  final String? refundOriginalInvoiceId;
  final String paymentMethod;
  final String? notes;

  Sale({
    required this.id,
    required this.total,
    this.subtotal = 0,
    this.discountAmount = 0,
    this.discountType = 'none',
    this.discountValue = 0,
    required this.items,
    required this.date,
    required this.saleItems,
    required this.cashierName,
    this.cashierUsername,
    this.cashierUserId,
    this.sessionId,
    this.invoiceTypeIndex = 0,
    this.refundOriginalInvoiceId,
    this.paymentMethod = 'cash',
    this.notes,
  });

  bool get isRefund => invoiceTypeIndex == 1;
  bool get canBeRefunded => !isRefund;
  bool get hasDiscount => discountType != 'none' && discountAmount > 0;

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'total': total,
      'subtotal': subtotal,
      'discount_amount': discountAmount,
      'discount_type': discountType,
      'discount_value': discountValue,
      'items': items,
      'date': date.toIso8601String(),
      'cashierName': cashierName,
      'cashierUsername': cashierUsername,
      'cashierUserId': cashierUserId,
      'sessionId': sessionId,
      'invoiceTypeIndex': invoiceTypeIndex,
      'refundOriginalInvoiceId': refundOriginalInvoiceId,
      'paymentMethod': paymentMethod,
      'notes': notes,
      'saleItems': saleItems.map((x) => x.toMap()).toList(),
    };
  }
}

class SaleItem {
  final String productId;
  final String productBarcode;
  final String name;
  final double price;
  final double salePrice;
  final double quantity;
  final double total;
  final double wholesalePrice;
  final double itemDiscount;
  final String unitAbbreviation;
  double refundedQuantity = 0;

  SaleItem({
    required this.productId,
    required this.productBarcode,
    required this.name,
    required this.price,
    this.salePrice = 0,
    required this.quantity,
    required this.total,
    required this.wholesalePrice,
    this.itemDiscount = 0,
    this.unitAbbreviation = '',
    this.refundedQuantity = 0,
  });

  double get effectivePrice => salePrice - itemDiscount;
  bool get hasDiscount => itemDiscount > 0;

  Map<String, dynamic> toMap() {
    return {
      'productId': productId,
      'productBarcode': productBarcode,
      'name': name,
      'price': price,
      'sale_price': salePrice,
      'quantity': quantity,
      'total': total,
      'wholesalePrice': wholesalePrice,
      'item_discount': itemDiscount,
      'unit_abbreviation': unitAbbreviation,
      'refundedQuantity': refundedQuantity,
    };
  }
}
