class CartItemModel {
  final String id;
  final String productId;
  final String name;
  final double originalPrice;
  double salePrice;
  double qty;
  final DateTime date;
  final double minPrice;
  final double wholesalePrice;
  final double stockQuantity;
  final String? unitAbbreviation;
  final String? imagePath;
  double discountAmount;
  String discountType; // 'none', 'percentage', 'fixed'

  CartItemModel({
    required this.id,
    required this.productId,
    required this.name,
    required this.originalPrice,
    required this.salePrice,
    required this.qty,
    required this.date,
    required this.minPrice,
    required this.wholesalePrice,
    this.stockQuantity = double.infinity,
    this.unitAbbreviation,
    this.imagePath,
    this.discountAmount = 0,
    this.discountType = 'none',
  });

  double get effectiveDiscount => salePrice - discountedPrice;

  String get productBarcode => id;

  double get discountedPrice {
    if (discountType == 'percentage') {
      return salePrice - (salePrice * discountAmount / 100);
    } else if (discountType == 'fixed') {
      return salePrice - discountAmount;
    }
    return salePrice;
  }

  double get total => discountedPrice * qty;

  bool get hasDiscount => discountType != 'none' && discountAmount > 0;

  bool isPriceBelowMin() => discountedPrice < minPrice;

  String get displayQuantity {
    if (unitAbbreviation != null && unitAbbreviation!.isNotEmpty) {
      return '$qty $unitAbbreviation';
    }
    return qty.toString();
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'productId': productId,
      'name': name,
      'price': salePrice,
      'qty': qty,
      'date': date,
      'minPrice': minPrice,
      'originalPrice': originalPrice,
      'wholesalePrice': wholesalePrice,
      'stockQuantity': stockQuantity,
      'unitAbbreviation': unitAbbreviation,
      'imagePath': imagePath,
      'discountAmount': discountAmount,
      'discountType': discountType,
    };
  }

  CartItemModel copyWith({
    String? id,
    String? productId,
    String? name,
    double? originalPrice,
    double? salePrice,
    double? qty,
    DateTime? date,
    double? minPrice,
    double? wholesalePrice,
    double? stockQuantity,
    String? unitAbbreviation,
    String? imagePath,
    double? discountAmount,
    String? discountType,
  }) {
    return CartItemModel(
      id: id ?? this.id,
      productId: productId ?? this.productId,
      name: name ?? this.name,
      originalPrice: originalPrice ?? this.originalPrice,
      salePrice: salePrice ?? this.salePrice,
      qty: qty ?? this.qty,
      date: date ?? this.date,
      minPrice: minPrice ?? this.minPrice,
      wholesalePrice: wholesalePrice ?? this.wholesalePrice,
      stockQuantity: stockQuantity ?? this.stockQuantity,
      unitAbbreviation: unitAbbreviation ?? this.unitAbbreviation,
      imagePath: imagePath ?? this.imagePath,
      discountAmount: discountAmount ?? this.discountAmount,
      discountType: discountType ?? this.discountType,
    );
  }
}
