import 'package:sphinx/core/data/services/supabase_service.dart';
import 'package:sphinx/core/di/dependency_injection.dart';
import 'package:sphinx/core/error/error_handler.dart';
import 'package:sphinx/core/state/state_synchronizer.dart';
import 'package:dartz/dartz.dart';
import '../../../../core/error/failure.dart';
import '../../../branches/presentation/cubit/branch_cubit.dart';
import '../../../products/data/models/product_model.dart';
import '../../domain/pos_repository.dart';
import '../models/sale_model.dart';
import '../models/cart_item_model.dart';
import 'package:supabase_flutter/supabase_flutter.dart' hide User, Session;
import 'package:uuid/uuid.dart';

class PosRepositoryImpl implements PosRepository {
  final SupabaseService _supabaseService;

  PosRepositoryImpl({SupabaseService? supabaseService})
      : _supabaseService = supabaseService ?? SupabaseService();

  String _databaseTimestamp(DateTime value) => value.toUtc().toIso8601String();

  @override
  Future<Either<Failure, Product?>> findProductByBarcode(String barcode) async {
    try {
      final trimmed = barcode.trim();
      if (trimmed.isEmpty) return const Right(null);

      final isUuid = RegExp(
              r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$')
          .hasMatch(trimmed);
      final filter = isUuid
          ? 'barcode.eq.$trimmed,id.eq.$trimmed,name.ilike.%$trimmed%'
          : 'barcode.eq.$trimmed,name.ilike.%$trimmed%';

      dynamic response;
      try {
        response = await _supabaseService
            .from('products')
            .select('*, product_units(abbreviation)')
            .or(filter)
            .eq('is_active', true)
            .limit(1)
            .maybeSingle();
      } catch (e) {
        response = await _supabaseService
            .from('products')
            .select('*')
            .or(filter)
            .eq('is_active', true)
            .limit(1)
            .maybeSingle();
      }

      if (response == null) {
        response = await _supabaseService
            .from('products')
            .select('*')
            .eq('barcode', trimmed)
            .maybeSingle();
      }

      if (response == null) return const Right(null);

      // Get stock from branch_stock if branchId is available
      double stockVal = 0;
      double minStockVal = 0;
      final branchId = getIt<BranchCubit>().effectiveBranchId;
      if (branchId != null && response['id'] != null) {
        final stockRow = await _supabaseService
            .from('branch_stock')
            .select('quantity, min_quantity')
            .eq('branch_id', branchId)
            .eq('product_id', response['id'] as String)
            .maybeSingle();
        if (stockRow != null) {
          stockVal = (stockRow['quantity'] as num?)?.toDouble() ?? 0;
          minStockVal = (stockRow['min_quantity'] as num?)?.toDouble() ?? 0;
        }
      } else {
        // Fallback to products.stock for primary admin with no branch selected
        stockVal =
            (response['stock_quantity'] ?? response['quantity'] ?? 100 as num)
                .toDouble();
        minStockVal = (response['min_quantity'] ?? 0 as num).toDouble();
      }

      final product = Product(
        id: response['id'] as String,
        name: response['name'] as String,
        barcode: (response['barcode'] as String?) ?? trimmed,
        price: (response['price'] as num?)?.toDouble() ?? 0.0,
        minPrice: (response['min_price'] as num?)?.toDouble() ?? 0.0,
        wholesalePrice:
            (response['wholesale_price'] as num?)?.toDouble() ?? 0.0,
        quantity: stockVal,
        minQuantity: minStockVal,
        category: response['category'] as String? ?? 'General',
        imagePath: response['image_url'] as String?,
        unitId: response['unit_id'] as String?,
        unitAbbreviation: (response['product_units']
                as Map<String, dynamic>?)?['abbreviation'] as String? ??
            'pc',
      );

      return Right(product);
    } catch (e) {
      print('⚠️ findProductByBarcode error: $e');
      return const Right(null);
    }
  }

  @override
  Future<Either<Failure, List<Product>>> getAllProducts() async {
    try {
      final response = await _supabaseService
          .from('products')
          .select('*, product_units(abbreviation)')
          .eq('is_active', true);

      final branchId = getIt<BranchCubit>().effectiveBranchId;
      Map<String, Map<String, dynamic>> stockMap = {};

      if (branchId != null) {
        final stockResponse = await _supabaseService
            .from('branch_stock')
            .select('product_id, quantity, min_quantity')
            .eq('branch_id', branchId);
        for (var row in (stockResponse as List)) {
          stockMap[row['product_id'] as String] = row;
        }
      }

      final products = (response as List).map((m) {
        final productId = m['id'] as String;
        final stock = stockMap[productId];
        final stockVal = stock != null
            ? (stock['quantity'] as num?)?.toDouble() ?? 0
            : (m['stock_quantity'] ?? m['quantity'] ?? 100 as num).toDouble();
        final minStockVal = stock != null
            ? (stock['min_quantity'] as num?)?.toDouble() ?? 0
            : (m['min_quantity'] ?? 0 as num).toDouble();
        return Product(
          id: productId,
          name: m['name'] as String,
          barcode: (m['barcode'] as String?) ?? '',
          price: (m['price'] as num?)?.toDouble() ?? 0.0,
          minPrice: (m['min_price'] as num?)?.toDouble() ?? 0.0,
          wholesalePrice: (m['wholesale_price'] as num?)?.toDouble() ?? 0.0,
          quantity: stockVal,
          minQuantity: minStockVal,
          category: m['category'] as String? ?? 'General',
          imagePath: m['image_url'] as String?,
          unitId: m['unit_id'] as String?,
          unitAbbreviation: (m['product_units']
                  as Map<String, dynamic>?)?['abbreviation'] as String? ??
              'pc',
        );
      }).toList();

      return Right(products);
    } catch (e) {
      return Left(CacheFailure('Error fetching products: ${e.toString()}'));
    }
  }

  @override
  Future<Either<Failure, Unit>> saveSale(Sale sale) async {
    if (!sale.isRefund) {
      return completeSale(sale);
    }
    return ErrorHandler.executeWithErrorHandling(
      operation: () async {
        final branchId = getIt<BranchCubit>().effectiveBranchId;

        // Insert refund sale record
        await _supabaseService.from('sales').insert({
          'id': sale.id,
          'total': sale.total,
          'subtotal': sale.subtotal,
          'items': sale.items,
          'created_at': sale.date.toUtc().toIso8601String(),
          'cashier_name': sale.cashierName,
          'cashier_user_id': sale.cashierUserId,
          'invoice_type_index': 1,
          'payment_method': sale.paymentMethod,
          'notes': sale.notes,
          'refund_original_invoice_id': sale.refundOriginalInvoiceId,
          if (sale.sessionId != null) 'session_id': sale.sessionId,
          if (branchId != null) 'branch_id': branchId,
        });

        // Insert refund sale items
        for (final item in sale.saleItems) {
          await _supabaseService.from('sale_items').insert({
            'sale_id': sale.id,
            'product_id': item.productId,
            'product_barcode': item.productBarcode,
            'name': item.name,
            'quantity': item.quantity,
            'price': item.price,
            'sale_price': item.salePrice,
            'total': item.total,
            'wholesale_price': item.wholesalePrice,
            if (branchId != null) 'branch_id': branchId,
          });
        }

        // Increment branch stock back for each refunded item
        if (branchId != null) {
          for (final item in sale.saleItems) {
            final stockRow = await _supabaseService
                .from('branch_stock')
                .select('quantity')
                .eq('branch_id', branchId)
                .eq('product_id', item.productId)
                .maybeSingle();
            final currentStock = stockRow != null
                ? (stockRow['quantity'] as num).toDouble()
                : 0.0;
            await _supabaseService.from('branch_stock').upsert({
              'branch_id': branchId,
              'product_id': item.productId,
              'quantity': currentStock + item.quantity,
            }, onConflict: 'branch_id,product_id');
          }
        }

        StateSynchronizer.notify(DataChangeEvent(
          entityType: 'sale',
          operation: 'create',
          id: sale.id,
        ));
        StateSynchronizer.notify(DataChangeEvent(
          entityType: 'product_stock',
          operation: 'update',
        ));

        return const Right(unit);
      },
      operationName: 'saveSale',
      userFriendlyMessage: 'Failed to save refund',
      source: 'PosRepository',
    );
  }

  @override
  Future<Either<Failure, Unit>> completeSale(Sale sale) async {
    return ErrorHandler.executeWithErrorHandling(
      operation: () async {
        try {
          final branchId = getIt<BranchCubit>().effectiveBranchId;
          await _supabaseService.client.rpc('complete_sale', params: {
            'sale_input': {
              'id': sale.id,
              'total': sale.total,
              'subtotal': sale.subtotal,
              'discount_amount': sale.discountAmount,
              'discount_type': sale.discountType,
              'discount_value': sale.discountValue,
              'created_at': sale.date.toUtc().toIso8601String(),
              'user_id': sale.cashierUserId,
              'cashier_name': sale.cashierName,
              'payment_method': sale.paymentMethod,
              'notes': sale.notes,
              if (sale.sessionId != null) 'session_id': sale.sessionId,
              if (branchId != null) 'branch_id': branchId,
            },
            'items_input': sale.saleItems
                .map((item) => {
                      'product_id': item.productId,
                      'product_barcode': item.productBarcode,
                      'name': item.name,
                      'quantity': item.quantity,
                      'price': item.price,
                      'sale_price': item.salePrice,
                      'item_discount': item.itemDiscount,
                      'wholesale_price': item.wholesalePrice,
                      'unit_abbreviation': item.unitAbbreviation,
                      'total': item.total,
                      if (branchId != null) 'branch_id': branchId,
                    })
                .toList(),
          });
        } catch (e) {
          print('RPC complete_sale failed: $e');
          rethrow;
        }
        StateSynchronizer.notify(DataChangeEvent(
          entityType: 'sale',
          operation: 'create',
          id: sale.id,
        ));
        StateSynchronizer.notify(DataChangeEvent(
          entityType: 'product_stock',
          operation: 'update',
        ));
        return const Right(unit);
      },
      operationName: 'completeSale',
      userFriendlyMessage: 'Failed to complete sale',
      source: 'PosRepository',
    );
  }

  Future<List<Sale>> _getSalesWithItems(
      List<Map<String, dynamic>> saleRows) async {
    if (saleRows.isEmpty) return [];

    final saleIds = saleRows.map((r) => r['id'] as String).toList();

    final itemResponse = await _supabaseService
        .from('sale_items')
        .select()
        .inFilter('sale_id', saleIds);

    final itemsMap = <String, List<SaleItem>>{};
    for (var row in (itemResponse as List)) {
      final saleId = row['sale_id'] as String;
      if (!itemsMap.containsKey(saleId)) {
        itemsMap[saleId] = [];
      }
      itemsMap[saleId]!.add(SaleItem(
        productId: row['product_id'] as String,
        productBarcode: row['product_barcode'] as String? ?? '',
        name: row['name'] as String,
        price: (row['price'] as num).toDouble(),
        salePrice: (row['sale_price'] as num?)?.toDouble() ??
            (row['price'] as num).toDouble(),
        itemDiscount: (row['item_discount'] as num?)?.toDouble() ?? 0,
        unitAbbreviation: row['unit_abbreviation'] as String? ?? '',
        quantity: (row['quantity'] as num).toDouble(),
        total: (row['total'] as num).toDouble(),
        wholesalePrice: (row['wholesale_price'] as num?)?.toDouble() ?? 0.0,
        refundedQuantity: (row['refunded_quantity'] as num?)?.toDouble() ?? 0,
      ));
    }

    return saleRows.map((row) {
      final id = row['id'] as String;
      return Sale(
        id: id,
        total: (row['total'] as num).toDouble(),
        subtotal: (row['subtotal'] as num?)?.toDouble() ??
            (row['total'] as num).toDouble(),
        discountAmount: (row['discount_amount'] as num?)?.toDouble() ?? 0,
        discountType: row['discount_type'] as String? ?? 'none',
        discountValue: (row['discount_value'] as num?)?.toDouble() ?? 0,
        items: row['items'] as int? ?? 0,
        date: DateTime.parse(row['created_at'] as String),
        saleItems: itemsMap[id] ?? [],
        cashierName: row['cashier_name'] as String?,
        cashierUserId: row['cashier_user_id'] as String?,
        sessionId: row['session_id'] as String?,
        invoiceTypeIndex: (row['invoice_type_index'] as int?) ?? 0,
        refundOriginalInvoiceId: row['refund_original_invoice_id'] as String?,
        paymentMethod: row['payment_method'] as String? ?? 'cash',
        notes: row['notes'] as String?,
      );
    }).toList();
  }

  @override
  Future<Either<Failure, List<Sale>>> getRecentSales({
    int limit = 10,
    DateTime? startDate,
    DateTime? endDate,
    String? sessionId,
  }) async {
    try {
      var query = _supabaseService.from('sales').select();

      final branchId = getIt<BranchCubit>().effectiveBranchId;
      if (branchId != null) {
        query = query.eq('branch_id', branchId);
      }

      if (startDate != null) {
        query = query.gte('created_at', _databaseTimestamp(startDate));
      }
      if (endDate != null) {
        query = query.lte('created_at', _databaseTimestamp(endDate));
      }
      if (sessionId != null) {
        query = query.eq('session_id', sessionId);
      }

      final response =
          await query.order('created_at', ascending: false).limit(limit);

      final sales = await _getSalesWithItems(
          (response as List).cast<Map<String, dynamic>>());
      return Right(sales);
    } catch (e) {
      return Left(CacheFailure('Error fetching recent sales: ${e.toString()}'));
    }
  }

  @override
  Future<Either<Failure, Unit>> updateProductQuantity(
      String barcode, double newQuantity) async {
    try {
      final branchId = getIt<BranchCubit>().effectiveBranchId;
      if (branchId != null) {
        // Find the product ID from barcode
        final productRow = await _supabaseService
            .from('products')
            .select('id')
            .eq('barcode', barcode)
            .maybeSingle();
        if (productRow != null) {
          final productId = productRow['id'] as String;
          await _supabaseService.from('branch_stock').upsert({
            'branch_id': branchId,
            'product_id': productId,
            'quantity': newQuantity,
          }, onConflict: 'branch_id,product_id');
        }
      } else {
        // Legacy fallback for primary admin with no branch selected
        await _supabaseService
            .from('products')
            .update({'quantity': newQuantity}).eq('barcode', barcode);
      }

      StateSynchronizer.notify(DataChangeEvent(
        entityType: 'product_stock',
        operation: 'update',
        id: barcode,
      ));

      return const Right(unit);
    } catch (e) {
      return Left(CacheFailure('Error updating quantity: ${e.toString()}'));
    }
  }

  @override
  Future<Either<Failure, bool>> validateMinPrice(
      String barcode, double salePrice) async {
    try {
      final response = await _supabaseService
          .from('products')
          .select('price, min_price')
          .eq('barcode', barcode)
          .maybeSingle();

      if (response == null) return const Right(false);
      final minimumPrice = (response['min_price'] as num?)?.toDouble() ?? 0;
      return Right(salePrice >= minimumPrice);
    } catch (e) {
      return Left(CacheFailure('Error checking price: ${e.toString()}'));
    }
  }

  @override
  Future<Either<Failure, Unit>> createSaleWithCashier({
    required List<CartItemModel> items,
    required double total,
    required String cashierName,
    required String cashierUsername,
  }) async {
    return ErrorHandler.executeWithErrorHandling(
      operation: () async {
        final saleId = const Uuid().v4();
        final authUser = Supabase.instance.client.auth.currentUser;
        if (authUser == null) {
          return Left(CacheFailure('An authenticated user is required'));
        }

        final branchId = getIt<BranchCubit>().effectiveBranchId;

        final sale = Sale(
          id: saleId,
          total: total,
          items: items.length,
          date: DateTime.now(),
          cashierName: cashierName,
          cashierUsername: cashierUsername,
          cashierUserId: authUser.id,
          saleItems: items
              .map((item) => SaleItem(
                    productId: item.productId,
                    productBarcode: item.id,
                    name: item.name,
                    price: item.salePrice,
                    quantity: item.qty,
                    total: item.total,
                    wholesalePrice: item.wholesalePrice,
                  ))
              .toList(),
        );

        await _supabaseService.from('sales').insert({
          'id': sale.id,
          'total': sale.total,
          'items': sale.items,
          'created_at': sale.date.toUtc().toIso8601String(),
          'cashier_name': sale.cashierName,
          'cashier_user_id': sale.cashierUserId,
          'invoice_type_index': sale.isRefund ? 1 : 0,
          'payment_method': sale.paymentMethod,
          if (branchId != null) 'branch_id': branchId,
        });

        for (final item in sale.saleItems) {
          await _supabaseService.from('sale_items').insert({
            'sale_id': sale.id,
            'product_id': item.productId,
            'product_barcode': item.productBarcode,
            'name': item.name,
            'quantity': item.quantity,
            'price': item.price,
            'sale_price': item.salePrice == 0 ? item.price : item.salePrice,
            'total': item.total,
            'wholesale_price': item.wholesalePrice,
            'refunded_quantity': 0,
            if (branchId != null) 'branch_id': branchId,
          });
        }

        // Decrement stock from branch_stock
        for (var item in items) {
          if (branchId != null) {
            // Find the product UUID from barcode
            final productRow = await _supabaseService
                .from('products')
                .select('id')
                .eq('barcode', item.id)
                .maybeSingle();
            if (productRow != null) {
              final productId = productRow['id'] as String;
              // Get current branch stock
              final stockRow = await _supabaseService
                  .from('branch_stock')
                  .select('quantity')
                  .eq('branch_id', branchId)
                  .eq('product_id', productId)
                  .maybeSingle();
              final currentStock = stockRow != null
                  ? (stockRow['quantity'] as num).toDouble()
                  : 0.0;
              await _supabaseService.from('branch_stock').upsert({
                'branch_id': branchId,
                'product_id': productId,
                'quantity': currentStock - item.qty,
              }, onConflict: 'branch_id,product_id');
            }
          } else {
            // Legacy fallback: RPC or direct products.stock update
            await _supabaseService.client
                .rpc('decrement_stock', params: {
                  'product_id_input': item.id,
                  'qty_input': item.qty,
                })
                .then((_) {})
                .catchError((_) async {
                  final product = await _supabaseService
                      .from('products')
                      .select('quantity')
                      .eq('barcode', item.id)
                      .single();
                  final currentStock = (product['quantity'] as num).toDouble();
                  await _supabaseService
                      .from('products')
                      .update({'quantity': currentStock - item.qty}).eq(
                          'barcode', item.id);
                });
          }
        }

        StateSynchronizer.notify(DataChangeEvent(
          entityType: 'sale',
          operation: 'create',
          id: saleId,
        ));
        StateSynchronizer.notify(DataChangeEvent(
          entityType: 'product_stock',
          operation: 'update',
        ));

        return const Right(unit);
      },
      operationName: 'createSaleWithCashier',
      userFriendlyMessage: 'Failed to create sale',
      source: 'PosRepository',
    );
  }

  @override
  Future<Either<Failure, Unit>> deleteSalesInRange(
      DateTime start, DateTime end) async {
    try {
      final branchId = getIt<BranchCubit>().effectiveBranchId;
      if (branchId == null) {
        return Left(CacheFailure('Select a branch before deleting invoices'));
      }
      final adjustedStart =
          DateTime(start.year, start.month, start.day, 0, 0, 0);
      final adjustedEnd =
          DateTime(end.year, end.month, end.day, 23, 59, 59, 999);

      var deleteQuery = _supabaseService
          .from('sales')
          .delete()
          .gte('created_at', _databaseTimestamp(adjustedStart))
          .lte('created_at', _databaseTimestamp(adjustedEnd))
          .eq('branch_id', branchId);

      await deleteQuery;

      return const Right(unit);
    } catch (e) {
      return Left(CacheFailure('Error deleting invoices: ${e.toString()}'));
    }
  }

  @override
  Future<Either<Failure, Unit>> deleteSalesByQuery(String query) async {
    try {
      final pattern = '%$query%';
      final branchId = getIt<BranchCubit>().effectiveBranchId;
      if (branchId == null) {
        return Left(CacheFailure('Select a branch before deleting invoices'));
      }

      var saleItemsQuery = _supabaseService
          .from('sale_items')
          .select('sale_id')
          .or('product_barcode.like.$pattern,name.like.$pattern')
          .eq('branch_id', branchId);

      final saleItemsResponse = await saleItemsQuery;

      final saleIds = (saleItemsResponse as List)
          .map((r) => r['sale_id'] as String)
          .toSet()
          .toList();

      var salesQuery = _supabaseService
          .from('sales')
          .select('id')
          .or('id.like.$pattern')
          .eq('branch_id', branchId);

      final salesResponse = await salesQuery.limit(100);

      for (var r in (salesResponse as List)) {
        saleIds.add(r['id'] as String);
      }

      final uniqueIds = saleIds.toSet().toList();
      for (final id in uniqueIds) {
        await deleteSale(id);
      }

      return const Right(unit);
    } catch (e) {
      return Left(
          CacheFailure('Error deleting matching invoices: ${e.toString()}'));
    }
  }

  @override
  Future<Either<Failure, Unit>> deleteSale(String saleId) async {
    try {
      final branchId = getIt<BranchCubit>().effectiveBranchId;
      if (branchId == null) {
        return Left(CacheFailure('Select a branch before deleting an invoice'));
      }
      await _supabaseService
          .from('sale_items')
          .delete()
          .eq('sale_id', saleId)
          .eq('branch_id', branchId);
      await _supabaseService
          .from('sales')
          .delete()
          .eq('id', saleId)
          .eq('branch_id', branchId);
      return const Right(unit);
    } catch (e) {
      return Left(CacheFailure('Error deleting sale: ${e.toString()}'));
    }
  }

  @override
  Future<Either<Failure, List<Sale>>> getAllSales() async {
    try {
      var query = _supabaseService.from('sales').select();

      final branchId = getIt<BranchCubit>().effectiveBranchId;
      if (branchId != null) {
        query = query.eq('branch_id', branchId);
      }

      final response =
          await query.order('created_at', ascending: false).limit(100);

      final sales = await _getSalesWithItems(
          (response as List).cast<Map<String, dynamic>>());
      return Right(sales);
    } catch (e) {
      return Left(CacheFailure('Error fetching sales: ${e.toString()}'));
    }
  }

  @override
  Future<Either<Failure, List<Sale>>> getSalesByIds(List<String> ids) async {
    try {
      if (ids.isEmpty) return const Right([]);

      var query = _supabaseService.from('sales').select().inFilter('id', ids);
      final branchId = getIt<BranchCubit>().effectiveBranchId;
      if (branchId != null) {
        query = query.eq('branch_id', branchId);
      }
      final response = await query;

      final sales = await _getSalesWithItems(
          (response as List).cast<Map<String, dynamic>>());
      return Right(sales);
    } catch (e) {
      return Left(
          CacheFailure('Error fetching selected invoices: ${e.toString()}'));
    }
  }

  @override
  Future<Either<Failure, List<Sale>>> getRefundsForInvoice(
      String originalInvoiceId) async {
    try {
      var query = _supabaseService
          .from('sales')
          .select()
          .eq('refund_original_invoice_id', originalInvoiceId)
          .eq('invoice_type_index', 1);
      final branchId = getIt<BranchCubit>().effectiveBranchId;
      if (branchId != null) {
        query = query.eq('branch_id', branchId);
      }
      final response = await query;

      final sales = await _getSalesWithItems(
          (response as List).cast<Map<String, dynamic>>());
      return Right(sales);
    } catch (e) {
      return Left(CacheFailure('Error fetching refunds: ${e.toString()}'));
    }
  }

  @override
  Future<Either<Failure, Unit>> linkSalesToSession(
      List<String> saleIds, String sessionId) async {
    try {
      if (saleIds.isEmpty) return const Right(unit);

      var query = _supabaseService
          .from('sales')
          .update({'session_id': sessionId}).inFilter('id', saleIds);
      final branchId = getIt<BranchCubit>().effectiveBranchId;
      if (branchId != null) {
        query = query.eq('branch_id', branchId);
      }
      await query;

      return const Right(unit);
    } catch (e) {
      return Left(
          CacheFailure('Error linking invoices to session: ${e.toString()}'));
    }
  }
}
