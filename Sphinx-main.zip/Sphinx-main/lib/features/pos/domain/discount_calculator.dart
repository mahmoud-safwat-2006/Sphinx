import '../data/models/cart_item_model.dart';

enum DiscountValidationError {
  invalidValue,
  invalidPercentage,
  exceedsSubtotal,
  belowMinimumPrice,
}

class DiscountResult {
  final double discountAmount;
  final double total;
  final DiscountValidationError? error;
  final CartItemModel? invalidItem;

  const DiscountResult({
    required this.discountAmount,
    required this.total,
    this.error,
    this.invalidItem,
  });

  bool get isValid => error == null;
}

class DiscountCalculator {
  const DiscountCalculator._();

  static double subtotal(Iterable<CartItemModel> items) =>
      items.fold(0.0, (sum, item) => sum + item.total);

  static DiscountResult validateItemDiscount({
    required CartItemModel item,
    required double value,
    required String type,
  }) {
    final error = _validateInput(value, type);
    if (error != null) {
      return DiscountResult(
        discountAmount: 0,
        total: item.total,
        error: error,
        invalidItem: item,
      );
    }

    final discountPerUnit = type == 'percentage'
        ? item.salePrice * value / 100
        : type == 'fixed'
            ? value
            : 0.0;
    final effectivePrice = item.salePrice - discountPerUnit;
    if (effectivePrice + 0.000001 < item.minPrice) {
      return DiscountResult(
        discountAmount: discountPerUnit * item.qty,
        total: effectivePrice * item.qty,
        error: DiscountValidationError.belowMinimumPrice,
        invalidItem: item,
      );
    }

    return DiscountResult(
      discountAmount: discountPerUnit * item.qty,
      total: effectivePrice * item.qty,
    );
  }

  static DiscountResult validateCartDiscount({
    required List<CartItemModel> items,
    required double value,
    required String type,
  }) {
    final currentSubtotal = subtotal(items);
    final error = _validateInput(value, type);
    if (error != null) {
      return DiscountResult(
        discountAmount: 0,
        total: currentSubtotal,
        error: error,
      );
    }

    final amount = type == 'percentage'
        ? currentSubtotal * value / 100
        : type == 'fixed'
            ? value
            : 0.0;
    if (amount > currentSubtotal + 0.000001) {
      return DiscountResult(
        discountAmount: amount,
        total: currentSubtotal - amount,
        error: DiscountValidationError.exceedsSubtotal,
      );
    }

    final factor = currentSubtotal > 0 ? amount / currentSubtotal : 0.0;
    for (final item in items) {
      final allocatedLineDiscount = item.total * factor;
      final allocatedPerUnit = item.qty > 0
          ? allocatedLineDiscount / item.qty
          : allocatedLineDiscount;
      if (item.discountedPrice - allocatedPerUnit + 0.000001 < item.minPrice) {
        return DiscountResult(
          discountAmount: amount,
          total: currentSubtotal - amount,
          error: DiscountValidationError.belowMinimumPrice,
          invalidItem: item,
        );
      }
    }

    return DiscountResult(
      discountAmount: amount,
      total: currentSubtotal - amount,
    );
  }

  static DiscountValidationError? _validateInput(double value, String type) {
    if (!value.isFinite || value < 0) {
      return DiscountValidationError.invalidValue;
    }
    if (type == 'percentage' && value > 100) {
      return DiscountValidationError.invalidPercentage;
    }
    return null;
  }
}
