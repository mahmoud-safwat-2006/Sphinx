import 'package:flutter/material.dart';
import 'package:sphinx/l10n/app_localizations.dart';
import '../../../../core/constants/app_colors.dart';

class TotalSectionCard extends StatefulWidget {
  final double totalAmount;
  final int itemCount;
  final VoidCallback? onCheckout;
  final VoidCallback? onClearCart;
  final VoidCallback? onDiscount;
  final bool compact;

  const TotalSectionCard({
    super.key,
    required this.totalAmount,
    required this.itemCount,
    this.onCheckout,
    this.onClearCart,
    this.onDiscount,
    this.compact = false,
  });

  @override
  State<TotalSectionCard> createState() => _TotalSectionCardState();
}

class _TotalSectionCardState extends State<TotalSectionCard> {
  bool _isHoveringCheckout = false;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final isCheckoutEnabled = widget.onCheckout != null;
    final isMobile = widget.compact || MediaQuery.of(context).size.width < 768;

    if (isMobile) {
      return _buildMobile(l10n, isCheckoutEnabled);
    }

    return _buildDesktop(l10n, isCheckoutEnabled);
  }

  Widget _buildMobile(AppLocalizations l10n, bool isCheckoutEnabled) {
    final formattedTotal = l10n.priceWithCurrency(
      widget.totalAmount.toStringAsFixed(2),
      l10n.currencyEg,
    );
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.borderColor),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.08),
            blurRadius: 16,
            offset: const Offset(0, -3),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                l10n.subtotalLabel,
                style: const TextStyle(
                  color: AppColors.mutedColor,
                  fontSize: 12,
                ),
              ),
              Text(
                formattedTotal,
                style: const TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          const SizedBox(height: 7),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                l10n.itemCountLabel,
                style: const TextStyle(
                  color: AppColors.mutedColor,
                  fontSize: 12,
                ),
              ),
              Text(
                l10n.itemCountValue(widget.itemCount),
                style: const TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 10),
            child: Divider(height: 1, color: AppColors.borderColor),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                l10n.grandTotalLabel,
                style: const TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                ),
              ),
              Text(
                formattedTotal,
                style: TextStyle(
                  color: AppColors.primaryColor,
                  fontSize: 23,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: SizedBox(
                  height: 52,
                  child: OutlinedButton.icon(
                    onPressed: widget.onDiscount,
                    icon: const Icon(Icons.percent_rounded, size: 18),
                    label: Text(l10n.discountButtonLabel),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.primaryColor,
                      side: const BorderSide(color: AppColors.borderColor),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                flex: 2,
                child: SizedBox(
                  height: 52,
                  child: ElevatedButton.icon(
                    onPressed: widget.onCheckout,
                    icon: const Icon(Icons.credit_card_rounded, size: 20),
                    label: Text(
                      l10n.checkoutBtn,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: isCheckoutEnabled
                          ? AppColors.kSuccessGreen
                          : AppColors.surfaceColor,
                      foregroundColor: isCheckoutEnabled
                          ? Colors.white
                          : AppColors.mutedColor,
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildDesktop(AppLocalizations l10n, bool isCheckoutEnabled) {
    return TweenAnimationBuilder<double>(
      duration: const Duration(milliseconds: 600),
      tween: Tween(begin: 0.0, end: 1.0),
      curve: Curves.easeOutCubic,
      builder: (context, value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, 15 * (1 - value)),
            child: child,
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: AppColors.kCardBackground,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.borderColor, width: 1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.03),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Icon(
                  Icons.receipt_long_rounded,
                  color: AppColors.primaryColor,
                  size: 20,
                ),
                const SizedBox(width: 8),
                Text(
                  l10n.invoiceSummaryTitle,
                  style: const TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  l10n.itemCountLabel,
                  style: TextStyle(
                    color: AppColors.mutedColor,
                    fontSize: 13,
                  ),
                ),
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 200),
                  child: Text(
                    l10n.itemCountValue(widget.itemCount),
                    key: ValueKey('cnt_${widget.itemCount}'),
                    style: const TextStyle(
                      color: AppColors.textPrimary,
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  l10n.subtotalLabel,
                  style: TextStyle(
                    color: AppColors.mutedColor,
                    fontSize: 13,
                  ),
                ),
                Text(
                  l10n.priceWithCurrency(
                      widget.totalAmount.toStringAsFixed(2), l10n.currencyEg),
                  style: const TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: Divider(color: AppColors.borderColor.withOpacity(0.6)),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  l10n.grandTotalLabel,
                  style: const TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 250),
                  transitionBuilder: (child, anim) => SlideTransition(
                    position: Tween<Offset>(
                      begin: const Offset(0, 0.2),
                      end: Offset.zero,
                    ).animate(anim),
                    child: FadeTransition(opacity: anim, child: child),
                  ),
                  child: Text(
                    l10n.priceWithCurrency(
                        widget.totalAmount.toStringAsFixed(2), l10n.currencyEg),
                    key: ValueKey('total_${widget.totalAmount}'),
                    style: TextStyle(
                      color: AppColors.primaryColor,
                      fontSize: 23,
                      fontWeight: FontWeight.w900,
                      letterSpacing: .3,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            MouseRegion(
              onEnter: (_) => setState(() => _isHoveringCheckout = true),
              onExit: (_) => setState(() => _isHoveringCheckout = false),
              child: AnimatedScale(
                scale: (_isHoveringCheckout && isCheckoutEnabled) ? 1.02 : 1.0,
                duration: const Duration(milliseconds: 150),
                child: Container(
                  height: 48,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    gradient: isCheckoutEnabled
                        ? LinearGradient(
                            colors: [
                              AppColors.kSuccessGreen,
                              AppColors.kSuccessGreen.withOpacity(0.85),
                            ],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          )
                        : null,
                    color: isCheckoutEnabled ? null : AppColors.surfaceColor,
                    boxShadow: isCheckoutEnabled
                        ? [
                            BoxShadow(
                              color: AppColors.kSuccessGreen.withOpacity(0.3),
                              blurRadius: 10,
                              offset: const Offset(0, 4),
                            )
                          ]
                        : null,
                  ),
                  child: ElevatedButton.icon(
                    onPressed: widget.onCheckout,
                    icon: const Icon(Icons.check_circle_rounded, size: 20),
                    label: Text(
                      l10n.checkoutBtn,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.transparent,
                      foregroundColor: isCheckoutEnabled
                          ? Colors.white
                          : AppColors.mutedColor,
                      shadowColor: Colors.transparent,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: widget.onDiscount,
                    icon: const Icon(Icons.percent_rounded, size: 16),
                    label: Text(l10n.discountButtonLabel,
                        style: const TextStyle(fontSize: 13)),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.primaryColor,
                      side: BorderSide(
                        color: AppColors.primaryColor.withOpacity(0.5),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: widget.onClearCart,
                    icon: const Icon(Icons.delete_outline_rounded, size: 16),
                    label: Text(
                      l10n.clearCartBtn,
                      style: const TextStyle(fontSize: 13),
                    ),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.kDangerRed,
                      side: BorderSide(
                        color: AppColors.kDangerRed.withOpacity(0.5),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
