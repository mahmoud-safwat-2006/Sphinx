import 'package:flutter/material.dart';
import 'package:sphinx/l10n/app_localizations.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/components/local_image_view.dart';
import '../../../products/data/models/product_model.dart';

class ProductSearchOverlay extends StatelessWidget {
  final List<Product> products;
  final List<Product>? allProducts;
  final Function(Product) onProductSelected;

  const ProductSearchOverlay({
    super.key,
    required this.products,
    required this.onProductSelected,
    this.allProducts,
  });

  @override
  Widget build(BuildContext context) {
    if (products.isEmpty) return const SizedBox.shrink();

    return TweenAnimationBuilder<double>(
      duration: const Duration(milliseconds: 200),
      tween: Tween(begin: 0.0, end: 1.0),
      curve: Curves.easeOutCubic,
      builder: (context, value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, 8 * (1 - value)),
            child: child,
          ),
        );
      },
      child: Container(
        margin: const EdgeInsets.only(top: 6),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.12),
              blurRadius: 24,
              offset: const Offset(0, 10),
            ),
          ],
          border: Border.all(color: AppColors.borderColor, width: 1),
        ),
        constraints: const BoxConstraints(maxHeight: 320),
        child: Material(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(14),
          clipBehavior: Clip.antiAlias,
          child: ListView.separated(
            shrinkWrap: true,
            padding: const EdgeInsets.symmetric(vertical: 6),
            itemCount: products.length,
            separatorBuilder: (context, index) =>
                Divider(color: AppColors.borderColor.withOpacity(0.5), height: 1),
            itemBuilder: (context, index) {
              final product = products[index];
              final List<Product> similar = [];
              if (allProducts != null && allProducts!.isNotEmpty) {
                final prefix = product.name.length >= 3
                    ? product.name.substring(0, 3).toLowerCase()
                    : product.name.toLowerCase();
                for (final other in allProducts!) {
                  if (other.barcode == product.barcode) continue;
                  if ((other.category).isNotEmpty &&
                      other.category == product.category) {
                    similar.add(other);
                    continue;
                  }
                  if (other.name.toLowerCase().contains(prefix)) {
                    similar.add(other);
                    continue;
                  }
                }
              }

              return Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  ListTile(
                    contentPadding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    leading: LocalImageView(
                      path: product.imagePath,
                      width: 42,
                      height: 42,
                      borderRadius: 10,
                      fallback: Container(
                        decoration: BoxDecoration(
                          color: AppColors.primaryColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        alignment: Alignment.center,
                        child: Icon(Icons.inventory_2_outlined,
                            color: AppColors.primaryColor, size: 20),
                      ),
                    ),
                    title: Text(
                      product.name,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: product.quantity <= 0 ? Colors.grey : AppColors.textPrimary,
                        decoration: product.quantity <= 0 ? TextDecoration.lineThrough : null,
                      ),
                    ),
                    subtitle: Text(
                      '${product.barcode} · ${product.category}',
                      style: TextStyle(color: AppColors.mutedColor, fontSize: 12),
                    ),
                    trailing: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          '${product.price.toStringAsFixed(2)} ${AppLocalizations.of(context).currencyEg}',
                          style: TextStyle(
                            color: AppColors.primaryColor,
                            fontWeight: FontWeight.w800,
                            fontSize: 13,
                          ),
                        ),
                        Text(
                          AppLocalizations.of(context).stockLabel(product.quantity),
                          style: TextStyle(
                            color: product.quantity <= (product.minQuantity)
                                ? AppColors.kDangerRed
                                : AppColors.kSuccessGreen,
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    enabled: product.quantity > 0,
                    onTap: product.quantity > 0 ? () => onProductSelected(product) : null,
                  ),
                  if (similar.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(
                          left: 68.0, right: 12.0, bottom: 8.0),
                      child: Wrap(
                        spacing: 6,
                        runSpacing: 4,
                        children: similar.take(3).map((sp) {
                          return ActionChip(
                            padding: EdgeInsets.zero,
                            labelStyle: const TextStyle(fontSize: 11),
                            label: Text('${sp.name} · ${sp.price.toStringAsFixed(0)} EGP'),
                            onPressed: () => onProductSelected(sp),
                          );
                        }).toList(),
                      ),
                    ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}
