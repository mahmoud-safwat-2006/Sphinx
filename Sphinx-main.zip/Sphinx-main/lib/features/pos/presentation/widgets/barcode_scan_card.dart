import 'package:flutter/material.dart';
import 'package:sphinx/l10n/app_localizations.dart';
import '../../../../core/constants/app_colors.dart';

class BarcodeScanCard extends StatefulWidget {
  final TextEditingController? controller;
  final FocusNode? focusNode;
  final Function(String)? onSubmitted;
  final Function(String)? onChanged;
  final VoidCallback? onCameraScan;
  final bool compact;

  const BarcodeScanCard({
    super.key,
    this.controller,
    this.focusNode,
    this.onSubmitted,
    this.onChanged,
    this.onCameraScan,
    this.compact = false,
  });

  @override
  State<BarcodeScanCard> createState() => _BarcodeScanCardState();
}

class _BarcodeScanCardState extends State<BarcodeScanCard> {
  late final FocusNode _internalFocusNode;
  bool _isFocused = false;
  bool _isHoveringCamera = false;

  FocusNode get _effectiveFocusNode => widget.focusNode ?? _internalFocusNode;

  @override
  void initState() {
    super.initState();
    _internalFocusNode = FocusNode();
    _effectiveFocusNode.addListener(_onFocusChange);
  }

  void _onFocusChange() {
    if (mounted) {
      setState(() {
        _isFocused = _effectiveFocusNode.hasFocus;
      });
    }
  }

  @override
  void dispose() {
    _effectiveFocusNode.removeListener(_onFocusChange);
    if (widget.focusNode == null) {
      _internalFocusNode.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    if (widget.compact) {
      return Container(
        height: 58,
        padding: const EdgeInsetsDirectional.only(start: 6, end: 4),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(13),
          border: Border.all(
            color: _isFocused ? AppColors.primaryColor : AppColors.borderColor,
            width: _isFocused ? 1.6 : 1,
          ),
        ),
        child: Row(
          children: [
            SizedBox(
              width: 48,
              height: 48,
              child: IconButton(
                tooltip: l10n.scanWithCamera,
                onPressed: widget.onCameraScan,
                icon: const Icon(Icons.qr_code_scanner_rounded),
                color: AppColors.primaryColor,
              ),
            ),
            Container(width: 1, height: 32, color: AppColors.borderColor),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: widget.controller,
                focusNode: _effectiveFocusNode,
                autofocus: true,
                onChanged: widget.onChanged,
                onSubmitted: widget.onSubmitted,
                textInputAction: TextInputAction.done,
                style: const TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
                decoration: InputDecoration(
                  hintText: l10n.barcodeScanHint,
                  hintStyle: const TextStyle(
                    color: AppColors.mutedColor,
                    fontSize: 13,
                  ),
                  border: InputBorder.none,
                ),
              ),
            ),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 10),
              child: Icon(
                Icons.search_rounded,
                color: AppColors.mutedColor,
                size: 22,
              ),
            ),
          ],
        ),
      );
    }
    return TweenAnimationBuilder<double>(
      duration: const Duration(milliseconds: 600),
      tween: Tween(begin: 0.0, end: 1.0),
      curve: Curves.easeOutCubic,
      builder: (context, value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, 15 * (1 - value)),
            child: child,
          ),
        );
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 18),
        decoration: BoxDecoration(
          color: AppColors.kCardBackground,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: _isFocused
                ? AppColors.primaryColor
                : AppColors.primaryColor.withOpacity(0.5),
            width: _isFocused ? 1.8 : 1.2,
          ),
          boxShadow: [
            BoxShadow(
              color: _isFocused
                  ? AppColors.primaryColor.withOpacity(0.12)
                  : AppColors.primaryColor.withOpacity(0.06),
              blurRadius: _isFocused ? 16 : 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: _isFocused
                    ? AppColors.primaryColor
                    : AppColors.primaryColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                Icons.qr_code_scanner_rounded,
                color: _isFocused ? Colors.white : AppColors.primaryColor,
                size: 22,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: TextField(
                controller: widget.controller,
                focusNode: _effectiveFocusNode,
                autofocus: true,
                onChanged: widget.onChanged,
                onSubmitted: widget.onSubmitted,
                textInputAction: TextInputAction.done,
                style: const TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 15,
                  fontWeight: FontWeight.w500,
                ),
                decoration: InputDecoration(
                  hintText: l10n.barcodeScanHint,
                  hintStyle: TextStyle(
                    color: AppColors.mutedColor.withOpacity(0.8),
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                  ),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(vertical: 14),
                ),
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: _isFocused
                    ? AppColors.primaryColor.withOpacity(0.1)
                    : const Color(0xFFF1F5F9),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.qr_code_2_rounded,
                    size: 14,
                    color: _isFocused
                        ? AppColors.primaryColor
                        : AppColors.mutedColor,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    l10n.barcodeQrLabel,
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      color: _isFocused
                          ? AppColors.primaryColor
                          : AppColors.mutedColor,
                    ),
                  ),
                ],
              ),
            ),
            if (widget.onCameraScan != null) ...[
              const SizedBox(width: 8),
              MouseRegion(
                onEnter: (_) => setState(() => _isHoveringCamera = true),
                onExit: (_) => setState(() => _isHoveringCamera = false),
                child: AnimatedScale(
                  scale: _isHoveringCamera ? 1.1 : 1.0,
                  duration: const Duration(milliseconds: 150),
                  child: IconButton(
                    tooltip: l10n.scanWithCamera,
                    onPressed: widget.onCameraScan,
                    icon: const Icon(Icons.photo_camera_rounded),
                    color: _isHoveringCamera
                        ? AppColors.primaryColor
                        : AppColors.mutedColor,
                    splashRadius: 22,
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
