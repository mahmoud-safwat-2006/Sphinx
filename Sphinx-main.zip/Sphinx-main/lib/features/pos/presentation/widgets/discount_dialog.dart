import 'package:sphinx/l10n/app_localizations.dart';
import 'package:flutter/material.dart';

class DiscountDialog extends StatefulWidget {
  final String productName;
  final double currentPrice;
  final double minPrice;
  final String currentType;
  final double currentValue;

  const DiscountDialog({
    super.key,
    required this.productName,
    required this.currentPrice,
    required this.minPrice,
    this.currentType = 'none',
    this.currentValue = 0,
  });

  @override
  State<DiscountDialog> createState() => _DiscountDialogState();
}

class _DiscountDialogState extends State<DiscountDialog> {
  String _discountType = 'none';
  final TextEditingController _amountController = TextEditingController();
  double _previewPrice = 0;

  @override
  void initState() {
    super.initState();
    _discountType = widget.currentType;
    if (widget.currentValue > 0) {
      _amountController.text = _discountType == 'percentage'
          ? widget.currentValue.toStringAsFixed(0)
          : widget.currentValue.toStringAsFixed(2);
    }
    _updatePreview();
  }

  void _updatePreview() {
    final amount = double.tryParse(_amountController.text) ?? 0;
    double discount = 0;

    if (_discountType == 'percentage') {
      discount = widget.currentPrice * (amount / 100);
    } else {
      discount = amount;
    }

    final finalPrice = widget.currentPrice - discount;
    setState(() {
      _previewPrice = finalPrice < widget.minPrice ? widget.minPrice : finalPrice;
    });
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final currency = l10n.currencyEg;

    return AlertDialog(
      title: Text(l10n.discountDialogTitle(widget.productName)),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(l10n.originalPriceLabel(widget.currentPrice.toStringAsFixed(2), currency)),
          const SizedBox(height: 8),
          Text(
            l10n.minPriceLabelDiscount(widget.minPrice.toStringAsFixed(2), currency),
            style: const TextStyle(color: Colors.grey),
          ),
          const SizedBox(height: 16),

          // Discount Type
          SegmentedButton<String>(
            segments: [
              ButtonSegment(value: 'none', label: Text(l10n.discountNone)),
              ButtonSegment(value: 'fixed', label: Text(l10n.discountFixed)),
              ButtonSegment(value: 'percentage', label: Text(l10n.discountPercent)),
            ],
            selected: {_discountType},
            onSelectionChanged: (Set<String> selected) {
              setState(() {
                _discountType = selected.first;
                _updatePreview();
              });
            },
          ),

          const SizedBox(height: 16),

          // Amount Input
          if (_discountType != 'none')
            TextField(
              controller: _amountController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: _discountType == 'percentage'
                    ? l10n.percentageLabel
                    : l10n.fixedAmountLabel(currency),
                suffixText: _discountType == 'percentage' ? '%' : currency,
              ),
              onChanged: (_) => _updatePreview(),
            ),

          const SizedBox(height: 16),

          // Preview
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _previewPrice < widget.currentPrice
                  ? Colors.green.shade50
                  : Colors.grey.shade100,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(l10n.finalPriceLabel),
                Text(
                  '${_previewPrice.toStringAsFixed(2)} $currency',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: _previewPrice < widget.currentPrice ? Colors.green : null,
                  ),
                ),
              ],
            ),
          ),

          if (_previewPrice == widget.minPrice && _previewPrice < widget.currentPrice)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(
                l10n.atMinimumPriceLabel,
                style: const TextStyle(color: Colors.orange, fontSize: 12),
              ),
            ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.of(context).pop({'type': 'none', 'value': 0.0});
          },
          child: Text(l10n.removeDiscountLabel),
        ),
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: Text(l10n.cancelBtn),
        ),
        ElevatedButton(
          onPressed: () {
            final amount = double.tryParse(_amountController.text) ?? 0;
            Navigator.of(context).pop({
              'type': _discountType,
              'value': amount,
            });
          },
          child: Text(l10n.applyLabel),
        ),
      ],
    );
  }

  @override
  void dispose() {
    _amountController.dispose();
    super.dispose();
  }
}
