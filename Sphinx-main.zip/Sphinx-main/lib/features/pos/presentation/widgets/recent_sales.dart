import 'package:flutter/material.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'package:intl/intl.dart';
import '../../../../core/constants/app_colors.dart';
import 'package:sphinx/l10n/app_localizations.dart';

class RecentSalesSection extends StatelessWidget {
  final List<Map<String, dynamic>> recentSales;
  final VoidCallback? onToggleCollapse;

  const RecentSalesSection({
    super.key,
    required this.recentSales,
    this.onToggleCollapse,
  });

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return TweenAnimationBuilder<double>(
      duration: const Duration(milliseconds: 600),
      tween: Tween(begin: 0.0, end: 1.0),
      curve: Curves.easeOutCubic,
      builder: (context, value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, 15 * (1 - value)),
            child: child,
          ),
        );
      },
      child: Container(
        height: double.infinity,
        constraints: const BoxConstraints(minHeight: 320),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: AppColors.kCardBackground,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.borderColor, width: 1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.03),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppColors.primaryColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(
                    LucideIcons.history,
                    color: AppColors.primaryColor,
                    size: 18,
                  ),
                ),
                const SizedBox(width: 12),
                Text(
                  l10n.recentSalesTitle,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: AppColors.textPrimary,
                  ),
                ),
                const Spacer(),
                if (onToggleCollapse != null)
                  IconButton(
                    icon: Transform.flip(
                      flipX: l10n.localeName == 'ar',
                      child: const Icon(
                        LucideIcons.chevronRight,
                        color: AppColors.primaryColor,
                        size: 20,
                      ),
                    ),
                    tooltip: l10n.hideRecentSales,
                    onPressed: onToggleCollapse,
                  ),
              ],
            ),
            const SizedBox(height: 16),
            Expanded(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 300),
                child: recentSales.isEmpty
                    ? _buildEmptyState(context)
                    : ListView.separated(
                        key: const ValueKey('recent_sales_list'),
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        itemCount: recentSales.length,
                        separatorBuilder: (_, __) => Divider(
                          height: 16,
                          color: AppColors.borderColor.withOpacity(0.4),
                        ),
                        itemBuilder: (context, index) {
                          final sale = recentSales[index];
                          final date = sale['date'] as DateTime;
                          return _RecentSaleRowItem(
                            sale: sale,
                            date: date,
                          );
                        },
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return Center(
      key: const ValueKey('recent_sales_empty'),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: AppColors.surfaceColor,
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.receipt_long_outlined,
              size: 40,
              color: AppColors.mutedColor.withOpacity(0.6),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            l10n.noSales,
            style: TextStyle(
              color: AppColors.mutedColor,
              fontWeight: FontWeight.w600,
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }
}

class _RecentSaleRowItem extends StatefulWidget {
  final Map<String, dynamic> sale;
  final DateTime date;

  const _RecentSaleRowItem({
    required this.sale,
    required this.date,
  });

  @override
  State<_RecentSaleRowItem> createState() => _RecentSaleRowItemState();
}

class _RecentSaleRowItemState extends State<_RecentSaleRowItem> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final isRefund = widget.sale['isRefund'] == true;
    final color = isRefund ? AppColors.warningColor : AppColors.kSuccessGreen;
    final icon = isRefund ? LucideIcons.cornerUpLeft : LucideIcons.shoppingBag;
    final timeFormat = DateFormat('hh:mm a');

    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
        decoration: BoxDecoration(
          color: _isHovered
              ? color.withOpacity(0.06)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                icon,
                color: color,
                size: 16,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    isRefund ? l10n.refundProcess : l10n.saleProcess,
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 13,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    l10n.saleItemsSummary(
                        widget.sale['items'],
                        (widget.sale['total'] as num).toStringAsFixed(0),
                        l10n.currencyEg),
                    style: TextStyle(
                      fontSize: 12,
                      color: color,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            Text(
              timeFormat.format(widget.date),
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: AppColors.mutedColor,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
