import 'package:flutter/material.dart';
import 'package:sphinx/l10n/app_localizations.dart';
import '../../../../core/constants/app_colors.dart';
import 'cart_item.dart';

class CartSection extends StatelessWidget {
  final List<Map<String, dynamic>> cartItems;
  final Function(int)? onRemoveItem;
  final Function(int)? onIncreaseQty;
  final Function(int)? onDecreaseQty;
  final Function(int, double)? onEditPrice;
  final Function(int)? onEditQuantity;
  final Function(int)? onDiscount;
  final VoidCallback? onClearCart;
  final bool compact;

  const CartSection({
    super.key,
    required this.cartItems,
    this.onRemoveItem,
    this.onIncreaseQty,
    this.onDecreaseQty,
    this.onEditPrice,
    this.onEditQuantity,
    this.onDiscount,
    this.onClearCart,
    this.compact = false,
  });

  double _calculateRemainingQuantity(Map<String, dynamic> item) {
    final quantityInStock = (item['quantity'] as num?)?.toDouble() ?? 0;
    final currentQuantityInCart = (item['qty'] as num?)?.toDouble() ?? 0;
    return quantityInStock - currentQuantityInCart;
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final isMobile = compact || MediaQuery.of(context).size.width < 768;
    return TweenAnimationBuilder<double>(
      duration: const Duration(milliseconds: 700),
      tween: Tween(begin: 0.0, end: 1.0),
      curve: Curves.easeOutCubic,
      builder: (context, value, child) {
        return Opacity(
          opacity: value,
          child: Transform.scale(
            scale: 0.98 + (0.02 * value),
            child: child,
          ),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.kCardBackground,
          borderRadius: BorderRadius.circular(isMobile ? 10 : 16),
          border: Border.all(color: AppColors.borderColor, width: 1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 14,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          children: [
            if (isMobile)
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                child: Row(
                  children: [
                    Icon(Icons.shopping_cart_outlined,
                        color: AppColors.primaryColor, size: 21),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        l10n.cartProductList +
                            ' (' +
                            l10n.itemCountValue(cartItems.length) +
                            ')',
                        style: const TextStyle(
                          color: AppColors.textPrimary,
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    IconButton(
                      tooltip: l10n.clearCartBtn,
                      onPressed: cartItems.isEmpty ? null : onClearCart,
                      icon: const Icon(Icons.delete_outline_rounded),
                      color: AppColors.errorColor,
                      constraints: const BoxConstraints(
                        minWidth: 44,
                        minHeight: 44,
                      ),
                    ),
                  ],
                ),
              ),
            if (!isMobile)
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: AppColors.primaryColor.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(
                        Icons.shopping_bag_outlined,
                        color: AppColors.primaryColor,
                        size: 22,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      l10n.cartProductList,
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                            color: AppColors.secondaryColor,
                            fontSize: 16,
                          ),
                    ),
                    const SizedBox(width: 10),
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 250),
                      transitionBuilder: (child, anim) => ScaleTransition(
                        scale: anim,
                        child: child,
                      ),
                      child: Container(
                        key: ValueKey(cartItems.length),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: cartItems.isEmpty
                              ? AppColors.surfaceColor
                              : AppColors.primaryColor.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          '${cartItems.length}',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 13,
                            color: cartItems.isEmpty
                                ? AppColors.mutedColor
                                : AppColors.primaryColor,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            if (!isMobile)
              Divider(height: 1, color: AppColors.borderColor.withOpacity(0.6)),
            Expanded(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 300),
                child: cartItems.isEmpty
                    ? _buildEmptyState(context)
                    : ListView.separated(
                        key: const ValueKey('cart_list'),
                        padding: const EdgeInsets.symmetric(vertical: 6),
                        itemCount: cartItems.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 2),
                        itemBuilder: (context, index) {
                          final item = cartItems[index];
                          return CartItemRow(
                            key: ValueKey(item['id'] ?? index),
                            name: item['name'],
                            id: item['id'],
                            price: item['price'],
                            quantity: item['qty'],
                            remainingQuantity:
                                _calculateRemainingQuantity(item),
                            date: item['date'],
                            minPrice: item['minPrice'] ?? 0.0,
                            unitAbbreviation:
                                item['unitAbbreviation'] as String?,
                            imagePath: item['imagePath'] as String?,
                            compact: compact,
                            onRemove: () => onRemoveItem?.call(index),
                            onIncrease: () => onIncreaseQty?.call(index),
                            onDecrease: () => onDecreaseQty?.call(index),
                            onEditPrice: (newPrice) =>
                                onEditPrice?.call(index, newPrice),
                            onEditQuantity: () => onEditQuantity?.call(index),
                            onDiscount: () => onDiscount?.call(index),
                          );
                        },
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return Center(
      key: const ValueKey('cart_empty'),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TweenAnimationBuilder<double>(
              duration: const Duration(milliseconds: 1200),
              tween: Tween(begin: 0.0, end: 1.0),
              curve: Curves.elasticOut,
              builder: (context, val, child) {
                return Transform.scale(
                  scale: val,
                  child: child,
                );
              },
              child: Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: AppColors.primaryColor.withOpacity(0.06),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.shopping_cart_outlined,
                  size: 56,
                  color: AppColors.primaryColor.withOpacity(0.6),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              l10n.cartEmptyTitle,
              style: TextStyle(
                color: AppColors.secondaryColor,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              l10n.cartEmptySubtitle,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: AppColors.mutedColor.withOpacity(0.8),
                fontSize: 13,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
