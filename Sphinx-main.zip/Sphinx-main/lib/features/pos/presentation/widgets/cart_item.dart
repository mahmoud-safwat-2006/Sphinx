import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sphinx/l10n/app_localizations.dart';
import '../../../../core/localization/product_unit_localizer.dart';
import '../../../../core/components/local_image_view.dart';
import '../../../../core/constants/app_colors.dart';

class CartItemRow extends StatefulWidget {
  final String name;
  final String id;
  final double price;
  final double quantity;
  final double remainingQuantity;
  final DateTime date;
  final double minPrice;
  final String? unitAbbreviation;
  final String? imagePath;
  final bool compact;
  final VoidCallback? onRemove;
  final VoidCallback? onIncrease;
  final VoidCallback? onDecrease;
  final Function(double)? onEditPrice;
  final VoidCallback? onEditQuantity;
  final VoidCallback? onDiscount;

  const CartItemRow({
    super.key,
    required this.name,
    required this.id,
    required this.price,
    required this.quantity,
    required this.remainingQuantity,
    required this.date,
    required this.minPrice,
    this.unitAbbreviation,
    this.imagePath,
    this.compact = false,
    this.onRemove,
    this.onIncrease,
    this.onDecrease,
    this.onEditPrice,
    this.onEditQuantity,
    this.onDiscount,
  });

  @override
  State<CartItemRow> createState() => _CartItemRowState();
}

class _CartItemRowState extends State<CartItemRow> {
  late TextEditingController _priceController;
  bool _isHovered = false;

  @override
  void initState() {
    super.initState();
    _priceController =
        TextEditingController(text: widget.price.toStringAsFixed(2));
  }

  @override
  void dispose() {
    _priceController.dispose();
    super.dispose();
  }

  Future<void> _showEditPriceDialog() async {
    _priceController.text = widget.price.toStringAsFixed(2);

    await showDialog<void>(
      context: context,
      builder: (context) {
        final l10n = AppLocalizations.of(context);
        return AlertDialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: Text(l10n.editPriceTitle,
              style: const TextStyle(fontWeight: FontWeight.bold)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: AppColors.warningColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  l10n.minPriceLabel(
                      widget.minPrice.toStringAsFixed(2), l10n.currencyEg),
                  style: TextStyle(
                    color: AppColors.warningColor,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _priceController,
                autofocus: true,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,2}$')),
                ],
                decoration: InputDecoration(
                  labelText: l10n.newPriceLabel,
                  suffixText: l10n.currencyEg,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  filled: true,
                  fillColor: AppColors.surfaceColor,
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(l10n.cancelBtn),
            ),
            ElevatedButton(
              onPressed: () {
                final newPrice = double.tryParse(_priceController.text);
                if (newPrice != null && newPrice >= widget.minPrice) {
                  widget.onEditPrice?.call(newPrice);
                  Navigator.pop(context);
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        l10n.priceValidationError(
                            widget.minPrice.toStringAsFixed(2),
                            l10n.currencyEg),
                      ),
                      backgroundColor: AppColors.kDangerRed,
                    ),
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryColor,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
              ),
              child: Text(l10n.saveBtn,
                  style: const TextStyle(color: Colors.white)),
            ),
          ],
        );
      },
    );
  }

  Color _getRemainingQuantityColor() {
    if (widget.remainingQuantity <= 5) {
      return AppColors.kDangerRed;
    } else if (widget.remainingQuantity <= 20) {
      return AppColors.warningColor;
    } else {
      return AppColors.kSuccessGreen;
    }
  }

  String _formatQty(double qty) => qty == qty.roundToDouble()
      ? qty.toStringAsFixed(0)
      : qty.toStringAsFixed(2);

  @override
  Widget build(BuildContext context) {
    final total = widget.price * widget.quantity;
    final l10n = AppLocalizations.of(context);
    final isMobile = widget.compact || MediaQuery.of(context).size.width < 768;

    if (isMobile) {
      return _buildMobile(l10n, total);
    }

    return _buildDesktop(l10n, total);
  }

  Widget _buildMobile(AppLocalizations l10n, double total) {
    final unit = ProductUnitLocalizer.abbreviation(
      l10n,
      widget.unitAbbreviation,
    );
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: AppColors.kCardBackground,
        border: Border(
          bottom: BorderSide(color: AppColors.borderColor.withOpacity(.65)),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          LocalImageView(
            path: widget.imagePath,
            width: 72,
            height: 78,
            borderRadius: 12,
            fallback: Container(
              color: AppColors.primaryColor.withOpacity(.06),
              alignment: Alignment.center,
              child: Icon(
                Icons.inventory_2_outlined,
                color: AppColors.primaryColor,
                size: 26,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.name,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 14,
                    height: 1.25,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                if (unit.isNotEmpty) ...[
                  const SizedBox(height: 5),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 7,
                      vertical: 3,
                    ),
                    decoration: BoxDecoration(
                      color: AppColors.primaryColor.withOpacity(.08),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      unit,
                      style: TextStyle(
                        color: AppColors.primaryColor,
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
                const SizedBox(height: 7),
                InkWell(
                  onTap: _showEditPriceDialog,
                  child: Text(
                    l10n.priceWithCurrency(
                      widget.price.toStringAsFixed(2),
                      l10n.currencyEg,
                    ),
                    style: const TextStyle(
                      color: AppColors.textPrimary,
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              IconButton(
                tooltip: l10n.removeButtonLabel,
                icon: const Icon(Icons.delete_outline_rounded, size: 20),
                onPressed: widget.onRemove,
                color: AppColors.kDangerRed,
                constraints: const BoxConstraints(minWidth: 44, minHeight: 44),
                padding: EdgeInsets.zero,
              ),
              Text(
                l10n.priceWithCurrency(
                  total.toStringAsFixed(2),
                  l10n.currencyEg,
                ),
                style: TextStyle(
                  color: AppColors.primaryColor,
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 6),
              Container(
                height: 38,
                decoration: BoxDecoration(
                  border: Border.all(color: AppColors.borderColor),
                  borderRadius: BorderRadius.circular(9),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _buildQtyButton(Icons.remove, widget.onDecrease),
                    InkWell(
                      onTap: widget.onEditQuantity,
                      child: Container(
                        constraints: const BoxConstraints(minWidth: 38),
                        alignment: Alignment.center,
                        child: Text(
                          _formatQty(widget.quantity),
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ),
                    _buildQtyButton(Icons.add, widget.onIncrease),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildDesktop(AppLocalizations l10n, double total) {
    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: _isHovered
              ? AppColors.primaryColor.withOpacity(0.04)
              : AppColors.kCardBackground,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: _isHovered
                ? AppColors.primaryColor.withOpacity(0.3)
                : AppColors.borderColor.withOpacity(0.4),
          ),
        ),
        child: LayoutBuilder(
          builder: (context, constraints) {
            final isWide = constraints.maxWidth > 580;
            return ClipRect(
              child: Row(
                children: [
                  Expanded(
                    flex: isWide ? 4 : 3,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Wrap(
                          spacing: 6,
                          runSpacing: 4,
                          crossAxisAlignment: WrapCrossAlignment.center,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: AppColors.surfaceColor,
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                widget.id,
                                style: TextStyle(
                                  color: AppColors.mutedColor,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                            ConstrainedBox(
                              constraints: BoxConstraints(
                                  maxWidth: constraints.maxWidth * 0.5),
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  color: _getRemainingQuantityColor()
                                      .withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(
                                      Icons.inventory_2_outlined,
                                      size: 11,
                                      color: _getRemainingQuantityColor(),
                                    ),
                                    const SizedBox(width: 4),
                                    Flexible(
                                      child: Text(
                                        l10n.remainingLabel(
                                            widget.remainingQuantity),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          color: _getRemainingQuantityColor(),
                                          fontSize: 11,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  if (isWide) const SizedBox(width: 8),
                  Expanded(
                    flex: isWide ? 2 : 2,
                    child: InkWell(
                      onTap: _showEditPriceDialog,
                      borderRadius: BorderRadius.circular(8),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 6),
                        decoration: BoxDecoration(
                          color: AppColors.surfaceColor,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                              color: AppColors.borderColor.withOpacity(0.6)),
                        ),
                        child: FittedBox(
                          fit: BoxFit.scaleDown,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                l10n.priceWithCurrency(
                                    widget.price.toStringAsFixed(0),
                                    l10n.currencyEg),
                                style: const TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const SizedBox(width: 4),
                              Icon(
                                Icons.edit_rounded,
                                size: 12,
                                color: AppColors.primaryColor,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    flex: isWide ? 3 : 3,
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          _buildQtyButton(Icons.remove, widget.onDecrease),
                          InkWell(
                            onTap: widget.onEditQuantity,
                            borderRadius: BorderRadius.circular(6),
                            child: Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 5),
                              child: Text(
                                _formatQty(widget.quantity),
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 15,
                                ),
                              ),
                            ),
                          ),
                          _buildQtyButton(Icons.add, widget.onIncrease),
                        ],
                      ),
                    ),
                  ),
                  if (isWide) const SizedBox(width: 8),
                  Expanded(
                    flex: isWide ? 2 : 2,
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(
                        l10n.priceWithCurrency(
                            total.toStringAsFixed(0), l10n.currencyEg),
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 14,
                          color: AppColors.primaryColor,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 4),
                  IconButton(
                    tooltip: l10n.discountButtonLabel,
                    icon: const Icon(Icons.percent_rounded, size: 16),
                    onPressed: widget.onDiscount,
                    color: AppColors.primaryColor,
                    splashRadius: 18,
                  ),
                  IconButton(
                    tooltip: l10n.removeButtonLabel,
                    icon: const Icon(Icons.delete_outline_rounded, size: 18),
                    onPressed: widget.onRemove,
                    style: IconButton.styleFrom(
                      backgroundColor: AppColors.kDangerRed.withOpacity(0.1),
                      foregroundColor: AppColors.kDangerRed,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      padding: const EdgeInsets.all(6),
                    ),
                    splashRadius: 18,
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildQtyButton(
    IconData icon,
    VoidCallback? onPressed, {
    bool large = false,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(8),
        child: Container(
          width: large ? 44 : 28,
          height: large ? 44 : 28,
          decoration: BoxDecoration(
            color: AppColors.surfaceColor,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: AppColors.borderColor.withOpacity(0.8)),
          ),
          child: Icon(
            icon,
            size: large ? 18 : 14,
            color: AppColors.secondaryColor,
          ),
        ),
      ),
    );
  }
}
