import 'package:equatable/equatable.dart';
import '../../data/models/cart_item_model.dart';
import '../../data/models/sale_model.dart';

abstract class PosState extends Equatable {
  const PosState();

  @override
  List<Object?> get props => [];
}

class PosInitial extends PosState {}

class PosLoading extends PosState {}

class PosLoaded extends PosState {
  final List<CartItemModel> cartItems;
  final List<Sale> recentSales;
  final double totalAmount;
  final double subtotal;
  final double cartDiscountValue;
  final String cartDiscountType;
  final String? scannerMessage;

  const PosLoaded({
    required this.cartItems,
    required this.recentSales,
    required this.totalAmount,
    this.subtotal = 0,
    this.cartDiscountValue = 0,
    this.cartDiscountType = 'none',
    this.scannerMessage,
  });

  @override
  List<Object?> get props => [cartItems, recentSales, totalAmount, subtotal, cartDiscountValue, cartDiscountType, scannerMessage];
}

class PosError extends PosState {
  final String message;

  const PosError({required this.message});

  @override
  List<Object?> get props => [message];
}

class CheckoutSuccess extends PosState {
  final String message;
  final double total;

  const CheckoutSuccess({
    required this.message,
    required this.total,
  });

  @override
  List<Object?> get props => [message, total];
}

class CheckoutSuccessWithSale extends CheckoutSuccess {
  final Sale sale;

  const CheckoutSuccessWithSale({
    required super.message,
    required super.total,
    required this.sale,
  });

  @override
  List<Object?> get props => [message, total, sale];
}

class PriceValidationError extends PosState {
  final String message;
  final double minPrice;
  final double attemptedPrice;

  const PriceValidationError({
    required this.message,
    required this.minPrice,
    required this.attemptedPrice,
  });

  @override
  List<Object?> get props => [message, minPrice, attemptedPrice];
}
