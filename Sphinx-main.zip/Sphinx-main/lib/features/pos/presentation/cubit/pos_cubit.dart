import 'dart:async';
import 'package:sphinx/core/di/dependency_injection.dart';
import 'package:sphinx/features/auth/presentation/cubit/user_cubit.dart';
import 'package:sphinx/features/branches/presentation/cubit/branch_cubit.dart';
import 'package:sphinx/features/shifts/presentation/cubit/shift_cubit.dart';

import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:uuid/uuid.dart';
import 'package:sphinx/features/notifications/presentation/cubit/notifications_cubit.dart';
import '../../../invoice/presentation/cubit/invoice_cubit.dart';

import '../../../products/data/models/product_model.dart';
import '../../data/models/cart_item_model.dart';
import '../../data/models/sale_model.dart';
import '../../domain/pos_repository.dart';
import '../../domain/discount_calculator.dart';

import 'pos_state.dart';

class PosCubit extends Cubit<PosState> {
  final PosRepository repository;

  PosCubit({required this.repository}) : super(PosInitial());

  // HID buffer for keyboard-wedge scanners
  final StringBuffer _hidBuffer = StringBuffer();
  Timer? _hidTimer;
  bool _barcodeBusy = false;

  // In-memory data exposed via state
  final List<CartItemModel> _cartItems = [];
  List<Sale> _recentSales = [];
  Sale? _lastCompletedSale;

  // Cart-level discount
  double _cartDiscountValue = 0;
  String _cartDiscountType = 'none'; // 'none', 'percentage', 'fixed'

  double get cartDiscountValue => _cartDiscountValue;
  String get cartDiscountType => _cartDiscountType;
  bool get hasCartDiscount =>
      _cartDiscountType != 'none' && _cartDiscountValue > 0;

  void attachHidListener() {
    RawKeyboard.instance.addListener(_onRawKey);
  }

  void detachHidListener() {
    RawKeyboard.instance.removeListener(_onRawKey);
    _hidTimer?.cancel();
  }

  Future<void> load() async {
    emit(PosLoading());
    final recent = await repository.getRecentSales(limit: 10);
    recent.fold(
      (f) => emit(PosError(message: f.message)),
      (list) {
        _recentSales = list;
        _emitLoaded();
      },
    );
  }

  Future<void> reloadForBranchSelection() async {
    _cartItems.clear();
    _recentSales = [];
    _lastCompletedSale = null;
    _cartDiscountValue = 0;
    _cartDiscountType = 'none';
    _emitLoaded();
    await load();
  }

  Future<void> commitBarcode(String code) async {
    final trimmed = code.trim();
    if (trimmed.isEmpty || _barcodeBusy) return;
    _barcodeBusy = true;
    try {
      await _addByBarcode(trimmed);
    } finally {
      _barcodeBusy = false;
    }
  }

  void _onRawKey(RawKeyEvent e) {
    if (e is! RawKeyDownEvent) return;
    if (_editableHasFocus) return;

    if (e.logicalKey == LogicalKeyboardKey.enter ||
        e.logicalKey == LogicalKeyboardKey.numpadEnter) {
      _hidTimer?.cancel();
      final code = _hidBuffer.toString().trim();
      _hidBuffer.clear();
      commitBarcode(code);
      return;
    }

    String? ch = e.character;
    if ((ch == null || ch.isEmpty) && e.logicalKey.keyLabel.length == 1) {
      ch = e.logicalKey.keyLabel;
    }
    if (ch != null && ch.isNotEmpty && ch.codeUnitAt(0) >= 32) {
      _hidBuffer.write(ch);
    }

    _hidTimer?.cancel();
    _hidTimer = Timer(const Duration(milliseconds: 120), () {
      final code = _hidBuffer.toString().trim();
      _hidBuffer.clear();
      commitBarcode(code);
    });
  }

  bool get _editableHasFocus {
    final focusContext = FocusManager.instance.primaryFocus?.context;
    return focusContext?.widget is EditableText;
  }

  Future<void> _addByBarcode(String barcode) async {
    final res = await repository.findProductByBarcode(barcode);
    await res.fold(
      (f) async {
        emit(PosError(message: f.message));
        _emitLoaded();
      },
      (product) async {
        if (product == null) {
          emit(const PosError(message: 'productNotFoundCubit'));
          _emitLoaded();
          return;
        }
        if (product.quantity <= 0) {
          emit(const PosError(message: 'outOfStock'));
          _emitLoaded();
          return;
        }
        _addProductToCart(product);
      },
    );
  }

  void _addProductToCart(Product p) {
    final i = _cartItems.indexWhere((x) => x.id == p.barcode);
    if (i != -1) {
      if (_cartItems[i].qty + 1 > _cartItems[i].stockQuantity) {
        emit(const PosError(message: 'outOfStock'));
        _emitLoaded();
        return;
      }
      _cartItems[i] = _cartItems[i].copyWith(qty: _cartItems[i].qty + 1);
    } else {
      _cartItems.add(CartItemModel(
        id: p.barcode,
        productId: p.id ?? p.barcode,
        name: p.name,
        originalPrice: p.price,
        salePrice: p.price,
        qty: 1,
        date: DateTime.now(),
        minPrice: p.minPrice,
        wholesalePrice: p.wholesalePrice,
        stockQuantity: p.quantity,
        unitAbbreviation: p.unitAbbreviation,
      ));
    }
    _emitLoaded();
  }

  void addProduct(Product p) {
    _addProductToCart(p);
  }

  void increase(int index) {
    if (index < 0 || index >= _cartItems.length) return;
    if (_cartItems[index].qty + 1 > _cartItems[index].stockQuantity) {
      emit(const PosError(message: 'outOfStock'));
      _emitLoaded();
      return;
    }
    _cartItems[index] =
        _cartItems[index].copyWith(qty: _cartItems[index].qty + 1);
    _emitLoaded();
  }

  void decrease(int index) {
    if (index < 0 || index >= _cartItems.length) return;
    final q = _cartItems[index].qty;
    if (q > 1) {
      _cartItems[index] = _cartItems[index].copyWith(qty: q - 1);
    } else {
      _cartItems.removeAt(index);
    }
    _emitLoaded();
  }

  void remove(int index) {
    if (index < 0 || index >= _cartItems.length) return;
    _cartItems.removeAt(index);
    _emitLoaded();
  }

  void setQuantity(int index, double quantity) {
    if (index < 0 || index >= _cartItems.length || !quantity.isFinite) return;
    if (quantity <= 0) {
      remove(index);
      return;
    }
    final item = _cartItems[index];
    if (quantity > item.stockQuantity) {
      emit(const PosError(message: 'outOfStock'));
      _emitLoaded();
      return;
    }
    _cartItems[index] = item.copyWith(qty: quantity);
    _emitLoaded();
  }

  void clearCart() {
    _cartItems.clear();
    _cartDiscountValue = 0;
    _cartDiscountType = 'none';
    _emitLoaded();
  }

  Future<void> editPrice(int index, double newPrice) async {
    if (index < 0 || index >= _cartItems.length) return;
    final item = _cartItems[index];
    if (newPrice < item.minPrice) {
      emit(PriceValidationError(
        message: 'priceBelowMin:${item.minPrice.toStringAsFixed(2)}',
        minPrice: item.minPrice,
        attemptedPrice: newPrice,
      ));
      _emitLoaded();
      return;
    }
    _cartItems[index] = item.copyWith(salePrice: newPrice);
    _emitLoaded();
  }

  void applyItemDiscount(int index, double discount, String type) {
    if (index < 0 || index >= _cartItems.length) return;
    final item = _cartItems[index];

    final validation = DiscountCalculator.validateItemDiscount(
      item: item,
      value: discount,
      type: type,
    );
    if (!validation.isValid) {
      emit(PriceValidationError(
        message: 'discountBelowMin:${item.minPrice.toStringAsFixed(2)}',
        minPrice: item.minPrice,
        attemptedPrice: item.qty > 0 ? validation.total / item.qty : 0,
      ));
      _emitLoaded();
      return;
    }

    _cartItems[index] = item.copyWith(
      discountAmount: discount,
      discountType: type,
    );
    _emitLoaded();
  }

  void removeItemDiscount(int index) {
    if (index < 0 || index >= _cartItems.length) return;
    _cartItems[index] = _cartItems[index].copyWith(
      discountAmount: 0,
      discountType: 'none',
    );
    _emitLoaded();
  }

  void applyCartDiscount(double value, String type) {
    final validation = DiscountCalculator.validateCartDiscount(
      items: _cartItems,
      value: value,
      type: type,
    );
    if (!validation.isValid) {
      if (validation.error == DiscountValidationError.belowMinimumPrice) {
        final item = validation.invalidItem!;
        emit(PriceValidationError(
          message:
              'cartDiscountBelowMin:${item.name}:${item.minPrice.toStringAsFixed(2)}',
          minPrice: item.minPrice,
          attemptedPrice: validation.total,
        ));
      } else {
        emit(PosError(
            message: validation.error == DiscountValidationError.exceedsSubtotal
                ? 'discountExceedsSubtotal'
                : 'discountPercentageRange'));
      }
      _emitLoaded();
      return;
    }

    _cartDiscountValue = value;
    _cartDiscountType = type;
    _emitLoaded();
  }

  void removeCartDiscount() {
    _cartDiscountValue = 0;
    _cartDiscountType = 'none';
    _emitLoaded();
  }

  double _subtotal() => DiscountCalculator.subtotal(_cartItems);

  double _total() {
    final subtotal = _subtotal();
    if (!hasCartDiscount) return subtotal;

    return DiscountCalculator.validateCartDiscount(
      items: _cartItems,
      value: _cartDiscountValue,
      type: _cartDiscountType,
    ).total;
  }

  Future<void> checkout({String paymentMethod = 'cash'}) async {
    if (_cartItems.isEmpty) {
      emit(const PosError(message: 'cartIsEmpty'));
      _emitLoaded();
      return;
    }

    final branchId = getIt<BranchCubit>().effectiveBranchId;
    if (branchId == null) {
      emit(const PosError(message: 'branchRequired'));
      _emitLoaded();
      return;
    }

    final activeShift = getIt<ShiftCubit>().state.activeShift;
    if (activeShift == null) {
      emit(const PosError(message: 'shiftRequired'));
      _emitLoaded();
      return;
    }

    emit(PosLoading());

    final subtotal = _subtotal();
    final total = _total();
    final itemCount = _cartItems.length;
    final userName = getIt<UserCubit>().currentUser.name;

    final sessionId = activeShift.id;

    // The repository commits the sale, its lines, and stock changes in one
    // database transaction.
    final sale = Sale(
      id: const Uuid().v4(),
      total: total,
      subtotal: subtotal,
      discountAmount: hasCartDiscount ? (subtotal - total) : 0,
      discountType: _cartDiscountType,
      discountValue: _cartDiscountValue,
      items: itemCount,
      cashierName: userName,
      cashierUsername: getIt<UserCubit>().currentUser.username,
      cashierUserId: getIt<UserCubit>().currentUser.id,
      sessionId: sessionId,
      date: DateTime.now(),
      paymentMethod: paymentMethod,
      saleItems: _cartItems
          .map((x) => SaleItem(
                productId: x.productId,
                productBarcode: x.id,
                name: x.name,
                price: x.originalPrice,
                salePrice: x.salePrice,
                quantity: x.qty,
                total: x.total,
                wholesalePrice: x.wholesalePrice,
                itemDiscount: x.effectiveDiscount,
                unitAbbreviation: x.unitAbbreviation ?? '',
              ))
          .toList(),
    );

    final saved = await repository.completeSale(sale);
    if (saved.isLeft()) {
      saved.fold(
        (f) {
          emit(PosError(message: f.message));
          _emitLoaded();
        },
        (_) {},
      );
      return;
    }

    await getIt<ShiftCubit>().refresh();
    _lastCompletedSale = sale;

    for (final item in _cartItems) {
      getIt<NotificationsCubit>().addItem(Product(
        id: item.productId,
        name: item.name,
        barcode: item.id,
        price: item.originalPrice,
        minPrice: item.minPrice,
        wholesalePrice: item.wholesalePrice,
        quantity: item.stockQuantity - item.qty,
        minQuantity: 0,
        category: '',
        unitAbbreviation: item.unitAbbreviation,
      ));
    }

    _cartItems.clear();
    _cartDiscountValue = 0;
    _cartDiscountType = 'none';

    emit(CheckoutSuccessWithSale(
      message: 'saleSuccess',
      total: total,
      sale: sale,
    ));

    await load();
    getIt<InvoiceCubit>().loadSales();
  }

  void _emitLoaded() {
    emit(PosLoaded(
      cartItems: List.unmodifiable(_cartItems),
      recentSales: _recentSales,
      totalAmount: _total(),
      subtotal: _subtotal(),
      cartDiscountValue: _cartDiscountValue,
      cartDiscountType: _cartDiscountType,
    ));
  }

  Sale? get lastCompletedSale => _lastCompletedSale;
}
