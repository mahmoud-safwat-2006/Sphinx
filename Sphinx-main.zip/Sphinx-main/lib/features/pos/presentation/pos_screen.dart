import 'package:sphinx/core/constants/app_colors.dart';
import 'package:sphinx/core/di/dependency_injection.dart';
import 'package:sphinx/core/localization/product_unit_localizer.dart';
import 'package:sphinx/core/components/responsive/mobile_surface.dart';
import 'package:sphinx/core/utils/responsive_helper.dart';
import 'package:sphinx/core/security/role_permissions.dart';
import 'package:sphinx/features/auth/presentation/cubit/user_cubit.dart';
import 'package:sphinx/features/branches/presentation/cubit/branch_cubit.dart';
import 'package:sphinx/features/invoice/data/invoice_models.dart';
import 'package:sphinx/features/invoice/presentation/invoice_preview_screen.dart';
import 'package:sphinx/features/pos/data/models/cart_item_model.dart';
import 'package:sphinx/features/pos/data/models/sale_model.dart';
import 'package:sphinx/features/pos/domain/pos_repository.dart';
import 'package:sphinx/features/pos/presentation/cubit/pos_cubit.dart';
import 'package:sphinx/features/pos/presentation/cubit/pos_state.dart';
import 'package:sphinx/features/pos/presentation/widgets/discount_dialog.dart';
import 'package:sphinx/features/products/data/models/product_model.dart';
import 'package:sphinx/features/products/presentation/cubit/product_cubit.dart';
import 'package:sphinx/features/settings/presentation/cubit/settings_cubit.dart';
import 'package:sphinx/features/shifts/presentation/cubit/shift_cubit.dart';
import 'package:sphinx/features/shifts/presentation/cubit/shift_state.dart';
import 'package:sphinx/features/shifts/presentation/widgets/open_shift_dialog.dart';
import 'package:sphinx/features/shifts/presentation/widgets/close_shift_dialog.dart';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:sphinx/core/components/screen_header.dart';
import 'package:sphinx/l10n/app_localizations.dart';
import 'package:sphinx/features/pos/presentation/widgets/barcode_scan_card.dart';
import 'package:sphinx/features/pos/presentation/widgets/cart_section.dart';
import 'package:sphinx/features/pos/presentation/widgets/product_search_overlay.dart';
import 'package:sphinx/features/pos/presentation/widgets/recent_sales.dart';
import 'package:sphinx/features/pos/presentation/widgets/total_section_card.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

class PosScreen extends StatefulWidget {
  final PosRepository? repository;

  const PosScreen({super.key, this.repository});

  @override
  State<PosScreen> createState() => _PosScreenState();
}

class _PosScreenState extends State<PosScreen> {
  final _barcodeController = TextEditingController();
  final _searchController = TextEditingController();
  final _barcodeFocusNode = FocusNode();
  late final PosCubit _cubit;
  late final bool _ownsCubit;
  String _query = '';
  bool _isRecentSalesCollapsed = false;
  DateTime? _lastErrorTime;
  bool _shiftChecked = false;

  @override
  void initState() {
    super.initState();
    _ownsCubit = widget.repository != null;
    _cubit = widget.repository == null
        ? getIt<PosCubit>()
        : PosCubit(repository: widget.repository!);
    _cubit.load();
    getIt<ShiftCubit>().load();
    WidgetsBinding.instance.addPostFrameCallback((_) => _checkShift());
  }

  Future<void> _checkShift() async {
    if (_shiftChecked) return;
    _shiftChecked = true;
    if (!getIt<BranchCubit>().state.scope.isSingleBranch) return;
    await getIt<ShiftCubit>().load();
    if (!mounted) return;
    if (getIt<ShiftCubit>().state.activeShift == null) {
      await _promptOpenShift();
    }
  }

  Future<void> _promptOpenShift() async {
    if (!getIt<BranchCubit>().state.scope.isSingleBranch) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            Localizations.localeOf(context).languageCode == 'ar'
                ? 'اختر فرعاً أولاً لفتح وردية'
                : 'Select a branch first to open a shift',
          ),
        ),
      );
      return;
    }
    final result = await showDialog<double>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const OpenShiftDialog(),
    );
    if (!mounted) return;
    if (result != null) {
      try {
        await getIt<ShiftCubit>().open(result);
      } catch (_) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(_friendly('failedOpenSession'))),
        );
      }
    }
  }

  @override
  void dispose() {
    if (_ownsCubit) _cubit.close();
    _barcodeController.dispose();
    _searchController.dispose();
    _barcodeFocusNode.dispose();
    super.dispose();
  }

  Future<void> _submitBarcode([String? code]) async {
    if (!getIt<BranchCubit>().state.scope.isSingleBranch) return;
    final value = (code ?? _barcodeController.text).trim();
    if (value.isEmpty) return;
    // If search overlay has visible results, select the first match
    // instead of treating the typed text as a barcode.
    if (code == null && _visibleProducts.isNotEmpty) {
      final product = _visibleProducts.first;
      _cubit.addProduct(product);
      _barcodeController.clear();
      setState(() => _query = '');
      return;
    }
    _barcodeController.clear();
    if (_query.isNotEmpty && mounted) {
      setState(() => _query = '');
    }
    await _cubit.commitBarcode(value);
  }

  Future<void> _scanWithCamera() async {
    if (kIsWeb || (!Platform.isAndroid && !Platform.isIOS)) {
      final l10n = AppLocalizations.of(context);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(l10n.cameraScannerUnavailable),
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }
    try {
      final code = await Navigator.of(context).push<String>(
        MaterialPageRoute(builder: (_) => const _BarcodeScannerScreen()),
      );
      if (code != null && mounted) await _submitBarcode(code);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              AppLocalizations.of(context).scannerErrorMessage('$e'),
            ),
          ),
        );
      }
    }
  }

  Future<void> _editItemDiscount(int index, CartItemModel item) async {
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (_) => DiscountDialog(
        productName: item.name,
        currentPrice: item.salePrice,
        minPrice: item.minPrice,
        currentType: item.discountType,
        currentValue: item.discountAmount,
      ),
    );
    if (result == null) return;
    final type = result['type'] as String? ?? 'none';
    final value = (result['value'] as num?)?.toDouble() ?? 0;
    if (type == 'none' || value == 0) {
      _cubit.removeItemDiscount(index);
    } else {
      _cubit.applyItemDiscount(index, value, type);
    }
  }

  Future<void> _editCartDiscount(PosLoaded state) async {
    final l10n = AppLocalizations.of(context);
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (_) => DiscountDialog(
        productName: l10n.entireCartLabel,
        currentPrice: state.subtotal,
        minPrice: 0,
        currentType: state.cartDiscountType,
        currentValue: state.cartDiscountValue,
      ),
    );
    if (result == null) return;
    final type = result['type'] as String? ?? 'none';
    final value = (result['value'] as num?)?.toDouble() ?? 0;
    if (type == 'none' || value == 0) {
      _cubit.removeCartDiscount();
    } else {
      _cubit.applyCartDiscount(value, type);
    }
  }

  Future<void> _editQuantity(int index, CartItemModel item) async {
    final l10n = AppLocalizations.of(context);
    final controller = TextEditingController(text: _number(item.qty));
    final quantity = await showDialog<double>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('${l10n.quantity} \u00B7 ${item.name}'),
        content: TextField(
          controller: controller,
          autofocus: true,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: InputDecoration(
            labelText: item.unitAbbreviation == null
                ? l10n.quantity
                : '${l10n.quantity} '
                    '(${ProductUnitLocalizer.abbreviation(l10n, item.unitAbbreviation)})',
            helperText: '${l10n.availableQty}: '
                '${ProductUnitLocalizer.quantity(l10n, item.stockQuantity, item.unitAbbreviation)}',
          ),
          onSubmitted: (value) => Navigator.pop(
              context, double.tryParse(value.replaceAll(',', '.'))),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(l10n.cancelBtn),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(
              context,
              double.tryParse(controller.text.replaceAll(',', '.')),
            ),
            child: Text(l10n.saveBtn),
          ),
        ],
      ),
    );
    controller.dispose();
    if (quantity != null) _cubit.setQuantity(index, quantity);
  }

  Future<void> _checkout() async {
    if (!getIt<BranchCubit>().state.scope.isSingleBranch) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(_friendly('branchRequired'))),
      );
      return;
    }
    if (getIt<ShiftCubit>().state.activeShift == null) {
      await _promptOpenShift();
      return;
    }
    final l10n = AppLocalizations.of(context);
    final method = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(l10n.paymentMethod),
        content: Wrap(
          spacing: 12,
          children: [
            FilledButton.icon(
              onPressed: () => Navigator.pop(context, 'cash'),
              icon: const Icon(Icons.payments_outlined),
              label: Text(l10n.cashPayment),
            ),
            OutlinedButton.icon(
              onPressed: () => Navigator.pop(context, 'card'),
              icon: const Icon(Icons.credit_card),
              label: Text(l10n.cardPayment),
            ),
          ],
        ),
      ),
    );
    if (method != null) await _cubit.checkout(paymentMethod: method);
  }

  Future<void> _openInvoice(Sale sale) async {
    final settings = getIt<SettingsCubit>().currentStoreInfo;
    final data = InvoiceData(
      invoiceId: sale.id,
      date: sale.date,
      storeName: settings?.name ?? 'Sphinx',
      storeAddress: settings?.address ?? '',
      storePhone: settings?.phone ?? '',
      cashierName: sale.cashierName ?? 'Cashier',
      lines: sale.saleItems
          .map((item) => InvoiceLine(
                name: item.name,
                barcode: item.productBarcode,
                price: item.quantity == 0 ? 0 : item.total / item.quantity,
                qty: item.quantity,
              ))
          .toList(),
      subtotal: sale.subtotal,
      discount: sale.discountAmount,
      tax: 0,
      grandTotal: sale.total,
      paymentMethod: sale.paymentMethod,
    );
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => InvoicePreviewScreen(data: data, receiptMode: true),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final hasSelectedBranch = context.select<BranchCubit, bool>(
      (cubit) => cubit.state.scope.isSingleBranch,
    );
    return MultiBlocProvider(
      providers: [
        BlocProvider.value(value: _cubit),
        BlocProvider.value(value: getIt<ShiftCubit>()),
      ],
      child: BlocBuilder<ShiftCubit, ShiftState>(
        builder: (context, shiftState) => BlocConsumer<PosCubit, PosState>(
          listener: (context, state) {
            if (state is CheckoutSuccessWithSale) {
              ScaffoldMessenger.of(context).hideCurrentSnackBar();
              _lastErrorTime = null;
              _openInvoice(state.sale);
            } else if (state is PosError || state is PriceValidationError) {
              final message = state is PosError
                  ? state.message
                  : (state as PriceValidationError).message;
              ScaffoldMessenger.of(context)
                ..hideCurrentSnackBar()
                ..showSnackBar(SnackBar(content: Text(_friendly(message))));
              _lastErrorTime = DateTime.now();
            } else if (state is PosLoaded) {
              if (_lastErrorTime != null &&
                  DateTime.now().difference(_lastErrorTime!).inMilliseconds >
                      500) {
                ScaffoldMessenger.of(context).hideCurrentSnackBar();
                _lastErrorTime = null;
              }
            }
          },
          builder: (context, state) {
            final loaded = state is PosLoaded ? state : null;
            if (loaded == null) {
              return const Center(child: CircularProgressIndicator());
            }
            if (!hasSelectedBranch) {
              return _buildAllBranchesView(loaded);
            }

            // Lock POS if no shift is open
            if (shiftState.activeShift == null) {
              return _buildShiftLockOverlay();
            }

            return LayoutBuilder(
              builder: (context, constraints) {
                final isDesktop =
                    constraints.maxWidth >= ResponsiveHelper.desktopBreakpoint;
                if (isDesktop) {
                  return Container(
                    color: AppColors.backgroundColor,
                    child: SafeArea(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
                        child: _buildLegacyDesktop(loaded, true),
                      ),
                    ),
                  );
                }

                final useTabletSplit = constraints.maxWidth >= 760;
                return MobileSurface(
                  footer: useTabletSplit ? null : _buildCompactTotals(loaded),
                  child: useTabletSplit
                      ? _buildGuidedTablet(loaded)
                      : _buildGuidedPhone(loaded),
                );
              },
            );
          },
        ),
      ),
    );
  }

  List<Product> get _visibleProducts {
    if (_query.isEmpty) return const [];
    return getIt<ProductCubit>()
        .allProducts
        .where((product) {
          return product.name.toLowerCase().contains(_query) ||
              product.barcode.toLowerCase().contains(_query) ||
              product.category.toLowerCase().contains(_query);
        })
        .take(8)
        .toList();
  }

  List<Map<String, dynamic>> _cartMaps(PosLoaded state) => state.cartItems
      .map((item) => <String, dynamic>{
            'id': item.productBarcode,
            'name': item.name,
            'price': item.discountedPrice,
            'qty': item.qty,
            'quantity': item.stockQuantity,
            'date': DateTime.now(),
            'minPrice': item.minPrice,
            'unitAbbreviation': item.unitAbbreviation,
            'imagePath': item.imagePath,
          })
      .toList();

  List<Map<String, dynamic>> _recentMaps(PosLoaded state) => state.recentSales
      .map((sale) => <String, dynamic>{
            'id': sale.id,
            'total': sale.total,
            'items': sale.items,
            'date': sale.date,
            'isRefund': sale.isRefund,
          })
      .toList();

  Widget _legacySearch(PosLoaded state, {bool compact = false}) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          BarcodeScanCard(
            controller: _barcodeController,
            focusNode: _barcodeFocusNode,
            onSubmitted: _submitBarcode,
            onCameraScan: _scanWithCamera,
            compact: compact,
            onChanged: (value) => setState(() {
              _query = value.trim().toLowerCase();
            }),
          ),
          if (_visibleProducts.isNotEmpty)
            ProductSearchOverlay(
              products: _visibleProducts,
              allProducts: getIt<ProductCubit>().allProducts,
              onProductSelected: (product) {
                _cubit.addProduct(product);
                _barcodeController.clear();
                setState(() => _query = '');
              },
            ),
        ],
      );

  Widget _legacyCart(PosLoaded state, {bool compact = false}) => CartSection(
        compact: compact,
        cartItems: _cartMaps(state),
        onRemoveItem: _cubit.remove,
        onIncreaseQty: _cubit.increase,
        onDecreaseQty: _cubit.decrease,
        onEditPrice: _cubit.editPrice,
        onEditQuantity: (index) => _editQuantity(index, state.cartItems[index]),
        onDiscount: (index) => _editItemDiscount(index, state.cartItems[index]),
        onClearCart: _cubit.clearCart,
      );

  Widget _buildCompactTotals(PosLoaded state) => TotalSectionCard(
        compact: true,
        totalAmount: state.totalAmount,
        itemCount: state.cartItems.length,
        onCheckout: state.cartItems.isEmpty ? null : _checkout,
        onClearCart: _cubit.clearCart,
        onDiscount:
            state.cartItems.isEmpty ? null : () => _editCartDiscount(state),
      );

  Widget _buildGuidedPhone(PosLoaded state) {
    final l10n = AppLocalizations.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(
              Directionality.of(context) == TextDirection.rtl
                  ? Icons.chevron_left_rounded
                  : Icons.chevron_right_rounded,
              color: AppColors.textPrimary,
            ),
            const SizedBox(width: 6),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    l10n.salesScreenTitle,
                    style: const TextStyle(
                      color: AppColors.textPrimary,
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  Text(
                    l10n.salesScreenSubtitle,
                    style: const TextStyle(
                      color: AppColors.mutedColor,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        _legacySearch(state, compact: true),
        const SizedBox(height: 12),
        Expanded(child: _legacyCart(state, compact: true)),
      ],
    );
  }

  Widget _buildGuidedTablet(PosLoaded state) {
    final l10n = AppLocalizations.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ScreenHeader(
          title: l10n.salesScreenTitle,
          subtitle: l10n.salesScreenSubtitle,
          fontSize: 26,
          icon: Icons.point_of_sale,
          iconColor: AppColors.primaryColor,
          titleColor: AppColors.textPrimary,
          actions: [_buildShiftStatusChip()],
        ),
        const SizedBox(height: 12),
        _legacySearch(state, compact: true),
        const SizedBox(height: 12),
        Expanded(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Expanded(
                flex: 5,
                child: _legacyCart(state, compact: true),
              ),
              const SizedBox(width: 16),
              SizedBox(
                width: 320,
                child: Align(
                  alignment: Alignment.topCenter,
                  child: _buildCompactTotals(state),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildLegacyDesktop(PosLoaded state, bool desktop) {
    final l10n = AppLocalizations.of(context);
    return Directionality(
      textDirection:
          l10n.localeName == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: desktop ? 7 : 6,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ScreenHeader(
                  title: l10n.salesScreenTitle,
                  subtitle: l10n.salesScreenSubtitle,
                  fontSize: 30,
                  icon: Icons.point_of_sale,
                  iconColor: AppColors.primaryColor,
                  titleColor: AppColors.textPrimary,
                  actions: [
                    _buildShiftStatusChip(),
                  ],
                ),
                const ScreenHeaderGap(height: 16),
                Expanded(
                  child: Stack(children: [
                    Column(children: [
                      const Visibility(
                        visible: false,
                        maintainSize: true,
                        maintainAnimation: true,
                        maintainState: true,
                        child: BarcodeScanCard(),
                      ),
                      const SizedBox(height: 16),
                      Expanded(child: _legacyCart(state)),
                    ]),
                    Positioned(
                        top: 0, left: 0, right: 0, child: _legacySearch(state)),
                  ]),
                ),
              ],
            ),
          ),
          SizedBox(width: desktop ? 24 : 16),
          Expanded(
            flex: desktop ? 3 : 4,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const ScreenHeaderGap(height: 86),
                TotalSectionCard(
                  totalAmount: state.totalAmount,
                  itemCount: state.cartItems.length,
                  onCheckout: state.cartItems.isEmpty ? null : _checkout,
                  onClearCart: _cubit.clearCart,
                  onDiscount: state.cartItems.isEmpty
                      ? null
                      : () => _editCartDiscount(state),
                ),
                const SizedBox(height: 16),
                if (!_isRecentSalesCollapsed)
                  Expanded(
                    child: RecentSalesSection(
                      recentSales: _recentMaps(state),
                      onToggleCollapse: () =>
                          setState(() => _isRecentSalesCollapsed = true),
                    ),
                  )
                else
                  OutlinedButton.icon(
                    onPressed: () =>
                        setState(() => _isRecentSalesCollapsed = false),
                    icon: const Icon(Icons.history),
                    label: Text(l10n.showRecentSales),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _friendly(String message) {
    final l10n = AppLocalizations.of(context);
    if (message.contains('outOfStock')) {
      return l10n.outOfStockMessage;
    }
    if (message.contains('productNotFound')) {
      return l10n.productNotFoundMessage;
    }
    if (message.contains('BelowMin')) {
      return l10n.priceBelowMinMessage;
    }
    if (message.contains('discountExceeds')) {
      return l10n.discountExceedsMessage;
    }
    if (message.contains('discountPercentage')) {
      return l10n.discountPercentageMessage;
    }
    if (message.contains('shiftRequired')) {
      return l10n.localeName == 'ar'
          ? 'يجب فتح وردية قبل إتمام البيع'
          : 'Open a shift before completing a sale';
    }
    if (message.contains('branchRequired')) {
      return l10n.localeName == 'ar'
          ? 'اختر فرعاً أولاً'
          : 'Select a branch first';
    }
    if (message.contains('failedOpenSession')) {
      return l10n.localeName == 'ar'
          ? 'تعذر فتح الوردية'
          : 'Could not open the shift';
    }
    return message;
  }

  static String _number(double value) => value == value.roundToDouble()
      ? value.toStringAsFixed(0)
      : value.toStringAsFixed(3).replaceFirst(RegExp(r'0+$'), '');

  Widget _buildShiftStatusChip() {
    final l10n = AppLocalizations.of(context);
    final isArabic = l10n.localeName == 'ar';
    final session = getIt<ShiftCubit>().state.activeShift;
    if (session == null) return const SizedBox.shrink();

    final duration = DateTime.now().difference(session.openTime);
    final hours = duration.inHours;
    final minutes = duration.inMinutes % 60;
    final timeStr = hours > 0 ? '${hours}h ${minutes}m' : '${minutes}m';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.green.shade50,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.green.shade200),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: Colors.green,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 6),
          Text(
            '${isArabic ? "شيفت مفتوح" : "Shift Open"} · $timeStr',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: Colors.green.shade800,
            ),
          ),
          const SizedBox(width: 8),
          if (getIt<UserCubit>()
              .currentUser
              .hasPermission(Permission.closeShift))
            GestureDetector(
              onTap: () async {
                // Refresh shift data before closing to get accurate financials
                await getIt<ShiftCubit>().refresh();
                if (!mounted) return;
                final freshSession = getIt<ShiftCubit>().state.activeShift;
                if (freshSession == null) return;
                final declaredCash = await showDialog<double>(
                  context: context,
                  builder: (_) => CloseShiftDialog(
                    session: freshSession,
                    totalSales: freshSession.cashSales + freshSession.cardSales,
                    totalRefunds:
                        freshSession.cashRefunds + freshSession.cardRefunds,
                  ),
                );
                if (declaredCash != null && mounted) {
                  await getIt<ShiftCubit>().closeShift(
                    shiftId: freshSession.id,
                    closingCash: declaredCash,
                  );
                }
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.red.shade50,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.red.shade200),
                ),
                child: Text(
                  isArabic ? 'إنهاء' : 'Finish',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: Colors.red.shade700,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildShiftLockOverlay({bool branchRequired = false}) {
    final l10n = AppLocalizations.of(context);
    final isArabic = l10n.localeName == 'ar';
    return Container(
      color: AppColors.backgroundColor,
      child: Center(
        child: Container(
          width: 400,
          padding: const EdgeInsets.all(40),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.08),
                blurRadius: 30,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: AppColors.primaryColor.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  LucideIcons.lock,
                  size: 48,
                  color: AppColors.primaryColor,
                ),
              ),
              const SizedBox(height: 24),
              Text(
                branchRequired
                    ? (isArabic ? 'اختر فرعاً' : 'Select a branch')
                    : (isArabic ? 'نقطة البيع مغلقة' : 'POS Locked'),
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textPrimary,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                branchRequired
                    ? (isArabic
                        ? 'يجب اختيار فرع واحد لاستخدام نقطة البيع'
                        : 'Choose one branch to use the POS')
                    : (isArabic
                        ? 'يجب فتح وردية أولاً لاستخدام نقطة البيع'
                        : 'Open a shift first to start using the POS'),
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 14,
                  color: AppColors.mutedColor,
                ),
              ),
              if (!branchRequired) ...[
                const SizedBox(height: 28),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primaryColor,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    onPressed: _promptOpenShift,
                    icon: Icon(LucideIcons.play, size: 18),
                    label: Text(
                      isArabic ? 'فتح وردية' : 'Open Shift',
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAllBranchesView(PosLoaded state) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final recent = RecentSalesSection(recentSales: _recentMaps(state));
        if (constraints.maxWidth >= 900) {
          return Padding(
            padding: const EdgeInsets.all(24),
            child: Row(
              children: [
                Expanded(child: _buildShiftLockOverlay(branchRequired: true)),
                const SizedBox(width: 20),
                Expanded(child: recent),
              ],
            ),
          );
        }
        return Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Expanded(child: _buildShiftLockOverlay(branchRequired: true)),
              const SizedBox(height: 16),
              SizedBox(height: 320, child: recent),
            ],
          ),
        );
      },
    );
  }
}

class _BarcodeScannerScreen extends StatefulWidget {
  const _BarcodeScannerScreen();

  @override
  State<_BarcodeScannerScreen> createState() => _BarcodeScannerScreenState();
}

class _BarcodeScannerScreenState extends State<_BarcodeScannerScreen> {
  bool _handled = false;

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: Text(AppLocalizations.of(context).scanBarcodeTitle),
        ),
        body: Stack(
          fit: StackFit.expand,
          children: [
            MobileScanner(
              onDetect: (capture) {
                if (_handled) return;
                String? value;
                for (final barcode in capture.barcodes) {
                  if (barcode.rawValue != null &&
                      barcode.rawValue!.isNotEmpty) {
                    value = barcode.rawValue;
                    break;
                  }
                }
                if (value == null || value.isEmpty) return;
                _handled = true;
                Navigator.pop(context, value);
              },
            ),
            Center(
              child: Container(
                width: 280,
                height: 150,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.white, width: 3),
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
            ),
          ],
        ),
      );
}
