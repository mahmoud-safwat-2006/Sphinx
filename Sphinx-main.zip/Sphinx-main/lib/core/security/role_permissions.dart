import 'package:sphinx/features/auth/data/models/user_model.dart';

/// Defines granular permissions per role.
/// This is the single source of truth for what each role can do.
class RolePermissions {
  static const Map<UserType, Set<Permission>> _permissions = {
    UserType.admin: {
      Permission.posCheckout,
      Permission.viewInvoices,
      Permission.deleteInvoices,
      Permission.manageProducts,
      Permission.viewReports,
      Permission.manageUsers,
      Permission.assignRoles,
      Permission.viewAnalytics,
      Permission.storeSettings,
      Permission.dataManagement,
      Permission.manageUnits,
      Permission.applyDiscounts,
      Permission.processRefunds,
      Permission.closeShift,
    },
    UserType.manager: {
      Permission.posCheckout,
      Permission.viewInvoices,
      Permission.deleteInvoices,
      Permission.manageProducts,
      Permission.viewReports,
      Permission.viewAnalytics,
      Permission.manageUsers,
      Permission.storeSettings,
      Permission.manageUnits,
      Permission.applyDiscounts,
      Permission.processRefunds,
      Permission.closeShift,
    },
    UserType.accountant: {
      Permission.viewInvoices,
      Permission.viewReports,
      Permission.viewAnalytics,
    },
    UserType.cashier: {
      Permission.posCheckout,
      Permission.viewInvoices,
      Permission.applyDiscounts,
      Permission.processRefunds,
      Permission.closeShift,
    },
    UserType.employee: {},
  };

  /// Check if a user type has a specific permission
  static bool hasPermission(UserType userType, Permission permission) {
    return _permissions[userType]?.contains(permission) ?? false;
  }

  /// Get all permissions for a user type
  static Set<Permission> getPermissions(UserType userType) {
    return _permissions[userType] ?? {};
  }
}

enum Permission {
  posCheckout,
  viewInvoices,
  deleteInvoices,
  manageProducts,
  viewReports,
  manageUsers,
  assignRoles,
  viewAnalytics,
  storeSettings,
  dataManagement,
  manageUnits,
  applyDiscounts,
  processRefunds,
  closeShift,
}
