import 'package:sphinx/features/auth/data/models/user_model.dart';
import 'role_permissions.dart';

class PermissionDeniedException implements Exception {
  final String message;
  PermissionDeniedException(
      [this.message =
          "Access denied: You don't have permission to perform this action."]);

  @override
  String toString() => message;
}

class PermissionGuard {
  /// Generic permission check — throws if denied
  static void check(User user, Permission permission, [String? customMessage]) {
    if (!user.hasPermission(permission)) {
      throw PermissionDeniedException(
          customMessage ?? "Access denied: ${permission.name}");
    }
  }

  /// Returns true/false without throwing
  static bool canAccess(User user, Permission permission) {
    return user.hasPermission(permission);
  }

  /// Refund permission — cashiers and above
  static void checkRefundPermission(User user) {
    check(user, Permission.processRefunds,
        "You don't have permission to process refunds.");
  }

  static void checkReportAccess(User user) {
    check(user, Permission.viewReports,
        "You don't have permission to view reports.");
  }

  static void checkDayClosePermission(User user) {
    // Only managers and admins can close the day
    if (!user.isManagerOrAbove) {
      throw PermissionDeniedException(
          "Only managers and admins can close the day.");
    }
  }

  static void checkManageProducts(User user) {
    check(user, Permission.manageProducts,
        "You don't have permission to manage products.");
  }

  static void checkManageUsers(User user) {
    check(user, Permission.manageUsers,
        "You don't have permission to manage users.");
  }

  static void checkManageUnits(User user) =>
      check(user, Permission.manageUnits);

  static void checkApplyDiscounts(User user) =>
      check(user, Permission.applyDiscounts);

  static void checkStoreSettings(User user) =>
      check(user, Permission.storeSettings);

  static void checkDataManagement(User user) =>
      check(user, Permission.dataManagement);
}
