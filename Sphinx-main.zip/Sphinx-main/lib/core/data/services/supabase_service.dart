import 'dart:async';

import 'package:sphinx/core/config/app_config.dart';
import 'package:sphinx/core/data/services/supabase_shift_recovery.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

enum SupabaseConnectionStatus { unknown, connected, disconnected }

class SupabaseService {
  static final SupabaseService _instance = SupabaseService._internal();

  factory SupabaseService() => _instance;

  SupabaseService._internal();

  Timer? _connectionTimer;
  bool _isConnected = true;

  final _connectionStatus =
      StreamController<SupabaseConnectionStatus>.broadcast();

  SupabaseClient get client => Supabase.instance.client;
  GoTrueClient get auth => client.auth;
  SupabaseStorageClient get storage => client.storage;
  RealtimeClient get realtime => client.realtime;
  Stream<SupabaseConnectionStatus> get connectionStatus =>
      _connectionStatus.stream;

  SupabaseQueryBuilder from(String table) => client.from(table);

  bool get isConnected => _isConnected;

  void startConnectionMonitor({Duration interval = const Duration(seconds: 30)}) {
    _connectionTimer?.cancel();
    checkConnection();
    _connectionTimer = Timer.periodic(interval, (_) => checkConnection());
  }

  void stopConnectionMonitor() {
    _connectionTimer?.cancel();
    _connectionTimer = null;
  }

  Future<T> withSessionRecovery<T>(Future<T> Function() operation) {
    return SupabaseSessionRecovery(
      clearLocalSession: () => client.auth.signOut(
        scope: SignOutScope.local,
      ),
    ).run(operation);
  }

  Future<bool> checkConnection() async {
    try {
      await withSessionRecovery(
        () => from('store_settings').select('id').limit(1),
      );
      _isConnected = true;
      _connectionStatus.add(SupabaseConnectionStatus.connected);
      return true;
    } catch (_) {
      _isConnected = false;
      _connectionStatus.add(SupabaseConnectionStatus.disconnected);
      return false;
    }
  }

  Future<T> withTransientRetry<T>(
    Future<T> Function() operation, {
    int maxAttempts = AppConfig.networkRetryAttempts,
    Duration initialDelay = const Duration(milliseconds: 250),
  }) async {
    Object? lastError;
    for (var attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        final result = await withSessionRecovery(operation);
        _connectionStatus.add(SupabaseConnectionStatus.connected);
        return result;
      } catch (error) {
        lastError = error;
        if (!_isTransient(error) || attempt == maxAttempts) rethrow;
        await Future<void>.delayed(initialDelay * attempt);
      }
    }
    throw StateError('Supabase operation failed: $lastError');
  }

  bool _isTransient(Object error) {
    if (error is TimeoutException) return true;
    if (error is PostgrestException) {
      return const {'PGRST000', 'PGRST001', 'PGRST002', 'PGRST003'}
          .contains(error.code);
    }
    final message = error.toString().toLowerCase();
    return message.contains('socket') ||
        message.contains('connection reset') ||
        message.contains('temporarily unavailable') ||
        message.contains('timeout');
  }
}
