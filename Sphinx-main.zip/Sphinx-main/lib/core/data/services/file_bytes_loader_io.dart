import 'dart:io';
import 'dart:typed_data';

Future<Uint8List> loadFileBytes(String path) => File(path).readAsBytes();
