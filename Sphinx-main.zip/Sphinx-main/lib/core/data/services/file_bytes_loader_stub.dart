import 'dart:typed_data';

Future<Uint8List> loadFileBytes(String path) {
  throw UnsupportedError('File paths are not available on this platform');
}
