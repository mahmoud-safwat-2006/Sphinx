import 'package:supabase_flutter/supabase_flutter.dart' show PostgrestException;

typedef ClearLocalSupabaseSession = Future<void> Function();

/// Recovers the one invalid-session state that cannot be refreshed normally.
///
/// A stored JWT whose `iat` claim is ahead of the API server is rejected by
/// PostgREST with PGRST303. Clearing that local session lets the caller retry
/// as an anonymous client or start a new sign-in. Other authentication errors
/// are intentionally left untouched.
class SupabaseSessionRecovery {
  SupabaseSessionRecovery({required ClearLocalSupabaseSession clearLocalSession})
      : _clearLocalSession = clearLocalSession;

  final ClearLocalSupabaseSession _clearLocalSession;

  Future<T> run<T>(Future<T> Function() operation) async {
    try {
      return await operation();
    } on PostgrestException catch (error) {
      if (!isFutureIssuedJwt(error)) {
        rethrow;
      }

      await _clearLocalSession();
      return operation();
    }
  }

  static bool isFutureIssuedJwt(PostgrestException error) {
    return error.code == 'PGRST303' &&
        error.message.toLowerCase().contains('jwt issued at future');
  }
}
