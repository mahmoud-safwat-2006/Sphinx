import 'file_logger.dart';

class CrashLogger {
  static CrashLogger? _instance;
  static CrashLogger get instance => _instance ??= CrashLogger._();

  CrashLogger._();

  Future<void> initialize(String _) async {}

  static void logException(
    Object error, {
    StackTrace? stackTrace,
    String? context,
    bool isFatal = false,
  }) {
    FileLogger.error(
      context ?? 'Exception caught',
      error: error,
      stackTrace: stackTrace,
      source: isFatal ? 'Fatal' : 'Exception',
    );
  }

  static Future<void> cleanOldCrashDumps() async {}
}
