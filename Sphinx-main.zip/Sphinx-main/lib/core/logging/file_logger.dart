import 'package:flutter/foundation.dart';

enum LogLevel { debug, info, warning, error, critical }

class FileLogger {
  static FileLogger? _instance;
  static FileLogger get instance => _instance ??= FileLogger._();

  FileLogger._();

  Future<void> initialize(String _) async {}

  static void debug(String message, {String? source}) =>
      _write(LogLevel.debug, message, source: source);

  static void info(String message, {String? source}) =>
      _write(LogLevel.info, message, source: source);

  static void warning(String message, {Object? error, String? source}) =>
      _write(LogLevel.warning, message, error: error, source: source);

  static void error(String message,
          {Object? error, StackTrace? stackTrace, String? source}) =>
      _write(LogLevel.error, message,
          error: error, stackTrace: stackTrace, source: source);

  static void critical(String message,
          {Object? error, StackTrace? stackTrace, String? source}) =>
      _write(LogLevel.critical, message,
          error: error, stackTrace: stackTrace, source: source);

  static void _write(LogLevel level, String message,
      {Object? error, StackTrace? stackTrace, String? source}) {
    final prefix = source == null ? '' : '[$source] ';
    debugPrint('[${level.name.toUpperCase()}] $prefix$message');
    if (error != null) debugPrint('Error: $error');
    if (stackTrace != null) debugPrintStack(stackTrace: stackTrace);
  }
}
