import 'package:flutter/material.dart';

/// Palette derived from the Sphinx logo:
/// bold black silhouette on a soft grey field, Samsung blue accent.
class AppColors {
  // ─── Brand ──────────────────────────────────────────────────
  static const Color primaryColor = Color(0xFF0E0E0E);
  static const Color sidebarColor = Color(0xFF1A1A1A);
  static const Color primaryForeground = Colors.white;
  static const Color secondaryColor = Color(0xFF2C2C2E);
  static const Color accentColor = Color(0xFF3B48C6);

  // ─── Surfaces ───────────────────────────────────────────────
  static const Color backgroundColor = Color(0xFFF5F5F5);
  static const Color surfaceColor = Color(0xFFFFFFFF);
  static const Color cardColor = Color(0xFFFFFFFF);

  // ─── Status ─────────────────────────────────────────────────
  static const Color errorColor = Color(0xFFEF4444);
  static const Color successColor = Color(0xFF22C55E);
  static const Color warningColor = Color(0xFFF59E0B);
  static const Color infoColor = Color(0xFF1428A0);

  // ─── Text ───────────────────────────────────────────────────
  static const Color textPrimary = Color(0xFF0E0E0E);
  static const Color textOnPrimary = Colors.white;
  static const Color textSecondary = Color(0xFF3A3A3C);
  static const Color mutedColor = Color(0xFF8E8E93);
  static const Color borderColor = Color(0xFFE0E0E0);

  // ─── Input ──────────────────────────────────────────────────
  static const Color inputFill = Color(0xFFF5F5F5);
  static const Color inputBorder = Color(0xFFE0E0E0);
  static const Color inputFocusBorder = Color(0xFF0E0E0E);

  // ─── Chips / Badges ────────────────────────────────────────
  static const Color chipFill = Color(0xFFF0F0F0);
  static const Color chipActive = Color(0xFF0E0E0E);
  static const Color chipText = Color(0xFF3A3A3C);
  static const Color chipActiveText = Colors.white;

  // ─── Divider / Hairline ─────────────────────────────────────
  static const Color divider = Color(0xFFE0E0E0);

  // ─── Convenience aliases ───────────────────────────────────
  static const Color kPrimaryBlack = primaryColor;
  static const Color kAccentBlue = accentColor;
  static const Color kSuccessGreen = successColor;
  static const Color kDangerRed = errorColor;
  static const Color kCardBackground = cardColor;
  static const Color kDarkChip = primaryColor;
  static const Color accentGold = accentColor;
  static const Color darkGold = Color(0xFF0D1F7A);
}
