import 'package:sphinx/l10n/app_localizations.dart';

abstract final class ProductUnitLocalizer {
  static String name(
    AppLocalizations l10n, {
    required String name,
    required String abbreviation,
  }) {
    return switch (_normalize(abbreviation)) {
      'pc' => l10n.unitPieceName,
      'box' => l10n.unitBoxName,
      'dz' => l10n.unitDozenName,
      'g' => l10n.unitGramName,
      'kg' => l10n.unitKilogramName,
      'l' => l10n.unitLiterName,
      'm' => l10n.unitMeterName,
      'pack' => l10n.unitPackName,
      _ => name,
    };
  }

  static String abbreviation(
    AppLocalizations l10n,
    String? abbreviation,
  ) {
    final original = abbreviation?.trim() ?? '';
    return switch (_normalize(original)) {
      'pc' => l10n.unitPieceAbbreviation,
      'box' => l10n.unitBoxAbbreviation,
      'dz' => l10n.unitDozenAbbreviation,
      'g' => l10n.unitGramAbbreviation,
      'kg' => l10n.unitKilogramAbbreviation,
      'l' => l10n.unitLiterAbbreviation,
      'm' => l10n.unitMeterAbbreviation,
      'pack' => l10n.unitPackAbbreviation,
      _ => original,
    };
  }

  static String quantity(
    AppLocalizations l10n,
    double quantity,
    String? unitAbbreviation,
  ) {
    final unit = abbreviation(l10n, unitAbbreviation);
    final value = _formatQuantity(quantity);
    return unit.isEmpty ? value : '$value $unit';
  }

  static String _normalize(String value) => value.trim().toLowerCase();

  static String _formatQuantity(double value) {
    return value == value.truncateToDouble()
        ? value.toStringAsFixed(0)
        : value.toStringAsFixed(3).replaceFirst(RegExp(r'0+$'), '');
  }
}
