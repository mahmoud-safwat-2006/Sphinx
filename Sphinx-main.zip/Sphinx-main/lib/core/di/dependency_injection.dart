import 'package:sphinx/features/auth/data/repository/user_repository_imp.dart';
import 'package:sphinx/features/auth/domain/repository/user_repository_int.dart';
import 'package:sphinx/features/auth/presentation/cubit/user_cubit.dart';
import 'package:sphinx/features/products/data/repository/product_repository_imp.dart';
import 'package:sphinx/features/products/presentation/cubit/product_cubit.dart';
import 'package:sphinx/features/stock/presentation/cubit/stock_cubit.dart';
import '../../features/branches/presentation/cubit/branch_cubit.dart';
import '../../features/branches/data/repositories/branch_repository.dart';
import '../../features/invoice/presentation/cubit/invoice_cubit.dart';
import '../../features/pos/domain/pos_repository.dart';
import '../../features/stock_summary/presentation/cubit/stock_summary_cubit.dart';
import 'package:get_it/get_it.dart';

import '../../features/analytics/data/analytics_repository_impl.dart';
import '../../features/analytics/domain/analytics_repository.dart';
import '../../features/analytics/presentation/cubit/analytics_cubit.dart';
import '../../features/notifications/presentation/cubit/notifications_cubit.dart';
import '../../features/pos/data/repository/pos_repository_impl.dart';

import '../../features/pos/presentation/cubit/pos_cubit.dart';
import '../../features/settings/data/data_source/store_info_data_source.dart';
import '../../features/settings/data/repositories/cloud_data_repository.dart';
import '../../features/settings/data/repository/settings_repository_imp.dart';
import '../../features/settings/presentation/cubit/settings_cubit.dart';
import '../../features/shifts/data/repositories/shift_repository_impl.dart';
import '../../core/shifts/shift_manager.dart';
import '../../core/localization/locale_provider.dart';
import '../../core/data/services/supabase_service.dart';
import '../../features/shifts/domain/shift_repository.dart';
import '../../features/shifts/presentation/cubit/shift_cubit.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

final getIt = GetIt.instance;

void setup() {
  // Core Services
  getIt.registerSingleton<SupabaseService>(SupabaseService());
  getIt.registerSingleton<LocaleProvider>(LocaleProvider());

  // Branch Cubit (must be initialized after login with user data)
  getIt.registerSingleton<BranchCubit>(BranchCubit());
  getIt.registerSingleton<BranchRepository>(BranchRepository());
  getIt.registerSingleton<CloudDataRepository>(CloudDataRepository());

  // Repositories
  final shiftRepository = SessionRepositoryImpl(
    supabaseService: getIt<SupabaseService>(),
  );
  getIt.registerSingleton<SessionRepositoryImpl>(shiftRepository);
  getIt.registerSingleton<ShiftRepository>(shiftRepository);

  // Session Manager (wraps SessionRepositoryImpl)
  final sessionManager = SessionManager();
  sessionManager.initialize(getIt<SessionRepositoryImpl>());
  getIt.registerSingleton<SessionManager>(sessionManager);
  getIt.registerSingleton<ShiftCubit>(ShiftCubit(
    shiftRepository,
    currentUserId: () => Supabase.instance.client.auth.currentUser?.id,
  ));

  final userRepo = UserRepositoryImp();
  getIt.registerSingleton<UserRepositoryInt>(userRepo);

  getIt.registerSingleton<UserCubit>(UserCubit(
      userRepository: userRepo,
      sessionRepository: getIt<SessionRepositoryImpl>()));

  getIt.registerSingleton<ProductCubit>(
      ProductCubit(productRepositoryInt: ProductRepositoryImp()));

  final salesRepo = PosRepositoryImpl();

  getIt.registerSingleton<PosRepository>(salesRepo);
  getIt.registerSingleton<PosRepositoryImpl>(salesRepo);

  getIt.registerSingleton<PosCubit>(PosCubit(repository: salesRepo));

  getIt.registerSingleton<StockCubit>(
      StockCubit(productRepository: ProductRepositoryImp()));

  getIt.registerSingleton<InvoiceCubit>(InvoiceCubit(salesRepo));

  getIt.registerSingleton<NotificationsCubit>(NotificationsCubit());

  final analyticsRepo = AnalyticsRepositoryImpl();
  getIt.registerSingleton<AnalyticsRepository>(analyticsRepo);

  getIt.registerSingleton<AnalyticsCubit>(AnalyticsCubit(analyticsRepo));

  getIt.registerFactory<StockSummaryCubit>(() => StockSummaryCubit());

  final storeInfoRepo = StoreInfoRepository(
    dataSource: StoreInfoDataSource(),
  );
  getIt.registerSingleton<StoreInfoRepository>(storeInfoRepo);

  getIt.registerLazySingleton<SettingsCubit>(() => SettingsCubit(
        userCubit: getIt<UserCubit>(),
        storeRepository: storeInfoRepo,
      ));
}
