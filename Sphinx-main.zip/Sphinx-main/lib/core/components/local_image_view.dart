import 'dart:typed_data';
import 'package:flutter/material.dart';

class LocalImageView extends StatelessWidget {
  const LocalImageView({
    super.key,
    required this.path,
    required this.width,
    required this.height,
    required this.fallback,
    this.borderRadius = 12,
    this.fit = BoxFit.cover,
    this.bytes,
  });

  final String? path;
  final Uint8List? bytes;
  final double width;
  final double height;
  final Widget fallback;
  final double borderRadius;
  final BoxFit fit;

  @override
  Widget build(BuildContext context) {
    // Priority 1: raw bytes (just picked from gallery)
    if (bytes != null && bytes!.isNotEmpty) {
      return SizedBox(
        width: width,
        height: height,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(borderRadius),
          child: Image.memory(bytes!, width: width, height: height, fit: fit),
        ),
      );
    }

    // Priority 2: path (URL or local file)
    final imagePath = path?.trim();
    if (imagePath == null || imagePath.isEmpty) {
      return SizedBox(
        width: width,
        height: height,
        child: ClipRRect(
            borderRadius: BorderRadius.circular(borderRadius), child: fallback),
      );
    }

    // Network URL
    if (imagePath.startsWith('http://') || imagePath.startsWith('https://')) {
      return SizedBox(
        width: width,
        height: height,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(borderRadius),
          child: Image.network(
            imagePath,
            width: width,
            height: height,
            fit: fit,
            frameBuilder: (context, child, frame, wasSynchronouslyLoaded) {
              if (wasSynchronouslyLoaded || frame != null) return child;
              return const _ImageShimmer();
            },
            errorBuilder: (_, __, ___) => fallback,
          ),
        ),
      );
    }

    // Local file path — show fallback (bytes should be used instead)
    return SizedBox(
      width: width,
      height: height,
      child: ClipRRect(
          borderRadius: BorderRadius.circular(borderRadius), child: fallback),
    );
  }
}

class _ImageShimmer extends StatefulWidget {
  const _ImageShimmer();

  @override
  State<_ImageShimmer> createState() => _ImageShimmerState();
}

class _ImageShimmerState extends State<_ImageShimmer>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1100),
  )..repeat();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: _controller,
        builder: (context, child) => DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment(-1.5 + (_controller.value * 3), 0),
              end: Alignment(-0.5 + (_controller.value * 3), 0),
              colors: const [
                Color(0xFFE8EDF2),
                Color(0xFFF7F9FB),
                Color(0xFFE8EDF2),
              ],
            ),
          ),
        ),
      );
}
