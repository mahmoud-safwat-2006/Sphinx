import 'package:sphinx/core/constants/app_colors.dart';
import 'package:sphinx/core/utils/responsive_helper.dart';
import 'package:flutter/material.dart';

class MobileSurface extends StatelessWidget {
  const MobileSurface({
    super.key,
    required this.child,
    this.footer,
    this.padding,
  });

  final Widget child;
  final Widget? footer;
  final EdgeInsets? padding;

  @override
  Widget build(BuildContext context) {
    if (ResponsiveHelper.isDesktop(context)) return child;

    return ColoredBox(
      color: AppColors.backgroundColor,
      child: SafeArea(
        top: false,
        child: Padding(
          padding: padding ??
              EdgeInsets.fromLTRB(
                ResponsiveHelper.pageGutter(context),
                10,
                ResponsiveHelper.pageGutter(context),
                12,
              ),
          child: Column(
            children: [
              Expanded(child: child),
              if (footer != null) ...[
                const SizedBox(height: 10),
                footer!,
              ],
            ],
          ),
        ),
      ),
    );
  }
}
