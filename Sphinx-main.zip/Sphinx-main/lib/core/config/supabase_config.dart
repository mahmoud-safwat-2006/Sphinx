// lib/core/config/supabase_config.dart

/// Supabase Backend Credentials & Service Configuration.
///
/// Supply environment overrides at build-time using `--dart-define`:
/// `flutter run --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_PUBLISHABLE_KEY=...`
abstract class SupabaseConfig {
  static const String url = String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: 'https://vrgikyqtbwhqianspvbe.supabase.co',
  );

  static const String anonKey = String.fromEnvironment(
    'SUPABASE_PUBLISHABLE_KEY',
    defaultValue: 'sb_publishable_byJezS6fmuBuYRX5u-DzAg_kZ7QbHZ9',
  );

  static bool get isConfigured =>
      url.trim().isNotEmpty && anonKey.trim().isNotEmpty;
}
