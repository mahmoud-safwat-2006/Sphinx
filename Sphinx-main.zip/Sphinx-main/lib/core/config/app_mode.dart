import 'package:flutter/foundation.dart';

enum AppMode { debug, release }

class AppModeConfig {
  static AppMode get current => kDebugMode ? AppMode.debug : AppMode.release;
  static bool get isDebug => current == AppMode.debug;
  static bool get isRelease => current == AppMode.release;
}
