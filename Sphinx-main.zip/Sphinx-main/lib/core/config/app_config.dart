// lib/core/config/app_config.dart

class AppConfig {
  static const String appName = 'Sphinx';
  static const String version = String.fromEnvironment(
    'APP_VERSION',
    defaultValue: '1.0.0',
  );
  static const String environment = String.fromEnvironment(
    'APP_ENV',
    defaultValue: 'production',
  );
  static const bool enableRealtime = bool.fromEnvironment(
    'ENABLE_REALTIME',
    defaultValue: true,
  );
  static const int networkRetryAttempts = int.fromEnvironment(
    'NETWORK_RETRY_ATTEMPTS',
    defaultValue: 3,
  );

  static bool get isProduction => environment == 'production';
}
