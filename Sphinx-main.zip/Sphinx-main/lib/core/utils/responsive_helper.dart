import 'package:flutter/material.dart';

class ResponsiveHelper {
  static const double mobileBreakpoint = 600;
  static const double desktopBreakpoint = 1024;
  static const double minimumTouchTarget = 44;

  static bool isMobile(BuildContext context) =>
      MediaQuery.of(context).size.width < mobileBreakpoint;

  static bool isTablet(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return width >= mobileBreakpoint && width < desktopBreakpoint;
  }

  static bool isDesktop(BuildContext context) =>
      MediaQuery.of(context).size.width >= desktopBreakpoint;

  static bool isMobileOrTablet(BuildContext context) =>
      MediaQuery.of(context).size.width < desktopBreakpoint;

  static double screenWidth(BuildContext context) =>
      MediaQuery.of(context).size.width;

  static double screenHeight(BuildContext context) =>
      MediaQuery.of(context).size.height;

  static double pageGutter(BuildContext context) => isTablet(context) ? 24 : 16;

  static double sectionSpacing(BuildContext context) =>
      isTablet(context) ? 16 : 12;

  static double surfaceRadius(BuildContext context) =>
      isTablet(context) ? 16 : 12;

  static double fontSize(BuildContext context,
      {double mobile = 14, double tablet = 16, double desktop = 18}) {
    if (isDesktop(context)) return desktop;
    if (isTablet(context)) return tablet;
    return mobile;
  }

  static EdgeInsets padding(BuildContext context,
      {EdgeInsets? mobile, EdgeInsets? tablet, EdgeInsets? desktop}) {
    if (isDesktop(context)) {
      return desktop ??
          const EdgeInsets.symmetric(horizontal: 32, vertical: 20);
    } else if (isTablet(context)) {
      return tablet ?? const EdgeInsets.symmetric(horizontal: 24, vertical: 16);
    } else {
      return mobile ?? const EdgeInsets.symmetric(horizontal: 16, vertical: 12);
    }
  }

  static int gridCount(BuildContext context,
      {int mobile = 2, int tablet = 3, int desktop = 4}) {
    if (isDesktop(context)) return desktop;
    if (isTablet(context)) return tablet;
    return mobile;
  }

  /// Returns a suitable dialog width for the current screen size.
  /// On mobile: nearly full screen. On tablet: 460. On desktop: [desktop] (default 460).
  static double dialogWidth(BuildContext context, {double desktop = 460}) {
    final w = screenWidth(context);
    if (w < mobileBreakpoint) return w - 48;
    if (w < desktopBreakpoint) return 460;
    return desktop;
  }

  /// Returns a suitable dialog max width for the current screen size.
  static double dialogMaxWidth(BuildContext context, {double desktop = 960}) {
    final w = screenWidth(context);
    if (w < mobileBreakpoint) return w - 24;
    if (w < desktopBreakpoint) return w - 48;
    return desktop;
  }

  /// Returns a suitable table minimum width — allows horizontal scroll on mobile.
  static double tableMinWidth(BuildContext context, {double desktop = 800}) {
    final w = screenWidth(context);
    if (w < desktopBreakpoint) return w - 48;
    return desktop;
  }
}
