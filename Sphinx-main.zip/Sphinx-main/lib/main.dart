import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:sphinx/l10n/app_localizations.dart';
import 'package:sphinx/core/localization/locale_provider.dart';
import 'dart:async';

import 'core/constants/bloc_observer.dart';
import 'core/di/dependency_injection.dart';
import 'core/theme/app_theme.dart';
import 'core/components/message_overlay.dart';
import 'core/logging/file_logger.dart';
import 'core/logging/crash_logger.dart';
import 'features/splash/splash_screen.dart';
import 'features/auth/presentation/login_screen.dart';
import 'package:supabase_flutter/supabase_flutter.dart' hide User, Session;
import 'package:sphinx/core/config/supabase_config.dart';
import 'features/auth/presentation/cubit/user_cubit.dart';
import 'features/auth/presentation/cubit/user_states.dart';

// Conditional imports for platform-specific code
import 'main_desktop.dart' if (dart.library.html) 'main_stub.dart';

import 'package:device_preview/device_preview.dart';

const bool _devicePreviewEnabled = kDebugMode;

void main() async {
  // Wrap entire app in error zone to catch all async errors
  runZonedGuarded(
    () async {
      try {
        WidgetsFlutterBinding.ensureInitialized();

        // Initialize Supabase
        await Supabase.initialize(
          url: SupabaseConfig.url,
          anonKey: SupabaseConfig.anonKey,
        );

        // 1. Initialize Window Manager for Desktop (no-op on web/mobile)
        await setupDesktopWindow();

        Bloc.observer = MyBlocObserver();

        // 2. Setup Dependency Injection
        setup();

        // 4. Run App Directly
        FileLogger.info('App starting normally', source: 'Main');
        runApp(DevicePreview(
          enabled: _devicePreviewEnabled,
          builder: (context) => const MyApp(),
        ));
      } catch (e, stack) {
        FileLogger.critical('Critical startup error',
            error: e, stackTrace: stack, source: 'Main');
        CrashLogger.logException(e,
            stackTrace: stack, context: 'App startup', isFatal: true);

        runApp(MaterialApp(
          home: Scaffold(
            body: Center(
              child: SelectableText('Failed to start application: $e'),
            ),
          ),
        ));
      }
    },
    (error, stack) {
      // Catch all unhandled async errors

      FileLogger.critical('Unhandled async error',
          error: error, stackTrace: stack, source: 'ErrorZone');
      CrashLogger.logException(error,
          stackTrace: stack, context: 'Unhandled async error', isFatal: true);
    },
  );
}

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final localeProvider = getIt<LocaleProvider>();

    return ListenableBuilder(
      listenable: localeProvider,
      builder: (context, _) {
        return BlocProvider<UserCubit>.value(
          value: getIt<UserCubit>(),
          child: MessageOverlay(
            child: MaterialApp(
              navigatorKey: navigatorKey,
              title: 'Sphinx',
              debugShowCheckedModeBanner: false,
              theme: AppTheme.lightTheme,
              home: const SplashScreen(),
              routes: {
                '/login': (context) => const LoginScreen(),
              },
              locale: localeProvider.locale,
              supportedLocales: const [
                Locale('ar'),
                Locale('en'),
              ],
              localizationsDelegates: [
                AppLocalizations.delegate,
                GlobalMaterialLocalizations.delegate,
                GlobalWidgetsLocalizations.delegate,
                GlobalCupertinoLocalizations.delegate,
              ],
              builder: (context, child) {
                // Initialize global message context
                GlobalMessage.initialize(context);

                final app = BlocListener<UserCubit, UserStates>(
                  listener: (context, state) {
                    if (state is UserInitial) {
                      // Global logout handler
                      navigatorKey.currentState?.pushAndRemoveUntil(
                        MaterialPageRoute(builder: (_) => const LoginScreen()),
                        (route) => false,
                      );
                    }
                  },
                  child: Directionality(
                    textDirection: localeProvider.isArabic
                        ? TextDirection.rtl
                        : TextDirection.ltr,
                    child: child!,
                  ),
                );

                return _devicePreviewEnabled
                    ? DevicePreview.appBuilder(context, app)
                    : app;
              },
            ),
          ),
        );
      },
    );
  }
}
