# Changelog

All notable changes to the **Sphinx POS & Retail Management System** will be documented in this file.

---

## [1.0.0] - 2026-08-01

### 🚀 Added Features
- **Multi-Branch Scoping & Isolation**:
  - Implemented branch-level filtering across all repository queries (Shifts, Sales, Analytics, POS, Expenses, User Shifts).
  - Added All-Branches aggregated views for administrators in Products & Inventory summaries.
  - Implemented branch switch re-hydration across BLoCs/Cubits.
  - Protected POS checkout and shift opening when All Branches mode is selected.
- **User Management & Soft Delete RPC**:
  - Added `soft_delete_user` PostgreSQL stored procedure (`004_soft_delete_user.sql`) with `SECURITY DEFINER` execution to safely deactivate users without breaking foreign key references.
  - Updated User Management Card in Settings to support soft deletion and active status toggling.
  - Added admin password challenge protection for sensitive settings operations.
- **Invoices & Partial Refunds System**:
  - Added `InvoicePdfService` supporting custom brand logos, Sphinx corporate palette, QR metadata, and printable receipt documents.
  - Built interactive `PartialRefundDialog` for refunding select items from existing transactions with automatic inventory inventory adjustment and shift balance updates.
- **Daily Shift Reports & Cash Audits**:
  - Implemented `DailyReportPdfService` for rendering formatted shift reports detailing starting float, total cash sales, card sales, expenses, and drawer variance.
- **Offline & Network Resilience**:
  - Added `ConnectionBanner` overlay component with automatic Supabase connection status check (`SupabaseService.checkConnection`).
  - Integrated exponential backoff retry mechanism (`withTransientRetry`) and session recovery (`withSessionRecovery`).
- **Store Information Management**:
  - Added store profile management dialog and persistence for corporate branding on printed receipts and invoices.

### 🔒 Security & Backend Enhancements
- Created `.gitignore` excluding build artifacts, Dart caches, platform ephemeral builds, credentials, and environment overrides.
- Added `.env.example` template for build-time `--dart-define` configuration.
- Configured Supabase Row Level Security (RLS) policies for cross-branch user claim prevention (`20260728095422_prevent_cross_branch_user_claim.sql`).
- Fixed auth user UUID sync and identity creation for admin-provisioned cashier accounts (`20260728100051_complete_admin_created_auth_identity.sql`).

### 📚 Documentation & Quality Assurance
- Published comprehensive enterprise [README.md](README.md) with feature matrix, technology stack, directory structure, setup instructions, and architecture breakdown.
- Documented all 12 PostgreSQL SQL migration files in [supabase/README.md](supabase/README.md).
- Added `SupabaseConfig` unit test suite under `test/core/config/supabase_config_test.dart`.
