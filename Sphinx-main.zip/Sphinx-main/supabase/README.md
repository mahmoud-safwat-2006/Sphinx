# Sphinx Supabase Database Schema & Migrations

This directory contains the PostgreSQL SQL migration files for the **Sphinx POS & ERP Enterprise System**.

---

## 🗄 Migration History

| Migration File | Description |
|---|---|
| `001_initial_setup.sql` | Core database schema (users, branches, products, categories, sales, sale_items, shifts, expenses, store_settings). |
| `002_fix_rls_recursion.sql` | Resolves infinite recursion issues in PostgreSQL RLS policies for role checking. |
| `003_add_shift_rpcs.sql` | Atomic Stored Procedures (`open_shift`, `close_shift`, `complete_sale`) bypassing race conditions during transactions. |
| `004_soft_delete_user.sql` | RPC function (`soft_delete_user`) executing with `SECURITY DEFINER` to safely deactivate users without breaking foreign key references. |
| `20260728090514_branch_scope_hardening.sql` | Hardens branch-level isolation, ensuring users only access data matching their active branch scope. |
| `20260728095050_secure_user_branch_management.sql` | Administrative RPCs and policies for assigned branch management and user creation. |
| `20260728095253_restrict_branch_directory.sql` | Restricts full branch directory lookup to administrative roles. |
| `20260728095422_prevent_cross_branch_user_claim.sql` | Prevents non-admin cashiers from changing their branch assignment. |
| `20260728095755_fix_admin_create_user_auth_id.sql` | Syncs `auth.users` UUID creation with public `users` table records. |
| `20260728100051_complete_admin_created_auth_identity.sql` | Generates identity credentials securely for admin-created cashier accounts. |
| `20260728100209_fix_generated_identity_email.sql` | Normalizes email address generation for cashier accounts. |
| `20260728105955_secure_expense_and_shift_access.sql` | Enforces RLS policies on shift closing reports and expense entries by branch. |

---

## 🔐 Key Database Features

### 1. Atomic Transaction RPCs
- `open_shift(p_user_id, p_branch_id, p_starting_cash)`: Starts a new cashier session safely.
- `close_shift(p_shift_id, p_actual_ending_cash, p_notes)`: Closes shift, computes expected cash, and records variance.
- `complete_sale(p_shift_id, p_branch_id, p_items, ...)`: Atomically deducts inventory stock, creates sale record, and appends line items in a single transaction block.

### 2. User Deactivation RPC
- `soft_delete_user(target_username TEXT)`: Deactivates user accounts (`is_active = false`) while retaining historic sales and shift audit logs.

### 3. Multi-Tenant Branch Scoping
- Row Level Security (RLS) policies enforce strict branch boundaries: cashier and branch manager roles can only read and mutate records associated with their assigned `branch_id`.

---

## 🚀 How to Apply Migrations

To apply these migrations to your Supabase project:

1. Log into your [Supabase Dashboard](https://app.supabase.com).
2. Open the **SQL Editor**.
3. Execute each SQL file in chronological order (`001` through `20260728105955`).
4. Alternatively, apply using the Supabase CLI:
```bash
supabase db push
```
