drop policy if exists "Read branches" on public.branches;
drop policy if exists "Owner manages branches" on public.branches;

create policy branches_select_scoped
on public.branches
for select
to authenticated
using (
  (select public.is_current_user_primary_admin())
  or id = (select public.current_user_branch_id())
);

create policy branches_insert_primary_admin
on public.branches
for insert
to authenticated
with check ((select public.is_current_user_primary_admin()));

create policy branches_update_primary_admin
on public.branches
for update
to authenticated
using ((select public.is_current_user_primary_admin()))
with check ((select public.is_current_user_primary_admin()));

create policy branches_delete_primary_admin
on public.branches
for delete
to authenticated
using ((select public.is_current_user_primary_admin()));
