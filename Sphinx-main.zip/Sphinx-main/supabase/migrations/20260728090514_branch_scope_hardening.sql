-- Branch scope security, consistency, and query performance.

create or replace function public.is_current_user_primary_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select coalesce((
    select u.is_primary_admin
    from public.users u
    where u.id = (select auth.uid())
      and u.is_active = true
  ), false);
$$;

create or replace function public.current_user_branch_id()
returns uuid
language sql
stable
security definer
set search_path = ''
as $$
  select u.branch_id
  from public.users u
  where u.id = (select auth.uid())
    and u.is_active = true;
$$;

create or replace function public.can_access_branch(requested_branch_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select requested_branch_id is not null and exists (
    select 1
    from public.users u
    where u.id = (select auth.uid())
      and u.is_active = true
      and (
        u.is_primary_admin = true
        or u.branch_id = requested_branch_id
      )
  );
$$;

revoke all on function public.is_current_user_primary_admin() from public, anon;
revoke all on function public.current_user_branch_id() from public, anon;
revoke all on function public.can_access_branch(uuid) from public, anon;
grant execute on function public.is_current_user_primary_admin() to authenticated;
grant execute on function public.current_user_branch_id() to authenticated;
grant execute on function public.can_access_branch(uuid) to authenticated;

-- Backfill any legacy records before enforcing branch ownership.
do $$
declare
  main_branch_id uuid;
begin
  select b.id
    into main_branch_id
    from public.branches b
   where b.is_active = true
   order by b.is_main_branch desc, b.created_at
   limit 1;

  if main_branch_id is null then
    raise exception 'ACTIVE_MAIN_BRANCH_REQUIRED';
  end if;

  update public.branches
     set is_main_branch = (id = main_branch_id)
   where is_main_branch is distinct from (id = main_branch_id);

  update public.sales
     set branch_id = main_branch_id
   where branch_id is null;

  update public.sale_items si
     set branch_id = s.branch_id
    from public.sales s
   where si.sale_id = s.id
     and si.branch_id is null;

  update public.shifts
     set branch_id = main_branch_id
   where branch_id is null;

  update public.expenses e
     set branch_id = coalesce(s.branch_id, main_branch_id)
    from public.shifts s
   where e.shift_id = s.id
     and e.branch_id is null;

  update public.expenses
     set branch_id = main_branch_id
   where branch_id is null;

  update public.inventory_snapshots
     set branch_id = main_branch_id
   where branch_id is null;
end
$$;

alter table public.sales alter column branch_id set not null;
alter table public.sale_items alter column branch_id set not null;
alter table public.shifts alter column branch_id set not null;
alter table public.expenses alter column branch_id set not null;
alter table public.inventory_snapshots alter column branch_id set not null;

create unique index if not exists idx_branches_single_main
  on public.branches (is_main_branch)
  where is_main_branch = true;

-- Replace broad FOR ALL policies with explicit read/write checks.
do $$
declare
  table_name text;
  old_policy text;
begin
  foreach table_name in array array[
    'branch_stock',
    'sales',
    'sale_items',
    'shifts',
    'expenses',
    'inventory_snapshots'
  ]
  loop
    for old_policy in
      select policyname
        from pg_policies
       where schemaname = 'public'
         and tablename = table_name
    loop
      execute format(
        'drop policy if exists %I on public.%I',
        old_policy,
        table_name
      );
    end loop;

    execute format(
      'create policy %I on public.%I for select to authenticated using ((select public.can_access_branch(branch_id)))',
      table_name || '_branch_select',
      table_name
    );
    execute format(
      'create policy %I on public.%I for insert to authenticated with check ((select public.can_access_branch(branch_id)))',
      table_name || '_branch_insert',
      table_name
    );
    execute format(
      'create policy %I on public.%I for update to authenticated using ((select public.can_access_branch(branch_id))) with check ((select public.can_access_branch(branch_id)))',
      table_name || '_branch_update',
      table_name
    );
    execute format(
      'create policy %I on public.%I for delete to authenticated using ((select public.is_current_user_primary_admin()))',
      table_name || '_branch_delete',
      table_name
    );
  end loop;
end
$$;

drop policy if exists "Allow all access to authenticated users"
  on public.inventory_snapshot_items;
drop policy if exists inventory_snapshot_items_branch_select
  on public.inventory_snapshot_items;
drop policy if exists inventory_snapshot_items_branch_insert
  on public.inventory_snapshot_items;
drop policy if exists inventory_snapshot_items_branch_update
  on public.inventory_snapshot_items;
drop policy if exists inventory_snapshot_items_branch_delete
  on public.inventory_snapshot_items;

create policy inventory_snapshot_items_branch_select
on public.inventory_snapshot_items
for select to authenticated
using (
  exists (
    select 1
      from public.inventory_snapshots snapshot
     where snapshot.id = inventory_snapshot_items.snapshot_id
       and (select public.can_access_branch(snapshot.branch_id))
  )
);

create policy inventory_snapshot_items_branch_insert
on public.inventory_snapshot_items
for insert to authenticated
with check (
  exists (
    select 1
      from public.inventory_snapshots snapshot
     where snapshot.id = inventory_snapshot_items.snapshot_id
       and (select public.can_access_branch(snapshot.branch_id))
  )
);

create policy inventory_snapshot_items_branch_update
on public.inventory_snapshot_items
for update to authenticated
using (
  exists (
    select 1
      from public.inventory_snapshots snapshot
     where snapshot.id = inventory_snapshot_items.snapshot_id
       and (select public.can_access_branch(snapshot.branch_id))
  )
)
with check (
  exists (
    select 1
      from public.inventory_snapshots snapshot
     where snapshot.id = inventory_snapshot_items.snapshot_id
       and (select public.can_access_branch(snapshot.branch_id))
  )
);

create policy inventory_snapshot_items_branch_delete
on public.inventory_snapshot_items
for delete to authenticated
using ((select public.is_current_user_primary_admin()));

create index if not exists idx_sales_branch_created
  on public.sales (branch_id, created_at desc);
create index if not exists idx_sales_branch_session
  on public.sales (branch_id, session_id);
create index if not exists idx_shifts_branch_open_time
  on public.shifts (branch_id, is_open, open_time desc);
create index if not exists idx_expenses_branch_created
  on public.expenses (branch_id, created_at desc);
create index if not exists idx_sale_items_branch_product
  on public.sale_items (branch_id, product_id);
create index if not exists idx_snapshots_branch_created
  on public.inventory_snapshots (branch_id, created_at desc);

-- One bounded statistics endpoint avoids repeated client round trips.
create or replace function public.get_branch_statistics(
  branch_id_input uuid,
  start_input timestamptz,
  end_input timestamptz
)
returns jsonb
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  result jsonb;
begin
  if (select auth.uid()) is null then
    raise exception 'AUTHENTICATION_REQUIRED';
  end if;

  if branch_id_input is null then
    if not (select public.is_current_user_primary_admin()) then
      raise exception 'BRANCH_ACCESS_DENIED';
    end if;
  elsif not (select public.can_access_branch(branch_id_input)) then
    raise exception 'BRANCH_ACCESS_DENIED';
  end if;

  with sale_totals as (
    select
      coalesce(sum(s.total) filter (where s.invoice_type_index = 0), 0) as gross_sales,
      coalesce(sum(abs(s.total)) filter (where s.invoice_type_index = 1), 0) as refunds,
      count(*) as transaction_count
    from public.sales s
    where s.created_at >= start_input
      and s.created_at < end_input
      and (branch_id_input is null or s.branch_id = branch_id_input)
  ),
  expense_totals as (
    select coalesce(sum(e.amount), 0) as expenses
    from public.expenses e
    where e.created_at >= start_input
      and e.created_at < end_input
      and (branch_id_input is null or e.branch_id = branch_id_input)
  ),
  shift_totals as (
    select
      count(*) filter (where sh.is_open = true) as open_shifts,
      count(*) filter (where sh.is_open = false) as completed_shifts
    from public.shifts sh
    where branch_id_input is null or sh.branch_id = branch_id_input
  ),
  user_totals as (
    select count(*) as active_users
    from public.users u
    where u.is_active = true
      and (branch_id_input is null or u.branch_id = branch_id_input)
  ),
  stock_totals as (
    select
      count(*) as product_count,
      count(*) filter (where bs.quantity <= 0) as out_of_stock,
      count(*) filter (
        where bs.quantity > 0 and bs.quantity <= bs.min_quantity
      ) as low_stock,
      coalesce(sum(bs.quantity * p.price), 0) as stock_retail_value,
      coalesce(sum(bs.quantity * p.wholesale_price), 0) as stock_cost_value
    from public.branch_stock bs
    join public.products p on p.id = bs.product_id
    where branch_id_input is null or bs.branch_id = branch_id_input
  )
  select jsonb_build_object(
    'gross_sales', st.gross_sales,
    'refunds', st.refunds,
    'net_sales', st.gross_sales - st.refunds,
    'expenses', et.expenses,
    'estimated_profit', st.gross_sales - st.refunds - et.expenses,
    'transaction_count', st.transaction_count,
    'active_user_count', ut.active_users,
    'open_shift_count', sht.open_shifts,
    'completed_shift_count', sht.completed_shifts,
    'product_count', skt.product_count,
    'low_stock_count', skt.low_stock,
    'out_of_stock_count', skt.out_of_stock,
    'stock_retail_value', skt.stock_retail_value,
    'stock_cost_value', skt.stock_cost_value
  )
  into result
  from sale_totals st
  cross join expense_totals et
  cross join shift_totals sht
  cross join user_totals ut
  cross join stock_totals skt;

  return result;
end;
$$;

revoke all on function public.get_branch_statistics(
  uuid,
  timestamptz,
  timestamptz
) from public, anon;
grant execute on function public.get_branch_statistics(
  uuid,
  timestamptz,
  timestamptz
) to authenticated;

-- Remove anonymous access from privileged mutation RPCs. PIN verification is
-- intentionally left unchanged because it is part of the existing pre-auth
-- login flow and needs a separate authentication redesign.
revoke all on function public.admin_create_user(
  text, text, text, text, text, text, uuid
) from public, anon;
revoke all on function public.admin_update_user(
  uuid, text, text, text, text, boolean, uuid
) from public, anon;
revoke all on function public.open_shift(numeric, uuid) from public, anon;
revoke all on function public.close_shift(uuid, numeric) from public, anon;
revoke all on function public.complete_sale(jsonb, jsonb) from public, anon;
revoke all on function public.create_branch_with_stock(text, text, text)
  from public, anon;
revoke all on function public.finalize_inventory_snapshot(uuid)
  from public, anon;
revoke all on function public.set_user_permission_overrides(uuid, jsonb)
  from public, anon;
revoke all on function public.set_user_pin(uuid, text) from public, anon;

grant execute on function public.admin_create_user(
  text, text, text, text, text, text, uuid
) to authenticated;
grant execute on function public.admin_update_user(
  uuid, text, text, text, text, boolean, uuid
) to authenticated;
grant execute on function public.open_shift(numeric, uuid) to authenticated;
grant execute on function public.close_shift(uuid, numeric) to authenticated;
grant execute on function public.complete_sale(jsonb, jsonb) to authenticated;
grant execute on function public.create_branch_with_stock(text, text, text)
  to authenticated;
grant execute on function public.finalize_inventory_snapshot(uuid)
  to authenticated;
grant execute on function public.set_user_permission_overrides(uuid, jsonb)
  to authenticated;
grant execute on function public.set_user_pin(uuid, text) to authenticated;

alter function public.update_updated_at() set search_path = '';
