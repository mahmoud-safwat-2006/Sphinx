-- ============================================================
-- 003 – RPC functions: open_shift, close_shift, complete_sale
-- ============================================================

-- ─── open_shift ──────────────────────────────────────────────
CREATE OR REPLACE FUNCTION public.open_shift(
  opening_cash_input NUMERIC,
  branch_id_input    UUID DEFAULT NULL
)
RETURNS SETOF public.shifts
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_user_id   UUID := auth.uid();
  v_next_num  INTEGER;
  v_branch    UUID;
BEGIN
  -- Block if user already has an open shift in this branch
  v_branch := COALESCE(branch_id_input, (
    SELECT branch_id FROM public.users WHERE id = v_user_id
  ));

  IF EXISTS (
    SELECT 1 FROM public.shifts
    WHERE user_id = v_user_id AND is_open = true
      AND branch_id IS NOT DISTINCT FROM v_branch
  ) THEN
    RAISE EXCEPTION 'SHIFT_ALREADY_OPEN';
  END IF;

  -- Auto-increment session number per user+branch
  SELECT COALESCE(MAX(session_number), 0) + 1
    INTO v_next_num
    FROM public.shifts
   WHERE user_id = v_user_id
     AND branch_id IS NOT DISTINCT FROM v_branch;

  RETURN QUERY
  INSERT INTO public.shifts (
    user_id, session_number, opening_cash, is_open, branch_id
  ) VALUES (
    v_user_id, v_next_num, opening_cash_input, true, v_branch
  )
  RETURNING *;
END;
$$;

-- ─── close_shift ─────────────────────────────────────────────
CREATE OR REPLACE FUNCTION public.close_shift(
  shift_id_input     UUID,
  closing_cash_input NUMERIC
)
RETURNS SETOF public.shifts
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_shift       public.shifts%ROWTYPE;
  v_cash_sales  NUMERIC := 0;
  v_card_sales  NUMERIC := 0;
  v_cash_ref    NUMERIC := 0;
  v_card_ref    NUMERIC := 0;
  v_expenses    NUMERIC := 0;
  v_net         NUMERIC;
BEGIN
  SELECT * INTO v_shift
    FROM public.shifts
   WHERE id = shift_id_input AND is_open = true;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'SHIFT_NOT_FOUND';
  END IF;

  -- Aggregate sales for this shift
  SELECT
    COALESCE(SUM(CASE WHEN payment_method != 'card' AND invoice_type_index = 0 THEN total ELSE 0 END), 0),
    COALESCE(SUM(CASE WHEN payment_method = 'card'  AND invoice_type_index = 0 THEN total ELSE 0 END), 0),
    COALESCE(SUM(CASE WHEN payment_method != 'card' AND invoice_type_index = 1 THEN total ELSE 0 END), 0),
    COALESCE(SUM(CASE WHEN payment_method = 'card'  AND invoice_type_index = 1 THEN total ELSE 0 END), 0)
  INTO v_cash_sales, v_card_sales, v_cash_ref, v_card_ref
  FROM public.sales
  WHERE session_id = shift_id_input;

  -- Aggregate expenses
  SELECT COALESCE(SUM(amount), 0) INTO v_expenses
    FROM public.expenses
   WHERE shift_id = shift_id_input;

  v_net := v_shift.opening_cash + v_cash_sales - v_cash_ref - v_expenses;

  RETURN QUERY
  UPDATE public.shifts SET
    is_open              = false,
    close_time           = NOW(),
    closed_by            = auth.uid(),
    closing_cash         = closing_cash_input,
    cash_sales           = v_cash_sales,
    card_sales           = v_card_sales,
    cash_refunds         = v_cash_ref,
    card_refunds         = v_card_ref,
    cash_expenses        = v_expenses,
    system_expected_cash = v_net,
    cash_difference      = closing_cash_input - v_net
  WHERE id = shift_id_input
  RETURNING *;
END;
$$;

-- ─── complete_sale ───────────────────────────────────────────
-- Inserts a sale + sale_items and decrements branch_stock atomically.
CREATE OR REPLACE FUNCTION public.complete_sale(
  sale_input   JSONB,
  items_input  JSONB
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_sale_id       UUID;
  v_branch_id     UUID;
  v_item          JSONB;
  v_item_count    INTEGER := 0;
  v_product_id    UUID;
  v_qty           NUMERIC;
  v_result        JSONB;
BEGIN
  v_sale_id   := (sale_input->>'id')::UUID;
  v_branch_id := sale_input->>'branch_id';

  -- 1. Insert the sale row
  INSERT INTO public.sales (
    id, total, subtotal, discount_amount, discount_type, discount_value,
    items, cashier_name, cashier_user_id, session_id,
    invoice_type_index, refund_original_invoice_id,
    payment_method, notes, branch_id, created_at
  ) VALUES (
    v_sale_id,
    (sale_input->>'total')::NUMERIC,
    COALESCE((sale_input->>'subtotal')::NUMERIC, 0),
    COALESCE((sale_input->>'discount_amount')::NUMERIC, 0),
    COALESCE(sale_input->>'discount_type', 'none'),
    COALESCE((sale_input->>'discount_value')::NUMERIC, 0),
    jsonb_array_length(items_input),
    sale_input->>'cashier_name',
    (sale_input->>'user_id')::UUID,
    (sale_input->>'session_id')::UUID,
    0,
    NULL,
    COALESCE(sale_input->>'payment_method', 'cash'),
    sale_input->>'notes',
    v_branch_id,
    COALESCE((sale_input->>'created_at')::TIMESTAMPTZ, NOW())
  );

  -- 2. Insert sale_items and decrement branch_stock
  FOR v_item IN SELECT * FROM jsonb_array_elements(items_input)
  LOOP
    v_item_count := v_item_count + 1;
    v_product_id := (v_item->>'product_id')::UUID;
    v_qty        := (v_item->>'quantity')::NUMERIC;

    INSERT INTO public.sale_items (
      sale_id, product_id, product_barcode, name,
      price, sale_price, quantity, total,
      wholesale_price, item_discount, unit_abbreviation,
      branch_id, created_at
    ) VALUES (
      v_sale_id,
      v_product_id,
      v_item->>'product_barcode',
      v_item->>'name',
      (v_item->>'price')::NUMERIC,
      COALESCE((v_item->>'sale_price')::NUMERIC, (v_item->>'price')::NUMERIC),
      v_qty,
      (v_item->>'total')::NUMERIC,
      COALESCE((v_item->>'wholesale_price')::NUMERIC, 0),
      COALESCE((v_item->>'item_discount')::NUMERIC, 0),
      COALESCE(v_item->>'unit_abbreviation', ''),
      v_branch_id,
      NOW()
    );

    -- Decrement branch_stock
    IF v_branch_id IS NOT NULL THEN
      UPDATE public.branch_stock
         SET quantity = GREATEST(quantity - v_qty, 0)
       WHERE branch_id = v_branch_id
         AND product_id = v_product_id;
    END IF;
  END LOOP;

  -- 3. Return the created sale
  SELECT row_to_json(s.*) INTO v_result
    FROM public.sales s WHERE s.id = v_sale_id;

  RETURN v_result;
END;
$$;
