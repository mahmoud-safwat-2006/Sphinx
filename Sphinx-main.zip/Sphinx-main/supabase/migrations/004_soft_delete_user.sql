-- ============================================================
-- 004 – Soft delete user RPC (bypasses RLS via SECURITY DEFINER)
-- ============================================================

CREATE OR REPLACE FUNCTION public.soft_delete_user(target_username TEXT)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  UPDATE public.users
  SET is_active = false
  WHERE username = target_username;
END;
$$;

REVOKE ALL ON FUNCTION public.soft_delete_user(TEXT) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.soft_delete_user(TEXT) TO authenticated;
