alter table public.users
  drop constraint if exists users_primary_branch_check;

alter table public.users
  add constraint users_primary_branch_check
  check (
    (is_primary_admin = true and branch_id is null)
    or
    (is_primary_admin = false and branch_id is not null)
  ) not valid;

alter table public.users validate constraint users_primary_branch_check;

create or replace function public.is_current_user_user_manager()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.users caller
    where caller.id = (select auth.uid())
      and caller.is_active = true
      and (
        caller.is_primary_admin = true
        or caller.role in ('admin', 'manager')
      )
  );
$$;

create or replace function public.current_user_can_create_user(
  requested_branch_id uuid,
  requested_role text
)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.users caller
    join public.branches requested_branch
      on requested_branch.id = requested_branch_id
     and requested_branch.is_active = true
    where caller.id = (select auth.uid())
      and caller.is_active = true
      and requested_role in (
        'admin', 'manager', 'accountant', 'cashier', 'employee'
      )
      and (
        caller.is_primary_admin = true
        or (
          caller.role = 'admin'
          and caller.branch_id = requested_branch_id
        )
        or (
          caller.role = 'manager'
          and caller.branch_id = requested_branch_id
          and requested_role in ('accountant', 'cashier', 'employee')
        )
      )
  );
$$;

create or replace function public.current_user_can_manage_user(
  target_user_id uuid,
  target_branch_id uuid,
  target_is_primary_admin boolean,
  target_role text
)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select
    target_user_id is not null
    and target_user_id <> (select auth.uid())
    and coalesce(target_is_primary_admin, false) = false
    and target_branch_id is not null
    and exists (
      select 1
      from public.users caller
      join public.branches target_branch
        on target_branch.id = target_branch_id
       and target_branch.is_active = true
      where caller.id = (select auth.uid())
        and caller.is_active = true
        and (
          caller.is_primary_admin = true
          or (
            caller.role = 'admin'
            and caller.branch_id = target_branch_id
          )
          or (
            caller.role = 'manager'
            and caller.branch_id = target_branch_id
            and target_role in ('accountant', 'cashier', 'employee')
          )
        )
    );
$$;

revoke all on function public.is_current_user_user_manager()
  from public, anon;
revoke all on function public.current_user_can_create_user(uuid, text)
  from public, anon;
revoke all on function public.current_user_can_manage_user(
  uuid, uuid, boolean, text
) from public, anon;

grant execute on function public.is_current_user_user_manager()
  to authenticated;
grant execute on function public.current_user_can_create_user(uuid, text)
  to authenticated;
grant execute on function public.current_user_can_manage_user(
  uuid, uuid, boolean, text
) to authenticated;

drop policy if exists "Branch-scoped users read" on public.users;
drop policy if exists "Owner manages users" on public.users;
drop policy if exists "Owner updates users" on public.users;
drop policy if exists "Owner deletes users" on public.users;

create policy users_select_scoped
on public.users
for select
to authenticated
using (
  id = (select auth.uid())
  or (select public.is_current_user_primary_admin())
  or (
    (select public.is_current_user_user_manager())
    and branch_id = (select public.current_user_branch_id())
    and is_primary_admin = false
  )
);

create policy users_update_scoped
on public.users
for update
to authenticated
using (
  (select public.current_user_can_manage_user(
    id, branch_id, is_primary_admin, role
  ))
)
with check (
  (select public.current_user_can_manage_user(
    id, branch_id, is_primary_admin, role
  ))
);

create policy users_delete_scoped
on public.users
for delete
to authenticated
using (
  (select public.current_user_can_manage_user(
    id, branch_id, is_primary_admin, role
  ))
);

drop policy if exists "Allow all access to authenticated users"
  on public.user_permission_overrides;

create policy permission_overrides_select_scoped
on public.user_permission_overrides
for select
to authenticated
using (
  user_id = (select auth.uid())
  or exists (
    select 1
    from public.users target
    where target.id = user_id
      and (
        (select public.is_current_user_primary_admin())
        or (
          (select public.is_current_user_user_manager())
          and target.branch_id = (select public.current_user_branch_id())
          and target.is_primary_admin = false
        )
      )
  )
);

drop function if exists public.admin_create_user(
  text, text, text, text, text, text, uuid
);

create function public.admin_create_user(
  email_input text,
  password_input text,
  username_input text,
  display_name_input text default '',
  phone_input text default '',
  role_input text default 'cashier',
  branch_id_input uuid default null
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  new_user_id uuid;
begin
  if not (select public.current_user_can_create_user(
    branch_id_input, role_input
  )) then
    raise exception 'USER_BRANCH_MANAGEMENT_FORBIDDEN'
      using errcode = '42501';
  end if;

  if nullif(trim(email_input), '') is null
     or nullif(trim(username_input), '') is null
     or nullif(password_input, '') is null then
    raise exception 'USER_REQUIRED_FIELDS_MISSING'
      using errcode = '22023';
  end if;

  select auth_user.id
    into new_user_id
  from auth.users auth_user
  where lower(auth_user.email) = lower(email_input)
  limit 1;

  if new_user_id is null then
    insert into auth.users (
      email,
      encrypted_password,
      email_confirmed_at,
      raw_user_meta_data
    )
    values (
      lower(trim(email_input)),
      extensions.crypt(password_input, extensions.gen_salt('bf')),
      now(),
      jsonb_build_object('username', trim(username_input))
    )
    returning id into new_user_id;
  end if;

  insert into public.users (
    id,
    username,
    display_name,
    phone,
    role,
    branch_id,
    is_primary_admin,
    is_active
  )
  values (
    new_user_id,
    trim(username_input),
    trim(display_name_input),
    trim(phone_input),
    role_input,
    branch_id_input,
    false,
    true
  )
  on conflict (id) do update set
    username = excluded.username,
    display_name = excluded.display_name,
    phone = excluded.phone,
    role = excluded.role,
    branch_id = excluded.branch_id,
    is_primary_admin = false,
    is_active = true,
    updated_at = now();

  return new_user_id;
end;
$$;

drop function if exists public.admin_update_user(
  uuid, text, text, text, text, boolean, uuid
);

create function public.admin_update_user(
  user_id_input uuid,
  password_input text default null,
  display_name_input text default '',
  phone_input text default '',
  role_input text default 'cashier',
  is_active_input boolean default true,
  branch_id_input uuid default null
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  target public.users%rowtype;
  self_update boolean;
begin
  select *
    into target
  from public.users
  where id = user_id_input;

  if not found then
    raise exception 'USER_NOT_FOUND' using errcode = 'P0002';
  end if;

  self_update := user_id_input = (select auth.uid());

  if self_update then
    if role_input is distinct from target.role
       or branch_id_input is distinct from target.branch_id
       or is_active_input is distinct from target.is_active then
      raise exception 'SELF_AUTHORIZATION_CHANGE_FORBIDDEN'
        using errcode = '42501';
    end if;
  elsif not (
    (select public.current_user_can_manage_user(
      target.id,
      target.branch_id,
      target.is_primary_admin,
      target.role
    ))
    and
    (select public.current_user_can_manage_user(
      target.id,
      branch_id_input,
      false,
      role_input
    ))
  ) then
    raise exception 'USER_BRANCH_MANAGEMENT_FORBIDDEN'
      using errcode = '42501';
  end if;

  if password_input is not null and password_input <> '' then
    update auth.users
       set encrypted_password =
         extensions.crypt(password_input, extensions.gen_salt('bf'))
     where id = user_id_input;
  end if;

  update public.users
     set display_name = trim(display_name_input),
         phone = trim(phone_input),
         role = role_input,
         is_active = is_active_input,
         branch_id = branch_id_input,
         updated_at = now()
   where id = user_id_input;
end;
$$;

create or replace function public.set_user_avatar(
  target_user_id uuid,
  avatar_url_input text
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  target public.users%rowtype;
begin
  select *
    into target
  from public.users
  where id = target_user_id;

  if not found then
    raise exception 'USER_NOT_FOUND' using errcode = 'P0002';
  end if;

  if target_user_id <> (select auth.uid())
     and not (select public.current_user_can_manage_user(
       target.id,
       target.branch_id,
       target.is_primary_admin,
       target.role
     )) then
    raise exception 'USER_BRANCH_MANAGEMENT_FORBIDDEN'
      using errcode = '42501';
  end if;

  update public.users
     set avatar_url = nullif(trim(avatar_url_input), ''),
         updated_at = now()
   where id = target_user_id;
end;
$$;

create or replace function public.set_user_permission_overrides(
  target_user_id uuid,
  overrides jsonb default '{}'::jsonb
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  target public.users%rowtype;
  permission_key text;
  permission_value boolean;
begin
  select *
    into target
  from public.users
  where id = target_user_id;

  if not found then
    raise exception 'USER_NOT_FOUND' using errcode = 'P0002';
  end if;

  if target.is_primary_admin
     or not (
       (select public.is_current_user_primary_admin())
       or (
         exists (
           select 1
           from public.users caller
           where caller.id = (select auth.uid())
             and caller.is_active = true
             and caller.role = 'admin'
             and caller.branch_id = target.branch_id
         )
       )
     ) then
    raise exception 'USER_PERMISSION_MANAGEMENT_FORBIDDEN'
      using errcode = '42501';
  end if;

  delete from public.user_permission_overrides
   where user_id = target_user_id;

  for permission_key, permission_value in
    select item.key, (item.value #>> '{}')::boolean
    from jsonb_each(overrides) item
  loop
    if permission_key not in (
      'posCheckout',
      'viewInvoices',
      'deleteInvoices',
      'manageProducts',
      'viewReports',
      'manageUsers',
      'assignRoles',
      'viewAnalytics',
      'storeSettings',
      'dataManagement',
      'manageUnits',
      'applyDiscounts',
      'processRefunds'
    ) then
      raise exception 'UNKNOWN_PERMISSION: %', permission_key
        using errcode = '22023';
    end if;

    insert into public.user_permission_overrides (
      user_id, permission, allowed
    )
    values (target_user_id, permission_key, permission_value)
    on conflict (user_id, permission)
    do update set allowed = excluded.allowed;
  end loop;
end;
$$;

create or replace function public.set_user_pin(
  target_user_id uuid,
  pin_code text default ''
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  target public.users%rowtype;
begin
  select *
    into target
  from public.users
  where id = target_user_id;

  if not found then
    raise exception 'USER_NOT_FOUND' using errcode = 'P0002';
  end if;

  if target_user_id <> (select auth.uid())
     and not (select public.current_user_can_manage_user(
       target.id,
       target.branch_id,
       target.is_primary_admin,
       target.role
     )) then
    raise exception 'USER_BRANCH_MANAGEMENT_FORBIDDEN'
      using errcode = '42501';
  end if;

  if pin_code <> '' and pin_code !~ '^[0-9]{6}$' then
    raise exception 'PIN_MUST_BE_SIX_DIGITS'
      using errcode = '22023';
  end if;

  update public.users
     set pin_hash = case
       when pin_code = '' then ''
       else extensions.crypt(pin_code, extensions.gen_salt('bf'))
     end,
         updated_at = now()
   where id = target_user_id;
end;
$$;

create or replace function public.verify_user_pin_only(pin_code text)
returns table(user_id uuid, verified boolean)
language plpgsql
security definer
set search_path = ''
as $$
declare
  matched_user_id uuid;
  stored_pin text;
begin
  if pin_code !~ '^[0-9]{6}$' then
    return query select null::uuid, false;
    return;
  end if;

  select user_row.id, user_row.pin_hash
    into matched_user_id, stored_pin
  from public.users user_row
  where user_row.is_active = true
    and (
      user_row.pin_hash = pin_code
      or (
        user_row.pin_hash like '$2%'
        and user_row.pin_hash =
          extensions.crypt(pin_code, user_row.pin_hash)
      )
    )
  limit 1;

  if matched_user_id is null then
    return query select null::uuid, false;
    return;
  end if;

  if stored_pin = pin_code then
    update public.users
       set pin_hash = extensions.crypt(
         pin_code, extensions.gen_salt('bf')
       ),
           updated_at = now()
     where id = matched_user_id;
  end if;

  return query select matched_user_id, true;
end;
$$;

revoke all on function public.admin_create_user(
  text, text, text, text, text, text, uuid
) from public, anon;
revoke all on function public.admin_update_user(
  uuid, text, text, text, text, boolean, uuid
) from public, anon;
revoke all on function public.set_user_avatar(uuid, text)
  from public, anon;
revoke all on function public.set_user_permission_overrides(uuid, jsonb)
  from public, anon;
revoke all on function public.set_user_pin(uuid, text)
  from public, anon;

grant execute on function public.admin_create_user(
  text, text, text, text, text, text, uuid
) to authenticated;
grant execute on function public.admin_update_user(
  uuid, text, text, text, text, boolean, uuid
) to authenticated;
grant execute on function public.set_user_avatar(uuid, text)
  to authenticated;
grant execute on function public.set_user_permission_overrides(uuid, jsonb)
  to authenticated;
grant execute on function public.set_user_pin(uuid, text)
  to authenticated;
