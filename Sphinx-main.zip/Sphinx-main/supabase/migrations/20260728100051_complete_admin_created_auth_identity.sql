create or replace function public.admin_create_user(
  email_input text,
  password_input text,
  username_input text,
  display_name_input text default '',
  phone_input text default '',
  role_input text default 'cashier',
  branch_id_input uuid default null
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  new_user_id uuid;
  normalized_email text;
begin
  if not (select public.current_user_can_create_user(
    branch_id_input, role_input
  )) then
    raise exception 'USER_BRANCH_MANAGEMENT_FORBIDDEN'
      using errcode = '42501';
  end if;

  if nullif(trim(email_input), '') is null
     or nullif(trim(username_input), '') is null
     or nullif(password_input, '') is null then
    raise exception 'USER_REQUIRED_FIELDS_MISSING'
      using errcode = '22023';
  end if;

  normalized_email := lower(trim(email_input));

  if exists (
    select 1
    from public.users existing_profile
    where lower(existing_profile.username) = lower(trim(username_input))
  ) or exists (
    select 1
    from auth.users existing_auth
    where lower(existing_auth.email) = normalized_email
  ) then
    raise exception 'USER_ALREADY_EXISTS'
      using errcode = '23505';
  end if;

  new_user_id := extensions.gen_random_uuid();

  insert into auth.users (
    instance_id,
    id,
    aud,
    role,
    email,
    encrypted_password,
    email_confirmed_at,
    raw_app_meta_data,
    raw_user_meta_data,
    created_at,
    updated_at
  )
  values (
    '00000000-0000-0000-0000-000000000000'::uuid,
    new_user_id,
    'authenticated',
    'authenticated',
    normalized_email,
    extensions.crypt(password_input, extensions.gen_salt('bf')),
    now(),
    jsonb_build_object(
      'provider', 'email',
      'providers', jsonb_build_array('email')
    ),
    jsonb_build_object('username', trim(username_input)),
    now(),
    now()
  );

  insert into auth.identities (
    provider_id,
    user_id,
    identity_data,
    provider,
    last_sign_in_at,
    created_at,
    updated_at,
    email
  )
  values (
    new_user_id::text,
    new_user_id,
    jsonb_build_object(
      'sub', new_user_id::text,
      'email', normalized_email,
      'email_verified', true,
      'phone_verified', false
    ),
    'email',
    now(),
    now(),
    now(),
    normalized_email
  );

  insert into public.users (
    id,
    username,
    display_name,
    phone,
    role,
    branch_id,
    is_primary_admin,
    is_active
  )
  values (
    new_user_id,
    trim(username_input),
    trim(display_name_input),
    trim(phone_input),
    role_input,
    branch_id_input,
    false,
    true
  );

  return new_user_id;
end;
$$;

revoke all on function public.admin_create_user(
  text, text, text, text, text, text, uuid
) from public, anon;

grant execute on function public.admin_create_user(
  text, text, text, text, text, text, uuid
) to authenticated;
