-- Fix infinite recursion in users RLS policies
-- The policies on the users table queried users itself to check is_primary_admin,
-- causing infinite recursion. SECURITY DEFINER functions bypass RLS to break the cycle.

-- Helper: check if current user is primary admin (bypasses RLS)
CREATE OR REPLACE FUNCTION public.is_current_user_primary_admin()
RETURNS BOOLEAN AS $$
  SELECT COALESCE(
    (SELECT is_primary_admin FROM public.users WHERE id = auth.uid()),
    false
  );
$$ LANGUAGE sql SECURITY DEFINER STABLE;

-- Helper: get current user's branch_id (bypasses RLS)
CREATE OR REPLACE FUNCTION public.current_user_branch_id()
RETURNS UUID AS $$
  SELECT branch_id FROM public.users WHERE id = auth.uid();
$$ LANGUAGE sql SECURITY DEFINER STABLE;

-- Drop and recreate all policies on users
DROP POLICY IF EXISTS "Branch-scoped users read" ON users;
DROP POLICY IF EXISTS "Owner manages users" ON users;
DROP POLICY IF EXISTS "Owner updates users" ON users;
DROP POLICY IF EXISTS "Owner deletes users" ON users;

CREATE POLICY "Branch-scoped users read" ON users
  FOR SELECT USING (
    public.is_current_user_primary_admin()
    OR branch_id = public.current_user_branch_id()
    OR id = auth.uid()
  );
CREATE POLICY "Owner manages users" ON users
  FOR INSERT WITH CHECK (
    -- Allow first user when table is empty (initial setup)
    (SELECT count(*) FROM public.users) = 0
    OR public.is_current_user_primary_admin()
  );
CREATE POLICY "Owner updates users" ON users
  FOR UPDATE USING (
    public.is_current_user_primary_admin() OR id = auth.uid()
  );
CREATE POLICY "Owner deletes users" ON users
  FOR DELETE USING (
    public.is_current_user_primary_admin()
  );

-- Drop and recreate all policies on branches (also referenced users directly)
DROP POLICY IF EXISTS "Owner manages branches" ON branches;

CREATE POLICY "Owner manages branches" ON branches
  FOR ALL USING (public.is_current_user_primary_admin());

-- Storage policies: allow authenticated users to upload/read assets
-- First create the bucket if it doesn't exist
INSERT INTO storage.buckets (id, name, public)
VALUES ('assets', 'assets', true)
ON CONFLICT (id) DO NOTHING;

-- Allow authenticated users to upload to assets bucket
DROP POLICY IF EXISTS "Authenticated upload assets" ON storage.objects;
CREATE POLICY "Authenticated upload assets" ON storage.objects
  FOR INSERT WITH CHECK (
    bucket_id = 'assets' AND auth.role() = 'authenticated'
  );

-- Allow public read access to assets bucket
DROP POLICY IF EXISTS "Public read assets" ON storage.objects;
CREATE POLICY "Public read assets" ON storage.objects
  FOR SELECT USING (
    bucket_id = 'assets'
  );

-- Allow authenticated users to update their own uploads
DROP POLICY IF EXISTS "Authenticated update assets" ON storage.objects;
CREATE POLICY "Authenticated update assets" ON storage.objects
  FOR UPDATE USING (
    bucket_id = 'assets' AND auth.role() = 'authenticated'
  );

-- ─── PIN verification function (missing) ─────────────────────
CREATE OR REPLACE FUNCTION public.verify_user_pin_only(pin_code TEXT)
RETURNS TABLE(user_id UUID, verified BOOLEAN) AS $$
BEGIN
  RETURN QUERY
  SELECT u.id, true
  FROM public.users u
  WHERE u.pin_hash = pin_code
    AND u.is_active = true
  LIMIT 1;

  -- If no row found, return false
  IF NOT FOUND THEN
    user_id := NULL;
    verified := false;
    RETURN NEXT;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ─── Enable Realtime on shifts table ─────────────────────────
ALTER PUBLICATION supabase_realtime ADD TABLE shifts;
