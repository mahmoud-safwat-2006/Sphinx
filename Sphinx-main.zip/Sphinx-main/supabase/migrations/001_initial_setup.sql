-- ============================================================
-- Sphinx POS – Initial Database Setup (with Multi-Branch)
-- ============================================================

-- ─── Extensions ─────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ─── Helper: updated_at trigger ─────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- 1. CATEGORIES
-- ============================================================
CREATE TABLE categories (
  id          UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name        TEXT NOT NULL UNIQUE,
  description TEXT,
  is_active   BOOLEAN DEFAULT true,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  updated_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE TRIGGER set_categories_updated_at
  BEFORE UPDATE ON categories
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all access to authenticated users"
  ON categories FOR ALL
  USING (auth.role() = 'authenticated');

-- ============================================================
-- 2. PRODUCT UNITS
-- ============================================================
CREATE TABLE product_units (
  id           UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name         TEXT NOT NULL,
  abbreviation TEXT NOT NULL,
  is_default   BOOLEAN DEFAULT false,
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  updated_at   TIMESTAMPTZ DEFAULT NOW()
);

CREATE TRIGGER set_product_units_updated_at
  BEFORE UPDATE ON product_units
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

ALTER TABLE product_units ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all access to authenticated users"
  ON product_units FOR ALL
  USING (auth.role() = 'authenticated');

-- ============================================================
-- 3. PRODUCTS (shared catalog — no branch scoping)
-- ============================================================
CREATE TABLE products (
  id               UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name             TEXT NOT NULL,
  barcode          TEXT UNIQUE,
  price            NUMERIC(10,3) DEFAULT 0,
  min_price        NUMERIC(10,3) DEFAULT 0,
  wholesale_price  NUMERIC(10,3) DEFAULT 0,
  quantity         NUMERIC(10,3) DEFAULT 0,
  min_quantity     NUMERIC(10,3) DEFAULT 0,
  category         TEXT,
  image_url        TEXT,
  unit_id          UUID REFERENCES product_units(id) ON DELETE SET NULL,
  is_active        BOOLEAN DEFAULT true,
  created_at       TIMESTAMPTZ DEFAULT NOW(),
  updated_at       TIMESTAMPTZ DEFAULT NOW()
);

CREATE TRIGGER set_products_updated_at
  BEFORE UPDATE ON products
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE INDEX idx_products_barcode ON products(barcode);
CREATE INDEX idx_products_category ON products(category);

ALTER TABLE products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all access to authenticated users"
  ON products FOR ALL
  USING (auth.role() = 'authenticated');

-- ============================================================
-- 4. USERS (created before branches — no branch_id yet)
-- ============================================================

-- Helper function: checks is_primary_admin WITHOUT triggering RLS (breaks recursion)
CREATE OR REPLACE FUNCTION public.is_current_user_primary_admin()
RETURNS BOOLEAN AS $$
  SELECT COALESCE(
    (SELECT is_primary_admin FROM public.users WHERE id = auth.uid()),
    false
  );
$$ LANGUAGE sql SECURITY DEFINER STABLE;

-- Helper function: gets current user's branch_id WITHOUT triggering RLS (breaks recursion)
CREATE OR REPLACE FUNCTION public.current_user_branch_id()
RETURNS UUID AS $$
  SELECT branch_id FROM public.users WHERE id = auth.uid();
$$ LANGUAGE sql SECURITY DEFINER STABLE;

CREATE TABLE users (
  id               UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  username         TEXT NOT NULL UNIQUE,
  display_name     TEXT,
  phone            TEXT DEFAULT '',
  email            TEXT,
  role             TEXT DEFAULT 'cashier'
                   CHECK (role IN ('admin','manager','accountant','cashier','employee')),
  avatar_url       TEXT,
  is_active        BOOLEAN DEFAULT true,
  is_primary_admin BOOLEAN DEFAULT false,
  pin_hash         TEXT DEFAULT '',
  created_at       TIMESTAMPTZ DEFAULT NOW(),
  updated_at       TIMESTAMPTZ DEFAULT NOW()
);

CREATE TRIGGER set_users_updated_at
  BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE INDEX idx_users_username ON users(username);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all access to authenticated users"
  ON users FOR ALL
  USING (auth.role() = 'authenticated');

-- ============================================================
-- 5. BRANCHES (users table exists now)
-- ============================================================
CREATE TABLE branches (
  id             UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name           TEXT NOT NULL,
  address        TEXT DEFAULT '',
  phone          TEXT DEFAULT '',
  is_main_branch BOOLEAN DEFAULT false,
  is_active      BOOLEAN DEFAULT true,
  created_at     TIMESTAMPTZ DEFAULT NOW(),
  updated_at     TIMESTAMPTZ DEFAULT NOW()
);

CREATE TRIGGER set_branches_updated_at
  BEFORE UPDATE ON branches
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

ALTER TABLE branches ENABLE ROW LEVEL SECURITY;

-- Seed the main branch
INSERT INTO branches (name, is_main_branch)
VALUES ('الفرع الرئيسي', true);

-- branches RLS
CREATE POLICY "Read branches" ON branches
  FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Owner manages branches" ON branches
  FOR ALL USING (public.is_current_user_primary_admin());

-- ============================================================
-- 6. ADD branch_id TO users (branches table exists now)
-- ============================================================
ALTER TABLE users ADD COLUMN branch_id UUID REFERENCES branches(id) ON DELETE SET NULL;
CREATE INDEX idx_users_branch_id ON users(branch_id);

-- Backfill: existing users belong to the main branch.
UPDATE users
SET branch_id = (SELECT id FROM branches WHERE is_main_branch = true)
WHERE branch_id IS NULL;

-- Primary admins see all branches (NULL = all).
UPDATE users SET branch_id = NULL WHERE is_primary_admin = true;

-- Replace blanket users RLS with branch-scoped policies
DROP POLICY IF EXISTS "Allow all access to authenticated users" ON users;

CREATE POLICY "Branch-scoped users read" ON users
  FOR SELECT USING (
    public.is_current_user_primary_admin()
    OR branch_id = public.current_user_branch_id()
    OR id = auth.uid()
  );
CREATE POLICY "Owner manages users" ON users
  FOR INSERT WITH CHECK (
    -- Allow first user when table is empty (initial setup)
    (SELECT count(*) FROM public.users) = 0
    OR public.is_current_user_primary_admin()
  );
CREATE POLICY "Owner updates users" ON users
  FOR UPDATE USING (
    public.is_current_user_primary_admin() OR id = auth.uid()
  );
CREATE POLICY "Owner deletes users" ON users
  FOR DELETE USING (
    public.is_current_user_primary_admin()
  );

-- ============================================================
-- 7. BRANCH STOCK (per-branch product quantities)
-- ============================================================
CREATE TABLE branch_stock (
  id            UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  branch_id     UUID NOT NULL REFERENCES branches(id) ON DELETE CASCADE,
  product_id    UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  quantity      NUMERIC(10,3) DEFAULT 0,
  min_quantity  NUMERIC(10,3) DEFAULT 0,
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(branch_id, product_id)
);

CREATE TRIGGER set_branch_stock_updated_at
  BEFORE UPDATE ON branch_stock
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE INDEX idx_branch_stock_branch_id ON branch_stock(branch_id);
CREATE INDEX idx_branch_stock_product_id ON branch_stock(product_id);

ALTER TABLE branch_stock ENABLE ROW LEVEL SECURITY;

-- Backfill: copy each product's current quantity into main branch stock.
INSERT INTO branch_stock (branch_id, product_id, quantity, min_quantity)
SELECT
  (SELECT id FROM branches WHERE is_main_branch = true),
  id,
  quantity,
  min_quantity
FROM products;

-- branch_stock RLS
CREATE POLICY "Branch-scoped stock read" ON branch_stock
  FOR SELECT USING (
    public.is_current_user_primary_admin() OR branch_id = public.current_user_branch_id()
  );
CREATE POLICY "Branch-scoped stock write" ON branch_stock
  FOR INSERT WITH CHECK (
    public.is_current_user_primary_admin() OR branch_id = public.current_user_branch_id()
  );
CREATE POLICY "Branch-scoped stock update" ON branch_stock
  FOR UPDATE USING (
    public.is_current_user_primary_admin() OR branch_id = public.current_user_branch_id()
  );
CREATE POLICY "Branch-scoped stock delete" ON branch_stock
  FOR DELETE USING (
    public.is_current_user_primary_admin()
  );

-- ============================================================
-- 8. SHIFTS (sessions) — branch-scoped
-- ============================================================
CREATE TABLE shifts (
  id                   UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id              UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  session_number       INTEGER DEFAULT 0,
  open_time            TIMESTAMPTZ DEFAULT NOW(),
  close_time           TIMESTAMPTZ,
  is_open              BOOLEAN DEFAULT true,
  closed_by            UUID REFERENCES users(id) ON DELETE SET NULL,
  opening_cash         NUMERIC(10,2) DEFAULT 0,
  closing_cash         NUMERIC(10,2) DEFAULT 0,
  system_expected_cash NUMERIC(10,2) DEFAULT 0,
  cash_difference      NUMERIC(10,2) DEFAULT 0,
  cash_sales           NUMERIC(10,2) DEFAULT 0,
  cash_refunds         NUMERIC(10,2) DEFAULT 0,
  card_sales           NUMERIC(10,2) DEFAULT 0,
  card_refunds         NUMERIC(10,2) DEFAULT 0,
  cash_expenses        NUMERIC(10,2) DEFAULT 0,
  branch_id            UUID REFERENCES branches(id) ON DELETE SET NULL,
  created_at           TIMESTAMPTZ DEFAULT NOW(),
  updated_at           TIMESTAMPTZ DEFAULT NOW()
);

CREATE TRIGGER set_shifts_updated_at
  BEFORE UPDATE ON shifts
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE INDEX idx_shifts_user_id ON shifts(user_id);
CREATE INDEX idx_shifts_is_open ON shifts(is_open);
CREATE INDEX idx_shifts_branch_id ON shifts(branch_id);

ALTER TABLE shifts ENABLE ROW LEVEL SECURITY;

-- Shifts RLS: branch-scoped
CREATE POLICY "Branch-scoped shifts" ON shifts
  FOR ALL USING (
    public.is_current_user_primary_admin() OR branch_id = public.current_user_branch_id()
  );

-- ============================================================
-- 9. SALES — branch-scoped
-- ============================================================
CREATE TABLE sales (
  id                      UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  total                   NUMERIC(10,2) NOT NULL DEFAULT 0,
  subtotal                NUMERIC(10,2) DEFAULT 0,
  discount_amount         NUMERIC(10,2) DEFAULT 0,
  discount_type           TEXT DEFAULT 'none',
  discount_value          NUMERIC(10,2) DEFAULT 0,
  items                   INTEGER DEFAULT 0,
  cashier_name            TEXT,
  cashier_username        TEXT,
  cashier_user_id         UUID REFERENCES users(id) ON DELETE SET NULL,
  session_id              UUID REFERENCES shifts(id) ON DELETE SET NULL,
  invoice_type_index      INTEGER DEFAULT 0,
  refund_original_invoice_id UUID,
  payment_method          TEXT DEFAULT 'cash',
  notes                   TEXT,
  branch_id               UUID REFERENCES branches(id) ON DELETE SET NULL,
  created_at              TIMESTAMPTZ DEFAULT NOW(),
  updated_at              TIMESTAMPTZ DEFAULT NOW()
);

CREATE TRIGGER set_sales_updated_at
  BEFORE UPDATE ON sales
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE INDEX idx_sales_session_id ON sales(session_id);
CREATE INDEX idx_sales_created_at ON sales(created_at);
CREATE INDEX idx_sales_cashier_user_id ON sales(cashier_user_id);
CREATE INDEX idx_sales_branch_id ON sales(branch_id);

ALTER TABLE sales ENABLE ROW LEVEL SECURITY;

-- Sales RLS: branch-scoped
CREATE POLICY "Branch-scoped sales" ON sales
  FOR ALL USING (
    public.is_current_user_primary_admin() OR branch_id = public.current_user_branch_id()
  );

-- ============================================================
-- 10. SALE ITEMS — branch-scoped
-- ============================================================
CREATE TABLE sale_items (
  id                UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  sale_id           UUID NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
  product_id        UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  product_barcode   TEXT,
  name              TEXT NOT NULL,
  price             NUMERIC(10,3) DEFAULT 0,
  sale_price        NUMERIC(10,3) DEFAULT 0,
  quantity          NUMERIC(10,3) DEFAULT 0,
  total             NUMERIC(10,3) DEFAULT 0,
  wholesale_price   NUMERIC(10,3) DEFAULT 0,
  item_discount     NUMERIC(10,3) DEFAULT 0,
  unit_abbreviation TEXT DEFAULT '',
  refunded_quantity NUMERIC(10,3) DEFAULT 0,
  branch_id         UUID REFERENCES branches(id) ON DELETE SET NULL,
  created_at        TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_sale_items_sale_id ON sale_items(sale_id);
CREATE INDEX idx_sale_items_product_id ON sale_items(product_id);
CREATE INDEX idx_sale_items_branch_id ON sale_items(branch_id);

ALTER TABLE sale_items ENABLE ROW LEVEL SECURITY;

-- Sale items RLS: branch-scoped
CREATE POLICY "Branch-scoped sale items" ON sale_items
  FOR ALL USING (
    public.is_current_user_primary_admin() OR branch_id = public.current_user_branch_id()
  );

-- ============================================================
-- 11. STORE SETTINGS
-- ============================================================
CREATE TABLE store_settings (
  id         UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name       TEXT DEFAULT 'Sphinx',
  address    TEXT DEFAULT '',
  phone      TEXT DEFAULT '',
  email      TEXT DEFAULT '',
  vat        TEXT DEFAULT '',
  logo_url   TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TRIGGER set_store_settings_updated_at
  BEFORE UPDATE ON store_settings
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

ALTER TABLE store_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all access to authenticated users"
  ON store_settings FOR ALL
  USING (auth.role() = 'authenticated');

INSERT INTO store_settings (name) VALUES ('Sphinx');

-- ============================================================
-- 12. EXPENSES — branch-scoped
-- ============================================================
CREATE TABLE expenses (
  id             UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  title          TEXT NOT NULL,
  amount         NUMERIC(10,2) NOT NULL DEFAULT 0,
  category       TEXT DEFAULT 'General',
  notes          TEXT,
  payment_method TEXT DEFAULT 'cash',
  shift_id       UUID REFERENCES shifts(id) ON DELETE SET NULL,
  branch_id      UUID REFERENCES branches(id) ON DELETE SET NULL,
  created_at     TIMESTAMPTZ DEFAULT NOW(),
  updated_at     TIMESTAMPTZ DEFAULT NOW()
);

CREATE TRIGGER set_expenses_updated_at
  BEFORE UPDATE ON expenses
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE INDEX idx_expenses_shift_id ON expenses(shift_id);
CREATE INDEX idx_expenses_branch_id ON expenses(branch_id);

ALTER TABLE expenses ENABLE ROW LEVEL SECURITY;

-- Expenses RLS: branch-scoped
CREATE POLICY "Branch-scoped expenses" ON expenses
  FOR ALL USING (
    public.is_current_user_primary_admin() OR branch_id = public.current_user_branch_id()
  );

-- ============================================================
-- 13. USER PERMISSION OVERRIDES
-- ============================================================
CREATE TABLE user_permission_overrides (
  id          UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  permission  TEXT NOT NULL,
  allowed     BOOLEAN NOT NULL DEFAULT false,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, permission)
);

CREATE INDEX idx_user_permission_overrides_user_id ON user_permission_overrides(user_id);

ALTER TABLE user_permission_overrides ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all access to authenticated users"
  ON user_permission_overrides FOR ALL
  USING (auth.role() = 'authenticated');

-- ============================================================
-- 14. INVENTORY SNAPSHOTS — branch-scoped
-- ============================================================
CREATE TABLE inventory_snapshots (
  id          UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id     UUID REFERENCES users(id) ON DELETE SET NULL,
  status      TEXT DEFAULT 'draft' CHECK (status IN ('draft','finalized','cancelled')),
  notes       TEXT,
  branch_id   UUID REFERENCES branches(id) ON DELETE SET NULL,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  finalized_at TIMESTAMPTZ
);

ALTER TABLE inventory_snapshots ENABLE ROW LEVEL SECURITY;

-- Inventory snapshots RLS: branch-scoped
CREATE POLICY "Branch-scoped snapshots" ON inventory_snapshots
  FOR ALL USING (
    public.is_current_user_primary_admin() OR branch_id = public.current_user_branch_id()
  );

-- ============================================================
-- 15. INVENTORY SNAPSHOT ITEMS
-- ============================================================
CREATE TABLE inventory_snapshot_items (
  id              UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  snapshot_id     UUID NOT NULL REFERENCES inventory_snapshots(id) ON DELETE CASCADE,
  product_id      UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  expected_qty    NUMERIC(10,3) DEFAULT 0,
  counted_qty     NUMERIC(10,3) DEFAULT 0,
  difference      NUMERIC(10,3) DEFAULT 0,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_inventory_snapshot_items_snapshot_id ON inventory_snapshot_items(snapshot_id);

ALTER TABLE inventory_snapshot_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all access to authenticated users"
  ON inventory_snapshot_items FOR ALL
  USING (auth.role() = 'authenticated');

-- ============================================================
-- RPC FUNCTIONS
-- ============================================================

-- admin_create_user
CREATE OR REPLACE FUNCTION admin_create_user(
  email_input        TEXT,
  password_input     TEXT,
  username_input     TEXT,
  display_name_input TEXT DEFAULT '',
  phone_input        TEXT DEFAULT '',
  role_input         TEXT DEFAULT 'cashier',
  branch_id_input    UUID DEFAULT NULL
) RETURNS UUID AS $$
DECLARE
  new_user_id UUID;
BEGIN
  new_user_id := (SELECT id FROM auth.users WHERE email = email_input LIMIT 1);

  IF new_user_id IS NULL THEN
    INSERT INTO auth.users (email, encrypted_password, email_confirmed_at, raw_user_meta_data)
    VALUES (
      email_input,
      crypt(password_input, gen_salt('bf')),
      NOW(),
      jsonb_build_object('username', username_input)
    )
    RETURNING id INTO new_user_id;
  END IF;

  INSERT INTO users (id, username, display_name, phone, role, branch_id)
  VALUES (new_user_id, username_input, display_name_input, phone_input, role_input, branch_id_input)
  ON CONFLICT (id) DO UPDATE SET
    username = EXCLUDED.username,
    display_name = EXCLUDED.display_name,
    phone = EXCLUDED.phone,
    role = EXCLUDED.role,
    branch_id = EXCLUDED.branch_id;

  RETURN new_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- admin_update_user
CREATE OR REPLACE FUNCTION admin_update_user(
  user_id_input      UUID,
  password_input     TEXT DEFAULT NULL,
  display_name_input TEXT DEFAULT '',
  phone_input        TEXT DEFAULT '',
  role_input         TEXT DEFAULT 'cashier',
  is_active_input    BOOLEAN DEFAULT true,
  branch_id_input    UUID DEFAULT NULL
) RETURNS VOID AS $$
BEGIN
  IF password_input IS NOT NULL AND password_input != '' THEN
    UPDATE auth.users
    SET encrypted_password = crypt(password_input, gen_salt('bf'))
    WHERE id = user_id_input;
  END IF;

  UPDATE users SET
    display_name = display_name_input,
    phone = phone_input,
    role = role_input,
    is_active = is_active_input,
    branch_id = branch_id_input,
    updated_at = NOW()
  WHERE id = user_id_input;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- set_user_pin
CREATE OR REPLACE FUNCTION set_user_pin(
  target_user_id UUID,
  pin_code       TEXT DEFAULT ''
) RETURNS VOID AS $$
BEGIN
  UPDATE users
  SET pin_hash = CASE
    WHEN pin_code = '' THEN ''
    ELSE pin_code
  END,
  updated_at = NOW()
  WHERE id = target_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- set_user_permission_overrides
CREATE OR REPLACE FUNCTION set_user_permission_overrides(
  target_user_id UUID,
  overrides      JSONB DEFAULT '{}'::jsonb
) RETURNS VOID AS $$
DECLARE
  key   TEXT;
  val   BOOLEAN;
BEGIN
  DELETE FROM user_permission_overrides WHERE user_id = target_user_id;

  FOR key, val IN SELECT * FROM jsonb_each_text(overrides) LOOP
    INSERT INTO user_permission_overrides (user_id, permission, allowed)
    VALUES (target_user_id, key, val::boolean)
    ON CONFLICT (user_id, permission) DO UPDATE SET allowed = EXCLUDED.allowed;
  END LOOP;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- finalize_inventory_snapshot: update branch_stock (not products)
CREATE OR REPLACE FUNCTION finalize_inventory_snapshot(
  snapshot_id_input UUID
) RETURNS VOID AS $$
DECLARE
  target_branch_id UUID;
BEGIN
  SELECT branch_id INTO target_branch_id
  FROM inventory_snapshots WHERE id = snapshot_id_input;

  IF target_branch_id IS NOT NULL THEN
    -- Update branch_stock for the snapshot's branch
    UPDATE branch_stock bs SET
      quantity = si.counted_qty,
      updated_at = NOW()
    FROM inventory_snapshot_items si
    WHERE si.snapshot_id = snapshot_id_input
      AND si.product_id = bs.product_id
      AND bs.branch_id = target_branch_id;
  ELSE
    -- Fallback: update products.quantity directly (primary admin, no branch)
    UPDATE products p SET
      quantity = si.counted_qty,
      updated_at = NOW()
    FROM inventory_snapshot_items si
    WHERE si.snapshot_id = snapshot_id_input
      AND si.product_id = p.id;
  END IF;

  UPDATE inventory_snapshots
  SET status = 'finalized',
      finalized_at = NOW()
  WHERE id = snapshot_id_input;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- create_branch_with_stock: create a branch + seed zero-qty stock rows
CREATE OR REPLACE FUNCTION create_branch_with_stock(
  name_input    TEXT,
  address_input TEXT DEFAULT '',
  phone_input   TEXT DEFAULT ''
) RETURNS UUID AS $$
DECLARE
  new_branch_id UUID;
BEGIN
  INSERT INTO branches (name, address, phone)
  VALUES (name_input, address_input, phone_input)
  RETURNING id INTO new_branch_id;

  INSERT INTO branch_stock (branch_id, product_id, quantity, min_quantity)
  SELECT new_branch_id, id, 0, min_quantity FROM products;

  RETURN new_branch_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================
-- STORAGE BUCKETS
-- ============================================================
INSERT INTO storage.buckets (id, name, public) VALUES ('avatars', 'avatars', true);
INSERT INTO storage.buckets (id, name, public) VALUES ('product-images', 'product-images', true);
INSERT INTO storage.buckets (id, name, public) VALUES ('store-logo', 'store-logo', true);

-- Storage policies
CREATE POLICY "Avatar upload access" ON storage.objects
  FOR INSERT WITH CHECK (bucket_id = 'avatars' AND auth.role() = 'authenticated');

CREATE POLICY "Avatar public access" ON storage.objects
  FOR SELECT USING (bucket_id = 'avatars');

CREATE POLICY "Product image upload access" ON storage.objects
  FOR INSERT WITH CHECK (bucket_id = 'product-images' AND auth.role() = 'authenticated');

CREATE POLICY "Product image public access" ON storage.objects
  FOR SELECT USING (bucket_id = 'product-images');

CREATE POLICY "Store logo upload access" ON storage.objects
  FOR INSERT WITH CHECK (bucket_id = 'store-logo' AND auth.role() = 'authenticated');

CREATE POLICY "Store logo public access" ON storage.objects
  FOR SELECT USING (bucket_id = 'store-logo');
