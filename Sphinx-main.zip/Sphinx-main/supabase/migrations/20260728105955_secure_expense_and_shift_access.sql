-- Secure expense creation and shift visibility/closing by branch and owner.
-- Remote migration version: 20260728105955.

create or replace function public.record_expense(expense_input jsonb)
returns public.expenses
language plpgsql
security definer
set search_path = ''
as $$
declare
  caller_id uuid := (select auth.uid());
  caller_role text;
  caller_branch_id uuid;
  caller_is_primary boolean;
  requested_branch_id uuid;
  requested_shift_id uuid;
  shift_row public.shifts%rowtype;
  created_expense public.expenses%rowtype;
begin
  if caller_id is null then
    raise exception 'AUTHENTICATION_REQUIRED';
  end if;

  select u.role, u.branch_id, u.is_primary_admin
    into caller_role, caller_branch_id, caller_is_primary
    from public.users u
   where u.id = caller_id
     and u.is_active = true;

  if not found then
    raise exception 'ACTIVE_USER_REQUIRED';
  end if;

  requested_branch_id := nullif(expense_input->>'branch_id', '')::uuid;
  requested_shift_id := nullif(expense_input->>'shift_id', '')::uuid;

  if requested_branch_id is null
     or not (
       caller_is_primary
       or caller_branch_id = requested_branch_id
     ) then
    raise exception 'BRANCH_ACCESS_DENIED';
  end if;

  if coalesce(trim(expense_input->>'title'), '') = '' then
    raise exception 'EXPENSE_TITLE_REQUIRED';
  end if;

  if coalesce((expense_input->>'amount')::numeric, 0) <= 0 then
    raise exception 'EXPENSE_AMOUNT_INVALID';
  end if;

  if requested_shift_id is not null then
    select s.*
      into shift_row
      from public.shifts s
     where s.id = requested_shift_id;

    if not found
       or shift_row.branch_id <> requested_branch_id then
      raise exception 'SHIFT_BRANCH_MISMATCH';
    end if;

    if not shift_row.is_open then
      raise exception 'SHIFT_NOT_OPEN';
    end if;

    if caller_role = 'cashier' and shift_row.user_id <> caller_id then
      raise exception 'SHIFT_ACCESS_DENIED';
    end if;
  elsif caller_role = 'cashier' then
    raise exception 'SHIFT_REQUIRED';
  end if;

  insert into public.expenses (
    title,
    amount,
    category,
    notes,
    payment_method,
    shift_id,
    branch_id,
    created_at
  )
  values (
    trim(expense_input->>'title'),
    (expense_input->>'amount')::numeric,
    coalesce(nullif(trim(expense_input->>'category'), ''), 'General'),
    nullif(trim(expense_input->>'notes'), ''),
    coalesce(nullif(trim(expense_input->>'payment_method'), ''), 'cash'),
    requested_shift_id,
    requested_branch_id,
    coalesce(
      nullif(expense_input->>'created_at', '')::timestamptz,
      now()
    )
  )
  returning * into created_expense;

  return created_expense;
end;
$$;

revoke all on function public.record_expense(jsonb) from public, anon;
grant execute on function public.record_expense(jsonb) to authenticated;

drop policy if exists shifts_branch_select on public.shifts;
drop policy if exists shifts_scoped_select on public.shifts;

create policy shifts_scoped_select
on public.shifts
for select
to authenticated
using (
  exists (
    select 1
      from public.users caller
     where caller.id = (select auth.uid())
       and caller.is_active = true
       and (
         caller.is_primary_admin = true
         or (
           caller.branch_id = shifts.branch_id
           and (
             caller.role in ('admin', 'manager', 'accountant')
             or shifts.user_id = (select auth.uid())
           )
         )
       )
  )
);

create or replace function public.open_shift(
  opening_cash_input numeric,
  branch_id_input uuid default null
)
returns setof public.shifts
language plpgsql
security definer
set search_path = ''
as $$
declare
  caller_id uuid := (select auth.uid());
  next_session_number integer;
begin
  if caller_id is null then
    raise exception 'AUTHENTICATION_REQUIRED';
  end if;

  if branch_id_input is null
     or not (select public.can_access_branch(branch_id_input)) then
    raise exception 'BRANCH_ACCESS_DENIED';
  end if;

  if exists (
    select 1
      from public.shifts s
     where s.user_id = caller_id
       and s.is_open = true
       and s.branch_id = branch_id_input
  ) then
    raise exception 'SHIFT_ALREADY_OPEN';
  end if;

  select coalesce(max(s.session_number), 0) + 1
    into next_session_number
    from public.shifts s
   where s.user_id = caller_id
     and s.branch_id = branch_id_input;

  return query
  insert into public.shifts (
    user_id,
    session_number,
    opening_cash,
    is_open,
    branch_id
  )
  values (
    caller_id,
    next_session_number,
    opening_cash_input,
    true,
    branch_id_input
  )
  returning *;
end;
$$;

create or replace function public.close_shift(
  shift_id_input uuid,
  closing_cash_input numeric
)
returns setof public.shifts
language plpgsql
security definer
set search_path = ''
as $$
declare
  caller_id uuid := (select auth.uid());
  caller_role text;
  caller_branch_id uuid;
  caller_is_primary boolean;
  shift_row public.shifts%rowtype;
  cash_sales_total numeric := 0;
  card_sales_total numeric := 0;
  cash_refunds_total numeric := 0;
  card_refunds_total numeric := 0;
  expenses_total numeric := 0;
  expected_cash numeric;
begin
  if caller_id is null then
    raise exception 'AUTHENTICATION_REQUIRED';
  end if;

  select u.role, u.branch_id, u.is_primary_admin
    into caller_role, caller_branch_id, caller_is_primary
    from public.users u
   where u.id = caller_id
     and u.is_active = true;

  if not found then
    raise exception 'ACTIVE_USER_REQUIRED';
  end if;

  select s.*
    into shift_row
    from public.shifts s
   where s.id = shift_id_input
     and s.is_open = true
   for update;

  if not found then
    raise exception 'SHIFT_NOT_FOUND';
  end if;

  if not (
    caller_is_primary
    or (
      caller_role in ('admin', 'manager')
      and caller_branch_id = shift_row.branch_id
    )
    or (
      caller_role in ('admin', 'manager', 'cashier')
      and shift_row.user_id = caller_id
    )
  ) then
    raise exception 'SHIFT_CLOSE_DENIED';
  end if;

  select
    coalesce(sum(s.total) filter (
      where s.payment_method <> 'card' and s.invoice_type_index = 0
    ), 0),
    coalesce(sum(s.total) filter (
      where s.payment_method = 'card' and s.invoice_type_index = 0
    ), 0),
    coalesce(sum(s.total) filter (
      where s.payment_method <> 'card' and s.invoice_type_index = 1
    ), 0),
    coalesce(sum(s.total) filter (
      where s.payment_method = 'card' and s.invoice_type_index = 1
    ), 0)
    into
      cash_sales_total,
      card_sales_total,
      cash_refunds_total,
      card_refunds_total
    from public.sales s
   where s.session_id = shift_id_input
     and s.branch_id = shift_row.branch_id;

  select coalesce(sum(e.amount), 0)
    into expenses_total
    from public.expenses e
   where e.shift_id = shift_id_input
     and e.branch_id = shift_row.branch_id;

  expected_cash :=
    shift_row.opening_cash
    + cash_sales_total
    - cash_refunds_total
    - expenses_total;

  return query
  update public.shifts
     set is_open = false,
         close_time = now(),
         closed_by = caller_id,
         closing_cash = closing_cash_input,
         cash_sales = cash_sales_total,
         card_sales = card_sales_total,
         cash_refunds = cash_refunds_total,
         card_refunds = card_refunds_total,
         cash_expenses = expenses_total,
         system_expected_cash = expected_cash,
         cash_difference = closing_cash_input - expected_cash
   where id = shift_id_input
  returning *;
end;
$$;

revoke all on function public.open_shift(numeric, uuid) from public, anon;
revoke all on function public.close_shift(uuid, numeric) from public, anon;
grant execute on function public.open_shift(numeric, uuid) to authenticated;
grant execute on function public.close_shift(uuid, numeric) to authenticated;
