import 'package:flutter_test/flutter_test.dart';
import 'package:sphinx/core/config/supabase_config.dart';

void main() {
  group('SupabaseConfig Test Suite', () {
    test('SupabaseConfig url returns a valid non-empty string', () {
      expect(SupabaseConfig.url, isNotEmpty);
      expect(SupabaseConfig.url.startsWith('http'), isTrue);
    });

    test('SupabaseConfig anonKey returns a valid non-empty string', () {
      expect(SupabaseConfig.anonKey, isNotEmpty);
    });

    test('SupabaseConfig isConfigured flag checks non-empty values', () {
      expect(SupabaseConfig.isConfigured, isTrue);
    });
  });
}
