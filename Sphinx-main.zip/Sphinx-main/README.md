<p align="center">
  <img src="assets/images/logo.png" alt="Sphinx Logo" width="180" />
</p>

<h1 align="center">Sphinx POS & Retail Management System</h1>

<p align="center">
  <strong>An Enterprise-Grade, Customized Online Multi-Branch Version of Bayaa POS powered by Supabase & Flutter</strong>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Flutter-3.27+-02569B?style=for-the-badge&logo=flutter&logoColor=white" alt="Flutter" />
  <img src="https://img.shields.io/badge/Dart-3.6+-0175C2?style=for-the-badge&logo=dart&logoColor=white" alt="Dart" />
  <img src="https://img.shields.io/badge/Supabase-Cloud%20Database-3ECF8E?style=for-the-badge&logo=supabase&logoColor=white" alt="Supabase" />
  <img src="https://img.shields.io/badge/Architecture-Clean%20%2B%20BLoC-FF6F00?style=for-the-badge" alt="Architecture" />
  <img src="https://img.shields.io/badge/Localization-Arabic%20%26%20English-blueviolet?style=for-the-badge" alt="Localization" />
</p>

---

## 💡 Origin & Heritage: Derived from Bayaa POS

**Sphinx** is an advanced, customized online enterprise edition evolved directly from **Bayaa POS**. 

While Bayaa POS established the robust foundation for retail point-of-sale operations, **Sphinx** elevates the system into a cloud-synchronized, multi-tenant enterprise solution by introducing **real-time cloud synchronization via Supabase**, **multi-branch isolation & directory management**, **atomic PostgreSQL RPC procedures**, **PDF shift audit reports**, and **partial refund accounting**.

---

## 📋 Overview

Sphinx brings sales, inventory, cash shifts, customizable PDF invoices, multi-branch scoping, financial analytics, expenses, and user permissions into one responsive application for desktop (Windows, macOS, Linux) and mobile (Android, iOS) workflows.

The system features full **Arabic (RTL)** and **English (LTR)** localization with dynamic runtime language switching.

---

## ✨ Key Features & Capabilities

### 🏢 Multi-Branch Management & Isolation *(New in Sphinx)*
* **Branch Data Isolation**: Enforces Row Level Security (RLS) so managers and cashiers operate strictly within their assigned branch.
* **Aggregated Corporate Admin Mode**: Executive dashboards allowing administrators to switch across individual outlets or view consolidated company metrics.
* **Branch Directory Controls**: Secured administrative workflows for managing store locations and user assignments.

### ⚡ Online Cloud Synchronization & Resilience *(New in Sphinx)*
* **Real-time Database Sync**: Multi-terminal live data updates powered by Supabase.
* **Connection Status Monitor**: Real-time connection health banner with exponential backoff retries and session recovery.

### 💵 Shift & Cash Register Control *(New in Sphinx)*
* **Shift Lifecycle RPCs**: Atomic procedures (`open_shift`, `close_shift`) to track starting float, cash transactions, expenses, and closing totals.
* **Cash Variance Detection**: Automatic balance reconciliation reporting physical drawer count versus expected cash.
* **Daily Shift Reports**: One-click generation of audit-ready daily PDF shift datasheets.

### 🛒 Point of Sale (POS) Workflow
* **Barcode Scanning & Quick Search**: Add items instantaneously via physical scanners or UI search.
* **Flexible Discounts & Tax Calculation**: Supports item-level and order-level fixed or percentage discounts.
* **Instant Thermal & PDF Receipts**: Generate, print, or export formatted transaction receipts.
* **Multi-Payment Method**: Cash, credit card, and digital payment handling.

### 🧾 Invoices & Partial Refund System
* **Custom Corporate PDF Invoicing**: High-resolution PDF generation (`pdf` + `printing` package) with custom headers, QR metadata, and line item breakdowns.
* **Full & Partial Refunds**: Dedicated refund flow allowing partial item returns while automatically updating inventory stock levels and shift totals.

### 📊 Analytics & Reporting
* **Interactive Visual Analytics**: Built with `fl_chart` for revenue trends, gross profit margins, expense breakdowns, and top-selling products.
* **Stock Summary & Low Stock Alerts**: Real-time notifications for low stock thresholds.

### 👤 User & Role Management
* **Role-Based Access Control (RBAC)**: Admin, Branch Manager, and Cashier permission tiers.
* **Admin Setup Wizard**: Secure password-protected administrative configurations.
* **Soft Delete User RPC**: Safely deactivates staff accounts (`soft_delete_user`) without breaking historical sales audit trails.

---

## 🛠 Technology Stack

| Layer | Technologies & Packages |
|---|---|
| **Framework** | [Flutter SDK](https://flutter.dev) (Desktop & Mobile) |
| **Language** | [Dart 3.6+](https://dart.dev) |
| **State Management** | [flutter_bloc](https://pub.dev/packages/flutter_bloc) / [bloc](https://pub.dev/packages/bloc) |
| **Dependency Injection** | [get_it](https://pub.dev/packages/get_it) |
| **Backend & Cloud Database** | [supabase_flutter](https://pub.dev/packages/supabase_flutter) (PostgreSQL, RLS, Realtime, RPCs) |
| **UI Components & Icons** | [lucide_icons_flutter](https://pub.dev/packages/lucide_icons_flutter), [data_table_2](https://pub.dev/packages/data_table_2) |
| **Charts & Graphics** | [fl_chart](https://pub.dev/packages/fl_chart) |
| **PDF & Printing** | [pdf](https://pub.dev/packages/pdf), [printing](https://pub.dev/packages/printing), [barcode](https://pub.dev/packages/barcode) |
| **Localization** | Flutter Intl (`app_ar.arb`, `app_en.arb`) with RTL support |

---

## 📁 Architecture & Directory Structure

Sphinx follows **Clean Architecture** principles grouped by feature:

```text
lib/
├── core/                         # Global core utilities & infrastructure
│   ├── components/               # Reusable UI widgets (ConnectionBanner, MessageOverlay, etc.)
│   ├── config/                   # Configuration (AppConfig, SupabaseConfig)
│   ├── di/                       # Service Locator & Dependency Injection (GetIt)
│   ├── error/                    # Failure and Exception models
│   ├── localization/             # Language providers (LocaleProvider)
│   ├── logging/                  # FileLogger & CrashLogger
│   ├── services/                 # Supabase & network recovery services
│   └── theme/                    # AppTheme, colors, typography
├── features/                     # Feature modules (Domain, Data, Presentation)
│   ├── analytics/                # Sales reports, chart widgets, repositories
│   ├── auth/                     # Authentication screens, user cubit, repositories
│   ├── branches/                 # Branch selector, branch stats & management
│   ├── dashboard/                # Main responsive layout, sidebar, stat cards
│   ├── expenses/                 # Expense tracking & categories
│   ├── invoice/                  # Invoices list, PDF invoice generator, partial refund dialog
│   ├── pos/                      # Cart section, barcode reader, checkout dialogs
│   ├── products/                 # Product inventory management, categories, dialogs
│   ├── settings/                 # Store info, user management card, security controls
│   ├── setup/                    # Setup wizard screen
│   ├── shifts/                   # Open/close shift dialogs, shift reports
│   └── splash/                   # Application splash & bootstrapper
└── l10n/                         # Localization files (Arabic & English ARB files)
```

---

## 🚀 Getting Started

### Prerequisites
* [Flutter SDK](https://docs.flutter.dev/get-started/install) (`v3.27` or higher)
* [Dart SDK](https://dart.dev/get-dart) (`v3.6` or higher)
* A valid [Supabase](https://supabase.com) project with database migrations applied.

### Installation

1. **Clone the repository**:
   ```bash
   git clone https://github.com/Desha29/Sphinx.git
   cd Sphinx
   ```

2. **Install dependencies**:
   ```bash
   flutter pub get
   ```

3. **Configure Environment Variables**:
   Copy `.env.example` to `.env` or pass Supabase environment variables at build-time:
   ```bash
   flutter run --dart-define=SUPABASE_URL=https://your-project.supabase.co --dart-define=SUPABASE_PUBLISHABLE_KEY=your-publishable-key
   ```

4. **Build & Run**:
   - **Windows Desktop**:
     ```bash
     flutter run -d windows
     ```
   - **Android / iOS**:
     ```bash
     flutter run -d android
     ```

---

## 🗄 Database Setup

Apply the SQL migration scripts located in `supabase/migrations/` sequentially using the Supabase SQL Editor or Supabase CLI:

```bash
supabase db push
```

Refer to [supabase/README.md](supabase/README.md) for full migration descriptions and RPC function definitions.

---

## 🧪 Testing & Verification

Run static analysis and unit test suites:

```bash
flutter analyze
flutter test
```

---

## 📄 License

Distributed under the MIT License. See `LICENSE` for more information.

---

<p align="center">
  Developed with ❤️ by <strong>Mostafa Amr</strong>
</p>
