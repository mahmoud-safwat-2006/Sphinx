# Public Portfolio Publication Design

## Goal

Publish the current Sphinx Flutter application as a public GitHub portfolio repository named `Sphinx` under the user's authenticated personal GitHub account without publishing Supabase project configuration, database migrations, database data, credentials, generated files, or sensitive historical commits.

## Publication Strategy

Create a sanitized portfolio snapshot with a new Git root commit. The public repository will not receive any commit from the existing local history because that history contains Supabase configuration and migration files. The local repository and its history remain intact.

The snapshot will reflect the current application source, including the user's uncommitted application changes, while omitting generated artifacts and private backend material.

## Included Content

- Flutter and Dart application source needed to present and build the client.
- Platform runner source that is safe and normally version-controlled.
- Dependency manifests and lockfiles.
- Localization resources, fonts, the Sphinx logo, and safe application assets.
- Safe screenshots that do not expose private or production business data.
- A portfolio-focused README with the logo, project overview, features, technology stack, safe setup instructions, repository privacy notes, and screenshots where appropriate.
- Existing non-sensitive engineering documentation when it does not reveal private backend implementation details.

## Excluded Content

- The entire `supabase/` directory, including migrations, seeds, CLI state, and configuration.
- Supabase project URLs, publishable/anonymous keys, service-role keys, database passwords, JWT secrets, and credentials of any kind.
- Database dumps, backups, exports, seed data, or production/customer data.
- Local environment files and machine-specific configuration.
- Build outputs, Dart/Flutter caches, generated binaries, logs, temporary files, IDE state, and operating-system metadata.
- Existing Git history and remotes.

## Safe Runtime Configuration

The public client will contain no embedded Supabase endpoint or key. Runtime values will be accepted only through explicit build-time environment variables. Missing values will produce a clear configuration error rather than silently connecting to a hard-coded project.

The README will document variable names and a placeholder-only command. It will explain that a developer must provide their own Supabase project and compatible private schema. No real value or backend schema will be published.

## README Design

The README will lead with the Sphinx logo and a concise portfolio description. It will cover:

1. Product purpose and primary capabilities.
2. Technology and architecture highlights.
3. Screenshots that pass the privacy review.
4. Local Flutter prerequisites and dependency installation.
5. Placeholder-only Supabase build-time configuration.
6. A statement that migrations and backend data are intentionally excluded.
7. Supported platforms and basic verification commands.

## Data and Screenshot Safety

All candidate screenshots and data-like assets will be reviewed before inclusion. Files showing real credentials, personal identifiers, customer records, production transaction details, or private operational data will be excluded. The logo remains included as the README brand asset.

## Verification

Before publication:

1. Build a separate sanitized staging copy so the user's local working tree and history are not replaced.
2. Confirm excluded paths are absent from the staged repository.
3. Scan staged text files for common secret formats and project-specific Supabase values without printing matched secret values.
4. Confirm no Git object from the existing repository is copied into the public history.
5. Run available Flutter static analysis and tests against the sanitized source, recording any pre-existing failures separately.
6. Inspect the final staged file list and README rendering references.
7. Create the public GitHub repository `Sphinx`, make one intentional initial commit, and push the sanitized default branch.

## Failure Handling

- If GitHub authentication is unavailable, stop before repository creation and request authentication.
- If a potentially sensitive file cannot be classified confidently, exclude it.
- If sanitizing runtime configuration breaks the client, fix the public configuration boundary without restoring embedded values.
- If verification reports unrelated application defects, publish only after clearly separating them from publication/security failures and obtaining direction when necessary.

## Success Criteria

- The public repository is named `Sphinx` and belongs to the user's authenticated personal GitHub account.
- Its history begins with the sanitized portfolio commit and contains no local historical commits.
- No Supabase configuration values, migrations, database data, dumps, secrets, caches, or build outputs are present.
- The README displays the Sphinx logo and clearly presents the project as a portfolio application.
- The repository can be cloned and inspected safely, with backend requirements documented using placeholders only.
