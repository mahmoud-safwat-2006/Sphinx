# Branch Data and User Access Design

## Purpose

Fix branch-filtered data loading across Cloud Data Management, analytics, and
invoices, while making store configuration explicitly global and completing
secure user-to-branch assignment.

## Confirmed Access Model

- Each non-primary user belongs to exactly one active branch.
- The primary admin can view all branches, select one branch, assign users, and
  move users between branches.
- A branch admin or manager can view and manage non-primary users only in their
  own branch.
- A branch admin or manager cannot move a user to another branch.
- Cashiers, accountants, and employees cannot manage user branch assignments.
- A non-primary user never sees the "All branches" option or another branch.
- Primary-admin accounts remain global and have a null `branch_id`.

This uses the existing `users.branch_id` column. A multi-branch membership
table is intentionally out of scope.

## Data Classification

### Global data

The following data is shared by the whole store and must not change when the
selected branch changes:

- Store information and branding
- Product definitions
- Categories
- Product units
- Application-wide configuration

### Branch-owned data

The following data must use the current branch scope:

- Sales, refunds, and invoices
- Sale items
- Shifts
- Expenses
- Branch stock
- Inventory snapshots and their items
- Non-primary users and their permission overrides

When the primary admin selects "All branches," read screens aggregate all
authorized rows. Branch-owned writes require one selected branch.

## Application Changes

### Cloud Data Management

Build PostgREST queries in this order:

1. Select the safe column list.
2. Apply the branch filter when the table is branch-owned.
3. Apply search filters.
4. Apply ordering and range pagination.
5. Request the exact count and await the response.

Count-only queries will not call modifiers on an already-created
`PostgrestResponse` builder. Global tables remain unfiltered. The screen stays
debug-only.

### Analytics

Convert local day boundaries to UTC before sending timestamp filters to
Supabase. The selected Cairo calendar day therefore includes rows stored on the
previous UTC date when appropriate.

Analytics reloads using its current date/session selection after a branch
change. An empty branch shows an intentional zero state rather than data from
another branch.

### Invoices

Invoice loading listens directly for branch-scope changes and reloads once per
selection revision. Repository failures become an error state instead of being
silently converted to an empty list.

Invoice queries filter `sales.branch_id`; associated sale items are fetched only
for those returned sale IDs. A branch with no invoices shows the normal empty
state.

### Settings

Store information and other global configuration do not listen to branch
selection and do not receive a `branch_id` filter. Branch-owned settings
sections, such as user management and branch stock, remain scoped.

### User Management

The add/edit-user form includes a required branch selector for every
non-primary user. The primary admin can select any active branch. A branch
admin or manager sees their own branch as a locked value.

Editing preserves the existing branch assignment. Moving a user is performed
through the same update flow and is available only to the primary admin.
User cards and tables display the assigned branch.

The form awaits create/update completion before closing and shows server
failures instead of reporting success early.

## Database Authorization

Database policies and privileged functions enforce the same rules as the UI:

- Primary admin: read and manage all non-primary user profiles and assignments.
- Branch admin/manager: read users in their own branch; manage eligible
  non-primary users in that same branch only.
- Other roles: read their own profile and no user-management mutations.
- No caller can create or promote another primary admin through these flows.
- A non-primary user must have a non-null active branch.

User mutation functions validate the caller, target role, target branch, and
primary-admin status inside the database. Client-supplied permissions are not
trusted without these checks.

## Error Handling

- Invalid or inactive branch assignments are rejected with a clear error.
- Branch-required forms cannot submit without a valid branch.
- Data query errors are visible to the relevant screen and support retry.
- Stale results from a previous branch selection are discarded.

## Verification

No test files will be added, per project requirement. Verification will use:

- Static analysis on changed Dart files and the full `lib` tree.
- Focused live Supabase queries for branch counts, user visibility, constraints,
  function grants, and RLS policies.
- Transactional migration validation before applying the migration.
- Manual debug-mode checks for Cloud Data, analytics day boundaries, invoice
  switching, global store settings, and user branch assignment.

## Out of Scope

- One user belonging to multiple branches.
- Branch-specific store branding.
- Allowing branch managers to transfer users between branches.
- Making Cloud Data Management available in release builds.
