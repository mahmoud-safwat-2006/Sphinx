# POS Branch Refresh and Shift Security Design

## Goal

Make branch selection authoritative across POS, expenses, stock summary,
analytics, recent sales, Cloud Data Management, and shift closing.

## Confirmed Problems

- POS treats an open shift from any branch as sufficient when the primary
  administrator selects **All branches**.
- Expense creation calls a `record_expense(jsonb)` RPC that is absent from the
  live database.
- Cloud Data Management filters `inventory_snapshot_items` through
  `inventory_snapshots.branch_id` while its count query does not embed the
  `inventory_snapshots` relationship, producing PostgREST error `PGRST108`.
- Page-owned Stock Summary and Analytics cubits are not reliably refreshed by
  the dashboard's global branch listener.
- Recent sales supports a branch predicate, but its refresh is not coupled
  reliably to branch selection.
- The shift-closing RPC does not independently enforce who may close a shift.

## Selected Design

### POS branch gate

POS requires one concrete branch. When the scope is **All branches** or is not
initialized, the entire POS surface remains locked and displays a clear request
to select a branch. It must not load, open, close, or complete a sale against an
ambiguous branch. Changing branches reloads the current user's active shift for
the newly selected branch.

### Branch-reactive data

Stock Summary, Analytics, Expenses, Shifts, and POS Recent Sales listen to the
branch selection revision at the screen/cubit ownership boundary. Each refresh
uses the current `BranchScope`:

- one branch: filter every branch-owned query by that branch ID;
- all branches: omit the branch predicate and aggregate all authorized rows;
- uninitialized: do not issue branch-owned mutations.

Refreshes replace old state with loading or empty state so data from the
previous branch is never displayed as if it belongs to the new selection.

### Expenses

Create `record_expense(expense_input jsonb)` as an authenticated database
function. It validates:

- the caller is authenticated;
- `branch_id` is present and accessible to the caller;
- `shift_id`, when present, belongs to the same branch;
- cashiers may attach expenses only to their own open shift.

The function inserts and returns the expense atomically. Execute permission is
revoked from `PUBLIC` and `anon` and granted only to `authenticated`.

### Shift visibility and closing

Cashiers can see only their own shifts and may close only their own open shift.
Managers and branch administrators can view and close shifts within their own
branch. The primary administrator can view and close shifts across branches,
but POS still requires selecting a single branch.

`close_shift` performs authorization inside the database before calculating
totals and updating the shift. Client-side permission checks improve the UI but
are not the security boundary.

### Cloud Data Management

Count queries for tables filtered through an embedded relation include that
relationship in the `select` clause. The row query and count query use the same
branch predicate, preventing `PGRST108` and count/data mismatches.

## Error Handling

- All-branches POS shows a branch-required locked state rather than an open
  shift dialog.
- Expense and shift authorization errors are converted to clear user messages.
- Branch refresh failures show an error/empty state and never preserve values
  from the previously selected branch.

## Verification

No test files will be added, per project instruction. Verification will use:

- focused Dart static analysis;
- existing project checks;
- read-only Supabase queries for function signatures and data distribution;
- transactional SQL assertions for expense creation, cashier shift ownership,
  manager branch scope, and rollback;
- formatting and `git diff --check`.

