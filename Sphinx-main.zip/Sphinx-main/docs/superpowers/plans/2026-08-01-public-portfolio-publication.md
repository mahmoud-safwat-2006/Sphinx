# Public Portfolio Publication Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Publish a public GitHub repository named `Sphinx` from a fresh, sanitized history while keeping Supabase configuration values, migrations, database data, generated files, and the existing Git history private.

**Architecture:** Make the client configuration safe in the working project first, then build a separate publication workspace from an allowlisted copy of the current source tree. Verify that workspace independently, initialize a new one-commit Git history, and create/push the public GitHub repository only after all privacy gates pass.

**Tech Stack:** Flutter/Dart, `supabase_flutter`, Flutter test tooling, Git, GitHub CLI, PowerShell, GitHub public repositories.

## Global Constraints

- The public repository name is `Sphinx` under the user's authenticated personal GitHub account.
- The repository visibility is public.
- Existing local Git commits must never be pushed because they contain Supabase configuration and migration history.
- The entire `supabase/` directory, database migrations, seeds, dumps, backups, exports, and production/customer data must be absent.
- Supabase URLs, publishable/anonymous keys, service-role keys, database passwords, JWT secrets, and credentials of any kind must be absent.
- The client may accept `SUPABASE_URL` and `SUPABASE_PUBLISHABLE_KEY` only as explicit build-time variables with no embedded default values.
- Build outputs, Dart/Flutter caches, generated binaries, logs, temporary files, IDE state, and OS metadata must be absent.
- The current local working tree and its existing history must remain intact.
- If a potentially sensitive asset cannot be classified confidently, exclude it.

---

## File Structure

- Modify: `.gitignore` — define local and public exclusions for generated files, credentials, Supabase backend files, and database artifacts.
- Modify: `lib/core/config/supabase_config.dart` — expose validated, build-time-only Supabase values without defaults.
- Create: `test/core/config/supabase_config_test.dart` — verify empty values fail closed and non-empty values pass through.
- Create: `README.md` — portfolio presentation, logo, features, stack, setup, privacy boundary, and validation commands.
- Reuse: `assets/images/logo.png` — README branding.
- Review only: `Screenshots/*.png` — include only individually approved, non-sensitive images in the publication workspace.
- Create outside the working repository: `C:/Users/Desha/.codex/visualizations/2026/08/01/019fbd48-f7c2-7123-a917-0fa5e409e22e/Sphinx-public/` — sanitized publication workspace and fresh Git repository.

---

### Task 1: Fail-Closed Supabase Client Configuration

**Files:**
- Modify: `lib/core/config/supabase_config.dart`
- Create: `test/core/config/supabase_config_test.dart`

**Interfaces:**
- Consumes: Dart compile-time values named `SUPABASE_URL` and `SUPABASE_PUBLISHABLE_KEY` supplied with Flutter `--dart-define` arguments.
- Produces: `SupabaseConfig.url`, `SupabaseConfig.anonKey`, and `SupabaseConfig.requireValue(String variableName, String value)`.

- [ ] **Step 1: Write the failing configuration tests**

Create `test/core/config/supabase_config_test.dart`:

```dart
import 'package:flutter_test/flutter_test.dart';
import 'package:sphinx/core/config/supabase_config.dart';

void main() {
  group('SupabaseConfig.requireValue', () {
    test('rejects a missing build-time value', () {
      expect(
        () => SupabaseConfig.requireValue('SUPABASE_URL', ''),
        throwsA(
          isA<StateError>().having(
            (error) => error.message,
            'message',
            contains('SUPABASE_URL'),
          ),
        ),
      );
    });

    test('rejects a whitespace-only build-time value', () {
      expect(
        () => SupabaseConfig.requireValue(
          'SUPABASE_PUBLISHABLE_KEY',
          '   ',
        ),
        throwsStateError,
      );
    });

    test('returns a supplied build-time value unchanged', () {
      const value = 'portfolio-test-value';

      expect(
        SupabaseConfig.requireValue('SUPABASE_URL', value),
        value,
      );
    });
  });
}
```

- [ ] **Step 2: Run the focused test and confirm the expected failure**

Run:

```powershell
flutter test test/core/config/supabase_config_test.dart
```

Expected: FAIL because `SupabaseConfig.requireValue` does not exist.

- [ ] **Step 3: Replace embedded defaults with validated build-time values**

Replace `lib/core/config/supabase_config.dart` with:

```dart
// lib/core/config/supabase_config.dart

final class SupabaseConfig {
  const SupabaseConfig._();

  static const String _url = String.fromEnvironment('SUPABASE_URL');
  static const String _publishableKey = String.fromEnvironment(
    'SUPABASE_PUBLISHABLE_KEY',
  );

  static String get url => requireValue('SUPABASE_URL', _url);

  static String get anonKey => requireValue(
        'SUPABASE_PUBLISHABLE_KEY',
        _publishableKey,
      );

  static String requireValue(String variableName, String value) {
    if (value.trim().isEmpty) {
      throw StateError(
        'Missing required build-time variable: $variableName. '
        'Supply it with --dart-define.',
      );
    }

    return value;
  }
}
```

- [ ] **Step 4: Run focused and full test suites**

Run:

```powershell
dart format lib/core/config/supabase_config.dart test/core/config/supabase_config_test.dart
flutter test test/core/config/supabase_config_test.dart
flutter test
```

Expected: all configuration tests pass; the full suite passes with the new test as the only test file if no other tests exist.

- [ ] **Step 5: Confirm embedded project values are gone without printing matches**

Run:

```powershell
$matches = rg -l --hidden -g '!build/**' -g '!.dart_tool/**' -g '!.git/**' 'https://[a-z0-9]{15,}\.supabase\.co|sb_(publishable|secret)_[A-Za-z0-9_-]{12,}|service[_-]?role' lib
if ($matches) { $matches; exit 1 }
Write-Output 'No embedded Supabase values found in lib.'
```

Expected: `No embedded Supabase values found in lib.`

- [ ] **Step 6: Commit only the configuration boundary and its tests**

```powershell
git add -- lib/core/config/supabase_config.dart test/core/config/supabase_config_test.dart
git diff --cached --check
git commit -m "security: require external Supabase configuration"
```

Expected: one commit containing only the two listed paths.

---

### Task 2: Repository Exclusions and Portfolio README

**Files:**
- Create: `.gitignore`
- Create: `README.md`
- Reuse: `assets/images/logo.png`
- Review only: `Screenshots/*.png`

**Interfaces:**
- Consumes: the safe configuration variables defined in Task 1 and the logo at `assets/images/logo.png`.
- Produces: a portfolio landing page and an exclusion policy used by the publication workspace.

- [ ] **Step 1: Create the exclusion policy**

Create `.gitignore` with:

```gitignore
# Dart and Flutter
.dart_tool/
.packages
.pub/
.pub-cache/
.flutter-plugins
.flutter-plugins-dependencies
build/
coverage/

# Generated platform dependencies
android/.gradle/
ios/Pods/
macos/Pods/
linux/flutter/ephemeral/
windows/flutter/ephemeral/

# Editors and operating systems
.idea/
.vscode/
*.iml
.DS_Store
Thumbs.db

# Logs and temporary files
*.log
*.tmp
*.temp
*.bak

# Local credentials and environment files
.env
.env.*
!.env.example
*.pem
*.key
*.p12
*.pfx
credentials*.json
secrets*.json

# Private Supabase backend and database material
supabase/
*.dump
*.backup
*.sql.gz
*.tar.gz

# Internal implementation documents
docs/superpowers/
```

- [ ] **Step 2: Verify the exclusion policy against known private paths**

Run:

```powershell
git check-ignore -v --no-index supabase/migrations/001_initial_setup.sql
git check-ignore -v --no-index build/.last_build_id
git check-ignore -v --no-index .dart_tool/package_config.json
git check-ignore -v --no-index .env
```

Expected: every command identifies the matching `.gitignore` rule.

- [ ] **Step 3: Review visual assets for private data**

Open `assets/images/logo.png` and each candidate under `Screenshots/` using image inspection. Record an allowlist containing only images with no credentials, personal identifiers, customer records, or production transaction details. If no screenshot clearly passes, publish the logo without screenshots.

Expected: `assets/images/logo.png` is approved; screenshots are approved individually or excluded.

- [ ] **Step 4: Create the portfolio README**

Create `README.md` with this structure and copy:

```markdown
<p align="center">
  <img src="assets/images/logo.png" alt="Sphinx logo" width="180" />
</p>

<h1 align="center">Sphinx</h1>

<p align="center">
  A bilingual Flutter point-of-sale and retail management application for desktop and mobile workflows.
</p>

## Overview

Sphinx brings sales, inventory, shifts, invoices, branch operations, analytics, expenses, and user management into one responsive application. The interface supports Arabic and English, including right-to-left layouts.

## Highlights

- Point-of-sale workflow with barcode support, discounts, refunds, and printable receipts
- Product, category, stock, and inventory-count management
- Branch-scoped dashboards, analytics, expenses, and shift reporting
- Invoice and daily-report PDF generation
- Role-aware user management and protected administrative workflows
- Responsive desktop and mobile layouts
- Arabic and English localization

## Technology

- Flutter and Dart
- BLoC state management
- Supabase client integration
- GetIt dependency injection
- PDF generation and printing
- FL Chart analytics

## Running Locally

Install Flutter with a Dart SDK compatible with the version declared in `pubspec.yaml`, then install dependencies:

```bash
flutter pub get
```

Provide your own Supabase project values at build time:

```bash
flutter run \
  --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co \
  --dart-define=SUPABASE_PUBLISHABLE_KEY=YOUR_PUBLISHABLE_KEY
```

For PowerShell, place the command on one line or use PowerShell backticks for line continuation.

## Backend Privacy

This portfolio repository intentionally excludes the Supabase project configuration, database migrations, seed data, database exports, and production data. Running the complete application requires a separately managed compatible backend schema.

## Verification

```bash
flutter analyze
flutter test
```

## Platforms

The project contains Flutter targets for Windows, Android, iOS, macOS, Linux, and web. The primary portfolio experience is optimized for desktop point-of-sale workflows.
```

If an image from the approved allowlist materially improves the portfolio, add it using a relative path under a `## Preview` section. Do not add any unreviewed screenshot.

- [ ] **Step 5: Verify README references and formatting**

Run:

```powershell
Test-Path README.md
Test-Path assets/images/logo.png
rg -n "assets/images/logo.png|Backend Privacy|SUPABASE_URL|SUPABASE_PUBLISHABLE_KEY" README.md
git diff --check -- .gitignore README.md
```

Expected: both files exist, all four README topics are found, and the diff check is clean.

- [ ] **Step 6: Commit the exclusions and README**

```powershell
git add -- .gitignore README.md
git diff --cached --check
git commit -m "docs: prepare secure portfolio repository"
```

Expected: one commit containing only `.gitignore` and `README.md`.

---

### Task 3: Build and Verify the Sanitized Publication Workspace

**Files:**
- Read from: `D:/My Projects/Sphinx/`
- Create: `C:/Users/Desha/.codex/visualizations/2026/08/01/019fbd48-f7c2-7123-a917-0fa5e409e22e/Sphinx-public/`

**Interfaces:**
- Consumes: the current working source tree after Tasks 1 and 2, plus the screenshot allowlist from Task 2.
- Produces: a standalone, sanitized source tree with no `.git` directory until verification passes.

- [ ] **Step 1: Resolve and validate the publication paths**

Run:

```powershell
$sourceRoot = (Resolve-Path 'D:/My Projects/Sphinx').Path
$publishRoot = 'C:/Users/Desha/.codex/visualizations/2026/08/01/019fbd48-f7c2-7123-a917-0fa5e409e22e/Sphinx-public'
$allowedParent = (Resolve-Path 'C:/Users/Desha/.codex/visualizations/2026/08/01/019fbd48-f7c2-7123-a917-0fa5e409e22e').Path
$publishParent = [System.IO.Path]::GetDirectoryName($publishRoot)
if ($publishParent -ne $allowedParent) { throw 'Publication path escaped the approved workspace.' }
if (Test-Path $publishRoot) { throw 'Publication workspace already exists; inspect it before continuing.' }
New-Item -ItemType Directory -Path $publishRoot | Out-Null
```

Expected: a new empty `Sphinx-public` directory inside the approved publication parent.

- [ ] **Step 2: Copy the current source through an explicit denylist**

Run:

```powershell
$sourceRoot = (Resolve-Path 'D:/My Projects/Sphinx').Path
$publishRoot = 'C:/Users/Desha/.codex/visualizations/2026/08/01/019fbd48-f7c2-7123-a917-0fa5e409e22e/Sphinx-public'
$excludedDirectories = @(
  '.git', '.dart_tool', '.idea', '.vscode', 'build', 'coverage',
  'supabase', 'Screenshots', 'docs/superpowers', 'ios/Pods', 'macos/Pods'
)
$excludedFiles = @(
  '.env', '.env.*', '*.log', '*.tmp', '*.temp', '*.bak',
  '*.dump', '*.backup', '*.sql.gz', '*.tar.gz', 'credentials*.json',
  'secrets*.json'
)
$arguments = @($sourceRoot, $publishRoot, '/E', '/COPY:DAT', '/R:1', '/W:1', '/NFL', '/NDL', '/NJH', '/NJS', '/NP', '/XD') +
  $excludedDirectories + @('/XF') + $excludedFiles
& robocopy @arguments
$copyExit = $LASTEXITCODE
if ($copyExit -ge 8) { throw "Sanitized copy failed with robocopy exit code $copyExit." }
```

Expected: robocopy exit code 0–7 and source files copied without excluded directories.

- [ ] **Step 3: Copy only approved screenshots**

If Task 2 approved no screenshots, skip this step. Otherwise create `Screenshots/` under `$publishRoot` and copy each approved filename explicitly with `Copy-Item -LiteralPath`; never use a wildcard.

Expected: every published screenshot appears on the reviewed allowlist and no other screenshot is present.

- [ ] **Step 4: Enforce path exclusions before Git initialization**

Run:

```powershell
$publishRoot = 'C:/Users/Desha/.codex/visualizations/2026/08/01/019fbd48-f7c2-7123-a917-0fa5e409e22e/Sphinx-public'
$forbiddenPaths = @(
  "$publishRoot/.git",
  "$publishRoot/.dart_tool",
  "$publishRoot/build",
  "$publishRoot/supabase",
  "$publishRoot/docs/superpowers"
)
$presentForbidden = $forbiddenPaths | Where-Object { Test-Path $_ }
if ($presentForbidden) { $presentForbidden; exit 1 }

$forbiddenFiles = Get-ChildItem -Recurse -Force -File $publishRoot | Where-Object {
  $_.Name -match '^\.env($|\.)|\.(dump|backup|log|tmp|temp|bak)$|\.sql\.gz$|\.tar\.gz$'
}
if ($forbiddenFiles) { $forbiddenFiles.FullName; exit 1 }
Write-Output 'Forbidden paths and file types are absent.'
```

Expected: `Forbidden paths and file types are absent.`

- [ ] **Step 5: Run a filename-only secret scan**

Run from `$publishRoot`:

```powershell
$publishRoot = 'C:/Users/Desha/.codex/visualizations/2026/08/01/019fbd48-f7c2-7123-a917-0fa5e409e22e/Sphinx-public'
Set-Location -LiteralPath $publishRoot
$secretPatterns = 'https://[a-z0-9]{15,}\.supabase\.co|sb_(publishable|secret)_[A-Za-z0-9_-]{12,}|service[_-]?role|SUPABASE_(SERVICE_ROLE|DB_PASSWORD|ACCESS_TOKEN)|JWT_SECRET|-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----'
$matches = rg -l --hidden -g '!.git/**' -g '!pubspec.lock' $secretPatterns .
if ($matches) {
  Write-Output 'Potential secrets found in:'
  $matches
  exit 1
}
Write-Output 'No credential-like values found.'
```

Expected: `No credential-like values found.` The scan prints filenames only if it fails, never matched values.

- [ ] **Step 6: Verify Flutter source from the sanitized workspace**

Run from `$publishRoot`:

```powershell
$publishRoot = 'C:/Users/Desha/.codex/visualizations/2026/08/01/019fbd48-f7c2-7123-a917-0fa5e409e22e/Sphinx-public'
Set-Location -LiteralPath $publishRoot
flutter pub get
dart format --output=none --set-exit-if-changed lib test
flutter analyze
flutter test
```

Expected: dependency resolution, formatting check, static analysis, and tests pass. If static analysis exposes pre-existing unrelated problems, record exact counts and stop before publication until the user approves proceeding.

- [ ] **Step 7: Initialize a fresh one-commit history**

Run from `$publishRoot`:

```powershell
$publishRoot = 'C:/Users/Desha/.codex/visualizations/2026/08/01/019fbd48-f7c2-7123-a917-0fa5e409e22e/Sphinx-public'
Set-Location -LiteralPath $publishRoot
git init -b main
git add -A
git diff --cached --check
git status --short
git commit -m "feat: publish Sphinx portfolio"
if ((git rev-list --count HEAD) -ne 1) { throw 'Public history must contain exactly one commit.' }
if (git remote) { throw 'Fresh publication workspace must not inherit a remote.' }
```

Expected: one root commit on `main`, no inherited remotes, and no excluded file is staged.

- [ ] **Step 8: Audit the committed file list and Git objects**

Run from `$publishRoot`:

```powershell
$publishRoot = 'C:/Users/Desha/.codex/visualizations/2026/08/01/019fbd48-f7c2-7123-a917-0fa5e409e22e/Sphinx-public'
Set-Location -LiteralPath $publishRoot
$trackedForbidden = git ls-files | Where-Object {
  $_ -match '(^|/)(supabase|build|\.dart_tool|docs/superpowers)(/|$)' -or
  $_ -match '(^|/)\.env($|\.)|\.(dump|backup|log|tmp|temp|bak)$|\.sql\.gz$|\.tar\.gz$'
}
if ($trackedForbidden) { $trackedForbidden; exit 1 }
if ((git rev-list --count HEAD) -ne 1) { throw 'Unexpected Git history detected.' }
git fsck --full
Write-Output 'Committed publication tree is sanitized.'
```

Expected: no forbidden tracked path, exactly one commit, a clean `git fsck`, and `Committed publication tree is sanitized.`

---

### Task 4: Create and Push the Public GitHub Repository

**Files:**
- Publish from: `C:/Users/Desha/.codex/visualizations/2026/08/01/019fbd48-f7c2-7123-a917-0fa5e409e22e/Sphinx-public/`

**Interfaces:**
- Consumes: the verified one-commit `main` branch from Task 3 and the user's authenticated GitHub CLI session.
- Produces: a public personal GitHub repository named `Sphinx` with the sanitized `main` branch.

- [ ] **Step 1: Ensure GitHub CLI is installed**

Run:

```powershell
gh --version
```

Expected: a GitHub CLI version is printed. If the command is missing, install the official GitHub CLI with Windows Package Manager after approval:

```powershell
winget install --id GitHub.cli --exact --source winget
```

Then open a new command environment and rerun `gh --version`.

- [ ] **Step 2: Confirm authentication and derive the personal account**

Run:

```powershell
gh auth status
$githubLogin = gh api user --jq .login
if (-not $githubLogin) { throw 'Unable to determine the authenticated GitHub login.' }
Write-Output "Authenticated GitHub account: $githubLogin"
```

Expected: authentication succeeds and the user's login is printed. If authentication is missing, stop and ask the user to complete `gh auth login` before continuing.

- [ ] **Step 3: Ensure the target repository does not already exist**

Run:

```powershell
$githubLogin = gh api user --jq .login
if (-not $githubLogin) { throw 'Unable to determine the authenticated GitHub login.' }
gh repo view "$githubLogin/Sphinx" --json nameWithOwner,visibility
```

Expected: the command reports that the repository does not exist. If it exists, stop without pushing and ask whether the user wants to use that repository or choose another name.

- [ ] **Step 4: Re-run final privacy gates immediately before creation**

Run from `$publishRoot`:

```powershell
$publishRoot = 'C:/Users/Desha/.codex/visualizations/2026/08/01/019fbd48-f7c2-7123-a917-0fa5e409e22e/Sphinx-public'
Set-Location -LiteralPath $publishRoot
if ((git rev-list --count HEAD) -ne 1) { throw 'Public history is no longer a single root commit.' }
if (git status --porcelain) { throw 'Publication workspace has uncommitted changes.' }
$forbidden = git ls-files | Where-Object {
  $_ -match '(^|/)(supabase|build|\.dart_tool|docs/superpowers)(/|$)' -or
  $_ -match '(^|/)\.env($|\.)|\.(dump|backup)$'
}
if ($forbidden) { $forbidden; exit 1 }
Write-Output 'Final privacy gates passed.'
```

Expected: `Final privacy gates passed.`

- [ ] **Step 5: Create the public repository and push `main`**

Run from `$publishRoot`:

```powershell
$publishRoot = 'C:/Users/Desha/.codex/visualizations/2026/08/01/019fbd48-f7c2-7123-a917-0fa5e409e22e/Sphinx-public'
Set-Location -LiteralPath $publishRoot
gh repo create Sphinx \
  --public \
  --source . \
  --remote origin \
  --push \
  --description "Bilingual Flutter point-of-sale and retail management portfolio application"
```

For PowerShell execution, place the command on one line or replace the backslashes with PowerShell backticks.

Expected: GitHub creates `$githubLogin/Sphinx`, adds `origin`, and pushes `main`.

- [ ] **Step 6: Verify remote visibility and content**

Run:

```powershell
$githubLogin = gh api user --jq .login
if (-not $githubLogin) { throw 'Unable to determine the authenticated GitHub login.' }
gh repo view "$githubLogin/Sphinx" --json nameWithOwner,url,visibility,defaultBranchRef
git remote -v
git ls-remote --heads origin main
```

Expected: visibility is `PUBLIC`, the default branch is `main`, `origin` points to the new repository, and the remote `main` head exists.

- [ ] **Step 7: Final handoff**

Report:

- The public repository URL.
- Confirmation that the public history has one root commit.
- Confirmation that Supabase configuration values, migrations, data, and generated files were excluded.
- Flutter analysis and test results.
- The local sanitized publication workspace path.
- Any screenshots intentionally excluded because their privacy could not be confirmed.
