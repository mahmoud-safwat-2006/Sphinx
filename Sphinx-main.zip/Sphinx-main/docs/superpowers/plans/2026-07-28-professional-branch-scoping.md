# Professional Branch Scoping Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use `superpowers:subagent-driven-development` (recommended) or `superpowers:executing-plans` to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Deliver a responsive branch selector and make every operational feature consistently read and write data for the selected branch, while “All branches” provides a fast aggregated read-only view.

**Architecture:** Keep products, categories, units, permissions, and store identity shared across the company. Introduce an explicit `BranchScope` value for uninitialized, all-branches, and single-branch modes; repositories consume that scope for reads, while a single write guard prevents branch-owned mutations outside a selected branch. Supabase remains the security boundary: RLS and transactional RPCs validate the authenticated user’s allowed branch and never trust a client-supplied branch ID by itself.

**Tech Stack:** Flutter 3 / Dart 3.6, `flutter_bloc`, `get_it`, Supabase Flutter, PostgreSQL RLS and PL/pgSQL.

## Global Constraints

- Do not add test files.
- Preserve all existing user changes in the dirty working tree.
- Mobile branch selection opens a modal bottom sheet.
- Desktop branch selection opens a direction-aware side drawer.
- Shared data: products, categories, product units, permission definitions, and store identity.
- Branch-owned data: stock, users, shifts, sales, invoices, refunds, expenses, inventory snapshots, notifications, dashboards, and reports.
- “All branches” is an aggregate read-only mode for branch-owned operational data.
- Creating or editing branch-owned data requires one concrete selected branch.
- Non-primary administrators and staff remain locked to their assigned branch.
- Use localized ARB strings; do not add hard-coded Arabic or English UI copy.
- Do not apply production DDL until the migration has been reviewed and local/static verification passes.

---

## File Map

### Create

- `lib/features/branches/domain/branch_scope.dart` — explicit branch selection value and write/read semantics.
- `lib/features/branches/data/models/branch_statistics.dart` — typed branch KPI, stock, workforce, and activity summary.
- `lib/features/branches/data/repositories/branch_repository.dart` — branch CRUD, validation counts, and statistics queries.
- `lib/features/branches/presentation/widgets/branch_selector_panel.dart` — shared selector content used by mobile bottom sheet and desktop drawer.
- `lib/features/branches/presentation/widgets/branch_scope_banner.dart` — compact current-scope/read-only indicator for screens.
- `lib/features/branches/presentation/widgets/branch_write_guard.dart` — one reusable guard for branch-owned UI actions.
- `lib/features/branches/presentation/widgets/branch_form.dart` — reusable add/edit branch form for mobile and desktop surfaces.
- `lib/features/branches/presentation/widgets/branch_details_panel.dart` — responsive branch statistics, health, and activity view.
- `lib/features/settings/data/models/cloud_table_definition.dart` — allow-listed table metadata, safe columns, labels, and branch ownership.
- `lib/features/settings/data/repositories/cloud_data_repository.dart` — paginated, branch-aware table counts and safe row inspection.
- `lib/features/settings/presentation/widgets/cloud_table_inspector.dart` — reusable responsive table browser.
- `lib/core/state/branch_refresh_coordinator.dart` — deduplicated refresh orchestration for singleton feature cubits.
- The exact migration file printed by `supabase migration new branch_scope_hardening` — generated with the Supabase CLI and then filled with the reviewed schema/RLS/RPC changes below.

### Modify

- `lib/features/branches/presentation/cubit/branch_cubit.dart`
- `lib/features/branches/presentation/widgets/branch_switcher.dart`
- `lib/features/branches/presentation/screens/branches_management_screen.dart`
- `lib/features/dashboard/presentation/dashboard_screen.dart`
- `lib/features/dashboard/presentation/widgets/header_actions.dart`
- `lib/features/dashboard/presentation/widgets/mobile_drawer.dart`
- `lib/core/di/dependency_injection.dart`
- `lib/core/state/state_synchronizer.dart`
- `lib/features/auth/data/repository/user_repository_imp.dart`
- `lib/features/auth/presentation/cubit/user_cubit.dart`
- `lib/features/products/data/repository/product_repository_imp.dart`
- `lib/features/products/presentation/cubit/product_cubit.dart`
- `lib/features/products/presentation/products_screen.dart`
- `lib/features/stock/presentation/cubit/stock_cubit.dart`
- `lib/features/stock_summary/presentation/cubit/stock_summary_cubit.dart`
- `lib/features/stock_summary/presentation/screens/take_inventory_screen.dart`
- `lib/features/pos/data/repository/pos_repository_impl.dart`
- `lib/features/pos/presentation/cubit/pos_cubit.dart`
- `lib/features/pos/presentation/pos_screen.dart`
- `lib/features/invoice/presentation/cubit/invoice_cubit.dart`
- `lib/features/expenses/data/expense_repository.dart`
- `lib/features/expenses/presentation/expenses_screen.dart`
- `lib/features/shifts/data/repositories/shift_repository_impl.dart`
- `lib/features/shifts/presentation/cubit/shift_cubit.dart`
- `lib/features/analytics/data/analytics_repository_impl.dart`
- `lib/features/analytics/presentation/cubit/analytics_cubit.dart`
- `lib/features/settings/presentation/settings_screen.dart`
- `lib/features/settings/presentation/screens/data_management_screen.dart`
- `lib/features/settings/presentation/widgets/data_management_card.dart`
- `lib/features/settings/presentation/widgets/users_management_card.dart`
- `lib/l10n/app_en.arb`
- `lib/l10n/app_ar.arb`
- Generated localization Dart files, using the repository’s existing localization generation command.

---

### Task 1: Establish the Baseline and Protect Existing Work

**Files:**

- Inspect: all files listed in the file map.
- Modify: none.

**Interfaces:**

- Consumes: current dirty working tree and current Supabase project schema.
- Produces: a recorded baseline that distinguishes pre-existing analyzer issues from implementation regressions.

- [ ] **Step 1: Record the working tree before editing**

Run:

```powershell
git status --short
git diff --stat
git diff -- lib/features/branches lib/features/dashboard supabase/migrations
```

Expected: existing changes remain visible; do not reset, checkout, delete, or format unrelated files.

- [ ] **Step 2: Record the Flutter baseline**

Run:

```powershell
flutter pub get
flutter analyze
```

Expected: save the existing analyzer output in the task notes. Later tasks may only claim success if they introduce no new errors.

- [ ] **Step 3: Discover the installed Supabase CLI commands**

Run:

```powershell
supabase --version
supabase migration --help
supabase db --help
```

Expected: use only flags shown by the installed CLI. If the CLI is unavailable, use the connected Supabase read tools for inspection and postpone DDL application until the CLI workflow is available.

- [ ] **Step 4: Inspect live schema health without changing it**

Use the connected Supabase project `vrgikyqtbwhqianspvbe` to:

1. list `public` tables and confirm RLS is enabled;
2. list applied migrations;
3. fetch security advisors;
4. fetch performance advisors.

Expected: capture advisor findings and remediation links in the implementation handoff.

---

### Task 2: Introduce an Explicit Branch Scope Contract

**Files:**

- Create: `lib/features/branches/domain/branch_scope.dart`
- Modify: `lib/features/branches/presentation/cubit/branch_cubit.dart`
- Modify: `lib/features/auth/presentation/cubit/user_cubit.dart`

**Interfaces:**

- Consumes: `Branch`, authenticated user `branchId`, and `isPrimaryAdmin`.
- Produces:
  - `enum BranchScopeMode { uninitialized, all, branch }`
  - `BranchScope.uninitialized()`
  - `BranchScope.all()`
  - `BranchScope.branch(String branchId)`
  - `String? BranchScope.branchId`
  - `bool BranchScope.isAll`
  - `bool BranchScope.canWriteBranchData`
  - `int BranchState.selectionRevision`
  - `Future<void> BranchCubit.selectAll()`
  - `Future<void> BranchCubit.selectBranch(String branchId)`

- [ ] **Step 1: Add the immutable scope value**

Implement:

```dart
enum BranchScopeMode { uninitialized, all, branch }

class BranchScope {
  const BranchScope._(this.mode, this.branchId);

  const BranchScope.uninitialized()
      : this._(BranchScopeMode.uninitialized, null);

  const BranchScope.all() : this._(BranchScopeMode.all, null);

  const BranchScope.branch(String id) : this._(BranchScopeMode.branch, id);

  final BranchScopeMode mode;
  final String? branchId;

  bool get isInitialized => mode != BranchScopeMode.uninitialized;
  bool get isAll => mode == BranchScopeMode.all;
  bool get isSingleBranch => mode == BranchScopeMode.branch;
  bool get canWriteBranchData => isSingleBranch;

  @override
  bool operator ==(Object other) =>
      other is BranchScope &&
      other.mode == mode &&
      other.branchId == branchId;

  @override
  int get hashCode => Object.hash(mode, branchId);
}
```

Do not use `null` alone to mean both “not initialized” and “all branches.”

- [ ] **Step 2: Refactor `BranchState` around `BranchScope`**

Replace `selectedBranchId` as the source of truth with:

```dart
final BranchScope scope;
final int selectionRevision;
```

Keep compatibility getters during the migration:

```dart
String? get selectedBranchId => scope.branchId;
bool get isAllBranches => scope.isAll;
```

Increment `selectionRevision` only when the effective scope changes. Loading, creating, updating, or deactivating branch records must not increment it.

- [ ] **Step 3: Make initialization deterministic**

Implement these rules in `BranchCubit.init`:

```dart
if (!isPrimaryAdmin && userBranchId != null) {
  scope = BranchScope.branch(userBranchId);
} else if (isPrimaryAdmin) {
  scope = const BranchScope.all();
} else {
  scope = const BranchScope.uninitialized();
}
```

If a non-primary user has no branch, expose a configuration error state instead of silently granting all-branch access.

- [ ] **Step 4: Validate branch selection before emitting**

`selectBranch` must:

1. return early for non-primary users;
2. find an active branch matching the ID;
3. emit a friendly localized error if it does not exist;
4. skip emitting if the scope is unchanged;
5. increment `selectionRevision` exactly once when it changes.

`selectAll` must be available only to primary administrators and follow the same no-op rule.

- [ ] **Step 5: Handle branch deactivation safely**

Before deactivation:

- reject the main branch;
- reject a branch that still owns active users or open shifts, returning counts to the UI;
- if the deactivated branch is selected, switch the primary administrator to `All branches`;
- never change a regular user’s branch implicitly.

- [ ] **Step 6: Verify statically**

Run:

```powershell
dart format lib/features/branches/domain/branch_scope.dart lib/features/branches/presentation/cubit/branch_cubit.dart lib/features/auth/presentation/cubit/user_cubit.dart
flutter analyze
```

Expected: no new analyzer errors and no new test files.

---

### Task 3: Build the Responsive Branch Selector

**Files:**

- Create: `lib/features/branches/presentation/widgets/branch_selector_panel.dart`
- Create: `lib/features/branches/presentation/widgets/branch_scope_banner.dart`
- Modify: `lib/features/branches/presentation/widgets/branch_switcher.dart`
- Modify: `lib/features/dashboard/presentation/widgets/header_actions.dart`
- Modify: `lib/features/dashboard/presentation/widgets/mobile_drawer.dart`
- Modify: `lib/l10n/app_en.arb`
- Modify: `lib/l10n/app_ar.arb`

**Interfaces:**

- Consumes: `BranchState`, `BranchCubit.selectAll`, and `BranchCubit.selectBranch`.
- Produces:
  - `BranchSelectorPanel({required VoidCallback onClose})`
  - `BranchScopeBanner({bool compact = false})`
  - `Future<void> showBranchSelector(BuildContext context)`

- [ ] **Step 1: Build one selector panel for both surfaces**

The panel contains:

- a drag handle only when rendered in the mobile bottom sheet;
- localized title and subtitle;
- current-scope summary;
- an “All branches” tile with an aggregate/read-only badge;
- active branch tiles with main-branch badge, address, and selected check;
- a search box shown when there are more than eight active branches;
- loading, empty, and error states;
- minimum 48px touch targets and direction-aware chevrons.

Keep selection content independent from its container so mobile and desktop cannot drift.

- [ ] **Step 2: Open the mobile selector as a bottom sheet**

For `ResponsiveHelper.isMobileOrTablet(context)` use:

```dart
showModalBottomSheet<void>(
  context: context,
  isScrollControlled: true,
  useSafeArea: true,
  backgroundColor: Colors.transparent,
  builder: (_) => FractionallySizedBox(
    heightFactor: .78,
    child: BranchSelectorPanel(onClose: () => Navigator.pop(context)),
  ),
);
```

Use a rounded 24px top edge, keyboard-safe padding, and the existing app color system.

- [ ] **Step 3: Open the desktop selector as a side drawer**

Use `showGeneralDialog<void>` with:

- a dimmed dismissible barrier;
- 220ms fade and slide transition;
- width clamped between 360px and 420px;
- alignment at `AlignmentDirectional.centerEnd`;
- full safe-area height;
- rounded leading corners according to text direction.

The desktop drawer must not resize the dashboard or recreate navigation state.

- [ ] **Step 4: Redesign the header trigger**

Show:

- store/building icon;
- selected branch name, or localized “All branches”;
- a small read-only aggregate indicator for all-branch mode;
- chevron;
- tooltip and semantic label.

Compact mobile mode shows icon plus a shortened label without overflowing the AppBar.

- [ ] **Step 5: Add current scope to the mobile navigation drawer**

Place `BranchScopeBanner` below the signed-in user block. Tapping it opens the same mobile bottom sheet. Hide the interaction for users locked to a branch, but still display their assigned branch.

- [ ] **Step 6: Generate localization output**

Add keys for:

```text
branches
allBranches
allBranchesReadOnly
selectBranch
searchBranches
mainBranch
currentBranch
branchRequired
branchLockedToUser
branchUnavailable
cannotDeactivateBranch
branchHasActiveUsers
branchHasOpenShifts
```

Run the repository’s localization generation command defined by `l10n.yaml`.

- [ ] **Step 7: Verify responsive behavior**

Run:

```powershell
dart format lib/features/branches/presentation/widgets lib/features/dashboard/presentation/widgets
flutter analyze
flutter build windows --debug
```

Manually verify at widths 390px, 768px, 1024px, and 1440px in both English and Arabic.

---

### Task 4: Redesign Branch Management with Bottom Sheet and Drawer Forms

**Files:**

- Create: `lib/features/branches/presentation/widgets/branch_form.dart`
- Modify: `lib/features/branches/presentation/screens/branches_management_screen.dart`
- Modify: `lib/features/branches/presentation/cubit/branch_cubit.dart`
- Modify: `lib/l10n/app_en.arb`
- Modify: `lib/l10n/app_ar.arb`

**Interfaces:**

- Consumes: branch CRUD methods and responsive breakpoint helpers.
- Produces:
  - `BranchForm.create(...)`
  - `BranchForm.edit({required Branch branch, ...})`
  - `Future<void> showBranchDetailsSurface(BuildContext, Branch)`

- [ ] **Step 1: Replace dialogs with a reusable branch form**

The form contains name, address, phone, validation, loading state, and server error state. Disable submit while the request is running and dispose all controllers.

- [ ] **Step 2: Use the correct responsive surface**

- Mobile/tablet: 85%-height draggable bottom sheet with handle.
- Desktop: direction-aware 420px side drawer.
- Use the same form and details widgets inside both.

- [ ] **Step 3: Professionalize the branch list**

Add:

- search;
- active/main/selected status chips;
- user count and open-shift count returned by the branch summary query;
- clear empty and error states;
- skeleton loading instead of replacing the full screen with one spinner;
- list item keys by branch ID;
- pagination only when branch count exceeds 100.

- [ ] **Step 4: Make deactivation a safe soft-delete workflow**

Show the impact summary before confirming. The primary branch cannot be deactivated. A branch with active users or open shifts must show actionable blockers instead of attempting the update.

- [ ] **Step 5: Remove broken hard-coded strings**

Replace all mojibake/hard-coded bilingual strings in `branches_management_screen.dart` with localization keys.

- [ ] **Step 6: Verify**

Run:

```powershell
dart format lib/features/branches
flutter analyze
flutter build windows --debug
```

Manually verify create, edit, details, validation, blocked deactivation, and Arabic directionality.

---

### Task 4A: Show Complete Statistics When a Branch Is Opened

**Files:**

- Create: `lib/features/branches/data/models/branch_statistics.dart`
- Create: `lib/features/branches/data/repositories/branch_repository.dart`
- Create: `lib/features/branches/presentation/widgets/branch_details_panel.dart`
- Modify: `lib/features/branches/presentation/cubit/branch_cubit.dart`
- Modify: `lib/features/branches/presentation/screens/branches_management_screen.dart`
- Modify: `lib/core/di/dependency_injection.dart`
- Modify: `lib/l10n/app_en.arb`
- Modify: `lib/l10n/app_ar.arb`

**Interfaces:**

- Consumes: a concrete branch ID or primary-admin all-branches scope plus an optional date range.
- Produces:
  - `Future<BranchStatistics> BranchRepository.getStatistics({String? branchId, required DateTime start, required DateTime end})`
  - `Future<List<BranchActivityItem>> BranchRepository.getRecentActivity({String? branchId, int limit = 20})`
  - `BranchDetailsPanel({required Branch? branch, required bool aggregate})`

- [ ] **Step 1: Define a typed statistics model**

Include:

```dart
class BranchStatistics {
  final double grossSales;
  final double refunds;
  final double netSales;
  final double expenses;
  final double estimatedProfit;
  final int transactionCount;
  final int activeUserCount;
  final int openShiftCount;
  final int completedShiftCount;
  final int productCount;
  final int lowStockCount;
  final int outOfStockCount;
  final double stockRetailValue;
  final double stockCostValue;
  final DateTime start;
  final DateTime end;
}
```

`BranchActivityItem` must identify the event type, record ID, branch ID/name, amount when applicable, actor, and timestamp.

- [ ] **Step 2: Move branch data access out of the cubit**

`BranchRepository` owns:

- branch listing and CRUD;
- user/open-shift blocker counts;
- statistics RPC calls;
- recent activity retrieval.

Inject it into `BranchCubit`; do not query `Supabase.instance.client` directly from presentation state.

- [ ] **Step 3: Add an overall summary to the branch screen**

At the top of `BranchesManagementScreen`, show primary-admin aggregate cards for:

- total active branches;
- today’s net sales;
- open shifts;
- low/out-of-stock totals;
- active users.

The summary uses all active branches and refreshes after branch CRUD, sales, shifts, expenses, or stock changes.

- [ ] **Step 4: Open full branch details on branch click**

Clicking a branch card opens:

- mobile/tablet: draggable 90%-height bottom sheet;
- desktop: direction-aware side drawer between 460px and 560px wide.

The panel contains:

1. branch identity, address, phone, main/active status;
2. date presets for Today, 7 days, 30 days, and custom range;
3. sales/refunds/net/expenses/profit KPI cards;
4. transaction and shift counts;
5. workforce summary;
6. stock health and inventory valuation;
7. recent sales, refunds, expenses, shift events, and inventory counts;
8. actions for Select branch, Edit, and safe Deactivate.

- [ ] **Step 5: Add an “All branches” statistics entry**

Provide a visually distinct aggregate card above the branch list. Clicking it opens the same details panel with `aggregate: true`, combines all active branches, and shows the source branch on every recent activity row.

The aggregate panel is read-only and must not offer branch edit/deactivate actions.

- [ ] **Step 6: Handle statistics loading professionally**

Cache statistics by `(branchId, start, end, selectionRevision)` for a short session lifetime, deduplicate identical in-flight requests, retain previous data during refresh, and invalidate relevant cache entries after branch-owned writes.

Show independent loading/error states for KPIs and recent activity so one failed section does not blank the entire panel.

- [ ] **Step 7: Verify branch statistics**

For Branch A, Branch B, and All branches:

- compare KPI values to invoices, expenses, shifts, and stock screens;
- confirm All equals the valid aggregate of A + B;
- confirm refunds and expenses reduce net/profit correctly;
- confirm activity rows show correct branch names;
- confirm changing date range never shows stale prior-range results.

Run `dart format` on the touched paths and `flutter analyze`.

---

### Task 5: Centralize Branch Change Refresh and Prevent Stale Results

**Files:**

- Create: `lib/core/state/branch_refresh_coordinator.dart`
- Create: `lib/features/branches/presentation/widgets/branch_write_guard.dart`
- Modify: `lib/core/state/state_synchronizer.dart`
- Modify: `lib/core/di/dependency_injection.dart`
- Modify: `lib/features/dashboard/presentation/dashboard_screen.dart`
- Modify: branch-dependent cubits listed in the file map.

**Interfaces:**

- Consumes: `BranchState.selectionRevision`.
- Produces:
  - `BranchRefreshCoordinator.refresh(BranchScope scope, int revision)`
  - `BranchWriteGuard.requireSelectedBranch(BuildContext context)`
  - data-change event `entityType: 'branch_scope'`

- [ ] **Step 1: Add one branch-scope event**

After a successful scope change, emit:

```dart
StateSynchronizer.notify(DataChangeEvent(
  entityType: 'branch_scope',
  operation: 'select',
  id: scope.branchId,
  metadata: {
    'mode': scope.mode.name,
    'revision': selectionRevision,
  },
));
```

Do not emit this event from `loadBranches`, create, edit, or error states.

- [ ] **Step 2: Add a deduplicating refresh coordinator**

The coordinator stores the latest revision, ignores duplicates, and refreshes singleton data sources concurrently:

```dart
await Future.wait<void>([
  stockCubit.loadData(),
  productCubit.getAllProducts(),
  invoiceCubit.loadSales(),
  analyticsCubit.refreshData(),
  shiftCubit.load(),
  posCubit.load(),
]);
notificationsCubit.loadData();
```

Change `StockCubit.loadData` and `NotificationsCubit.loadData` to return `Future<void>`/`void` consistently so the coordinator does not rely on dynamic return values.

- [ ] **Step 3: Protect against out-of-order network responses**

Add an integer request version to every branch-dependent cubit that does not already have one:

```dart
final request = ++_requestVersion;
final result = await repositoryCall();
if (request != _requestVersion || isClosed) return;
emit(...);
```

Apply to stock, stock summary, POS, invoices, shifts list/report loads, analytics, and users. Preserve current data while refreshing to avoid UI flashes.

- [ ] **Step 4: Refresh screen-owned state lazily**

`ExpensesScreen`, factory-created `StockSummaryCubit`, and screen-created analytics instances must listen for the `branch_scope` event and reload only while mounted. Cancel subscriptions in `dispose`.

Do not rebuild every navigation destination or recreate the whole dashboard.

- [ ] **Step 5: Add one reusable write guard**

`BranchWriteGuard.requireSelectedBranch`:

1. returns the selected branch ID in single-branch mode;
2. shows a localized bottom sheet explaining that aggregate mode is read-only;
3. offers “Select branch” and “Cancel” actions;
4. returns `null` when the user does not select a branch.

Use this guard for POS checkout, refunds, stock edits, inventory counts/finalization, expenses, and branch-specific user assignment operations.

- [ ] **Step 6: Remove the broad dashboard listener**

Replace the current `BlocListener<BranchCubit, BranchState>` that reloads on every state emission with:

```dart
listenWhen: (previous, current) =>
    previous.selectionRevision != current.selectionRevision,
```

Delegate work to `BranchRefreshCoordinator`.

- [ ] **Step 7: Verify rapid switching**

Manually switch Branch A → Branch B → All branches → Branch A quickly. Confirm:

- the last selection always wins;
- stale Branch B responses never overwrite Branch A;
- no duplicate reload occurs when merely opening branch management;
- current screen filters and date ranges remain intact.

Run `flutter analyze` after formatting.

---

### Task 6: Make Every Repository Consume the Same Branch Scope

**Files:**

- Modify all repositories and cubits listed in the file map.

**Interfaces:**

- Consumes: `BranchScope` captured once at the beginning of each operation.
- Produces: branch-filtered reads, aggregate reads, and selected-branch-only writes.

- [ ] **Step 1: Capture scope once per operation**

Use:

```dart
final scope = getIt<BranchCubit>().state.scope;
final branchId = scope.branchId;
```

Never call `effectiveBranchId` multiple times inside one async operation; selection could change between awaits.

- [ ] **Step 2: Apply the feature matrix**

| Feature | Single branch | All branches | Writes in all mode |
|---|---|---|---|
| Dashboard | selected branch metrics | summed metrics | none |
| Products | shared catalog + branch stock | shared catalog + summed stock | catalog metadata only |
| Stock alerts | selected branch thresholds | aggregate quantity and clearly labeled aggregate threshold | none |
| Stock summary | selected branch | aggregate | none |
| POS | selected branch products/stock/shift | disabled with branch prompt | blocked |
| Invoices/refunds | selected branch | combined list | blocked |
| Expenses | selected branch | combined list | blocked |
| Shifts | selected branch | combined list | opening/closing requires selected branch |
| Reports/analytics | selected branch | aggregate | read-only |
| Inventory counts | selected branch | combined history only | blocked |
| Notifications | selected branch | aggregate and branch-labeled | read-only |
| Users | assigned-branch list | all users for primary admin | assignment remains admin-only |
| Branch management | global | global | primary admin only |
| Store settings | shared | shared | permission-based, not scope-based |

- [ ] **Step 3: Fix product and stock queries**

For one branch, query `branch_stock` by `branch_id`. For all branches, aggregate in PostgreSQL instead of downloading every stock row and summing in Dart.

Provide an RPC or security-invoker view returning:

```sql
product_id,
sum(quantity) as quantity,
sum(min_quantity) as min_quantity,
count(*) as branch_count
```

Join the aggregate to the shared product catalog server-side. Keep pagination and filtering server-side; do not load all products before `skip/take`.

- [ ] **Step 4: Seed stock rows for every shared product**

Creating a product must create a zero-quantity `branch_stock` row for every active branch, then apply the entered quantity only to the selected branch. Creating a branch must create zero-quantity rows for every active product. Use one transactional RPC for each workflow.

- [ ] **Step 5: Filter sales, invoices, refunds, and sale items**

All list, search, range-delete, link-to-session, and refund operations must filter by the captured branch scope. A refund must inherit `branch_id` from the original sale in the database; the client must not choose it independently.

- [ ] **Step 6: Filter expenses and shifts**

Expense writes require the active shift and selected branch to match. Shift reads filter by selected branch; aggregate mode combines branches. Opening a shift passes the selected branch explicitly and the database validates access.

- [ ] **Step 7: Filter analytics and dashboard queries**

Pass `branch_id_input` to analytics RPCs. When null for an authorized primary administrator, aggregate across branches. Preserve date/session filters during branch changes.

Eliminate N+1 product lookups in analytics by joining product data in the query/RPC.

- [ ] **Step 8: Filter users and settings correctly**

Primary administrators in all mode see all users. In single-branch mode they see users for that branch plus themselves. Regular users never see another branch’s users. Store settings remain shared and do not reload on branch change.

- [ ] **Step 9: Verify each matrix row**

Use the existing app against two branches with distinct stock and transactions. For each row in the matrix, compare Branch A, Branch B, and All branches. Confirm the aggregate equals A + B where appropriate and that all forbidden write controls are disabled before a request is sent.

---

### Task 7: Harden Supabase Schema, RLS, Indexes, and RPCs

**Files:**

- Create through CLI: the exact migration file printed by `supabase migration new branch_scope_hardening`

**Interfaces:**

- Consumes: authenticated user ID, assigned branch, primary-admin flag, and requested branch.
- Produces:
  - `public.can_access_branch(uuid) returns boolean`
  - `public.get_branch_statistics(uuid, timestamptz, timestamptz)`
  - `public.get_branch_recent_activity(uuid, integer)`
  - `public.get_cloud_table_counts(uuid)`
  - hardened operational RLS policies
  - transactional product/stock and sale/refund RPCs
  - branch-aware aggregate query/RPC

- [ ] **Step 1: Generate the migration file correctly**

Run:

```powershell
supabase migration new branch_scope_hardening
```

Use the exact path printed by the CLI for all remaining steps. Do not invent or rename the timestamp.

- [ ] **Step 2: Backfill legacy null branch IDs**

Inside the migration:

```sql
do $$
declare
  main_branch_id uuid;
begin
  select id into main_branch_id
  from public.branches
  where is_main_branch = true and is_active = true
  order by created_at
  limit 1;

  if main_branch_id is null then
    raise exception 'ACTIVE_MAIN_BRANCH_REQUIRED';
  end if;

  update public.sales set branch_id = main_branch_id where branch_id is null;
  update public.sale_items si
     set branch_id = s.branch_id
    from public.sales s
   where si.sale_id = s.id and si.branch_id is null;
  update public.shifts set branch_id = main_branch_id where branch_id is null;
  update public.expenses e
     set branch_id = coalesce(s.branch_id, main_branch_id)
    from public.shifts s
   where e.shift_id = s.id and e.branch_id is null;
  update public.expenses
     set branch_id = main_branch_id
   where branch_id is null;
  update public.inventory_snapshots
     set branch_id = main_branch_id
   where branch_id is null;
end
$$;
```

Then make branch ownership non-null for new operational records:

```sql
alter table public.sales alter column branch_id set not null;
alter table public.sale_items alter column branch_id set not null;
alter table public.shifts alter column branch_id set not null;
alter table public.expenses alter column branch_id set not null;
alter table public.inventory_snapshots alter column branch_id set not null;
```

- [ ] **Step 3: Add an indexed access helper**

Implement with a fixed search path:

```sql
create or replace function public.can_access_branch(requested_branch_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.users u
    where u.id = (select auth.uid())
      and u.is_active = true
      and (
        u.is_primary_admin = true
        or u.branch_id = requested_branch_id
      )
  );
$$;
```

Revoke anonymous execution and grant only authenticated execution:

```sql
revoke all on function public.can_access_branch(uuid) from public, anon;
grant execute on function public.can_access_branch(uuid) to authenticated;
```

- [ ] **Step 4: Replace operational RLS policies**

For `branch_stock`, `sales`, `sale_items`, `shifts`, `expenses`, and `inventory_snapshots`, use separate policies with explicit roles:

```sql
create policy "branch read"
on public.sales for select
to authenticated
using ((select public.can_access_branch(branch_id)));

create policy "branch insert"
on public.sales for insert
to authenticated
with check ((select public.can_access_branch(branch_id)));

create policy "branch update"
on public.sales for update
to authenticated
using ((select public.can_access_branch(branch_id)))
with check ((select public.can_access_branch(branch_id)));

create policy "branch delete"
on public.sales for delete
to authenticated
using ((select public.is_current_user_primary_admin()));
```

Adapt names and delete permissions per table. Do not use deprecated `auth.role()` checks. Ensure UPDATE also has a SELECT policy.

- [ ] **Step 5: Protect child inventory rows**

Replace blanket access on `inventory_snapshot_items` with `exists` policies through the parent snapshot:

```sql
exists (
  select 1
  from public.inventory_snapshots snapshot
  where snapshot.id = inventory_snapshot_items.snapshot_id
    and (select public.can_access_branch(snapshot.branch_id))
)
```

Add both `USING` and `WITH CHECK` where required.

- [ ] **Step 6: Harden branch-sensitive RPCs**

For `open_shift`, `complete_sale`, `complete_refund`, `close_shift`, `finalize_inventory_snapshot`, and `create_branch_with_stock`:

- reject unauthenticated calls;
- validate `can_access_branch(requested_branch_id)`;
- require a concrete branch for operational writes;
- derive sale item and refund branch IDs from their parent sale;
- confirm the active shift belongs to the same branch;
- set `search_path = ''`;
- qualify every table with `public.`;
- revoke execution from `PUBLIC` and `anon`;
- grant execution only to `authenticated`;
- require primary admin inside branch-management RPCs.

- [ ] **Step 7: Make checkout atomic and prevent overselling**

Inside `complete_sale`, lock and decrement stock with:

```sql
update public.branch_stock
   set quantity = quantity - requested_quantity,
       updated_at = now()
 where branch_id = requested_branch_id
   and product_id = requested_product_id
   and quantity >= requested_quantity
returning quantity;
```

If no row is returned, raise `INSUFFICIENT_BRANCH_STOCK`; do not clamp with `greatest(..., 0)`. The whole RPC must roll back on any item failure.

- [ ] **Step 8: Add query-shaped composite indexes**

Add:

```sql
create index if not exists idx_sales_branch_created
  on public.sales (branch_id, created_at desc);

create index if not exists idx_sales_branch_session
  on public.sales (branch_id, session_id);

create index if not exists idx_shifts_branch_open_time
  on public.shifts (branch_id, is_open, open_time desc);

create index if not exists idx_expenses_branch_created
  on public.expenses (branch_id, created_at desc);

create index if not exists idx_sale_items_branch_product
  on public.sale_items (branch_id, product_id);

create index if not exists idx_snapshots_branch_created
  on public.inventory_snapshots (branch_id, created_at desc);
```

Keep the existing unique `(branch_id, product_id)` index on `branch_stock`; do not add redundant indexes.

- [ ] **Step 9: Add secure statistics and cloud-count RPCs**

`get_branch_statistics` must:

- require a primary administrator for `branch_id_input is null`;
- otherwise validate `can_access_branch(branch_id_input)`;
- use one SQL statement/CTE set to aggregate sales, refunds, expenses, shifts, users, and branch stock;
- use the same inclusive-start/exclusive-end date convention everywhere;
- return zeros rather than null numeric values.

`get_branch_recent_activity` must union only safe, user-facing fields from sales, refunds, expenses, shifts, and inventory snapshots, order by timestamp descending, and enforce a maximum limit of 100.

`get_cloud_table_counts` must return allow-listed business table counts. For branch-owned tables it filters by the requested branch; for shared tables it returns global counts. It must never expose `auth.users`, storage internals, migration tables, secrets, or unrestricted dynamic SQL.

Apply the same authentication, branch validation, fixed search path, and execution grants as the other hardened RPCs.

- [ ] **Step 10: Review the migration locally**

Run only commands supported by the installed CLI. Preferred flow:

```powershell
supabase db reset
supabase migration list --local
```

Expected: every migration applies from an empty local database and the generated migration appears exactly once.

- [ ] **Step 11: Inspect query plans**

Run representative `EXPLAIN (ANALYZE, BUFFERS)` queries for:

- sales by branch/date;
- shifts by branch/open status;
- expenses by branch/date;
- stock by branch/product;
- all-branch stock aggregation.
- branch statistics over the selected date range;
- cloud table count summary.

Expected: indexes are used for branch/date and branch/status filters at realistic row counts.

- [ ] **Step 12: Run advisors before applying remotely**

Fetch Supabase security and performance advisors. Resolve new warnings caused by the migration. Apply DDL to the connected project only after review and explicit implementation authorization.

---

### Task 8: Optimize Loading, Pagination, and Aggregate Views

**Files:**

- Modify repositories, cubits, and screens listed in Tasks 5 and 6.

**Interfaces:**

- Consumes: branch-aware server queries.
- Produces: bounded queries, cached shared data, and cancellation-safe UI updates.

- [ ] **Step 1: Keep shared data cached across branch changes**

Do not reload categories, units, store settings, or static permission definitions when the branch changes. Reload only branch stock and branch-owned entities.

- [ ] **Step 2: Move filtering and pagination to Supabase**

Replace “load everything then filter in Dart” paths. In particular:

- product pagination must use `.range(offset, offset + pageSize - 1)`;
- invoices must request a bounded page rather than `limit: 10000`;
- analytics must aggregate server-side;
- branch list counts must use one grouped query/RPC;
- searches must escape/validate PostgREST filter input.

- [ ] **Step 3: Preserve prior data during refresh**

Show a thin progress indicator or skeleton overlay while keeping previous content visible. Clear content only when the selected branch has no data or the request fails definitively.

- [ ] **Step 4: Add branch labels to aggregate rows**

In all-branch lists for invoices, expenses, shifts, inventory history, and notifications, return and display `branch_id` plus branch name. Do not force users to infer the source branch.

- [ ] **Step 5: Avoid duplicate work**

Each branch selection revision may trigger at most:

- one product/stock request group;
- one invoice request;
- one analytics request group;
- one shift request;
- one expense request when that screen is active.

Use the coordinator and request-version guards to enforce this.

- [ ] **Step 6: Verify performance behavior**

Use Flutter DevTools/network logging to confirm request counts while:

1. opening the selector without changing scope;
2. selecting a branch;
3. reopening the selected branch;
4. switching rapidly;
5. navigating through every feature.

Expected: steps 1 and 3 issue no branch-data refresh; stale requests do not update the UI.

---

### Task 8A: Rebuild Cloud Data Management for Every Business Table

**Files:**

- Create: `lib/features/settings/data/models/cloud_table_definition.dart`
- Create: `lib/features/settings/data/repositories/cloud_data_repository.dart`
- Create: `lib/features/settings/presentation/widgets/cloud_table_inspector.dart`
- Modify: `lib/features/settings/presentation/screens/data_management_screen.dart`
- Modify: `lib/features/settings/presentation/widgets/data_management_card.dart`
- Modify: `lib/core/di/dependency_injection.dart`
- Modify: `lib/l10n/app_en.arb`
- Modify: `lib/l10n/app_ar.arb`

**Interfaces:**

- Consumes: the current `BranchScope`, an allow-listed table key, page/search/sort settings, and the authenticated user’s data-management permission.
- Produces:
  - `List<CloudTableDefinition> cloudBusinessTables`
  - `Future<List<CloudTableSummary>> CloudDataRepository.getSummaries(BranchScope scope)`
  - `Future<CloudTablePage> CloudDataRepository.getRows({required CloudTableDefinition table, required BranchScope scope, required int page, required int pageSize, String search = ''})`

- [ ] **Step 1: Replace raw table names with a safe registry**

Register all application business tables:

```text
branches
branch_stock
products
categories
product_units
users
user_permission_overrides
shifts
sales
sale_items
expenses
inventory_snapshots
inventory_snapshot_items
store_settings
```

Each `CloudTableDefinition` declares:

- stable table key;
- localized label key;
- icon and color token;
- whether the table is global or branch-owned;
- branch column, or parent relation used to derive branch ownership;
- safe select columns;
- searchable columns;
- default sort column and direction;
- user-facing primary/secondary display columns.

Do not accept a table name from arbitrary text or URL input.

- [ ] **Step 2: Exclude sensitive and internal fields**

Never return or render:

- `pin_hash`;
- auth identities, password data, tokens, or session internals;
- storage object metadata not needed by the business UI;
- service keys or environment configuration;
- unrestricted permission payloads for users without primary-admin authorization.

For users, allow only safe profile fields such as ID, username, display name, role, active status, assigned branch, and timestamps.

- [ ] **Step 3: Show all table summaries**

Replace the five sequential count requests with `get_cloud_table_counts`. Display all registry tables in grouped sections:

- Organization: branches, users, permissions, store settings;
- Catalog: products, categories, units, branch stock;
- Operations: shifts, sales, sale items, expenses;
- Inventory: snapshots and snapshot items.

Each card shows row count, scope badge (“Shared”, selected branch, or “All branches”), last updated time when meaningful, and a clear inspect action.

- [ ] **Step 4: Make the whole screen branch-aware**

Add the standard `BranchScopeBanner` beneath the connection header.

- In single-branch mode, branch-owned table counts and rows show only that branch.
- In all-branches mode, branch-owned counts and rows include all authorized branches and display branch name per row.
- Shared tables always show company-wide data and carry a “Shared” badge.
- Non-primary users cannot escape their assigned branch through this screen.

- [ ] **Step 5: Implement server-side pagination and search**

Use 25 rows per page by default, with options for 25, 50, and 100. Apply `.range`, safe search filters, and server sorting before fetching.

Do not fetch 50 rows and search only the in-memory subset. Debounce search by 300ms and discard stale responses using a request version.

- [ ] **Step 6: Handle parent-scoped tables**

For `sale_items` and `inventory_snapshot_items`, branch ownership may be validated through the parent sale/snapshot even if a direct branch field is unavailable. Use safe joins or dedicated RPCs; never show child rows that RLS would hide through their parent.

- [ ] **Step 7: Build a professional responsive inspector**

Desktop:

- summary grid above;
- table inspector in a wide content panel;
- sticky column headers;
- horizontal scrolling for additional safe fields;
- sortable columns and pagination footer.

Mobile/tablet:

- summary cards;
- selected table opens in a draggable bottom sheet;
- rows render as expandable cards;
- filters and pagination stay reachable above the safe area.

Use formatted dates, currency, booleans/status chips, branch names, and friendly empty/error states instead of raw map dumps.

- [ ] **Step 8: Keep the screen read-only initially**

The cloud table browser is inspection-only. Do not add arbitrary row editing, deletion, SQL execution, table truncation, or schema controls. Existing domain screens remain the only supported mutation paths.

This prevents bypassing validation, audit behavior, branch guards, and transactional RPCs.

- [ ] **Step 9: Enforce permission and audit access**

Call `PermissionGuard.checkDataManagement` before navigating. Require primary administrator for aggregate cross-branch inspection and sensitive organizational summaries.

Log table inspection metadata locally without row contents:

```text
table key
scope mode
branch ID when selected
page
search-used boolean
timestamp
```

- [ ] **Step 10: Remove broken hard-coded strings**

Replace all mojibake and hard-coded bilingual strings in `data_management_screen.dart` with ARB localization keys, including table names, group headings, scope badges, pagination, search, connection state, errors, and empty states.

- [ ] **Step 11: Verify every table**

For every registered table:

1. open it in Branch A, Branch B, and All branches;
2. confirm counts match the inspected rows’ authorized scope;
3. confirm pagination reaches rows beyond the first page;
4. confirm search runs on the server;
5. confirm branch names appear in aggregate mode;
6. confirm no sensitive field is present in network payloads or rendered UI;
7. confirm regular users cannot inspect another branch.

Run:

```powershell
dart format lib/features/settings/data lib/features/settings/presentation/screens/data_management_screen.dart lib/features/settings/presentation/widgets/cloud_table_inspector.dart
flutter analyze
flutter build windows --debug
```

---

### Task 9: End-to-End Verification Without New Test Files

**Files:**

- Modify: only files requiring fixes discovered during verification.
- Do not create: any test files.

**Interfaces:**

- Consumes: completed Flutter and Supabase changes.
- Produces: evidence that branch isolation, aggregate views, security, localization, and performance meet the approved design.

- [ ] **Step 1: Format only touched Dart files**

Run `dart format` with the explicit list of touched paths. Do not format the entire dirty repository.

- [ ] **Step 2: Run static and build verification**

Run:

```powershell
flutter analyze
flutter build windows --release
flutter build web --release
```

Expected: no new analyzer errors and both builds complete successfully.

- [ ] **Step 3: Verify the complete feature matrix**

With Branch A and Branch B containing intentionally different data:

1. select Branch A and record every dashboard/list total;
2. select Branch B and confirm no Branch A operational row appears;
3. select All branches and confirm aggregates equal A + B;
4. confirm aggregate lists show branch names;
5. attempt every branch-owned write in All mode and confirm it is blocked locally;
6. confirm shared catalog and store identity remain consistent.

- [ ] **Step 4: Verify authorization with real roles**

Check:

- primary admin: all/single selection and branch management;
- branch admin/manager: assigned branch only;
- cashier/employee: assigned branch only and permission-limited;
- user with missing branch: blocked configuration state, never all-branch access.

- [ ] **Step 5: Verify database enforcement**

Using authenticated sessions for a primary admin and a branch user, run safe rollback-wrapped checks proving:

- a branch user cannot read another branch;
- a branch user cannot insert/update another branch;
- client-supplied foreign `branch_id` is rejected by RPCs;
- all-branch access works only for primary admin;
- a refund inherits the original sale branch;
- insufficient stock rolls back the complete sale.

- [ ] **Step 6: Re-run Supabase advisors**

Fetch security and performance advisors and include remediation links for any remaining notices. Do not claim schema completion with unresolved critical findings.

- [ ] **Step 7: Final regression pass**

Verify login, PIN login, open/close shift, POS checkout, refund, product edit, stock adjustment, inventory count, expense creation, invoice search, dashboard, analytics date filters, user management, branch CRUD, language toggle, RTL layout, and logout.

- [ ] **Step 8: Review the final diff**

Run:

```powershell
git status --short
git diff --check
git diff --stat
git diff -- lib supabase/migrations docs/superpowers/plans
```

Expected: no whitespace errors, no secrets, no generated build output, no test files, and no unrelated user changes overwritten.

---

## Completion Criteria

- Mobile branch selector is a polished bottom sheet.
- Desktop branch selector is a polished direction-aware side drawer.
- Branch management forms use the same responsive surface rule.
- Clicking a branch opens complete date-filtered statistics, stock health, workforce data, and recent activity.
- Clicking the aggregate branch entry opens the same statistics for all active branches.
- Every branch-owned feature follows the matrix in Task 6.
- All-branch mode is correctly aggregated and read-only.
- Cloud Data Management safely displays every allow-listed business table with branch-aware counts, server pagination, and no secret fields.
- Shared catalog/configuration does not reload unnecessarily.
- Rapid selection cannot show stale data.
- Supabase RLS and RPCs enforce branch access independently of the client.
- Branch/date/status queries use appropriate composite indexes.
- Existing Flutter checks and release builds pass without adding test files.
- Security and performance advisor results are reviewed and reported.
