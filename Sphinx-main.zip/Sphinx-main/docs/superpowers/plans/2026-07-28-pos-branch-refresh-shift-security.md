# POS Branch Refresh and Shift Security Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make branch selection authoritative for POS, expenses, stock summary, analytics, recent sales, Cloud Data Management, and shift visibility/closing.

**Architecture:** Keep `BranchCubit` as the single branch-scope source. Page-owned cubits refresh from local branch listeners, repositories apply the current scope at query time, and Supabase functions enforce mutation authorization independently of the client.

**Tech Stack:** Flutter, flutter_bloc, Dart, Supabase Flutter/PostgREST, PostgreSQL RLS and PL/pgSQL.

## Global Constraints

- Do not create test files.
- POS requires one concrete branch and remains locked for **All branches**.
- Read-only reporting may aggregate all authorized branches.
- Cashiers can close and view only their own shifts.
- Managers and branch administrators operate only within their assigned branch.
- The primary administrator may manage all branches.

---

### Task 1: Fix Cloud Data nested branch counts

**Files:**
- Modify: `lib/features/settings/data/models/cloud_table_definition.dart`
- Modify: `lib/features/settings/data/repositories/cloud_data_repository.dart`

**Interfaces:**
- Consumes: `CloudTableDefinition.branchFilterPath`
- Produces: `CloudTableDefinition.countSelectColumns` and branch-consistent table counts

- [ ] **Step 1: Reproduce the failing query**

Run the existing Cloud Data count path for `inventory_snapshot_items` with a
single branch and confirm PostgREST returns `PGRST108`.

- [ ] **Step 2: Add an explicit count projection**

Add an optional `countSelectColumns` to `CloudTableDefinition`, defaulting to
`id`. Configure inventory snapshot items with:

```dart
countSelectColumns: 'id,inventory_snapshots!inner(branch_id)',
```

- [ ] **Step 3: Use the count projection**

Change `_count` to select `table.countSelectColumns`, then apply the existing
scope predicate before `.count(CountOption.exact)`.

- [ ] **Step 4: Verify**

Query counts for both a single branch and all branches. Confirm no `PGRST108`
and that the selected-branch count is not greater than the all-branch count.

### Task 2: Enforce a single branch throughout POS

**Files:**
- Modify: `lib/features/pos/presentation/pos_screen.dart`
- Modify: `lib/features/pos/presentation/cubit/pos_cubit.dart`
- Modify: `lib/features/shifts/data/repositories/shift_repository_impl.dart`
- Modify: `lib/features/dashboard/presentation/dashboard_screen.dart`

**Interfaces:**
- Consumes: `BranchCubit.state.scope`, `BranchState.selectionRevision`
- Produces: `PosCubit.reloadForBranchSelection()` and a branch-required POS lock

- [ ] **Step 1: Define the POS branch gate**

Treat `!scope.isSingleBranch` as locked. Do not open the shift dialog, submit
barcodes, or complete checkout while locked.

- [ ] **Step 2: Render the locked state**

Show a full POS overlay in Arabic/English explaining that a single branch must
be selected. The overlay has no “open shift” action while scope is all or
uninitialized.

- [ ] **Step 3: Refresh branch-dependent state**

On `selectionRevision` changes, clear the cart and stale recent sales, reload
recent sales, then reload `ShiftCubit`. `getActiveShift` must include the
selected branch ID and return no active shift when there is no single branch.

- [ ] **Step 4: Verify**

Check these transitions:

```text
All branches -> POS locked, no shift inherited
Sphinx1 -> only Sphinx1 active shift and recent sales
Sphinx2 -> only Sphinx2 active shift and recent sales
Sphinx2 -> All branches -> POS locked and stale branch data cleared
```

### Task 3: Refresh page-owned reporting data

**Files:**
- Modify: `lib/features/stock_summary/presentation/screens/stock_summary_screen.dart`
- Modify: `lib/features/stock_summary/presentation/cubit/stock_summary_cubit.dart`
- Modify: `lib/features/analytics/presentation/screens/analytics_screen.dart`
- Modify: `lib/features/analytics/presentation/cubit/analytics_cubit.dart`
- Modify: `lib/features/expenses/presentation/expenses_screen.dart`
- Modify: `lib/features/shifts/presentation/screens/shifts_screen.dart`
- Modify: `lib/features/dashboard/presentation/dashboard_screen.dart`

**Interfaces:**
- Consumes: `BranchState.selectionRevision`
- Produces: page-local reloads that replace stale branch data

- [ ] **Step 1: Add local branch listeners**

Each page that owns its cubit listens to `BranchCubit`. On a revision change,
invoke that page cubit's reload method using its existing filter/date state.

- [ ] **Step 2: Clear stale state before fetch**

Ensure Stock Summary, Analytics, Expenses, Shifts, and recent sales display
loading/empty state while the new branch loads instead of retaining previous
branch values.

- [ ] **Step 3: Remove invalid global cubit lookups**

Remove dashboard calls to cubits that are created inside page `BlocProvider`s.
Keep singleton refresh calls only for singleton cubits.

- [ ] **Step 4: Verify**

Switch Sphinx1 → Sphinx2 → All branches on each page and compare displayed
counts with direct database branch counts.

### Task 4: Restore secured expense creation

**Files:**
- Create: `supabase/migrations/20260728105955_secure_expense_and_shift_access.sql`
- Modify: `lib/features/expenses/data/expense_repository.dart`

**Interfaces:**
- Consumes: `record_expense(expense_input jsonb)`
- Produces: one inserted `public.expenses` row

- [ ] **Step 1: Generate the migration**

Run:

```powershell
supabase migration new secure_expense_and_shift_access
```

- [ ] **Step 2: Implement `record_expense`**

Create a `SECURITY DEFINER SET search_path = ''` function that validates
authentication, branch access, matching shift branch, and cashier shift
ownership before inserting the whitelisted fields.

- [ ] **Step 3: Restrict execution**

```sql
revoke all on function public.record_expense(jsonb) from public, anon;
grant execute on function public.record_expense(jsonb) to authenticated;
```

- [ ] **Step 4: Apply and verify transactionally**

Verify an own-branch expense succeeds, an all-branch/NULL branch fails, a
cross-branch expense fails, and all verification rows are rolled back.

### Task 5: Secure shift visibility and closing

**Files:**
- Modify: `supabase/migrations/20260728105955_secure_expense_and_shift_access.sql`
- Modify: `lib/core/security/role_permissions.dart`
- Modify: `lib/features/shifts/presentation/screens/shifts_screen.dart`
- Modify: `lib/features/shifts/presentation/widgets/shift_detail_drawer.dart`

**Interfaces:**
- Produces: `Permission.closeOwnShift`
- Produces: secured `close_shift(uuid, numeric)`

- [ ] **Step 1: Add the close permission**

Grant `closeOwnShift` to cashier, manager, and admin roles. Use ownership and
branch checks to decide which shift close action is visible.

- [ ] **Step 2: Scope cashier shift reads**

Update shifts SELECT policy so cashiers can read only rows whose
`user_id = auth.uid()`. Managers/admins remain branch-scoped, and primary admin
remains global.

- [ ] **Step 3: Authorize `close_shift`**

Before calculating totals, reject callers unless:

```text
primary admin
OR shift.user_id = auth.uid()
OR caller is manager/admin and caller.branch_id = shift.branch_id
```

Retain the existing atomic totals and close update.

- [ ] **Step 4: Apply and verify transactionally**

Assert cashier own-shift close succeeds, cashier other-shift close fails,
manager same-branch close succeeds, and manager cross-branch close fails.
Rollback all temporary changes.

### Task 6: Final verification

**Files:**
- Modify only files required by Tasks 1–5.

- [ ] **Step 1: Format**

Run Dart formatting on the modified Dart files only.

- [ ] **Step 2: Analyze**

Run focused `dart analyze` on modified feature directories. Expected: no errors
or warnings introduced by this implementation.

- [ ] **Step 3: Check repository integrity**

Run:

```powershell
git diff --check
git status --short
```

- [ ] **Step 4: Confirm constraints**

Confirm no test files were created, Cloud Data is still debug-only, global
store settings remain unfiltered, and unrelated dirty files were preserved.
