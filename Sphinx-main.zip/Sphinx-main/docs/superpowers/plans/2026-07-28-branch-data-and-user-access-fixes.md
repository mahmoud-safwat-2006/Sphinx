# Branch Data and User Access Fixes Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fix branch-filtered Cloud Data, analytics, and invoice loading, preserve global settings, and enforce secure single-branch user assignment.

**Architecture:** `BranchCubit` remains the single client-side source of branch scope. Global repositories ignore branch scope; branch-owned repositories read the effective branch at query time. Supabase RLS and guarded RPCs enforce the same user-management boundary independently of the UI.

**Tech Stack:** Flutter/Dart, flutter_bloc, supabase_flutter/PostgREST, PostgreSQL RLS and PL/pgSQL.

## Global Constraints

- Do not add test files.
- Cloud Data Management remains debug-only.
- Store information, products, categories, product units, and global configuration remain unfiltered.
- Every non-primary user belongs to exactly one active branch.
- Only the primary admin can move users between branches.
- Branch admins and managers may manage eligible non-primary users only within their own branch.

---

### Task 1: Repair Cloud Data query composition

**Files:**
- Modify: `lib/features/settings/data/repositories/cloud_data_repository.dart`

**Interfaces:**
- Consumes: `CloudTableDefinition`, `BranchScope`
- Produces: `getSummaries(BranchScope)` and `getRows(...)` without applying modifiers to `ResponsePostgrestBuilder`

- [ ] Build row queries as select → scope/search filters → order/range → count.
- [ ] Build count queries as select → scope filters → count, without `limit`.
- [ ] Preserve unfiltered behavior for definitions without `branchFilterPath`.
- [ ] Run targeted Dart analysis.

### Task 2: Correct local-day analytics boundaries and branch refresh

**Files:**
- Modify: `lib/features/analytics/data/analytics_repository_impl.dart`
- Modify: `lib/features/analytics/presentation/cubit/analytics_cubit.dart`

**Interfaces:**
- Consumes: local `DateTime` values selected in the UI
- Produces: UTC ISO-8601 timestamps for Supabase comparisons

- [ ] Add one private timestamp encoder:

```dart
String _databaseTimestamp(DateTime value) =>
    value.toUtc().toIso8601String();
```

- [ ] Use the encoder for all analytics `created_at`, `open_time`, and `close_time` filters.
- [ ] Add `reloadForBranchSelection()` to retain the current date/session filter.
- [ ] Use that method from the dashboard branch listener.
- [ ] Run targeted Dart analysis.

### Task 3: Make invoices branch-reactive and surface failures

**Files:**
- Modify: `lib/features/invoice/presentation/cubit/invoice_cubit.dart`
- Modify: `lib/features/invoice/presentation/cubit/invoice_state.dart`
- Modify: `lib/features/pos/data/repository/pos_repository_impl.dart`

**Interfaces:**
- Consumes: `StateSynchronizer` events with `entityType == 'branch_scope'`
- Produces: one invoice reload for each branch selection and a visible load error

- [ ] Subscribe `InvoiceCubit` to both sale and branch-scope events.
- [ ] Replace `getOrElse(() => [])` failure swallowing with a shared loader that emits the repository failure.
- [ ] Keep filter/search/date state while reloading.
- [ ] Convert invoice timestamp filters to UTC.
- [ ] Scope destructive invoice operations to the effective branch.
- [ ] Run targeted Dart analysis.

### Task 4: Complete user branch assignment UI and async flow

**Files:**
- Modify: `lib/features/settings/presentation/widgets/add_edit_user_dialog.dart`
- Modify: `lib/features/settings/presentation/widgets/users_management_card.dart`
- Modify: `lib/features/auth/presentation/cubit/user_cubit.dart`
- Modify: `lib/features/auth/data/repository/user_repository_imp.dart`
- Modify: `lib/features/auth/data/models/user_model.dart`
- Modify: localization ARB/generated localization files as required

**Interfaces:**
- Consumes: active branches from `BranchCubit`
- Produces: required `User.branchId` for non-primary users

- [ ] Add a branch selector to add/edit user.
- [ ] Allow the primary admin to choose any active branch.
- [ ] Lock branch admins/managers to their own branch.
- [ ] Preserve the branch ID in `User` construction and editing.
- [ ] Make `saveUser` and `updateUser` return `Future<bool>` and await completion before closing.
- [ ] Display the assigned branch on user cards/table rows.
- [ ] Prevent mutation controls when the current user lacks the approved scope.
- [ ] Run targeted Dart analysis.

### Task 5: Enforce user-management authorization in Supabase

**Files:**
- Create: `supabase/migrations/<generated>_secure_user_branch_management.sql`

**Interfaces:**
- Consumes: authenticated caller identity, caller role, caller branch, target user and target branch
- Produces: guarded user mutation RPCs and matching users/permission-overrides RLS policies

- [ ] Generate the migration filename with the Supabase CLI.
- [ ] Add helper authorization functions with fixed `search_path`.
- [ ] Require active branch assignment for non-primary users.
- [ ] Prevent creating or promoting primary admins through client RPCs.
- [ ] Permit primary-admin cross-branch management.
- [ ] Permit branch admin/manager same-branch management only.
- [ ] Replace broad user and permission-override policies with scoped policies.
- [ ] Revoke public/anon execution and grant only authenticated callers.
- [ ] Validate the migration inside a transaction and roll it back.
- [ ] Apply the validated migration and verify live policies/functions.

### Task 6: Verify requirements and diagnostics

**Files:**
- Modify only files needed to correct verification failures.

**Interfaces:**
- Consumes: all changes from Tasks 1–5
- Produces: evidence-backed completion report

- [ ] Confirm global tables have no branch filter.
- [ ] Confirm Sphinx1's Cairo-local July 28 sale is included by UTC boundaries.
- [ ] Confirm Sphinx2 returns an intentional empty invoice/analytics result.
- [ ] Confirm user creation requires a branch and manager transfer is rejected.
- [ ] Run `dart analyze lib`.
- [ ] Run `git diff --check` on changed source, migration, and docs.
- [ ] Review the final diff for unrelated changes and do not stage them.
